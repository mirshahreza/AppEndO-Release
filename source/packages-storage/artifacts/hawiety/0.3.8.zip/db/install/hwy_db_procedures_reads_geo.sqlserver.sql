SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_nodes_count
  @legacy_kind NVARCHAR(64),
  @search_like NVARCHAR(256) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  SELECT COUNT(*) AS total
    FROM dbo.hwy_etl_geo_map gm
    INNER JOIN dbo.base_info b ON b.id = gm.base_info_id
    WHERE gm.legacy_kind = @legacy_kind
      AND (
        @search_like IS NULL
        OR b.title_en LIKE @search_like
        OR b.title_ar LIKE @search_like
        OR b.title_path_ar LIKE @search_like
        OR CAST(gm.legacy_id AS NVARCHAR(32)) LIKE @search_like
        OR dbo.hwy_base_info_iq_title_path(gm.base_info_id) LIKE @search_like
      );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_nodes_list
  @legacy_kind NVARCHAR(64),
  @geo_level NVARCHAR(32),
  @role_name NVARCHAR(128),
  @search_like NVARCHAR(256) = NULL,
  @offset INT,
  @page_size INT
AS
BEGIN
  SET NOCOUNT ON;
  SELECT
      gm.base_info_id AS geoBaseInfoId,
      gm.legacy_id AS legacyGeoId,
      dbo.hwy_geo_leaf_title(gm.base_info_id) AS title,
      dbo.hwy_geo_leaf_title(parent.id) AS parentTitle,
      COALESCE(
        NULLIF(LTRIM(RTRIM(dbo.hwy_base_info_iq_title_path(gm.base_info_id))), N''),
        NULLIF(LTRIM(RTRIM(b.title_path_ar)), N''),
        NULLIF(LTRIM(RTRIM(b.title_path_en)), N'')
      ) AS titlePath,
      maleAsnDisplay.displayName AS maleAssigneeDisplayName,
      maleAsnDisplay.username AS maleAssigneeUsername,
      maleAsnDisplay.avatarUrl AS maleAssigneeAvatarUrl,
      maleAsnDisplay.electoralDivisionPath AS maleAssigneeElectoralDivisionPath,
      maleAsnDisplay.memberId AS maleAssigneeMemberId,
      maleAsnDisplay.userId AS maleAssigneeUserId,
      maleAsnDisplay.hasProfileImage AS maleAssigneeHasProfileImage,
      malePendingDisplay.displayName AS malePendingDisplayName,
      malePendingDisplay.username AS malePendingUsername,
      malePendingDisplay.avatarUrl AS malePendingAvatarUrl,
      malePendingDisplay.electoralDivisionPath AS malePendingElectoralDivisionPath,
      malePendingDisplay.memberId AS malePendingMemberId,
      malePendingDisplay.userId AS malePendingUserId,
      malePendingDisplay.hasProfileImage AS malePendingHasProfileImage,
      malePending.requestId AS malePendingRequestId,
      maleAssigneeRemovalPending.requestId AS maleAssigneePendingRemovalRequestId,
      femaleAsnDisplay.displayName AS femaleAssigneeDisplayName,
      femaleAsnDisplay.username AS femaleAssigneeUsername,
      femaleAsnDisplay.avatarUrl AS femaleAssigneeAvatarUrl,
      femaleAsnDisplay.electoralDivisionPath AS femaleAssigneeElectoralDivisionPath,
      femaleAsnDisplay.memberId AS femaleAssigneeMemberId,
      femaleAsnDisplay.userId AS femaleAssigneeUserId,
      femaleAsnDisplay.hasProfileImage AS femaleAssigneeHasProfileImage,
      femalePendingDisplay.displayName AS femalePendingDisplayName,
      femalePendingDisplay.username AS femalePendingUsername,
      femalePendingDisplay.avatarUrl AS femalePendingAvatarUrl,
      femalePendingDisplay.electoralDivisionPath AS femalePendingElectoralDivisionPath,
      femalePendingDisplay.memberId AS femalePendingMemberId,
      femalePendingDisplay.userId AS femalePendingUserId,
      femalePendingDisplay.hasProfileImage AS femalePendingHasProfileImage,
      femalePending.requestId AS femalePendingRequestId,
      femaleAssigneeRemovalPending.requestId AS femaleAssigneePendingRemovalRequestId
    FROM dbo.hwy_etl_geo_map gm
    INNER JOIN dbo.base_info b ON b.id = gm.base_info_id
    LEFT JOIN dbo.base_info parent ON parent.id = b.parent_id
    OUTER APPLY (
      SELECT TOP 1 r.member_id, r.user_id
      FROM dbo.hwy_geo_responsibility_requests r
      INNER JOIN dbo.hwy_members rm ON rm.id = r.member_id
      WHERE r.geo_base_info_id = gm.base_info_id
        AND r.role_name = @role_name
        AND r.geo_level = @geo_level
        AND r.status = N'approved'
        AND r.revoked_at IS NULL
        AND r.request_kind = N'nomination'
        AND dbo.hwy_geo_member_is_male(rm.gender_code) = 1
      ORDER BY COALESCE(r.decided_at, r.nominated_at) DESC
    ) maleOfficialReq
    OUTER APPLY (
      SELECT TOP 1
        vm.id AS memberId,
        vm.user_id AS userId,
        vm.has_profile_image AS hasProfileImage,
        COALESCE(NULLIF(vm.display_full_name, N''), vm.username) AS displayName,
        vm.username AS username,
        vm.avatar_url AS avatarUrl,
        vm.electoral_division_path AS electoralDivisionPath
      FROM dbo.vw_hwy_members vm
      WHERE vm.id = maleOfficialReq.member_id
    ) maleAsnDisplay
    OUTER APPLY (
      SELECT TOP 1 r.member_id, CAST(r.id AS NVARCHAR(36)) AS requestId
      FROM dbo.hwy_geo_responsibility_requests r
      INNER JOIN dbo.hwy_members rm ON rm.id = r.member_id
      WHERE r.geo_base_info_id = gm.base_info_id
        AND r.role_name = @role_name
        AND r.geo_level = @geo_level
        AND r.status = N'submitted'
        AND r.request_kind = N'nomination'
        AND dbo.hwy_geo_member_is_male(rm.gender_code) = 1
        AND (
          maleOfficialReq.member_id IS NULL
          OR r.member_id <> maleOfficialReq.member_id
        )
      ORDER BY r.nominated_at DESC
    ) malePending
    OUTER APPLY (
      SELECT TOP 1
        vm.id AS memberId,
        vm.user_id AS userId,
        vm.has_profile_image AS hasProfileImage,
        COALESCE(NULLIF(vm.display_full_name, N''), vm.username) AS displayName,
        vm.username AS username,
        vm.avatar_url AS avatarUrl,
        vm.electoral_division_path AS electoralDivisionPath
      FROM dbo.vw_hwy_members vm
      WHERE vm.id = malePending.member_id
    ) malePendingDisplay
    OUTER APPLY (
      SELECT TOP 1 CAST(r.id AS NVARCHAR(36)) AS requestId
      FROM dbo.hwy_geo_responsibility_requests r
      WHERE r.geo_base_info_id = gm.base_info_id
        AND r.role_name = @role_name
        AND r.geo_level = @geo_level
        AND r.status = N'submitted'
        AND r.request_kind = N'official_removal'
        AND r.member_id = maleOfficialReq.member_id
        AND maleOfficialReq.member_id IS NOT NULL
      ORDER BY r.nominated_at DESC
    ) maleAssigneeRemovalPending
    OUTER APPLY (
      SELECT TOP 1 r.member_id, r.user_id
      FROM dbo.hwy_geo_responsibility_requests r
      INNER JOIN dbo.hwy_members rm ON rm.id = r.member_id
      WHERE r.geo_base_info_id = gm.base_info_id
        AND r.role_name = @role_name
        AND r.geo_level = @geo_level
        AND r.status = N'approved'
        AND r.revoked_at IS NULL
        AND r.request_kind = N'nomination'
        AND dbo.hwy_geo_member_is_female(rm.gender_code) = 1
      ORDER BY COALESCE(r.decided_at, r.nominated_at) DESC
    ) femaleOfficialReq
    OUTER APPLY (
      SELECT TOP 1
        vm.id AS memberId,
        vm.user_id AS userId,
        vm.has_profile_image AS hasProfileImage,
        COALESCE(NULLIF(vm.display_full_name, N''), vm.username) AS displayName,
        vm.username AS username,
        vm.avatar_url AS avatarUrl,
        vm.electoral_division_path AS electoralDivisionPath
      FROM dbo.vw_hwy_members vm
      WHERE vm.id = femaleOfficialReq.member_id
    ) femaleAsnDisplay
    OUTER APPLY (
      SELECT TOP 1 r.member_id, CAST(r.id AS NVARCHAR(36)) AS requestId
      FROM dbo.hwy_geo_responsibility_requests r
      INNER JOIN dbo.hwy_members rm ON rm.id = r.member_id
      WHERE r.geo_base_info_id = gm.base_info_id
        AND r.role_name = @role_name
        AND r.geo_level = @geo_level
        AND r.status = N'submitted'
        AND r.request_kind = N'nomination'
        AND dbo.hwy_geo_member_is_female(rm.gender_code) = 1
        AND (
          femaleOfficialReq.member_id IS NULL
          OR r.member_id <> femaleOfficialReq.member_id
        )
      ORDER BY r.nominated_at DESC
    ) femalePending
    OUTER APPLY (
      SELECT TOP 1
        vm.id AS memberId,
        vm.user_id AS userId,
        vm.has_profile_image AS hasProfileImage,
        COALESCE(NULLIF(vm.display_full_name, N''), vm.username) AS displayName,
        vm.username AS username,
        vm.avatar_url AS avatarUrl,
        vm.electoral_division_path AS electoralDivisionPath
      FROM dbo.vw_hwy_members vm
      WHERE vm.id = femalePending.member_id
    ) femalePendingDisplay
    OUTER APPLY (
      SELECT TOP 1 CAST(r.id AS NVARCHAR(36)) AS requestId
      FROM dbo.hwy_geo_responsibility_requests r
      WHERE r.geo_base_info_id = gm.base_info_id
        AND r.role_name = @role_name
        AND r.geo_level = @geo_level
        AND r.status = N'submitted'
        AND r.request_kind = N'official_removal'
        AND r.member_id = femaleOfficialReq.member_id
        AND femaleOfficialReq.member_id IS NOT NULL
      ORDER BY r.nominated_at DESC
    ) femaleAssigneeRemovalPending
    WHERE gm.legacy_kind = @legacy_kind
      AND (
        @search_like IS NULL
        OR b.title_en LIKE @search_like
        OR b.title_ar LIKE @search_like
        OR b.title_path_ar LIKE @search_like
        OR CAST(gm.legacy_id AS NVARCHAR(32)) LIKE @search_like
        OR dbo.hwy_base_info_iq_title_path(gm.base_info_id) LIKE @search_like
      )
    ORDER BY gm.legacy_id ASC
    OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_requests_count
  @status NVARCHAR(32),
  @geo_level NVARCHAR(32) = NULL,
  @official_removal_only BIT = 0
AS
BEGIN
  SET NOCOUNT ON;

  SELECT COUNT(*) AS total
  FROM dbo.hwy_geo_responsibility_requests r
  WHERE r.status = @status
    AND (@geo_level IS NULL OR r.geo_level = @geo_level)
    AND (
      @official_removal_only = 0
      OR r.request_kind = N'official_removal'
    );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_requests_list
  @status NVARCHAR(32),
  @geo_level NVARCHAR(32) = NULL,
  @official_removal_only BIT = 0,
  @offset INT,
  @page_size INT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(r.id AS NVARCHAR(36)) AS id,
    r.status,
    r.request_kind,
    r.geo_level,
    r.geo_base_info_id,
    dbo.hwy_geo_leaf_title(r.geo_base_info_id) AS geoTitle,
    NULLIF(LTRIM(RTRIM(dbo.hwy_base_info_iq_title_path(r.geo_base_info_id))), N'') AS geoTitlePath,
    CAST(r.member_id AS VARCHAR(32)) AS member_id,
    COALESCE(NULLIF(vm.display_full_name, N''), vm.username) AS memberDisplayName,
    vm.username AS memberUsername,
    NULLIF(LTRIM(RTRIM(vm.phone1)), N'') AS memberPhone,
    vm.avatar_url AS memberAvatarUrl,
    vm.user_id AS memberUserId,
    vm.has_profile_image AS memberHasProfileImage,
    vm.gender_code AS memberGenderCode,
    r.role_name,
    r.nominated_at,
    COALESCE(NULLIF(CONCAT(np.firstname, N' ', np.lastname), N' '), nu.username) AS nominatedByDisplayName,
    nu.username AS nominatedByUsername,
    r.decision_note
  FROM dbo.hwy_geo_responsibility_requests r
  INNER JOIN dbo.vw_hwy_members vm ON vm.id = r.member_id
  LEFT JOIN dbo.base_users nu ON nu.id = r.nominated_by
  LEFT JOIN dbo.base_user_profiles np ON np.user_id = nu.id
  WHERE r.status = @status
    AND (@geo_level IS NULL OR r.geo_level = @geo_level)
    AND (
      @official_removal_only = 0
      OR r.request_kind = N'official_removal'
    )
  ORDER BY r.nominated_at DESC
  OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_montadhemin_count
  @active_membership_code NVARCHAR(128),
  @search_like NVARCHAR(256) = NULL
AS
BEGIN
  SET NOCOUNT ON;

  SELECT COUNT(*) AS total
  FROM dbo.vw_hwy_members vm WITH (NOLOCK)
  WHERE vm.membership_status_code = @active_membership_code
    AND (
      @search_like IS NULL
      OR vm.username LIKE @search_like
      OR vm.display_full_name LIKE @search_like
    );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_montadhemin_list
  @active_membership_code NVARCHAR(128),
  @geo_role_names_csv NVARCHAR(4000),
  @search_like NVARCHAR(256) = NULL,
  @offset INT,
  @page_size INT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(vm.id AS VARCHAR(32)) AS id,
    vm.username,
    vm.display_full_name AS displayFullName,
    vm.gender_code AS genderCode,
    vm.avatar_url AS avatarUrl,
    CAST(vm.user_id AS VARCHAR(32)) AS userId,
    vm.has_profile_image AS hasProfileImage,
    vm.electoral_division_path AS electoralDivisionPath,
    CAST(dbo.hwy_member_passed_necessary_dorat(vm.id) AS BIT) AS passedNecessaryDorat,
    clearance.can_get_title AS canGetResponsibilityTitle,
    clearance.can_get_note AS canGetResponsibilityNote,
    clearance.allows_title AS allowsResponsibilityTitle,
    activeResp.role_name AS activeResponsibilityRole,
    activeResp.geo_title_path AS activeResponsibilityGeoTitlePath
  FROM dbo.vw_hwy_members vm WITH (NOLOCK)
  OUTER APPLY (
    SELECT TOP 1
      COALESCE(NULLIF(bi.title_ar, N''), bi.title_en) AS can_get_title,
      NULLIF(LTRIM(RTRIM(sp.can_get_responsibility_note)), N'') AS can_get_note,
      COALESCE(NULLIF(biAllows.title_ar, N''), biAllows.title_en) AS allows_title
    FROM dbo.hwy_member_security_profile sp WITH (NOLOCK)
    LEFT JOIN dbo.base_info bi ON bi.id = sp.can_get_responsibility_code
    LEFT JOIN dbo.base_info biAllows ON biAllows.id = sp.allows_responsibility_code
    WHERE sp.member_id = vm.id
    ORDER BY sp.created_at DESC
  ) clearance
  OUTER APPLY (
    SELECT TOP 1
      a.role_name,
      dbo.hwy_base_info_iq_title_path(a.geo_base_info_id) AS geo_title_path
    FROM dbo.hwy_geo_responsibility_requests a WITH (NOLOCK)
    WHERE a.member_id = vm.id
      AND a.status = N'approved'
      AND a.revoked_at IS NULL
      AND a.request_kind = N'nomination'
      AND a.role_name IN (SELECT LTRIM(RTRIM(value)) FROM STRING_SPLIT(@geo_role_names_csv, N','))
    ORDER BY COALESCE(a.decided_at, a.nominated_at) DESC
  ) activeResp
  WHERE vm.membership_status_code = @active_membership_code
    AND (
      @search_like IS NULL
      OR vm.username LIKE @search_like
      OR vm.display_full_name LIKE @search_like
    )
  ORDER BY vm.display_full_name ASC, vm.username ASC
  OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_geo_leaf_title
  @geo_base_info_id NVARCHAR(128)
AS
BEGIN
  SET NOCOUNT ON;

  SELECT dbo.hwy_geo_leaf_title(@geo_base_info_id) AS title;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_member_lookup
  @username NVARCHAR(128)
AS
BEGIN
  SET NOCOUNT ON;

  SELECT TOP 1
    CAST(m.id AS VARCHAR(32)) AS id,
    CAST(m.user_id AS VARCHAR(32)) AS user_id,
    m.username,
    m.first_name,
    m.father_name,
    m.grandfather_name,
    m.family_name,
    m.gender_code,
    sp.can_get_responsibility_code
  FROM dbo.hwy_members m
  OUTER APPLY (
    SELECT TOP 1 can_get_responsibility_code
    FROM dbo.hwy_member_security_profile sp
    WHERE sp.member_id = m.id
    ORDER BY sp.id DESC
  ) sp
  WHERE m.username = @username;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_electoral_options
  @kind NVARCHAR(32),
  @parent_id NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    gm.base_info_id AS geoBaseInfoId,
    gm.legacy_id AS legacyGeoId,
    dbo.hwy_geo_leaf_title(gm.base_info_id) AS title
  FROM dbo.hwy_etl_geo_map gm
  INNER JOIN dbo.base_info b ON b.id = gm.base_info_id
  WHERE gm.legacy_kind = @kind
    AND (@kind = N'province' OR b.parent_id = @parent_id)
  ORDER BY b.title_ar ASC, b.title_en ASC, gm.legacy_id ASC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_electoral_selection
  @start_id NVARCHAR(128)
AS
BEGIN
  SET NOCOUNT ON;

  WITH chain AS (
    SELECT CAST(b.id AS NVARCHAR(128)) AS id, CAST(b.parent_id AS NVARCHAR(128)) AS parent_id
    FROM dbo.base_info b
    WHERE b.id = @start_id
    UNION ALL
    SELECT CAST(b.id AS NVARCHAR(128)), CAST(b.parent_id AS NVARCHAR(128))
    FROM dbo.base_info b
    INNER JOIN chain c ON b.id = c.parent_id
  )
  SELECT c.id, gm.legacy_kind
  FROM chain c
  LEFT JOIN dbo.hwy_etl_geo_map gm ON gm.base_info_id = c.id
  WHERE gm.legacy_kind IN (N'province', N'ghavateh', N'circle', N'maktab', N'region');
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_province_has_ghavateh
  @province_id NVARCHAR(128)
AS
BEGIN
  SET NOCOUNT ON;

  SELECT TOP 1 CAST(1 AS bit) AS has_ghavateh
  FROM dbo.hwy_etl_geo_map gm
  INNER JOIN dbo.base_info b ON b.id = gm.base_info_id
  WHERE gm.legacy_kind = N'ghavateh'
    AND b.parent_id = @province_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_nomination_province_scope
  @start_id NVARCHAR(128),
  @geo_level NVARCHAR(32)
AS
BEGIN
  SET NOCOUNT ON;

  IF @geo_level = N'province'
  BEGIN
    SELECT @start_id AS province_id;
    RETURN;
  END;

  WITH chain AS (
    SELECT CAST(b.id AS NVARCHAR(128)) AS id, CAST(b.parent_id AS NVARCHAR(128)) AS parent_id
    FROM dbo.base_info b
    WHERE b.id = @start_id
    UNION ALL
    SELECT CAST(b.id AS NVARCHAR(128)), CAST(b.parent_id AS NVARCHAR(128))
    FROM dbo.base_info b
    INNER JOIN chain c ON b.id = c.parent_id
  )
  SELECT TOP 1 c.id AS province_id
  FROM chain c
  INNER JOIN dbo.hwy_etl_geo_map gm ON gm.base_info_id = c.id
  WHERE gm.legacy_kind = N'province';
END;
GO
