-- Pipeline / card-flow / legacy-view support columns on dbo.hwy_members (snake_case physical storage).

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NULL
BEGIN
  PRINT 'hwy_member_pipeline_snake_columns skipped — dbo.hwy_members missing';
END
ELSE
BEGIN
  IF COL_LENGTH(N'dbo.hwy_members', N'gender_legacy_id') IS NULL
    ALTER TABLE dbo.hwy_members ADD gender_legacy_id INT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'gender_id') IS NULL
    ALTER TABLE dbo.hwy_members ADD gender_id INT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'device_os_type_legacy_id') IS NULL
    ALTER TABLE dbo.hwy_members ADD device_os_type_legacy_id INT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'membership_status_legacy') IS NULL
    ALTER TABLE dbo.hwy_members ADD membership_status_legacy INT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'nakheb_join_province_id') IS NULL
    ALTER TABLE dbo.hwy_members ADD nakheb_join_province_id BIGINT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'nakheb_join_circle_id') IS NULL
    ALTER TABLE dbo.hwy_members ADD nakheb_join_circle_id BIGINT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'nakheb_join_tamvin_id') IS NULL
    ALTER TABLE dbo.hwy_members ADD nakheb_join_tamvin_id BIGINT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'nakheb_join_eghtera_id') IS NULL
    ALTER TABLE dbo.hwy_members ADD nakheb_join_eghtera_id BIGINT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'area_limit_id') IS NULL
    ALTER TABLE dbo.hwy_members ADD area_limit_id BIGINT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'area_limit_province_id') IS NULL
    ALTER TABLE dbo.hwy_members ADD area_limit_province_id BIGINT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'area_limit_circle_id') IS NULL
    ALTER TABLE dbo.hwy_members ADD area_limit_circle_id BIGINT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'area_limit_tamvin_id') IS NULL
    ALTER TABLE dbo.hwy_members ADD area_limit_tamvin_id BIGINT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'education_level_legacy_id') IS NULL
    ALTER TABLE dbo.hwy_members ADD education_level_legacy_id BIGINT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'card_flow_last_status_id') IS NULL
    ALTER TABLE dbo.hwy_members ADD card_flow_last_status_id BIGINT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'card_flow_visibility') IS NULL
    ALTER TABLE dbo.hwy_members ADD card_flow_visibility BIT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'card_flow_started_by') IS NULL
    ALTER TABLE dbo.hwy_members ADD card_flow_started_by NVARCHAR(256) NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'card_flow_started_on') IS NULL
    ALTER TABLE dbo.hwy_members ADD card_flow_started_on DATETIME2 NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'picture_file_name') IS NULL
    ALTER TABLE dbo.hwy_members ADD picture_file_name NVARCHAR(512) NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'picture_file_size') IS NULL
    ALTER TABLE dbo.hwy_members ADD picture_file_size BIGINT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'picture_file_mime') IS NULL
    ALTER TABLE dbo.hwy_members ADD picture_file_mime NVARCHAR(128) NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'picture_file_body') IS NULL
    ALTER TABLE dbo.hwy_members ADD picture_file_body VARBINARY(MAX) NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'picture_file_body_xs') IS NULL
    ALTER TABLE dbo.hwy_members ADD picture_file_body_xs VARBINARY(MAX) NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'national_card_front_file_body') IS NULL
    ALTER TABLE dbo.hwy_members ADD national_card_front_file_body VARBINARY(MAX) NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'national_card_behind_file_body') IS NULL
    ALTER TABLE dbo.hwy_members ADD national_card_behind_file_body VARBINARY(MAX) NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'nakheb_card_front_file_body') IS NULL
    ALTER TABLE dbo.hwy_members ADD nakheb_card_front_file_body VARBINARY(MAX) NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'maskan_card_front_file_body') IS NULL
    ALTER TABLE dbo.hwy_members ADD maskan_card_front_file_body VARBINARY(MAX) NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'nakheb_card_front_approved') IS NULL
    ALTER TABLE dbo.hwy_members ADD nakheb_card_front_approved BIT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'national_card_front_approved') IS NULL
    ALTER TABLE dbo.hwy_members ADD national_card_front_approved BIT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'national_card_behind_approved') IS NULL
    ALTER TABLE dbo.hwy_members ADD national_card_behind_approved BIT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'picture_approved') IS NULL
    ALTER TABLE dbo.hwy_members ADD picture_approved BIT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'maskan_card_front_approved') IS NULL
    ALTER TABLE dbo.hwy_members ADD maskan_card_front_approved BIT NULL;

  PRINT 'hwy member pipeline snake columns ensured';
END
GO
