-- ImageFix editor parity: NakhebCard_Front_Check / NakhebCard_Front_TypeId
-- Legacy Pictures_Reviewed is not ported (no ImageFix/Todo usage); drop if a dev DB added it.
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF COL_LENGTH(N'dbo.hwy_members', N'pictures_reviewed') IS NOT NULL
BEGIN
  DECLARE @dfPicturesReviewed NVARCHAR(256);
  SELECT @dfPicturesReviewed = dc.name
  FROM sys.default_constraints dc
  INNER JOIN sys.columns c
    ON c.default_object_id = dc.object_id
  WHERE dc.parent_object_id = OBJECT_ID(N'dbo.hwy_members')
    AND c.name = N'pictures_reviewed';
  IF @dfPicturesReviewed IS NOT NULL
    EXEC(N'ALTER TABLE dbo.hwy_members DROP CONSTRAINT ' + QUOTENAME(@dfPicturesReviewed));
  ALTER TABLE dbo.hwy_members DROP COLUMN pictures_reviewed;
END
GO

IF COL_LENGTH(N'dbo.hwy_members', N'nakheb_card_front_check') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_members ADD nakheb_card_front_check BIT NOT NULL
    CONSTRAINT DF_hwy_members_nakheb_card_front_check DEFAULT (0);
END
GO

IF COL_LENGTH(N'dbo.hwy_members', N'nakheb_card_front_type_code') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_members ADD nakheb_card_front_type_code NVARCHAR(1000) NULL;
END
GO

PRINT 'hwy_member_imagefix_editor_columns ready';
GO
