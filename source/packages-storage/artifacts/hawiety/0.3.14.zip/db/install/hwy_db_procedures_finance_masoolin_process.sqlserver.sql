-- Masoolin payable batch (no hwy_masoolin_stars tables required).
-- Full stars procs: hwy_db_procedures_finance_masoolin.sqlserver.sql

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NOT NULL
   AND COL_LENGTH(N'dbo.hwy_members', N'chief_masool') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_members ADD chief_masool BIT NULL;
END;
GO

-- HWY_SP_Masoolin_SetAsMainPayable → hwy_masoolin_set_as_main_payable
CREATE OR ALTER PROCEDURE dbo.hwy_masoolin_set_as_main_payable 
	@member_id INT
AS
BEGIN

DECLARE @SameRoghe TABLE
(
	id INT,user_name NVARCHAR(64),first_name NVARCHAR(64),father_name NVARCHAR(64),grand_father_name NVARCHAR(64),last_name NVARCHAR(64),phone1 VARCHAR(64),payable BIT,approved_on DATETIME
)

	DECLARE @MID BIGINT;
	DECLARE @AreaId INT = (SELECT TOP 1 item_id FROM hwy_member_area_limits WHERE member_id=@member_id);

	INSERT INTO @SameRoghe
	SELECT * FROM [dbo].[HWY_UFN_SameRogheMembers] (@member_id);

	DECLARE MasoolinCUR CURSOR
		FOR SELECT id FROM @SameRoghe
	OPEN MasoolinCUR
	FETCH NEXT FROM MasoolinCUR INTO @MID

	WHILE @@FETCH_STATUS = 0
	BEGIN

		IF(@member_id=@MID) UPDATE hwy_members SET chief_masool=1 WHERE id=@MID;
		ELSE UPDATE hwy_members SET chief_masool=0 WHERE id=@MID;
		
		FETCH NEXT FROM MasoolinCUR INTO @MID

	END
	CLOSE MasoolinCUR;
	DEALLOCATE MasoolinCUR;

	IF(LEN(@AreaId)=4) EXEC DBO.HWY_SP_H_Tamvinat_UpdateFlags @AreaId;
	IF(LEN(@AreaId)=6) EXEC DBO.HWY_SP_H_Eghteraat_UpdateFlags @AreaId;
	IF(LEN(@AreaId)=7) EXEC DBO.HWY_SP_H_Circles_UpdateFlags @AreaId;

END
GO

-- HWY_SP_Masoolin_Performance_Process → hwy_masoolin_performance_process
CREATE OR ALTER PROCEDURE dbo.hwy_masoolin_performance_process
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #Tmp
    (
        member_id BIGINT, role_name NVARCHAR(200), gender_id INT, user_name NVARCHAR(200),
        first_name NVARCHAR(200), father_name NVARCHAR(200), grand_father_name NVARCHAR(200),
        last_name NVARCHAR(200), phone1 NVARCHAR(50), SameRagbatCount INT,

        area_limit_province_id INT, area_limit_circle_id INT, AreaLimitTanzimId INT,
        AreaLimitProvinceTitle NVARCHAR(200), AreaLimitCircleTitle NVARCHAR(200),
        AreaLimitTanzimTitle NVARCHAR(200), AreaLimitCenterName NVARCHAR(200),

        payable DECIMAL(18,2), HasRemoveRequest BIT, AreaLimitCenterName2 NVARCHAR(200),

        D1Y INT, D1M INT, D2Y INT, D2M INT, D3Y INT, D3M INT,

        PM1_PayAmount DECIMAL(18,2), PM2_PayAmount DECIMAL(18,2), PM3_PayAmount DECIMAL(18,2),

        S1_LevelId INT, B1LevelId_Title NVARCHAR(200), S1_StarsSum INT,
        S2_LevelId INT, B2LevelId_Title NVARCHAR(200), S2_StarsSum INT,
        S3_LevelId INT, B3LevelId_Title NVARCHAR(200), S3_StarsSum INT,

        DaysInRole INT
    );

    CREATE TABLE #Result
    (
        ResultType NVARCHAR(20),

        member_id BIGINT, role_name NVARCHAR(200), gender_id INT, user_name NVARCHAR(200),
        first_name NVARCHAR(200), father_name NVARCHAR(200), grand_father_name NVARCHAR(200),
        last_name NVARCHAR(200), phone1 NVARCHAR(50), SameRagbatCount INT,

        area_limit_province_id INT, area_limit_circle_id INT, AreaLimitTanzimId INT,
        AreaLimitProvinceTitle NVARCHAR(200), AreaLimitCircleTitle NVARCHAR(200),
        AreaLimitTanzimTitle NVARCHAR(200), AreaLimitCenterName NVARCHAR(200),

        payable DECIMAL(18,2), HasRemoveRequest BIT, AreaLimitCenterName2 NVARCHAR(200),

        D1Y INT, D1M INT, D2Y INT, D2M INT, D3Y INT, D3M INT,

        PM1_PayAmount DECIMAL(18,2), PM2_PayAmount DECIMAL(18,2), PM3_PayAmount DECIMAL(18,2),

        S1_LevelId INT, B1LevelId_Title NVARCHAR(200), S1_StarsSum INT,
        S2_LevelId INT, B2LevelId_Title NVARCHAR(200), S2_StarsSum INT,
        S3_LevelId INT, B3LevelId_Title NVARCHAR(200), S3_StarsSum INT,

        DaysInRole INT
    );

    CREATE TABLE #SameRoghe
    (
        id BIGINT, user_name NVARCHAR(200), first_name NVARCHAR(200), father_name NVARCHAR(200),
        grand_father_name NVARCHAR(200), last_name NVARCHAR(200), phone1 NVARCHAR(50),
        payable DECIMAL(18,2), approved_on DATETIME
    );

    TRUNCATE TABLE #Tmp;

    INSERT INTO #Tmp EXEC [dbo].[hwy_masoolin_performance_list] 1000000,1,'',0,0,0,0,0,0,0,'MoneyAmount','','','','Zero';
    INSERT INTO #Result SELECT 'Zero', * FROM #Tmp;

    TRUNCATE TABLE #Tmp;

    INSERT INTO #Tmp EXEC [dbo].[hwy_masoolin_performance_list] 1000000,1,'',0,0,0,0,0,0,0,'MoneyAmount','','','','MoreThanOne';
    INSERT INTO #Result SELECT 'MoreThanOne', * FROM #Tmp;

    DECLARE @TotalCount INT = (SELECT COUNT(*) FROM #Result);

    PRINT (@TotalCount);

    DECLARE @ResultType NVARCHAR(20),@member_id BIGINT,@first_name NVARCHAR(200),@last_name NVARCHAR(200),@phone1 NVARCHAR(50),@MainId BIGINT;

    DECLARE cur CURSOR FAST_FORWARD FOR
    SELECT ResultType, member_id, first_name, last_name, phone1 FROM #Result;

    OPEN cur;

    FETCH NEXT FROM cur INTO @ResultType, @member_id, @first_name, @last_name, @phone1;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        TRUNCATE TABLE #SameRoghe;
        INSERT INTO #SameRoghe SELECT * FROM dbo.HWY_UFN_SameRogheMembers(@member_id);

        SELECT TOP 1 @MainId = id FROM #SameRoghe ORDER BY approved_on ASC;

        PRINT @MainId;

        IF @MainId IS NOT NULL
        BEGIN

            IF @ResultType = 'Zero'
            BEGIN
                PRINT CONCAT('ZERO => ', @member_id, ' | ', @first_name, ' ', @last_name);
                EXEC dbo.hwy_masoolin_set_as_main_payable @MainId;
            END
            ELSE
            BEGIN
                PRINT CONCAT('MORE THAN ONE => ', @member_id, ' | ', @first_name, ' ', @last_name);
                EXEC dbo.hwy_masoolin_set_as_main_payable @MainId;
            END

        END

        FETCH NEXT FROM cur INTO @ResultType, @member_id, @first_name, @last_name, @phone1;
    END

    CLOSE cur;
    DEALLOCATE cur;

    DROP TABLE #Tmp;
    DROP TABLE #Result;
    DROP TABLE #SameRoghe;
END
GO
