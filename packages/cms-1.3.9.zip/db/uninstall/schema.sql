-- CMS package Phase 1 uninstall (SQL Server)
-- Drops domain tables only. Base Info CMS root/subtree is removed by the seed rollback helper.

IF OBJECT_ID(N'dbo.cms_settings', N'U') IS NOT NULL DROP TABLE dbo.cms_settings;
IF OBJECT_ID(N'dbo.cms_content_relations', N'U') IS NOT NULL DROP TABLE dbo.cms_content_relations;
IF OBJECT_ID(N'dbo.cms_content_tags', N'U') IS NOT NULL DROP TABLE dbo.cms_content_tags;
IF OBJECT_ID(N'dbo.cms_content_assets', N'U') IS NOT NULL DROP TABLE dbo.cms_content_assets;
IF OBJECT_ID(N'dbo.cms_content_revisions', N'U') IS NOT NULL DROP TABLE dbo.cms_content_revisions;
IF OBJECT_ID(N'dbo.cms_contents', N'U') IS NOT NULL DROP TABLE dbo.cms_contents;

-- Removes exactly the 43 row(s) captured from base_info
DELETE FROM [base_info] WHERE [id] IN (N'101', N'101.001', N'101.002', N'101.003', N'101.004', N'101.005', N'101.006', N'101.001.001', N'101.001.002', N'101.001.003', N'101.001.004', N'101.001.005', N'101.001.006', N'101.001.007', N'101.001.008', N'101.002.001', N'101.002.002', N'101.002.003', N'101.002.004', N'101.002.005', N'101.003.001', N'101.003.002', N'101.003.003', N'101.004.001', N'101.004.002', N'101.004.003', N'101.005.001', N'101.005.002', N'101.005.003', N'101.005.004', N'101.005.005', N'101.005.006', N'101.005.007', N'101.005.008', N'101.005.009', N'101.005.010', N'101.005.011', N'101.005.012', N'101.005.013', N'101.005.014', N'101.005.015', N'101.006.001', N'101.006.002');
