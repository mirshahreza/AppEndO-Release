SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_activities_admin_count
  @status_code NVARCHAR(32) = NULL,
  @exclude_central_type BIT = 0,
  @central_type_only BIT = 0,
  @central_type_code NVARCHAR(32) = N'213915',
  @search_like NVARCHAR(256) = NULL,
  @activity_subtype_code NVARCHAR(64) = NULL,
  @id_filter NVARCHAR(32) = NULL,
  @title_like NVARCHAR(256) = NULL,
  @date_from DATE = NULL,
  @date_to DATE = NULL,
  @participant_username_like NVARCHAR(128) = NULL,
  @device_os_id_like NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;

  SELECT COUNT(*) AS total
  FROM dbo.hwy_activities a
  WHERE 1 = 1
    AND (@status_code IS NULL OR a.status_code = @status_code)
    AND (@exclude_central_type = 0 OR a.activity_type_code IS NULL OR a.activity_type_code <> @central_type_code)
    AND (@central_type_only = 0 OR a.activity_type_code = @central_type_code)
    AND (@activity_subtype_code IS NULL OR a.activity_subtype_code = @activity_subtype_code)
    AND (@id_filter IS NULL OR CAST(a.id AS NVARCHAR(32)) = @id_filter)
    AND (@title_like IS NULL OR a.title LIKE @title_like)
    AND (@date_from IS NULL OR a.activity_date >= @date_from)
    AND (@date_to IS NULL OR a.activity_date <= @date_to)
    AND (
      @search_like IS NULL
      OR CAST(a.id AS NVARCHAR(32)) LIKE @search_like
      OR a.title LIKE @search_like
      OR a.legacy_created_by LIKE @search_like
    )
    AND (
      @participant_username_like IS NULL
      OR EXISTS (
        SELECT 1
        FROM dbo.hwy_activity_attendances att WITH (NOLOCK)
        INNER JOIN dbo.vw_hwy_members m WITH (NOLOCK) ON m.id= att.member_id
        WHERE att.activity_id = a.id
          AND m.username LIKE @participant_username_like
      )
    )
    AND (
      @device_os_id_like IS NULL
      OR EXISTS (
        SELECT 1
        FROM dbo.hwy_activity_attendances att WITH (NOLOCK)
        WHERE att.activity_id = a.id
          AND (
            att.nb_device_id LIKE @device_os_id_like
            OR att.nb_device_os LIKE @device_os_id_like
          )
      )
    );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_activities_admin_list
  @status_code NVARCHAR(32) = NULL,
  @exclude_central_type BIT = 0,
  @central_type_only BIT = 0,
  @central_type_code NVARCHAR(32) = N'213915',
  @search_like NVARCHAR(256) = NULL,
  @activity_subtype_code NVARCHAR(64) = NULL,
  @id_filter NVARCHAR(32) = NULL,
  @title_like NVARCHAR(256) = NULL,
  @date_from DATE = NULL,
  @date_to DATE = NULL,
  @participant_username_like NVARCHAR(128) = NULL,
  @device_os_id_like NVARCHAR(128) = NULL,
  @offset INT,
  @page_size INT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    a.id,
    a.title,
    a.note,
    a.activity_date,
    a.activity_type_code,
    a.activity_subtype_code,
    a.status_code,
    a.status_note,
    a.nashat_location,
    a.legacy_province_id,
    a.legacy_created_by,
    a.legacy_updated_by,
    a.created_at,
    a.updated_at,
    (SELECT COUNT(*) FROM dbo.hwy_activity_attendances att WHERE att.activity_id = a.id) AS member_count,
    (SELECT COUNT(*) FROM dbo.hwy_activity_files f WHERE f.activity_id = a.id) AS file_count
  FROM dbo.hwy_activities a
  WHERE 1 = 1
    AND (@status_code IS NULL OR a.status_code = @status_code)
    AND (@exclude_central_type = 0 OR a.activity_type_code IS NULL OR a.activity_type_code <> @central_type_code)
    AND (@central_type_only = 0 OR a.activity_type_code = @central_type_code)
    AND (@activity_subtype_code IS NULL OR a.activity_subtype_code = @activity_subtype_code)
    AND (@id_filter IS NULL OR CAST(a.id AS NVARCHAR(32)) = @id_filter)
    AND (@title_like IS NULL OR a.title LIKE @title_like)
    AND (@date_from IS NULL OR a.activity_date >= @date_from)
    AND (@date_to IS NULL OR a.activity_date <= @date_to)
    AND (
      @search_like IS NULL
      OR CAST(a.id AS NVARCHAR(32)) LIKE @search_like
      OR a.title LIKE @search_like
      OR a.legacy_created_by LIKE @search_like
    )
    AND (
      @participant_username_like IS NULL
      OR EXISTS (
        SELECT 1
        FROM dbo.hwy_activity_attendances att WITH (NOLOCK)
        INNER JOIN dbo.vw_hwy_members m WITH (NOLOCK) ON m.id= att.member_id
        WHERE att.activity_id = a.id
          AND m.username LIKE @participant_username_like
      )
    )
    AND (
      @device_os_id_like IS NULL
      OR EXISTS (
        SELECT 1
        FROM dbo.hwy_activity_attendances att WITH (NOLOCK)
        WHERE att.activity_id = a.id
          AND (
            att.nb_device_id LIKE @device_os_id_like
            OR att.nb_device_os LIKE @device_os_id_like
          )
      )
    )
  ORDER BY
    CASE WHEN @central_type_only = 1 THEN a.status_code ELSE NULL END ASC,
    CASE WHEN @central_type_only = 1 THEN a.created_at ELSE a.activity_date END DESC,
    a.id DESC
  OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_courses_admin_count
  @draft_status NVARCHAR(32) = NULL,
  @review_status_csv NVARCHAR(256) = NULL,
  @search_like NVARCHAR(256) = NULL,
  @id_filter NVARCHAR(32) = NULL,
  @note_like NVARCHAR(256) = NULL,
  @date_from DATE = NULL,
  @date_to DATE = NULL,
  @participant_username_like NVARCHAR(128) = NULL,
  @trainer_username_like NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;

  SELECT COUNT(*) AS total
  FROM dbo.hwy_courses c
  LEFT JOIN dbo.vw_hwy_members trainer ON trainer.id= c.trainer_member_id
  WHERE 1 = 1
    AND (@draft_status IS NULL OR c.status_code = @draft_status)
    AND (
      @review_status_csv IS NULL
      OR c.status_code IN (SELECT LTRIM(RTRIM(value)) FROM STRING_SPLIT(@review_status_csv, N','))
    )
    AND (@id_filter IS NULL OR CAST(c.id AS NVARCHAR(32)) = @id_filter)
    AND (@note_like IS NULL OR c.note LIKE @note_like)
    AND (@date_from IS NULL OR c.course_date >= @date_from)
    AND (@date_to IS NULL OR c.course_date <= @date_to)
    AND (
      @participant_username_like IS NULL
      OR EXISTS (
        SELECT 1
        FROM dbo.hwy_course_attendances att WITH (NOLOCK)
        INNER JOIN dbo.vw_hwy_members m WITH (NOLOCK) ON m.id= att.member_id
        WHERE att.course_id = c.id
          AND m.username LIKE @participant_username_like
      )
    )
    AND (
      @trainer_username_like IS NULL
      OR trainer.username LIKE @trainer_username_like
    )
    AND (
      @search_like IS NULL
      OR CAST(c.id AS NVARCHAR(32)) LIKE @search_like
      OR c.note LIKE @search_like
      OR c.legacy_created_by LIKE @search_like
      OR trainer.username LIKE @search_like
      OR trainer.display_full_name LIKE @search_like
    );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_courses_admin_list
  @draft_status NVARCHAR(32) = NULL,
  @review_status_csv NVARCHAR(256) = NULL,
  @search_like NVARCHAR(256) = NULL,
  @id_filter NVARCHAR(32) = NULL,
  @note_like NVARCHAR(256) = NULL,
  @date_from DATE = NULL,
  @date_to DATE = NULL,
  @participant_username_like NVARCHAR(128) = NULL,
  @trainer_username_like NVARCHAR(128) = NULL,
  @offset INT,
  @page_size INT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    c.id,
    c.course_date,
    c.course_type_code,
    c.course_subtype_code,
    c.status_code,
    c.note,
    c.trainer_member_id,
    trainer.display_full_name AS trainer_display_name,
    trainer.username AS trainer_username,
    trainer.avatar_url AS trainer_avatar_url,
    trainer.user_id AS trainer_user_id,
    trainer.gender_code AS trainer_gender_code,
    trainer.phone1 AS trainer_phone1,
    trainer.has_profile_image AS trainer_has_profile_image,
    c.legacy_created_by,
    c.created_at,
    (SELECT COUNT(*) FROM dbo.hwy_course_attendances att WHERE att.course_id = c.id) AS member_count
  FROM dbo.hwy_courses c
  LEFT JOIN dbo.vw_hwy_members trainer ON trainer.id= c.trainer_member_id
  WHERE 1 = 1
    AND (@draft_status IS NULL OR c.status_code = @draft_status)
    AND (
      @review_status_csv IS NULL
      OR c.status_code IN (SELECT LTRIM(RTRIM(value)) FROM STRING_SPLIT(@review_status_csv, N','))
    )
    AND (@id_filter IS NULL OR CAST(c.id AS NVARCHAR(32)) = @id_filter)
    AND (@note_like IS NULL OR c.note LIKE @note_like)
    AND (@date_from IS NULL OR c.course_date >= @date_from)
    AND (@date_to IS NULL OR c.course_date <= @date_to)
    AND (
      @participant_username_like IS NULL
      OR EXISTS (
        SELECT 1
        FROM dbo.hwy_course_attendances att WITH (NOLOCK)
        INNER JOIN dbo.vw_hwy_members m WITH (NOLOCK) ON m.id= att.member_id
        WHERE att.course_id = c.id
          AND m.username LIKE @participant_username_like
      )
    )
    AND (
      @trainer_username_like IS NULL
      OR trainer.username LIKE @trainer_username_like
    )
    AND (
      @search_like IS NULL
      OR CAST(c.id AS NVARCHAR(32)) LIKE @search_like
      OR c.note LIKE @search_like
      OR c.legacy_created_by LIKE @search_like
      OR trainer.username LIKE @search_like
      OR trainer.display_full_name LIKE @search_like
    )
  ORDER BY c.course_date DESC, c.id DESC
  OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_activity_admin_detail
  @activity_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    a.id,
    a.title,
    a.note,
    a.status_note,
    a.activity_date,
    a.activity_type_code,
    a.activity_subtype_code,
    a.status_code,
    a.nashat_location,
    a.legacy_province_id,
    a.legacy_region_province_id,
    a.legacy_region_circle_id,
    a.enable_self_announcement,
    a.require_submission_device_metadata,
    a.nb_location_lat,
    a.nb_location_lon,
    a.nb_max_distance_m,
    a.nb_window_start_at,
    a.nb_window_end_at,
    a.nb_legacy_province_id,
    a.nb_legacy_circle_id,
    a.nb_legacy_maktab_id,
    a.nb_legacy_region_id,
    a.nb_legacy_gender_id,
    a.nb_allowed_roles,
    a.nb_organization_ids,
    a.nb_only_kashafeh,
    a.nb_allow_gov,
    a.legacy_created_by,
    a.legacy_updated_by,
    vm_creator.id AS creator_member_id,
    vm_creator.display_full_name AS creator_display_name,
    vm_creator.username AS creator_username,
    vm_creator.avatar_url AS creator_avatar_url,
    vm_creator.user_id AS creator_user_id,
    vm_creator.gender_code AS creator_gender_code,
    vm_creator.phone1 AS creator_phone1,
    vm_creator.has_profile_image AS creator_has_profile_image,
    vm_updater.id AS updater_member_id,
    vm_updater.display_full_name AS updater_display_name,
    vm_updater.username AS updater_username,
    vm_updater.avatar_url AS updater_avatar_url,
    vm_updater.user_id AS updater_user_id,
    vm_updater.gender_code AS updater_gender_code,
    vm_updater.phone1 AS updater_phone1,
    vm_updater.has_profile_image AS updater_has_profile_image,
    a.created_at,
    a.updated_at,
    (SELECT COUNT(*) FROM dbo.hwy_activity_attendances att WHERE att.activity_id = a.id) AS member_count,
    (SELECT COUNT(*) FROM dbo.hwy_activity_files f WHERE f.activity_id = a.id) AS file_count,
    (SELECT COUNT(*) FROM dbo.hwy_activity_approval_steps s WHERE s.activity_id = a.id) AS approval_step_count
  FROM dbo.hwy_activities a
  LEFT JOIN dbo.vw_hwy_members vm_creator ON (
    vm_creator.id = TRY_CONVERT(BIGINT, NULLIF(LTRIM(RTRIM(a.legacy_created_by)), ''))
    OR vm_creator.username = LTRIM(RTRIM(a.legacy_created_by))
    OR vm_creator.user_id = TRY_CONVERT(BIGINT, NULLIF(LTRIM(RTRIM(a.legacy_created_by)), ''))
  )
  LEFT JOIN dbo.vw_hwy_members vm_updater ON (
    vm_updater.id = TRY_CONVERT(BIGINT, NULLIF(LTRIM(RTRIM(a.legacy_updated_by)), ''))
    OR vm_updater.username = LTRIM(RTRIM(a.legacy_updated_by))
    OR vm_updater.user_id = TRY_CONVERT(BIGINT, NULLIF(LTRIM(RTRIM(a.legacy_updated_by)), ''))
  )
  WHERE a.id = @activity_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_course_admin_detail
  @course_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    c.id,
    c.course_date,
    c.course_type_code,
    c.course_subtype_code,
    c.status_code,
    c.status_note,
    c.note,
    c.trainer_member_id,
    vm.display_full_name AS trainer_display_name,
    vm.username AS trainer_username,
    vm.avatar_url AS trainer_avatar_url,
    vm.user_id AS trainer_user_id,
    vm.gender_code AS trainer_gender_code,
    vm.phone1 AS trainer_phone1,
    vm.has_profile_image AS trainer_has_profile_image,
    vm_creator.id AS creator_member_id,
    vm_creator.display_full_name AS creator_display_name,
    vm_creator.username AS creator_username,
    vm_creator.avatar_url AS creator_avatar_url,
    vm_creator.user_id AS creator_user_id,
    vm_creator.gender_code AS creator_gender_code,
    vm_creator.phone1 AS creator_phone1,
    vm_creator.has_profile_image AS creator_has_profile_image,
    vm_updater.id AS updater_member_id,
    vm_updater.display_full_name AS updater_display_name,
    vm_updater.username AS updater_username,
    vm_updater.avatar_url AS updater_avatar_url,
    vm_updater.user_id AS updater_user_id,
    vm_updater.gender_code AS updater_gender_code,
    vm_updater.phone1 AS updater_phone1,
    vm_updater.has_profile_image AS updater_has_profile_image,
    c.legacy_province_id,
    c.legacy_created_by,
    c.legacy_updated_by,
    c.legacy_status_changed_by,
    c.status_changed_at,
    c.created_at,
    c.updated_at,
    (SELECT COUNT(*) FROM dbo.hwy_course_attendances att WHERE att.course_id = c.id) AS member_count,
    (SELECT COUNT(*) FROM dbo.hwy_course_approval_steps s WHERE s.course_id = c.id) AS approval_step_count
  FROM dbo.hwy_courses c
  LEFT JOIN dbo.vw_hwy_members vm ON vm.id= c.trainer_member_id
  LEFT JOIN dbo.vw_hwy_members vm_creator ON (
    vm_creator.id = TRY_CONVERT(BIGINT, NULLIF(LTRIM(RTRIM(c.legacy_created_by)), ''))
    OR vm_creator.username = LTRIM(RTRIM(c.legacy_created_by))
    OR vm_creator.user_id = TRY_CONVERT(BIGINT, NULLIF(LTRIM(RTRIM(c.legacy_created_by)), ''))
  )
  LEFT JOIN dbo.vw_hwy_members vm_updater ON (
    vm_updater.id = TRY_CONVERT(BIGINT, NULLIF(LTRIM(RTRIM(c.legacy_updated_by)), ''))
    OR vm_updater.username = LTRIM(RTRIM(c.legacy_updated_by))
    OR vm_updater.user_id = TRY_CONVERT(BIGINT, NULLIF(LTRIM(RTRIM(c.legacy_updated_by)), ''))
  )
  WHERE c.id = @course_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_activity_admin_attendances_list
  @activity_id BIGINT,
  @offset INT,
  @page_size INT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    att.id,
    att.member_id,
    m.display_full_name,
    m.username,
    m.avatar_url,
    m.user_id,
    m.gender_code,
    m.phone1,
    m.has_profile_image,
    m.electoral_division_path,
    att.rfid_batch,
    att.from_legacy_province_id,
    att.from_legacy_circle_id,
    att.nb_location_lat,
    att.nb_location_lon,
    att.selfie_file_name,
    att.selfie_mime,
    att.selfie_size_bytes,
    CASE WHEN att.selfie_content IS NOT NULL AND DATALENGTH(att.selfie_content) > 0 THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS has_selfie_content,
    att.nb_device_os,
    att.nb_device_id,
    att.nb_device_datetime,
    att.legacy_created_by,
    att.created_at
  FROM dbo.hwy_activity_attendances att
  INNER JOIN dbo.vw_hwy_members m ON m.id= att.member_id
  WHERE att.activity_id = @activity_id
  ORDER BY att.created_at DESC, att.id DESC
  OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_course_admin_attendances_list
  @course_id BIGINT,
  @offset INT,
  @page_size INT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    att.id,
    att.member_id,
    m.display_full_name,
    m.username,
    m.avatar_url,
    m.user_id,
    m.gender_code,
    m.phone1,
    m.has_profile_image,
    m.electoral_division_path,
    att.note,
    att.nb_location_lat,
    att.nb_location_lon,
    att.nb_device_os,
    att.nb_device_id,
    att.nb_device_datetime,
    att.legacy_created_by,
    att.legacy_updated_by,
    att.created_at,
    att.updated_at
  FROM dbo.hwy_course_attendances att
  INNER JOIN dbo.vw_hwy_members m ON m.id= att.member_id
  WHERE att.course_id = @course_id
  ORDER BY att.created_at DESC, att.id DESC
  OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_activity_admin_files_list
  @activity_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    id,
    original_file_name,
    mime,
    size_bytes,
    CASE WHEN content IS NOT NULL AND DATALENGTH(content) > 0 THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS has_content,
    created_at
  FROM dbo.hwy_activity_files
  WHERE activity_id = @activity_id
  ORDER BY created_at DESC, id DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_activity_admin_approval_steps_list
  @activity_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT id, status_code, note, legacy_created_by, created_at
  FROM dbo.hwy_activity_approval_steps
  WHERE activity_id = @activity_id
  ORDER BY created_at DESC, id DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_course_admin_approval_steps_list
  @course_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT id, status_code, note, legacy_created_by, created_at
  FROM dbo.hwy_course_approval_steps
  WHERE course_id = @course_id
  ORDER BY created_at DESC, id DESC;
END;
GO
