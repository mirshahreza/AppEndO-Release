-- Legacy parity: center candidate responsibility pipeline (stages security, interview, courses, install).

CREATE OR ALTER PROCEDURE dbo.hwy_legacy_operator_geo_scope
  @username NVARCHAR(128)
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @area_limit_id BIGINT = NULL;
  DECLARE @geo_limits_csv NVARCHAR(MAX) = NULL;

  IF NULLIF(LTRIM(RTRIM(@username)), N'') IS NOT NULL
  BEGIN
    SELECT TOP 1 @area_limit_id = m.area_limit_id
    FROM dbo.vw_hwy_platform_users u WITH (NOLOCK)
    INNER JOIN dbo.hwy_members m WITH (NOLOCK) ON m.user_id = u.id
    WHERE u.username = @username;

    SELECT @geo_limits_csv = STRING_AGG(CAST(v.geo_id AS NVARCHAR(32)), N',')
    FROM (
      SELECT DISTINCT al.item_id AS geo_id
      FROM dbo.vw_hwy_platform_users u WITH (NOLOCK)
      INNER JOIN dbo.hwy_members m WITH (NOLOCK) ON m.user_id = u.id
      INNER JOIN dbo.hwy_member_area_limits al WITH (NOLOCK) ON al.member_id = m.id AND al.approved = 1
      WHERE u.username = @username AND al.item_id IS NOT NULL
      UNION
      SELECT m.area_limit_province_id FROM dbo.vw_hwy_platform_users u WITH (NOLOCK) INNER JOIN dbo.hwy_members m ON m.user_id = u.id WHERE u.username = @username AND m.area_limit_province_id IS NOT NULL
      UNION
      SELECT m.area_limit_circle_id FROM dbo.vw_hwy_platform_users u WITH (NOLOCK) INNER JOIN dbo.hwy_members m ON m.user_id = u.id WHERE u.username = @username AND m.area_limit_circle_id IS NOT NULL
      UNION
      SELECT m.area_limit_tamvin_id FROM dbo.vw_hwy_platform_users u WITH (NOLOCK) INNER JOIN dbo.hwy_members m ON m.user_id = u.id WHERE u.username = @username AND m.area_limit_tamvin_id IS NOT NULL
      UNION
      SELECT m.nakheb_join_eghtera_id FROM dbo.vw_hwy_platform_users u WITH (NOLOCK) INNER JOIN dbo.hwy_members m ON m.user_id = u.id WHERE u.username = @username AND m.nakheb_join_eghtera_id IS NOT NULL
    ) v
    WHERE v.geo_id IS NOT NULL;
  END;

  SELECT @area_limit_id AS area_limit_id, @geo_limits_csv AS geo_limits_csv;
END;
GO

CREATE OR ALTER FUNCTION dbo.hwy_candidate_pipeline_where_clause(
  @stage NVARCHAR(32),
  @list_type NVARCHAR(64),
  @role_id NVARCHAR(32),
  @is_approved NVARCHAR(8),
  @approve_state NVARCHAR(8),
  @passed_or_not NVARCHAR(8),
  @interview_approve_state NVARCHAR(32),
  @scope_unrestricted BIT,
  @nakheb_province_id BIGINT,
  @nakheb_circle_id BIGINT,
  @nakheb_tamvin_id BIGINT,
  @date_start NVARCHAR(32),
  @date_end NVARCHAR(32),
  @username NVARCHAR(128),
  @phone NVARCHAR(64),
  @gender_id NVARCHAR(32),
  @alias NVARCHAR(8),
  @actor_user_name NVARCHAR(128) = NULL,
  @area_limit_id BIGINT = NULL,
  @geo_limits_csv NVARCHAR(MAX) = NULL,
  @member_name NVARCHAR(256) = NULL,
  @extra_search_csv NVARCHAR(512) = NULL,
  @extra_search_and_or NVARCHAR(8) = NULL
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
  DECLARE @w NVARCHAR(MAX) = N'';
  DECLARE @lt NVARCHAR(64) = NULLIF(LTRIM(RTRIM(@list_type)), N'');
  DECLARE @rid NVARCHAR(32) = NULLIF(LTRIM(RTRIM(@role_id)), N'');
  DECLARE @st NVARCHAR(32) = LOWER(LTRIM(RTRIM(@stage)));

  IF @st = N'security'
  BEGIN
    IF @lt IS NULL SET @lt = N'WaitForInitialVoteMembers';
    IF @lt = N'WaitForInitialVoteMembers'
      SET @w = @w + N' AND ((SELECT COUNT(*) FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.id)=0 OR (SELECT TOP 1 SP.can_get_masooliat FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.id ORDER BY SP.created_on DESC)=211753)';
    ELSE IF @lt = N'RejectedMembers'
      SET @w = @w + N' AND (SELECT TOP 1 SP.can_get_masooliat FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.id ORDER BY SP.created_on DESC)=211752';
    ELSE IF @lt = N'AcceptedMembers'
      SET @w = @w + N' AND (SELECT TOP 1 SP.can_get_masooliat FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.id ORDER BY SP.created_on DESC)=211751';
    ELSE IF @lt = N'' OR @lt = N'All'
      SET @w = @w + N'';
    IF NULLIF(LTRIM(RTRIM(@is_approved)), N'') IS NOT NULL AND @is_approved <> N'-1'
      SET @w = @w + N' AND ISNULL(' + @alias + N'.is_approved, 0)=' + @is_approved;
    IF @rid IS NOT NULL
      SET @w = @w + N' AND EXISTS (SELECT 1 FROM dbo.vw_hwy_platform_user_roles URR WITH (NOLOCK) WHERE URR.user_id=' + @alias + N'.user_id AND URR.role_id=' + @rid + N')';
  END
  ELSE IF @st = N'interview'
  BEGIN
    IF @lt IS NULL SET @lt = N'NotInterviewed';
    IF @lt = N'NotInterviewed'
      SET @w = @w + N' AND ' + @alias + N'.interview_on IS NULL';
    ELSE IF @lt = N'Interviewed'
      SET @w = @w + N' AND ' + @alias + N'.interview_on IS NOT NULL';
    DECLARE @ias NVARCHAR(32) = NULLIF(LTRIM(RTRIM(@interview_approve_state)), N'');
    IF @ias IS NOT NULL AND @ias <> N'All'
      SET @w = @w + N' AND ' + @alias + N'.interview_final_result=''' + REPLACE(@ias, N'''', N'''''') + N'''';
    IF NULLIF(LTRIM(RTRIM(@approve_state)), N'') IS NOT NULL AND @approve_state <> N'-1'
      SET @w = @w + N' AND EXISTS (SELECT 1 FROM dbo.vw_hwy_platform_user_roles URR WITH (NOLOCK) WHERE URR.user_id=' + @alias + N'.user_id AND URR.role_id=' + @alias + N'.role_id AND URR.role_id IN (1000004,1000005) AND URR.approved=' + @approve_state + N')';
    IF @rid IS NOT NULL AND @rid <> N''
      SET @w = @w + N' AND ' + @alias + N'.role_id=' + @rid;
  END
  ELSE IF @st = N'courses'
  BEGIN
    IF @lt IS NULL SET @lt = N'NotPassed';
    IF @lt = N'NotPassed'
      SET @w = @w + N' AND COALESCE(' + @alias + N'.passed_necessary_dorat, 0)=0';
    ELSE IF @lt = N'Passed'
      SET @w = @w + N' AND COALESCE(' + @alias + N'.passed_necessary_dorat, 0)=1';
    IF @rid IS NOT NULL AND @rid <> N''
      SET @w = @w + N' AND EXISTS (SELECT 1 FROM dbo.vw_hwy_platform_user_roles URR WITH (NOLOCK) WHERE URR.user_id=' + @alias + N'.user_id AND URR.role_id=' + @rid + N')';
    IF NULLIF(LTRIM(RTRIM(@approve_state)), N'') IS NOT NULL AND @approve_state <> N'-1'
      SET @w = @w + N' AND EXISTS (SELECT 1 FROM dbo.vw_hwy_platform_user_roles URR WITH (NOLOCK) WHERE URR.user_id=' + @alias + N'.user_id AND URR.role_id IN (1000004,1000005) AND URR.approved=' + @approve_state + N')';
  END
  ELSE IF @st = N'install'
  BEGIN
    IF OBJECT_ID(N'dbo.HWY_FN_CanApproveResponsibility', N'FN') IS NOT NULL
      SET @w = @w + N' AND dbo.HWY_FN_CanApproveResponsibility(' + @alias + N'.id)=1';
    SET @w = @w + N' AND ' + @alias + N'.security_status=211751';
    DECLARE @pon NVARCHAR(8) = NULLIF(LTRIM(RTRIM(@passed_or_not)), N'');
    IF @pon IS NULL SET @pon = N'-1';
    IF @pon <> N'-1'
      SET @w = @w + N' AND ' + @alias + N'.necessary_dorat_passed=' + @pon;
    IF @rid IS NOT NULL AND @rid <> N''
      SET @w = @w + N' AND EXISTS (SELECT 1 FROM dbo.vw_hwy_platform_user_roles URR WITH (NOLOCK) WHERE URR.user_id=' + @alias + N'.user_id AND URR.role_id=' + @rid + N')';
  END;

  DECLARE @tarshih_prov NVARCHAR(MAX) = N'(SELECT TOP 1 A.HWY_StateId FROM dbo.hwy_member_area_limits AL WITH (NOLOCK) LEFT JOIN dbo.HWY_VW_H_AllArea A ON A.area_id=AL.item_id WHERE AL.member_id=' + @alias + N'.id AND AL.approved=1 ORDER BY AL.id DESC)';
  DECLARE @tarshih_circle NVARCHAR(MAX) = N'(SELECT TOP 1 A.CircleId FROM dbo.hwy_member_area_limits AL WITH (NOLOCK) LEFT JOIN dbo.HWY_VW_H_AllArea A ON A.area_id=AL.item_id WHERE AL.member_id=' + @alias + N'.id AND AL.approved=1 ORDER BY AL.id DESC)';
  DECLARE @tarshih_tamvin NVARCHAR(MAX) = N'(SELECT TOP 1 A.TamvinId FROM dbo.hwy_member_area_limits AL WITH (NOLOCK) LEFT JOIN dbo.HWY_VW_H_AllArea A ON A.area_id=AL.item_id WHERE AL.member_id=' + @alias + N'.id AND AL.approved=1 ORDER BY AL.id DESC)';

  IF @nakheb_province_id IS NOT NULL
  BEGIN
    IF @st IN (N'interview', N'courses', N'install')
      SET @w = @w + N' AND ' + @tarshih_prov + N'=' + CAST(@nakheb_province_id AS NVARCHAR(32));
    ELSE
      SET @w = @w + N' AND ' + @alias + N'.nakheb_join_province_id=' + CAST(@nakheb_province_id AS NVARCHAR(32));
  END;
  IF @nakheb_circle_id IS NOT NULL
  BEGIN
    IF @st IN (N'interview', N'courses', N'install')
      SET @w = @w + N' AND ' + @tarshih_circle + N'=' + CAST(@nakheb_circle_id AS NVARCHAR(32));
    ELSE
      SET @w = @w + N' AND ' + @alias + N'.nakheb_join_circle_id=' + CAST(@nakheb_circle_id AS NVARCHAR(32));
  END;
  IF @nakheb_tamvin_id IS NOT NULL
  BEGIN
    IF @st IN (N'interview', N'courses', N'install')
      SET @w = @w + N' AND ' + @tarshih_tamvin + N'=' + CAST(@nakheb_tamvin_id AS NVARCHAR(32));
    ELSE
      SET @w = @w + N' AND ' + @alias + N'.nakheb_join_tamvin_id=' + CAST(@nakheb_tamvin_id AS NVARCHAR(32));
  END;

  IF NULLIF(LTRIM(RTRIM(@date_start)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.date_of_tarshih >= ''' + REPLACE(@date_start, N'''', N'''''') + N' 00:00''';
  IF NULLIF(LTRIM(RTRIM(@date_end)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.date_of_tarshih <= ''' + REPLACE(@date_end, N'''', N'''''') + N' 23:59''';

  IF NULLIF(LTRIM(RTRIM(@username)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.username LIKE ''%'' + ''' + REPLACE(@username, N'''', N'''''') + N''' + ''%''';
  IF NULLIF(LTRIM(RTRIM(@phone)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.phone1 LIKE ''%'' + ''' + REPLACE(@phone, N'''', N'''''') + N''' + ''%''';
  IF NULLIF(LTRIM(RTRIM(@gender_id)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.gender_id=' + @gender_id;

  IF NULLIF(LTRIM(RTRIM(@member_name)), N'') IS NOT NULL
  BEGIN
    DECLARE @mn NVARCHAR(256) = REPLACE(@member_name, N'''', N'''''');
    SET @w = @w + N' AND (' + @alias + N'.first_name LIKE N''%' + @mn + N'%'''
      + N' OR ' + @alias + N'.father_name LIKE N''%' + @mn + N'%'''
      + N' OR ' + @alias + N'.grandfather_name LIKE N''%' + @mn + N'%'''
      + N' OR ' + @alias + N'.family_name LIKE N''%' + @mn + N'%'')';
  END;

  IF @st = N'courses'
    AND NULLIF(LTRIM(RTRIM(@extra_search_csv)), N'') IS NOT NULL
    AND @extra_search_csv NOT LIKE N'%[^0-9,]%'
  BEGIN
    DECLARE @extra_joiner NVARCHAR(8) = N' AND ';
    IF UPPER(LTRIM(RTRIM(ISNULL(@extra_search_and_or, N'')))) = N'OR'
      SET @extra_joiner = N' OR ';
    DECLARE @extra_pred NVARCHAR(MAX);
    SELECT @extra_pred = STRING_AGG(
      N'ISNULL(' + @alias + N'.passed_dorat, N'''') LIKE N''%' + LTRIM(RTRIM(value)) + N'%''',
      @extra_joiner
    )
    FROM STRING_SPLIT(@extra_search_csv, N',')
    WHERE LTRIM(RTRIM(value)) <> N'';
    IF @extra_pred IS NOT NULL AND LEN(@extra_pred) > 0
      SET @w = @w + N' AND (' + @extra_pred + N')';
  END;

  DECLARE @actor NVARCHAR(128) = NULLIF(LTRIM(RTRIM(@actor_user_name)), N'');
  IF @actor IS NOT NULL AND @st = N'security'
  BEGIN
    IF @actor LIKE N'%,0'
      SET @w = @w + N' AND ' + @alias + N'.moarassheh_of_tarshih=''' + REPLACE(REPLACE(@actor, N',0', N''), N'''', N'''''') + N'''';
    ELSE IF @actor LIKE N'%,1'
      SET @w = @w + N' AND ' + @alias + N'.approved_by=''' + REPLACE(REPLACE(@actor, N',1', N''), N'''', N'''''') + N'''';
    ELSE
      SET @w = @w + N' AND (' + @alias + N'.moarassheh_of_tarshih LIKE ''%'' + ''' + REPLACE(@actor, N'''', N'''''') + N''' + ''%'' OR ' + @alias + N'.approved_by LIKE ''%'' + ''' + REPLACE(@actor, N'''', N'''''') + N''' + ''%'')';
  END;

  IF @scope_unrestricted = 0 AND @area_limit_id IS NOT NULL AND @geo_limits_csv IS NOT NULL AND LTRIM(RTRIM(@geo_limits_csv)) <> N''
  BEGIN
    DECLARE @geo NVARCHAR(MAX) = N' AND (1=0';
    IF @area_limit_id = 111321
      SET @geo = N'';
    ELSE IF @area_limit_id = 111322
    BEGIN
      IF @st IN (N'interview', N'courses', N'install')
        SET @geo = @geo + N' OR ' + @tarshih_prov + N' IN (' + @geo_limits_csv + N')';
      ELSE
        SET @geo = @geo + N' OR ' + @alias + N'.nakheb_join_province_id IN (' + @geo_limits_csv + N')';
    END
    ELSE IF @area_limit_id = 111325
    BEGIN
      IF @st IN (N'interview', N'courses', N'install')
        SET @geo = @geo + N' OR ' + @tarshih_circle + N' IN (' + @geo_limits_csv + N')';
      ELSE
        SET @geo = @geo + N' OR ' + @alias + N'.nakheb_join_circle_id IN (' + @geo_limits_csv + N')';
    END
    ELSE IF @area_limit_id = 111323
    BEGIN
      IF @st IN (N'interview', N'courses', N'install')
        SET @geo = @geo + N' OR ' + @tarshih_tamvin + N' IN (' + @geo_limits_csv + N')';
      ELSE
        SET @geo = @geo + N' OR ' + @alias + N'.nakheb_join_tamvin_id IN (' + @geo_limits_csv + N')';
    END
    ELSE IF @area_limit_id = 111324
      SET @geo = @geo + N' OR ' + @alias + N'.nakheb_join_eghtera_id IN (' + @geo_limits_csv + N')';
    IF @geo <> N''
      SET @w = @w + @geo + N')';
  END;

  RETURN @w;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_candidate_pipeline_count
  @stage NVARCHAR(32),
  @list_type NVARCHAR(64) = NULL,
  @role_id NVARCHAR(32) = NULL,
  @is_approved NVARCHAR(8) = NULL,
  @approve_state NVARCHAR(8) = NULL,
  @passed_or_not NVARCHAR(8) = NULL,
  @interview_approve_state NVARCHAR(32) = NULL,
  @scope_unrestricted BIT = 0,
  @nakheb_province_id BIGINT = NULL,
  @nakheb_circle_id BIGINT = NULL,
  @nakheb_tamvin_id BIGINT = NULL,
  @date_start NVARCHAR(32) = NULL,
  @date_end NVARCHAR(32) = NULL,
  @username NVARCHAR(128) = NULL,
  @phone NVARCHAR(64) = NULL,
  @gender_id NVARCHAR(32) = NULL,
  @actor_user_name NVARCHAR(128) = NULL,
  @area_limit_id BIGINT = NULL,
  @geo_limits_csv NVARCHAR(MAX) = NULL,
  @member_name NVARCHAR(256) = NULL,
  @extra_search_csv NVARCHAR(512) = NULL,
  @extra_search_and_or NVARCHAR(8) = NULL
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @view sysname = CASE LOWER(LTRIM(RTRIM(@stage)))
    WHEN N'security' THEN N'vw_hwy_candidate_pipeline_security'
    WHEN N'interview' THEN N'vw_hwy_candidate_pipeline_interview'
    WHEN N'courses' THEN N'vw_hwy_candidate_pipeline_courses'
    WHEN N'install' THEN N'vw_hwy_candidate_pipeline_install'
    ELSE NULL
  END;

  IF @view IS NULL OR OBJECT_ID(N'dbo.' + @view, N'V') IS NULL
    THROW 50400, N'Legacy candidate pipeline view is not available for this stage.', 1;

  DECLARE @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS total FROM dbo.' + QUOTENAME(@view) + N' V WITH (NOLOCK) WHERE 1=1';
  SET @sql = @sql + dbo.hwy_candidate_pipeline_where_clause(
    @stage, @list_type, @role_id, @is_approved, @approve_state, @passed_or_not,
    @interview_approve_state, @scope_unrestricted, @nakheb_province_id, @nakheb_circle_id,
    @nakheb_tamvin_id, @date_start, @date_end, @username, @phone, @gender_id, N'V',
    @actor_user_name, @area_limit_id, @geo_limits_csv, @member_name, @extra_search_csv, @extra_search_and_or);
  EXEC sp_executesql @sql;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_candidate_pipeline_list
  @stage NVARCHAR(32),
  @list_type NVARCHAR(64) = NULL,
  @role_id NVARCHAR(32) = NULL,
  @is_approved NVARCHAR(8) = NULL,
  @approve_state NVARCHAR(8) = NULL,
  @passed_or_not NVARCHAR(8) = NULL,
  @interview_approve_state NVARCHAR(32) = NULL,
  @scope_unrestricted BIT = 0,
  @nakheb_province_id BIGINT = NULL,
  @nakheb_circle_id BIGINT = NULL,
  @nakheb_tamvin_id BIGINT = NULL,
  @date_start NVARCHAR(32) = NULL,
  @date_end NVARCHAR(32) = NULL,
  @username NVARCHAR(128) = NULL,
  @phone NVARCHAR(64) = NULL,
  @gender_id NVARCHAR(32) = NULL,
  @actor_user_name NVARCHAR(128) = NULL,
  @area_limit_id BIGINT = NULL,
  @geo_limits_csv NVARCHAR(MAX) = NULL,
  @member_name NVARCHAR(256) = NULL,
  @extra_search_csv NVARCHAR(512) = NULL,
  @extra_search_and_or NVARCHAR(8) = NULL,
  @offset INT = 0,
  @page_size INT = 25
AS
BEGIN
  SET NOCOUNT ON;

  IF LOWER(LTRIM(RTRIM(@stage))) = N'interview'
  BEGIN
    DECLARE @interview_where NVARCHAR(MAX) = dbo.hwy_candidate_pipeline_where_clause(
      @stage, @list_type, @role_id, @is_approved, @approve_state, @passed_or_not,
      @interview_approve_state, @scope_unrestricted, @nakheb_province_id, @nakheb_circle_id,
      @nakheb_tamvin_id, @date_start, @date_end, @username, @phone, @gender_id, N'V',
      @actor_user_name, @area_limit_id, @geo_limits_csv, @member_name, @extra_search_csv, @extra_search_and_or);

    DECLARE @interview_sql NVARCHAR(MAX) = N'
;WITH eligible AS (
  SELECT
    M.id,
    M.username,
    M.user_id,
    M.first_name,
    M.father_name,
    M.grandfather_name,
    M.family_name,
    M.phone1,
    M.gender_id,
    M.nakheb_join_province_id,
    M.nakheb_join_circle_id,
    M.nakheb_join_tamvin_id,
    M.nakheb_join_eghtera_id,
    iv.interview_on AS interview_on,
    iv.final_result AS interview_final_result,
    R.role_name AS role_of_tarshih,
    URR.role_id AS role_id,
    URR.created_at AS date_of_tarshih,
    URR.created_by AS moarassheh_of_tarshih,
    sec.created_on AS date_of_sp
  FROM dbo.hwy_members M WITH (NOLOCK)
  INNER JOIN dbo.vw_hwy_platform_user_roles URR WITH (NOLOCK)
    ON URR.user_id = M.user_id AND URR.role_id IN (1000004, 1000005)
  LEFT OUTER JOIN dbo.vw_hwy_platform_roles R WITH (NOLOCK) ON R.id= URR.role_id
  OUTER APPLY (
    SELECT TOP 1 SP.can_get_masooliat, SP.created_on
    FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK)
    WHERE SP.member_id = M.id
    ORDER BY SP.created_on DESC
  ) sec
  OUTER APPLY (
    SELECT TOP 1 I.interview_on, I.final_result
    FROM dbo.hwy_member_interviews_2022 I WITH (NOLOCK)
    WHERE I.member_id = M.id
    ORDER BY I.created_on DESC
  ) iv
  WHERE M.membership_status_legacy = 10851
    AND sec.can_get_masooliat = 211751
),
filtered AS (
  SELECT V.*, COUNT(*) OVER() AS pipeline_total
  FROM eligible V
  WHERE 1=1' + @interview_where + N'
),
paged AS (
  SELECT *
  FROM filtered V
  ORDER BY V.date_of_tarshih DESC, V.id DESC
  OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY
)
SELECT
  CAST(p.id AS VARCHAR(32)) AS id,
  p.username AS username,
  CAST(p.user_id AS VARCHAR(32)) AS user_id,
  p.first_name AS first_name,
  p.father_name AS father_name,
  p.grandfather_name AS grandfather_name,
  p.family_name AS family_name,
  p.phone1 AS phone1,
  vm.electoral_division_path AS electoral_division_path,
  (SELECT TOP 1 BI.title FROM dbo.hwy_ref_base_information BI WITH (NOLOCK) WHERE BI.id = p.nakheb_join_province_id) AS nakheb_join_province_name,
  (SELECT TOP 1 C.circle_name FROM dbo.hwy_ref_h_circles C WITH (NOLOCK) WHERE C.circle_id = p.nakheb_join_circle_id) AS nakheb_join_circle_name,
  (SELECT TOP 1 T.tamvin_name FROM dbo.hwy_ref_h_tamvinat T WITH (NOLOCK) WHERE T.tamvin_id = p.nakheb_join_tamvin_id) AS nakheb_join_tamvin_name,
  (SELECT TOP 1 BI.title FROM dbo.hwy_ref_base_information BI WITH (NOLOCK) WHERE BI.id = p.nakheb_join_eghtera_id) AS nakheb_join_eghtera_name,
  CAST(p.nakheb_join_eghtera_id AS VARCHAR(32)) AS nakheb_join_eghtera_id,
  CAST(p.gender_id AS VARCHAR(32)) AS gender_id,
  p.role_of_tarshih AS role_of_tarshih,
  dbo.hwy_member_agg_area_limits_for_tarshih(p.id) AS area_of_tarshih,
  CONVERT(VARCHAR(32), p.date_of_tarshih, 126) AS date_of_tarshih,
  p.moarassheh_of_tarshih AS moarassheh_of_tarshih,
  CONVERT(VARCHAR(32), p.interview_on, 126) AS interview_on,
  CAST(p.interview_final_result AS VARCHAR(32)) AS interview_final_result,
  BI_iv.title AS interview_final_result_title,
  CAST(p.role_id AS VARCHAR(32)) AS role_id,
  DATEDIFF(DAY, p.date_of_tarshih, GETDATE()) AS days_from,
  p.pipeline_total,
  vm.display_full_name AS display_full_name,
  vm.avatar_url AS avatar_url,
  vm.birth_year AS birth_year,
  vm.gender_code AS gender_code,
  CONVERT(VARCHAR(32), vm.membership_on, 126) AS membership_on,
  vm.phone2 AS phone2,
  vm.tracking_code AS tracking_code,
  CAST(vm.addr_province_id AS VARCHAR(32)) AS addr_province_id,
  CAST(vm.addr_region_id AS VARCHAR(32)) AS addr_region_id,
  CAST(vm.addr_maktab_id AS VARCHAR(32)) AS addr_maktab_id,
  CAST(vm.nakhebin_region_id AS VARCHAR(32)) AS nakhebin_region_id,
  CAST(vm.nakhebin_maktab_id AS VARCHAR(32)) AS nakhebin_maktab_id,
  CONVERT(VARCHAR(32), vm.created_at, 126) AS created_at
FROM paged p
LEFT JOIN dbo.hwy_ref_base_information BI_iv WITH (NOLOCK) ON BI_iv.id= p.interview_final_result
LEFT JOIN dbo.vw_hwy_members vm WITH (NOLOCK) ON vm.id= CAST(p.id AS VARCHAR(32))';

    EXEC sp_executesql @interview_sql, N'@offset INT, @page_size INT', @offset = @offset, @page_size = @page_size;
    RETURN;
  END;

  DECLARE @view sysname = CASE LOWER(LTRIM(RTRIM(@stage)))
    WHEN N'security' THEN N'vw_hwy_candidate_pipeline_security'
    WHEN N'interview' THEN N'vw_hwy_candidate_pipeline_interview'
    WHEN N'courses' THEN N'vw_hwy_candidate_pipeline_courses'
    WHEN N'install' THEN N'vw_hwy_candidate_pipeline_install'
    ELSE NULL
  END;

  IF @view IS NULL OR OBJECT_ID(N'dbo.' + @view, N'V') IS NULL
    THROW 50400, N'Legacy candidate pipeline view is not available for this stage.', 1;

  DECLARE @areaCol NVARCHAR(MAX) = N'';
  IF LOWER(LTRIM(RTRIM(@stage))) = N'security'
    SET @areaCol = N', V.days_from AS days_from, CAST(V.is_approved AS INT) AS is_approved_row, (SELECT TOP 1 SP.can_get_masooliat FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=V.id ORDER BY SP.created_on DESC) AS last_security_profile_can_get_masooliat';
  ELSE IF LOWER(LTRIM(RTRIM(@stage))) = N'interview'
    SET @areaCol = N', CONVERT(VARCHAR(32), V.interview_on, 126) AS interview_on, CAST(V.interview_final_result AS VARCHAR(32)) AS interview_final_result, (SELECT TOP 1 B.title FROM dbo.hwy_member_interviews_2022 I2022 WITH (NOLOCK) LEFT JOIN dbo.hwy_ref_base_information B WITH (NOLOCK) ON B.id= I2022.final_result WHERE I2022.member_id = V.id ORDER BY I2022.created_on DESC) AS interview_final_result_title, CAST(V.role_id AS VARCHAR(32)) AS role_id';
  ELSE IF LOWER(LTRIM(RTRIM(@stage))) = N'courses'
    SET @areaCol = N', CAST(V.passed_necessary_dorat AS BIT) AS passed_necessary_dorat';
  ELSE IF LOWER(LTRIM(RTRIM(@stage))) = N'install'
    SET @areaCol = N', CAST(V.area_id AS VARCHAR(32)) AS area_id, CAST(V.necessary_dorat_passed AS BIT) AS necessary_dorat_passed, V.interview_final_result_title AS interview_final_result_title, CAST(V.profile_perfect AS INT) AS profile_perfect, CAST(V.all_images_approved AS BIT) AS all_images_approved, CAST(V.has_oath AS BIT) AS has_oath, V.gender_limits AS gender_limits, V.areas_limits AS areas_limits, V.roles_limits AS roles_limits';

  DECLARE @passedDoratCol NVARCHAR(128) = N'CAST(NULL AS NVARCHAR(MAX)) AS passed_dorat_html';
  IF LOWER(LTRIM(RTRIM(@stage))) = N'courses'
    SET @passedDoratCol = N'V.passed_dorat AS passed_dorat_html';

  DECLARE @sql NVARCHAR(MAX) = N'
    SELECT
      CAST(V.id AS VARCHAR(32)) AS id,
      V.username AS username,
      CAST(V.user_id AS VARCHAR(32)) AS user_id,
      V.first_name AS first_name,
      V.father_name AS father_name,
      V.grandfather_name AS grandfather_name,
      V.family_name AS family_name,
      V.phone1 AS phone1,
      vm.electoral_division_path AS electoral_division_path,
      (SELECT TOP 1 BI.title FROM dbo.hwy_ref_base_information BI WITH (NOLOCK) WHERE BI.id = V.nakheb_join_province_id) AS nakheb_join_province_name,
      (SELECT TOP 1 C.circle_name FROM dbo.hwy_ref_h_circles C WITH (NOLOCK) WHERE C.circle_id = V.nakheb_join_circle_id) AS nakheb_join_circle_name,
      (SELECT TOP 1 T.tamvin_name FROM dbo.hwy_ref_h_tamvinat T WITH (NOLOCK) WHERE T.tamvin_id = V.nakheb_join_tamvin_id) AS nakheb_join_tamvin_name,
      (SELECT TOP 1 BI.title FROM dbo.hwy_ref_base_information BI WITH (NOLOCK) WHERE BI.id = V.nakheb_join_eghtera_id) AS nakheb_join_eghtera_name,
      CAST(V.nakheb_join_eghtera_id AS VARCHAR(32)) AS nakheb_join_eghtera_id,
      CAST(V.gender_id AS VARCHAR(32)) AS gender_id,
      V.role_of_tarshih AS role_of_tarshih,
      V.area_of_tarshih AS area_of_tarshih,
      CONVERT(VARCHAR(32), V.date_of_tarshih, 126) AS date_of_tarshih,
      V.moarassheh_of_tarshih AS moarassheh_of_tarshih,
      ' + @passedDoratCol + @areaCol + N',
      COUNT(*) OVER() AS pipeline_total,
      vm.display_full_name AS display_full_name,
      vm.avatar_url AS avatar_url,
      vm.birth_year AS birth_year,
      vm.gender_code AS gender_code,
      CONVERT(VARCHAR(32), vm.membership_on, 126) AS membership_on,
      vm.phone2 AS phone2,
      vm.tracking_code AS tracking_code,
      CAST(vm.addr_province_id AS VARCHAR(32)) AS addr_province_id,
      CAST(vm.addr_region_id AS VARCHAR(32)) AS addr_region_id,
      CAST(vm.addr_maktab_id AS VARCHAR(32)) AS addr_maktab_id,
      CAST(vm.nakhebin_region_id AS VARCHAR(32)) AS nakhebin_region_id,
      CAST(vm.nakhebin_maktab_id AS VARCHAR(32)) AS nakhebin_maktab_id,
      CONVERT(VARCHAR(32), vm.created_at, 126) AS created_at
    FROM dbo.' + QUOTENAME(@view) + N' V WITH (NOLOCK)
    LEFT JOIN dbo.vw_hwy_members vm WITH (NOLOCK) ON vm.id= CAST(V.id AS VARCHAR(32))
    WHERE 1=1';

  SET @sql = @sql + dbo.hwy_candidate_pipeline_where_clause(
    @stage, @list_type, @role_id, @is_approved, @approve_state, @passed_or_not,
    @interview_approve_state, @scope_unrestricted, @nakheb_province_id, @nakheb_circle_id,
    @nakheb_tamvin_id, @date_start, @date_end, @username, @phone, @gender_id, N'V',
    @actor_user_name, @area_limit_id, @geo_limits_csv, @member_name, @extra_search_csv, @extra_search_and_or);

  SET @sql = @sql + N' ORDER BY V.date_of_tarshih DESC, V.id DESC OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY';

  EXEC sp_executesql @sql, N'@offset INT, @page_size INT', @offset = @offset, @page_size = @page_size;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_candidate_pipeline_install_approve
  @member_id BIGINT,
  @area_id BIGINT,
  @actor NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @len INT = LEN(CAST(@area_id AS NVARCHAR(32)));
  IF @len = 4
  BEGIN
    IF OBJECT_ID(N'dbo.HWY_SP_H_Tamvin_Approve_SuggestedResponsible', N'P') IS NULL
      THROW 50400, N'Legacy tamvin approve SP is not available.', 1;
    DECLARE @r BIT;
    EXEC dbo.HWY_SP_H_Tamvin_Approve_SuggestedResponsible
      @MemberId = @member_id,
      @TamvinId = @area_id,
      @Actor = @actor,
      @Result = @r OUTPUT;
    IF @r = 0 THROW 50422, N'Tamvin responsibility approve failed.', 1;
    RETURN;
  END;
  IF OBJECT_ID(N'dbo.HWY_SP_H_Eghtera_Approve_SuggestedResponsible', N'P') IS NULL
    THROW 50400, N'Legacy eghtera approve SP is not available.', 1;
  DECLARE @re BIT;
  EXEC dbo.HWY_SP_H_Eghtera_Approve_SuggestedResponsible
    @MemberId = @member_id,
    @EghteraId = @area_id,
    @Actor = @actor,
    @Result = @re OUTPUT;
  IF @re = 0 THROW 50422, N'Eghtera responsibility approve failed.', 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_candidate_pipeline_security_record
  @member_id BIGINT,
  @can_get_identity_card INT,
  @can_get_identity_card_note NVARCHAR(1024) = NULL,
  @can_get_masooliat INT,
  @can_get_masooliat_note NVARCHAR(1024) = NULL,
  @can_be_member_of_aammeh INT,
  @can_be_member_of_aammeh_note NVARCHAR(1024) = NULL,
  @allows_responsibility INT,
  @allows_responsibility_note NVARCHAR(1024) = NULL,
  @actor NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.hwy_member_security_profile_history', N'U') IS NULL
    THROW 50400, N'hwy_member_security_profile_history table is not available.', 1;

  IF @can_get_masooliat NOT IN (211751, 211752, 211753)
    OR @can_get_identity_card NOT IN (211751, 211752, 211753)
    OR @can_be_member_of_aammeh NOT IN (211751, 211752, 211753)
    OR @allows_responsibility NOT IN (211751, 211752, 211753)
    THROW 50422, N'Invalid security opinion value.', 1;

  IF @can_get_masooliat = 211752 AND NULLIF(LTRIM(RTRIM(@can_get_masooliat_note)), N'') IS NULL
    THROW 50422, N'CanGetMasooliat rejection note is required.', 1;

  DECLARE @actor_name NVARCHAR(64) = COALESCE(NULLIF(LTRIM(RTRIM(@actor)), N''), N'system');
  INSERT INTO dbo.hwy_member_security_profile_history (
    id, member_id,
    can_get_identity_card, can_get_identity_card_note,
    can_get_masooliat, can_get_masooliat_note,
    can_be_member_of_aammeh, can_be_member_of_aammeh_note,
    allows_responsibility, allows_responsibility_note,
    created_by, created_on
  )
  VALUES (
    NEWID(), @member_id,
    @can_get_identity_card, COALESCE(@can_get_identity_card_note, N''),
    @can_get_masooliat, COALESCE(@can_get_masooliat_note, N''),
    @can_be_member_of_aammeh, COALESCE(@can_be_member_of_aammeh_note, N''),
    @allows_responsibility, COALESCE(@allows_responsibility_note, N''),
    @actor_name, SYSUTCDATETIME()
  );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_candidate_pipeline_interview_last
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.hwy_member_interviews_2022', N'U') IS NULL
    THROW 50400, N'hwy_member_interviews_2022 table is not available.', 1;

  SELECT TOP 1
    CAST(I.id AS VARCHAR(36)) AS interview_id,
    CAST(I.member_id AS VARCHAR(32)) AS member_id,
    CONVERT(VARCHAR(32), I.interview_on, 126) AS interview_on,
    I.karizma AS karizma,
    I.like_to_learn_more AS like_to_learn_more,
    I.show_is_fan AS show_is_fan,
    I.ability_to_make_team AS ability_to_make_team,
    I.ghodrat_elec AS ghodrat_elec,
    I.knows_masoolin AS knows_masoolin,
    CAST(I.is_motefaregh AS BIT) AS is_motefaregh,
    I.is_motefaregh_saat AS is_motefaregh_saat,
    I.note AS note,
    I.final_result AS final_result,
    FR.Title AS final_result_title,
    I.created_by AS created_by,
    CONVERT(VARCHAR(32), I.created_on, 126) AS created_at,
    (
      SELECT
        CAST(M.id AS VARCHAR(32)) AS member_id,
        M.username AS username,
        M.first_name AS first_name,
        M.father_name AS father_name,
        M.grandfather_name AS grandfather_name,
        M.family_name AS family_name
      FROM dbo.hwy_member_interviews_2022_hazerin H WITH (NOLOCK)
      INNER JOIN dbo.hwy_members M WITH (NOLOCK) ON M.id= H.hazer_id
      WHERE H.interview_id = I.id
      FOR JSON PATH
    ) AS hazerin_json
  FROM dbo.hwy_member_interviews_2022 I WITH (NOLOCK)
  LEFT JOIN dbo.hwy_ref_base_information FR WITH (NOLOCK) ON FR.id= I.final_result
  WHERE I.member_id = @member_id
  ORDER BY I.created_on DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_candidate_pipeline_interview_create
  @member_id BIGINT,
  @interview_on NVARCHAR(32),
  @karizma INT,
  @like_to_learn_more INT,
  @show_is_fan INT,
  @ability_to_make_team INT,
  @ghodrat_elec INT,
  @knows_masoolin INT,
  @is_motefaregh BIT,
  @is_motefaregh_saat INT,
  @note NVARCHAR(2048),
  @final_result INT,
  @hazerin_json NVARCHAR(MAX),
  @actor NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.hwy_member_interviews_2022', N'U') IS NULL
    THROW 50400, N'hwy_member_interviews_2022 table is not available.', 1;
  IF OBJECT_ID(N'dbo.hwy_member_interviews_2022_hazerin', N'U') IS NULL
    THROW 50400, N'hwy_member_interviews_2022_hazerin table is not available.', 1;
  IF @final_result NOT IN (213609, 213610, 213611)
    THROW 50422, N'Invalid interview final result.', 1;

  DECLARE @unset_score INT = 211525;
  IF @karizma = @unset_score OR @like_to_learn_more = @unset_score OR @show_is_fan = @unset_score
    OR @ability_to_make_team = @unset_score OR @ghodrat_elec = @unset_score OR @knows_masoolin = @unset_score
    THROW 50422, N'All interview score dimensions must be answered.', 1;

  IF @is_motefaregh_saat IS NULL OR @is_motefaregh_saat < 1 OR @is_motefaregh_saat > 24
    THROW 50422, N'IsMotefaregh_Saat must be between 1 and 24.', 1;

  IF @note IS NULL OR LEN(LTRIM(RTRIM(@note))) < 50
    THROW 50422, N'Interview note must be at least 50 characters.', 1;

  DECLARE @actor_name NVARCHAR(64) = COALESCE(NULLIF(LTRIM(RTRIM(@actor)), N''), N'system');
  DECLARE @interview_id UNIQUEIDENTIFIER = NEWID();

  INSERT INTO dbo.hwy_member_interviews_2022 (
    id, member_id, karizma, like_to_learn_more, show_is_fan, ability_to_make_team,
    ghodrat_elec, knows_masoolin, is_motefaregh, is_motefaregh_saat,
    final_result, interview_on, note, created_by, created_on
  )
  VALUES (
    @interview_id, @member_id, @karizma, @like_to_learn_more, @show_is_fan, @ability_to_make_team,
    @ghodrat_elec, @knows_masoolin, @is_motefaregh, @is_motefaregh_saat,
    @final_result, TRY_CONVERT(DATETIME, @interview_on, 126), @note,
    @actor_name, SYSUTCDATETIME()
  );

  IF @hazerin_json IS NOT NULL AND LTRIM(RTRIM(@hazerin_json)) <> N''
  BEGIN
    INSERT INTO dbo.hwy_member_interviews_2022_hazerin (id, interview_id, hazer_id)
    SELECT NEWID(), @interview_id, J.hazer_id
    FROM OPENJSON(@hazerin_json) WITH (hazer_id BIGINT '$.hazer_id') AS J
    WHERE J.hazer_id IS NOT NULL;
  END;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_candidate_pipeline_install_reject
  @member_id BIGINT,
  @area_id BIGINT,
  @actor NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @len INT = LEN(CAST(@area_id AS NVARCHAR(32)));
  IF @len = 4
  BEGIN
    IF OBJECT_ID(N'dbo.HWY_SP_H_Tamvin_Remove_SuggestedResponsible', N'P') IS NULL
      THROW 50400, N'Legacy tamvin remove suggestion SP is not available.', 1;
    EXEC dbo.HWY_SP_H_Tamvin_Remove_SuggestedResponsible
      @MemberId = @member_id,
      @TamvinId = @area_id,
      @Actor = @actor;
    RETURN;
  END;
  IF OBJECT_ID(N'dbo.HWY_SP_H_Eghtera_Remove_SuggestedResponsible', N'P') IS NULL
    THROW 50400, N'Legacy eghtera remove suggestion SP is not available.', 1;
  EXEC dbo.HWY_SP_H_Eghtera_Remove_SuggestedResponsible
    @MemberId = @member_id,
    @EghteraId = @area_id,
    @Actor = @actor;
END;
GO
