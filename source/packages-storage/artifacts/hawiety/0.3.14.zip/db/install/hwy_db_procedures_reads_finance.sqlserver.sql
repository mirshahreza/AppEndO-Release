-- Payment documents grid reads — server builds @extra_where (scope + filters).
-- Requires dbo.hwy_payment_documents on edge.

CREATE OR ALTER PROCEDURE dbo.hwy_payment_documents_count
  @extra_where NVARCHAR(MAX) = N''
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @sql NVARCHAR(MAX) = N'
    SELECT COUNT(*) AS total
    FROM dbo.hwy_payment_documents D WITH (NOLOCK)
    WHERE 1=1' + ISNULL(@extra_where, N'');
  EXEC sp_executesql @sql;
END
GO

CREATE OR ALTER PROCEDURE dbo.hwy_payment_documents_aggregates
  @extra_where NVARCHAR(MAX) = N''
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @sql NVARCHAR(MAX) = N'
    SELECT
      ISNULL(SUM(CAST(D.total_members_count AS BIGINT)), 0) AS sum_total_members_count,
      ISNULL(SUM(CAST(D.payable_members_count_ok AS BIGINT)), 0) AS sum_payable_members_count_ok,
      ISNULL(SUM(CAST(D.payable_members_count_nok AS BIGINT)), 0) AS sum_payable_members_count_nok,
      ISNULL(SUM(CAST(D.not_payable_members_count AS BIGINT)), 0) AS sum_not_payable_members_count,
      ISNULL(SUM(CAST(D.total_amount AS BIGINT)), 0) AS sum_total_amount,
      ISNULL(SUM(CAST(D.payable_amount_ok AS BIGINT)), 0) AS sum_payable_amount_ok,
      ISNULL(SUM(CAST(D.payable_amount_nok AS BIGINT)), 0) AS sum_payable_amount_nok,
      ISNULL(SUM(CAST(D.not_payable_amount AS BIGINT)), 0) AS sum_not_payable_amount
    FROM dbo.hwy_payment_documents D WITH (NOLOCK)
    WHERE 1=1' + ISNULL(@extra_where, N'');
  EXEC sp_executesql @sql;
END
GO

CREATE OR ALTER PROCEDURE dbo.hwy_payment_documents_list
  @extra_where NVARCHAR(MAX) = N'',
  @offset INT = 0,
  @page_size INT = 25
AS
BEGIN
  SET NOCOUNT ON;
  IF @page_size < 1 SET @page_size = 25;
  IF @page_size > 100 SET @page_size = 100;
  IF @offset < 0 SET @offset = 0;

  DECLARE @sql NVARCHAR(MAX) = N'
    SELECT
      CAST(D.id AS VARCHAR(32)) AS id,
      D.doc_year AS doc_year,
      D.doc_month AS doc_month,
      CAST(D.doc_gender_id AS VARCHAR(32)) AS doc_gender_id,
      (SELECT TOP 1 BI.title FROM dbo.hwy_ref_base_information BI WITH (NOLOCK) WHERE BI.id = D.doc_gender_id) AS doc_gender_id_title,
      CAST(D.doc_province_id AS VARCHAR(32)) AS doc_province_id,
      (SELECT TOP 1 BI.title FROM dbo.hwy_ref_base_information BI WITH (NOLOCK) WHERE BI.id = D.doc_province_id) AS doc_province_id_title,
      CAST(D.doc_circle_id AS VARCHAR(32)) AS doc_circle_id,
      (SELECT TOP 1 C.circle_name FROM dbo.hwy_ref_h_circles C WITH (NOLOCK) WHERE C.circle_id = D.doc_circle_id) AS doc_circle_id_title,
      D.total_members_count AS total_members_count,
      D.payable_members_count_ok AS payable_members_count_ok,
      D.payable_members_count_nok AS payable_members_count_nok,
      D.not_payable_members_count AS not_payable_members_count,
      D.total_amount AS total_amount,
      D.payable_amount_ok AS payable_amount_ok,
      D.payable_amount_nok AS payable_amount_nok,
      D.not_payable_amount AS not_payable_amount,
      D.area_ok AS area_ok,
      D.area_ok_by AS area_ok_by,
      CONVERT(VARCHAR(32), D.area_ok_on, 126) AS area_ok_on,
      D.final_ok AS final_ok,
      D.final_ok_by AS final_ok_by,
      CONVERT(VARCHAR(32), D.final_ok_on, 126) AS final_ok_on,
      D.closed AS closed,
      D.closed_by AS closed_by,
      CONVERT(VARCHAR(32), D.closed_on, 126) AS closed_on,
      D.created_by AS created_by,
      CONVERT(VARCHAR(32), D.created_on, 126) AS created_at
    FROM dbo.hwy_payment_documents D WITH (NOLOCK)
    WHERE 1=1' + ISNULL(@extra_where, N'') + N'
    ORDER BY D.created_on DESC, D.id DESC
    OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY';

  EXEC sp_executesql @sql, N'@offset INT, @page_size INT', @offset = @offset, @page_size = @page_size;
END
GO

CREATE OR ALTER PROCEDURE dbo.hwy_payment_documents_members_count
  @extra_where NVARCHAR(MAX) = N''
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @sql NVARCHAR(MAX) = N'
    SELECT COUNT(*) AS total
    FROM dbo.vw_hwy_payment_documents_members V WITH (NOLOCK)
    WHERE 1=1' + ISNULL(@extra_where, N'');
  EXEC sp_executesql @sql;
END
GO

CREATE OR ALTER PROCEDURE dbo.hwy_payment_documents_members_list
  @extra_where NVARCHAR(MAX) = N'',
  @offset INT = 0,
  @page_size INT = 25
AS
BEGIN
  SET NOCOUNT ON;
  IF @page_size < 1 SET @page_size = 25;
  IF @page_size > 100 SET @page_size = 100;
  IF @offset < 0 SET @offset = 0;

  DECLARE @sql NVARCHAR(MAX) = N'
    SELECT
      CAST(V.id AS VARCHAR(32)) AS id,
      M.username AS username,
      M.first_name AS first_name,
      M.father_name AS father_name,
      M.grandfather_name AS grandfather_name,
      M.family_name AS family_name,
      R.role_name AS role_name,
      PD.doc_year AS doc_year,
      PD.doc_month AS doc_month,
      V.pay_amount AS pay_amount,
      (SELECT TOP 1 BI.title FROM dbo.hwy_ref_base_information BI WITH (NOLOCK) WHERE BI.id = V.payable_reason_id) AS payable_reason_title,
      V.pay_ok AS pay_ok,
      V.payable AS payable
    FROM dbo.vw_hwy_payment_documents_members V WITH (NOLOCK)
    INNER JOIN dbo.vw_hwy_members_legacy_row M WITH (NOLOCK) ON M.id= V.member_id
    INNER JOIN dbo.hwy_payment_documents PD WITH (NOLOCK) ON PD.id= V.document_id
    LEFT JOIN dbo.vw_hwy_platform_roles R WITH (NOLOCK) ON R.id= V.role_id
    WHERE 1=1' + ISNULL(@extra_where, N'') + N'
    ORDER BY V.id DESC
    OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY';

  EXEC sp_executesql @sql, N'@offset INT, @page_size INT', @offset = @offset, @page_size = @page_size;
END
GO
