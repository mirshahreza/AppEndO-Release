-- dbo.hwy_members.Payable / payable → chief_masool (masool of record: chief vs deputy in same roqhe group — not payment eligibility).

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NOT NULL
BEGIN
  IF COL_LENGTH(N'dbo.hwy_members', N'Payable') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'chief_masool') IS NULL
    EXEC sys.sp_rename N'dbo.hwy_members.Payable', N'chief_masool', N'COLUMN';

  IF COL_LENGTH(N'dbo.hwy_members', N'payable') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'chief_masool') IS NULL
    EXEC sys.sp_rename N'dbo.hwy_members.payable', N'chief_masool', N'COLUMN';

  IF COL_LENGTH(N'dbo.hwy_members', N'chief_masool') IS NULL
    ALTER TABLE dbo.hwy_members ADD chief_masool BIT NULL;
END
GO

PRINT 'hwy_members chief_masool column ready';
GO
