-- Rename finance ETL tables on the AppEndO edge DB to dbo.hwy_* snake_case.
-- Idempotent: skips when the target name already exists.

IF OBJECT_ID(N'dbo.HWY_PaymentDocuments', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.hwy_payment_documents', N'U') IS NULL
  EXEC sp_rename N'dbo.HWY_PaymentDocuments', N'hwy_payment_documents';
GO

IF OBJECT_ID(N'dbo.HWY_PaymentDocuments_Members', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.hwy_payment_documents_members', N'U') IS NULL
  EXEC sp_rename N'dbo.HWY_PaymentDocuments_Members', N'hwy_payment_documents_members';
GO

IF OBJECT_ID(N'dbo.HWY_PaymentDocuments_Members_PayAmountLog', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.hwy_payment_documents_members_pay_amount_log', N'U') IS NULL
  EXEC sp_rename N'dbo.HWY_PaymentDocuments_Members_PayAmountLog', N'hwy_payment_documents_members_pay_amount_log';
GO

IF OBJECT_ID(N'dbo.HWY_MasoolinStars', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.hwy_masoolin_stars', N'U') IS NULL
  EXEC sp_rename N'dbo.HWY_MasoolinStars', N'hwy_masoolin_stars';
GO

IF OBJECT_ID(N'dbo.HWY_MasoolinStarsHistory', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.hwy_masoolin_stars_history', N'U') IS NULL
  EXEC sp_rename N'dbo.HWY_MasoolinStarsHistory', N'hwy_masoolin_stars_history';
GO

IF OBJECT_ID(N'dbo.HWY_MasoolinStarsCurrent', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.hwy_masoolin_stars_current', N'U') IS NULL
  EXEC sp_rename N'dbo.HWY_MasoolinStarsCurrent', N'hwy_masoolin_stars_current';
GO

IF OBJECT_ID(N'dbo.HWY_MasoolinStarsOveral', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.hwy_masoolin_stars_overal', N'U') IS NULL
  EXEC sp_rename N'dbo.HWY_MasoolinStarsOveral', N'hwy_masoolin_stars_overal';
GO

-- Drop duplicate legacy names when standard tables already exist (e.g. fresh ETL before rename).
IF OBJECT_ID(N'dbo.hwy_payment_documents', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_PaymentDocuments', N'U') IS NOT NULL
  DROP TABLE dbo.HWY_PaymentDocuments;
GO

IF OBJECT_ID(N'dbo.hwy_payment_documents_members', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_PaymentDocuments_Members', N'U') IS NOT NULL
  DROP TABLE dbo.HWY_PaymentDocuments_Members;
GO

IF OBJECT_ID(N'dbo.hwy_masoolin_stars', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_MasoolinStars', N'U') IS NOT NULL
  DROP TABLE dbo.HWY_MasoolinStars;
GO

IF OBJECT_ID(N'dbo.hwy_masoolin_stars_history', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_MasoolinStarsHistory', N'U') IS NOT NULL
  DROP TABLE dbo.HWY_MasoolinStarsHistory;
GO

IF OBJECT_ID(N'dbo.hwy_masoolin_stars_current', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_MasoolinStarsCurrent', N'U') IS NOT NULL
  DROP TABLE dbo.HWY_MasoolinStarsCurrent;
GO

IF OBJECT_ID(N'dbo.hwy_masoolin_stars_overal', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_MasoolinStarsOveral', N'U') IS NOT NULL
  DROP TABLE dbo.HWY_MasoolinStarsOveral;
GO
