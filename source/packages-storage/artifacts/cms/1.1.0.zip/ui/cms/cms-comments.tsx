import React from 'react';
import { buildAppTableGridColumns } from '@/domain/component-designer/DesignerRuntimeAppTableGrid';
import { applyClientGridQuery, EMPTY_GRID_QUERY, type GridQueryState } from '@/shared/lib/appTableGridQuery';
import { resolveDataGridTotalCount, sliceDataGridRowsForDisplay, buildDataGridPageNumbers } from '@/domain/component-designer/designerDataGridRuntime';
import { applyDesignerGridToolbarClientFilters } from '@/domain/component-designer/designerGridToolbarConfig';
import { createDefaultColumnLayout } from '@/shared/lib/appTableGridColumnLayout';
import { AppTableGrid, GridPagingFooter } from '@/shared/ui';
import { Button, Modal, Toast, toast } from '@heroui/react';

const parseApiErrorMessage = async (response: Response): Promise<string> => {
  try {
    const payload = await response.json();
    if (payload && typeof payload === "object") {
      const record = payload as Record<string, unknown>;
      const message = record.message ?? record.error ?? record.detail;
      if (typeof message === "string" && message.trim().length > 0) {
        return message.trim();
      }
    }
  } catch {
    // fall through to status text
  }
  return response.statusText || `Request failed (${response.status})`;
};

const readBindingParamValue = (
  context: Record<string, unknown> | null | undefined,
  dataPath: string,
): unknown => {
  const segments = dataPath.split(".").map((segment) => segment.trim()).filter(Boolean);
  let cursor: unknown = context;
  for (const segment of segments) {
    if (cursor && typeof cursor === "object" && segment in (cursor as Record<string, unknown>)) {
      cursor = (cursor as Record<string, unknown>)[segment];
    } else {
      return undefined;
    }
  }
  return cursor;
};

const resolveBindingTemplateValue = (
  template: string,
  context: Record<string, unknown> | null | undefined,
  paramPaths: Record<string, string>,
): string =>
  template.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, paramName: string) => {
    const dataPath = paramPaths[paramName];
    if (!dataPath) {
      return "";
    }
    const cursor = readBindingParamValue(context, dataPath);
    return cursor === undefined || cursor === null ? "" : String(cursor);
  });

const resolveBindingUrl = (
  endpointTemplate: string,
  context: Record<string, unknown> | null | undefined,
  paramPaths: Record<string, string>,
): string => {
  const usedParamNames = new Set<string>();
  let resolvedPath = endpointTemplate.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, paramName: string) => {
    usedParamNames.add(paramName);
    const dataPath = paramPaths[paramName];
    if (!dataPath) {
      return "";
    }
    const cursor = readBindingParamValue(context, dataPath);
    return cursor === undefined || cursor === null ? "" : String(cursor);
  });
  for (const [paramName, dataPath] of Object.entries(paramPaths)) {
    if (usedParamNames.has(paramName)) {
      continue;
    }
    const colonParamPattern = new RegExp(`:${paramName}(?=/|$)`, "g");
    if (!colonParamPattern.test(resolvedPath)) {
      continue;
    }
    usedParamNames.add(paramName);
    const cursor = readBindingParamValue(context, dataPath);
    const text = cursor === undefined || cursor === null ? "" : String(cursor);
    resolvedPath = resolvedPath.replace(new RegExp(`:${paramName}(?=/|$)`, "g"), text);
  }
  const searchParams = new URLSearchParams();
  for (const [paramName, dataPath] of Object.entries(paramPaths)) {
    if (usedParamNames.has(paramName)) {
      continue;
    }
    const cursor = readBindingParamValue(context, dataPath);
    if (cursor === undefined || cursor === null) {
      continue;
    }
    const text = String(cursor).trim();
    if (text.length === 0) {
      continue;
    }
    searchParams.set(paramName, text);
  }
  const queryString = searchParams.toString();
  if (!queryString) {
    return resolvedPath;
  }
  return resolvedPath.includes("?") ? `${resolvedPath}&${queryString}` : `${resolvedPath}?${queryString}`;
};

const resolveBindingHeaders = (
  context: Record<string, unknown> | null | undefined,
  headerTemplates: Record<string, string>,
  paramPaths: Record<string, string>,
): Record<string, string> =>
  Object.fromEntries(
    Object.entries(headerTemplates).map(([key, template]) => [
      key,
      resolveBindingTemplateValue(template, context, paramPaths),
    ]),
  );

const setNestedPayloadValue = (target: Record<string, unknown>, path: string, value: unknown): void => {
  const segments = path.split(".").map((segment) => segment.trim()).filter(Boolean);
  if (segments.length === 0) {
    return;
  }
  let cursor: Record<string, unknown> = target;
  for (let index = 0; index < segments.length - 1; index += 1) {
    const segment = segments[index];
    const next = cursor[segment];
    if (!next || typeof next !== "object" || Array.isArray(next)) {
      cursor[segment] = {};
    }
    cursor = cursor[segment] as Record<string, unknown>;
  }
  cursor[segments[segments.length - 1]] = value;
};

const mapDesignerListBoxItems = (rawItems: unknown): Array<{ id: string; textValue: string }> => {
  const items = Array.isArray(rawItems) ? rawItems : [];
  return items
    .map((entry) => {
      if (!entry || typeof entry !== "object") {
        return null;
      }
      const record = entry as Record<string, unknown>;
      const id = String(record.id ?? "").trim();
      if (!id || id === "100" || id === "102") {
        return null;
      }
      const textValue = String(record.textValue ?? record.label ?? record.title ?? id).trim();
      return { id, textValue: textValue || id };
    })
    .filter((entry): entry is { id: string; textValue: string } => entry !== null);
};

const mapDesignerLovItems = (
  rawItems: unknown,
  returnColumn: string,
  displayColumn: string,
): Array<{ id: string; textValue: string }> => {
  const items = Array.isArray(rawItems) ? rawItems : [];
  return items
    .map((entry) => {
      if (!entry || typeof entry !== "object") {
        return null;
      }
      const record = entry as Record<string, unknown>;
      const id = String(record[returnColumn] ?? "").trim();
      if (!id) {
        return null;
      }
      const textValue = String(record[displayColumn] ?? id).trim();
      return { id, textValue: textValue || id };
    })
    .filter((entry): entry is { id: string; textValue: string } => entry !== null);
};

const collectRegionFormDataFromContainer = (
  container: ParentNode,
  formFieldNames: readonly string[],
): FormData => {
  const formData = new FormData();
  for (const formFieldName of formFieldNames) {
    const escapedName = formFieldName.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    const field = container.querySelector(`[name="${escapedName}"]`);
    if (!field) {
      continue;
    }
    if (field instanceof HTMLInputElement) {
      if (field.type === "checkbox" || field.type === "radio") {
        formData.set(formFieldName, field.checked ? "true" : "false");
      } else {
        formData.set(formFieldName, field.value);
      }
      continue;
    }
    if (field instanceof HTMLTextAreaElement || field instanceof HTMLSelectElement) {
      formData.set(formFieldName, field.value);
      continue;
    }
    formData.set(formFieldName, field.getAttribute("value") ?? "");
  }
  return formData;
};

const applyPayloadFieldTransform = (value: FormDataEntryValue | null, transform?: string): unknown => {
  const raw = value === null ? "" : String(value);
  switch (transform) {
    case "number": {
      const parsed = Number(raw);
      return Number.isFinite(parsed) ? parsed : raw;
    }
    case "boolean":
      return raw === "true" || raw === "1" || raw === "on";
    case "commaSeparatedArray":
      return raw.split(",").map((entry) => entry.trim()).filter(Boolean);
    default:
      return raw;
  }
};

// --- AUTH / TOKEN LIFECYCLE INJECTION POINT ---
// Register your application-wide 401 interceptor and token refresh handler here before production.
// Example: const designerFetch = createAuthenticatedFetch({ getAccessToken, refreshTokens, onSessionExpired });
const designerFetch: typeof fetch = fetch;

function useDataFetch<T>(url: string, options: { headers?: Record<string, string> } = {}) {
  const [data, setData] = React.useState<T | null>(null);
  const [isLoading, setIsLoading] = React.useState(Boolean(url));
  const [error, setError] = React.useState<string | null>(null);
  const [refreshNonce, setRefreshNonce] = React.useState(0);
  const headersKey = JSON.stringify(options.headers ?? {});

  const refresh = React.useCallback(async () => {
    setRefreshNonce((previous) => previous + 1);
  }, []);

  React.useEffect(() => {
    if (!url) {
      setData(null);
      setIsLoading(false);
      setError(null);
      return undefined;
    }

    let cancelled = false;
    const load = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const response = await designerFetch(url, {
          method: "GET",
          headers: options.headers,
        });
        if (!response.ok) {
          throw new Error(await parseApiErrorMessage(response));
        }
        const payload = (await response.json()) as T;
        if (!cancelled) {
          setData(payload);
        }
      } catch (loadError) {
        if (!cancelled) {
          setData(null);
          setError(loadError instanceof Error ? loadError.message : "Request failed");
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, [url, headersKey, refreshNonce]);

  return { data, isLoading, error, refresh };
}

const readNestedContextValue = (
  context: Record<string, unknown> | null | undefined,
  path: string,
): unknown => {
  const segments = path.split(".").map((segment) => segment.trim()).filter(Boolean);
  let cursor: unknown = context;
  for (const segment of segments) {
    if (cursor && typeof cursor === "object" && segment in (cursor as Record<string, unknown>)) {
      cursor = (cursor as Record<string, unknown>)[segment];
    } else {
      return undefined;
    }
  }
  return cursor;
};

const applyResponseDataPath = (
  payload: unknown,
  responseMapping?: { dataPath?: string; arrayPath?: string },
): unknown => {
  if (!responseMapping) {
    return payload;
  }
  const arrayPath = responseMapping.arrayPath?.trim();
  if (arrayPath) {
    const arrayValue = readNestedContextValue(
      payload && typeof payload === "object" ? payload as Record<string, unknown> : {},
      arrayPath,
    );
    if (Array.isArray(arrayValue)) {
      return arrayValue;
    }
  }
  const dataPath = responseMapping.dataPath?.trim();
  if (!dataPath || !payload || typeof payload !== "object") {
    return payload;
  }
  return readNestedContextValue(payload as Record<string, unknown>, dataPath);
};

const coerceApiRecordValue = (value: unknown): Record<string, unknown> | undefined => {
  if (value === undefined || value === null) {
    return undefined;
  }
  if (Array.isArray(value)) {
    return value.find(
      (entry): entry is Record<string, unknown> =>
        typeof entry === "object" && entry !== null && !Array.isArray(entry),
    );
  }
  if (typeof value === "object") {
    return value as Record<string, unknown>;
  }
  return undefined;
};

const transformApiRowsToChartData = (
  rows: Array<Record<string, unknown>>,
  mapping: { categoryField: string; categoryAs?: string; series: Array<{ apiField: string; seriesKey: string; aggregation?: string }> },
): Array<Record<string, string | number>> => {
  const categoryKey = mapping.categoryAs?.trim() || "label";
  const parseNum = (raw: unknown): number => {
    if (typeof raw === "number" && Number.isFinite(raw)) return raw;
    if (typeof raw === "string") { const p = Number(raw); return Number.isFinite(p) ? p : 0; }
    return 0;
  };
  const aggregate = (values: number[], agg: string): number => {
    if (values.length === 0) return 0;
    if (agg === "count") return values.length;
    if (agg === "avg") return values.reduce((s, v) => s + v, 0) / values.length;
    if (agg === "min") return Math.min(...values);
    if (agg === "max") return Math.max(...values);
    if (agg === "sum") return values.reduce((s, v) => s + v, 0);
    return values[0] ?? 0;
  };
  const needsGrouping = mapping.series.some((s) => s.aggregation && s.aggregation !== "none");
  if (!needsGrouping) {
    return rows.map((row) => {
      const chartRow: Record<string, string | number> = { [categoryKey]: String(row[mapping.categoryField] ?? "") };
      for (const series of mapping.series) { chartRow[series.seriesKey] = parseNum(row[series.apiField]); }
      return chartRow;
    });
  }
  const grouped = new Map<string, Array<Record<string, unknown>>>();
  for (const row of rows) {
    const cat = String(row[mapping.categoryField] ?? "");
    const bucket = grouped.get(cat);
    if (bucket) bucket.push(row); else grouped.set(cat, [row]);
  }
  return Array.from(grouped.entries()).map(([category, groupRows]) => {
    const chartRow: Record<string, string | number> = { [categoryKey]: category };
    for (const series of mapping.series) {
      const values = groupRows.map((r) => parseNum(r[series.apiField]));
      chartRow[series.seriesKey] = aggregate(values, series.aggregation ?? "sum");
    }
    return chartRow;
  });
};

const readVizStringField = (row: Record<string, unknown>, field: string, fallback = ""): string => {
  const value = row[field];
  if (value === undefined || value === null) return fallback;
  return String(value);
};

const transformApiRowsToTreeNodes = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "tree"; idField: string; labelField: string; parentIdField?: string },
): Array<{ id: string; label: string; children?: unknown[] }> => {
  const parentField = mapping.parentIdField?.trim();
  if (!parentField) {
    return rows.map((row, index) => ({
      id: readVizStringField(row, mapping.idField, `node-${index + 1}`),
      label: readVizStringField(row, mapping.labelField, `Item ${index + 1}`),
    }));
  }
  const nodeMap = new Map<string, { id: string; label: string; children: unknown[] }>();
  rows.forEach((row) => {
    const id = readVizStringField(row, mapping.idField);
    if (!id) return;
    nodeMap.set(id, { id, label: readVizStringField(row, mapping.labelField, id), children: [] });
  });
  const roots: Array<{ id: string; label: string; children?: unknown[] }> = [];
  rows.forEach((row) => {
    const id = readVizStringField(row, mapping.idField);
    if (!id) return;
    const node = nodeMap.get(id);
    if (!node) return;
    const parentId = readVizStringField(row, parentField);
    if (parentId && nodeMap.has(parentId)) {
      nodeMap.get(parentId)!.children.push(node);
    } else {
      roots.push(node);
    }
  });
  return roots;
};

const readVizNumberField = (row: Record<string, unknown>, field: string): number | undefined => {
  const value = row[field];
  const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(parsed) ? parsed : undefined;
};

const transformApiRowsToTimelineEvents = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "timeline" | "gantt"; idField?: string; titleField: string; startField: string; endField?: string; descriptionField?: string; progressField?: string },
): Array<{ id?: string; title: string; start: string; end?: string; description?: string; progress?: number }> =>
  rows.map((row, index) => {
    const progress = mapping.progressField ? readVizNumberField(row, mapping.progressField) : undefined;
    return {
      id: mapping.idField ? readVizStringField(row, mapping.idField, `evt-${index + 1}`) : `evt-${index + 1}`,
      title: readVizStringField(row, mapping.titleField, `Event ${index + 1}`),
      start: readVizStringField(row, mapping.startField),
      ...(mapping.endField ? { end: readVizStringField(row, mapping.endField) } : {}),
      ...(mapping.descriptionField ? { description: readVizStringField(row, mapping.descriptionField) } : {}),
      ...(progress !== undefined ? { progress } : {}),
    };
  });

const transformApiRowsToKanbanBoard = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "kanban"; cardIdField: string; cardTitleField: string; cardDescriptionField?: string; cardColumnField: string; columnOrder?: Array<{ id: string; title: string }> },
): { columns: Array<{ id: string; title: string; cards: Array<{ id: string; title: string; description?: string }> }> } => {
  const cardsByColumn = new Map<string, Array<{ id: string; title: string; description?: string }>>();
  rows.forEach((row, index) => {
    const columnKey = readVizStringField(row, mapping.cardColumnField, "default");
    const card = {
      id: readVizStringField(row, mapping.cardIdField, `card-${index + 1}`),
      title: readVizStringField(row, mapping.cardTitleField, `Card ${index + 1}`),
      ...(mapping.cardDescriptionField ? { description: readVizStringField(row, mapping.cardDescriptionField) } : {}),
    };
    cardsByColumn.set(columnKey, [...(cardsByColumn.get(columnKey) ?? []), card]);
  });
  const columnOrder = mapping.columnOrder && mapping.columnOrder.length > 0
    ? mapping.columnOrder
    : Array.from(cardsByColumn.keys()).map((key) => ({ id: key, title: key }));
  const columns = columnOrder.map((columnDef) => ({
    id: columnDef.id,
    title: columnDef.title,
    cards: cardsByColumn.get(columnDef.id) ?? cardsByColumn.get(columnDef.title) ?? [],
  }));
  cardsByColumn.forEach((cards, columnKey) => {
    if (!columns.some((column) => column.id === columnKey || column.title === columnKey)) {
      columns.push({ id: columnKey, title: columnKey, cards });
    }
  });
  return { columns };
};

const transformApiRowsToSheetData = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "sheet"; columns: Array<{ header: string; field: string }> },
): { columns: string[]; rows: string[][] } => ({
  columns: mapping.columns.map((column) => column.header),
  rows: rows.map((row) => mapping.columns.map((column) => readVizStringField(row, column.field))),
});

type EntityPickerOption = { id: string; textValue: string };
type EntityPickerFieldMapping = { returnField: string; displayField: string };

function normalizeEntityPickerItems(payload: unknown, mapping?: EntityPickerFieldMapping): EntityPickerOption[] {
  const returnField = mapping?.returnField?.trim() || "id";
  const displayField = mapping?.displayField?.trim() || "label";
  if (Array.isArray(payload)) {
    return payload
      .map((entry) => {
        if (!entry || typeof entry !== "object") {
          return null;
        }
        const record = entry as Record<string, unknown>;
        const mappedId = record[returnField];
        const id = typeof mappedId === "string" && mappedId.trim()
          ? mappedId.trim()
          : typeof record.id === "string" && record.id.trim()
            ? record.id.trim()
            : typeof record.value === "string" && record.value.trim()
              ? record.value.trim()
              : "";
        const mappedLabel = record[displayField];
        const textValue = typeof mappedLabel === "string" && mappedLabel.trim()
          ? mappedLabel.trim()
          : typeof record.textValue === "string" && record.textValue.trim()
            ? record.textValue.trim()
            : typeof record.label === "string" && record.label.trim()
              ? record.label.trim()
              : typeof record.name === "string" && record.name.trim()
                ? record.name.trim()
                : id;
        if (!id || !textValue) {
          return null;
        }
        return { id, textValue };
      })
      .filter((entry): entry is EntityPickerOption => entry !== null);
  }

  if (payload && typeof payload === "object") {
    const record = payload as Record<string, unknown>;
    const items = record.items ?? record.results ?? record.data;
    return normalizeEntityPickerItems(items, mapping);
  }

  return [];
}

function useEntityPickerOptions(entityRef: string, searchParam: string, mapping?: EntityPickerFieldMapping) {
  const [items, setItems] = React.useState<EntityPickerOption[]>([]);
  const [isLoading, setIsLoading] = React.useState(false);

  const loadOptions = React.useCallback(async (query: string) => {
    if (!entityRef) {
      setItems([]);
      return;
    }

    setIsLoading(true);
    try {
      const url = entityRef.startsWith("http")
        ? new URL(entityRef)
        : new URL(entityRef, window.location.origin);
      // Option A (parity audit items 31/32): Autocomplete is Select-based — no live typing.
      // Still honour an explicit non-empty query if a caller passes one, but initial load uses "".
      if (query.trim()) {
        url.searchParams.set(searchParam, query);
      }
      const response = await fetch(url.toString());
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      const payload = await response.json();
      setItems(normalizeEntityPickerItems(payload, mapping));
    } catch {
      setItems([]);
    } finally {
      setIsLoading(false);
    }
  }, [entityRef, searchParam, mapping?.returnField, mapping?.displayField]);

  React.useEffect(() => {
    void loadOptions("");
  }, [loadOptions]);

  return { items, isLoading, loadOptions };
}
function useDesignerStore<T extends Record<string, unknown>>(initial: T) {
  const [store, setStore] = React.useState<T>(initial);
  const patch = React.useCallback((path: string, value: unknown) => {
    setStore((previous) => {
      const next = { ...previous };
      setNestedPayloadValue(next, path, value);
      return next as T;
    });
  }, []);
  return { store, patch };
}
function evaluateDesignerCondition(
  designerStore: Record<string, unknown>,
  dataContext: Record<string, unknown> | null,
  scope: { item?: unknown; index?: number },
  condition: string,
): boolean {
  const trimmed = condition.trim();
  if (!trimmed) {
    return true;
  }
  try {
    const formatPathChain = (root: string, path: string): string => {
      const chain = path
        .split('.')
        .filter(Boolean)
        .map((segment) => {
          if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(segment)) {
            return `?.${segment}`;
          }
          return `?.[${JSON.stringify(segment)}]`;
        })
        .join('');
      return `(${root}${chain})`;
    };
    let compiled = trimmed
      .replace(/\bstore\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('designerStore', path))
      .replace(/\bdata\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('dataContext', path))
      .replace(/\bdataContext\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('dataContext', path));
    const evaluator = new Function('designerStore', 'dataContext', 'item', 'index', `return Boolean(${compiled});`);
    return Boolean(evaluator(designerStore, dataContext, scope.item, scope.index));
  } catch {
    return false;
  }
}

export const GeneratedComponent: React.FC = () => {
  const { store: designerStore, patch: patchDesignerStore } = useDesignerStore<Record<string, unknown>>({"selection":{"id":null}});
  const handleGridRowAction_heroui_app_table_grid_1785520942124_65mkc = React.useCallback((row: Record<string, unknown>, actionId: string) => {
    switch (actionId) {
      case "approve": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-74261e60-c42b-48b9-87e0-d7f22cde62c7", true);
        return;
      }
      case "reject": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-db122a3a-5015-4504-a65d-87b68b67abfc", true);
        return;
      }
      case "spam": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-b7c9ec15-22f8-4305-ab31-f39b4efe3946", true);
        return;
      }
      case "delete": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-3d800c2a-5398-4a47-a6b6-ccf19ef99889", true);
        return;
      }
      default:
        return;
    }
  }, [patchDesignerStore]);
  const { data: raw_gridData_heroui_app_table_grid_1785520942124_65mkc, isLoading: isLoading_gridData_heroui_app_table_grid_1785520942124_65mkc, error: error_gridData_heroui_app_table_grid_1785520942124_65mkc, refresh: refresh_gridData_heroui_app_table_grid_1785520942124_65mkc } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/comments", designerStore, { "search": "gridToolbar.search", "statusCode": "gridToolbar.filters.statusCode", "sortBy": "gridQuery.sortBy", "sortDir": "gridQuery.sortDir", "page": "gridQuery.page", "pageSize": "gridQuery.pageSize", "body": "gridQuery.filters.body", "authorDisplayName": "gridQuery.filters.authorDisplayName", "createdAtFrom": "gridQuery.filters.createdAt.from", "createdAtTo": "gridQuery.filters.createdAt.to", "view": "static:summary" }), {});
  const gridData_heroui_app_table_grid_1785520942124_65mkc = React.useMemo(() => applyResponseDataPath(raw_gridData_heroui_app_table_grid_1785520942124_65mkc, {"dataPath":"data","arrayPath":"data","totalPath":"count"}), [raw_gridData_heroui_app_table_grid_1785520942124_65mkc]);
  const gridColumns_heroui_app_table_grid_1785520942124_65mkc = React.useMemo(() => buildAppTableGridColumns([{"key":"body","label":"Comment","sort":true,"filter":true,"filterType":"text","cardRole":"title"},{"key":"authorDisplayName","label":"Author","sort":true,"filter":true,"filterType":"text","cardRole":"field"},{"key":"contentTitle","label":"Content","cellKind":"link","cellFields":{"labelField":"contentTitle","labelFallbackField":"contentId","hrefTemplate":"/studio/cms/contents/edit/{contentId}"},"cardRole":"field"},{"key":"statusCode","label":"Status","sort":true,"cellKind":"status-badge","cellFields":{"labelField":"statusCodeTitle","labelFallbackField":"statusCode","htmlField":"statusCodeUiHtml"},"cardRole":"meta"},{"key":"createdAt","label":"Created","sort":true,"filter":true,"filterType":"dateRange","cellKind":"date","cardRole":"meta"},{"key":"actions","label":"","kind":"action-group","actions":[{"actionId":"approve","icon":"BadgeCheck","intent":"utility","tooltip":"Approve","behavior":{"kind":"open-modal","modalNodeId":"node-74261e60-c42b-48b9-87e0-d7f22cde62c7","primaryKeyField":"id","selectionStorePath":"selection.id"},"disabledWhen":{"preset":"expression","expression":"row.statusCode === '101.002.006'"}},{"actionId":"reject","icon":"XCircle","intent":"delete","tooltip":"Reject","behavior":{"kind":"open-modal","modalNodeId":"node-db122a3a-5015-4504-a65d-87b68b67abfc","primaryKeyField":"id","selectionStorePath":"selection.id"},"disabledWhen":{"preset":"expression","expression":"row.statusCode === '101.002.007'"}},{"actionId":"spam","icon":"ShieldAlert","intent":"warning","tooltip":"Mark as spam","behavior":{"kind":"open-modal","modalNodeId":"node-b7c9ec15-22f8-4305-ab31-f39b4efe3946","primaryKeyField":"id","selectionStorePath":"selection.id"},"disabledWhen":{"preset":"expression","expression":"row.statusCode === '101.002.008'"}},{"actionId":"delete","icon":"Trash2","intent":"delete","tooltip":"Delete","behavior":{"kind":"open-modal","modalNodeId":"node-3d800c2a-5398-4a47-a6b6-ccf19ef99889","primaryKeyField":"id","selectionStorePath":"selection.id"}}],"cardRole":"actions","layoutHideable":false,"layoutResizable":false,"layoutReorderable":false,"width":"140px"}], "server", {
    mode: 'runtime',
    detailFlowRef: { current: null },
    rowActionHandlerRef: { current: handleGridRowAction_heroui_app_table_grid_1785520942124_65mkc },
    cellClickHandlerRef: { current: undefined },
    designerStoreRef: { current: designerStore },
  }), [designerStore, handleGridRowAction_heroui_app_table_grid_1785520942124_65mkc]);
  const [gridQuery_heroui_app_table_grid_1785520942124_65mkc, setGridQuery_heroui_app_table_grid_1785520942124_65mkc] = React.useState<GridQueryState>(() => ({ ...EMPTY_GRID_QUERY, sort: { columnId: "createdAt", direction: 'asc' } }));
  const [gridPage_heroui_app_table_grid_1785520942124_65mkc, setGridPage_heroui_app_table_grid_1785520942124_65mkc] = React.useState(1);
  const [gridPageSize_heroui_app_table_grid_1785520942124_65mkc, setGridPageSize_heroui_app_table_grid_1785520942124_65mkc] = React.useState(50);
  const [gridListMode_heroui_app_table_grid_1785520942124_65mkc, setGridListMode_heroui_app_table_grid_1785520942124_65mkc] = React.useState<'paging' | 'infinite'>("paging");
  const [gridColumnLayout_heroui_app_table_grid_1785520942124_65mkc, setGridColumnLayout_heroui_app_table_grid_1785520942124_65mkc] = React.useState(() => createDefaultColumnLayout(gridColumns_heroui_app_table_grid_1785520942124_65mkc));
  const [gridSearchInput_heroui_app_table_grid_1785520942124_65mkc, setGridSearchInput_heroui_app_table_grid_1785520942124_65mkc] = React.useState('');
  const [gridDebouncedSearch_heroui_app_table_grid_1785520942124_65mkc, setGridDebouncedSearch_heroui_app_table_grid_1785520942124_65mkc] = React.useState('');
  const [gridRoleFilters_heroui_app_table_grid_1785520942124_65mkc, setGridRoleFilters_heroui_app_table_grid_1785520942124_65mkc] = React.useState<Record<string, boolean>>({});
  const gridFilteredRows_heroui_app_table_grid_1785520942124_65mkc = React.useMemo(() => applyClientGridQuery(((Array.isArray(gridData_heroui_app_table_grid_1785520942124_65mkc?.data) ? gridData_heroui_app_table_grid_1785520942124_65mkc?.data : []) ?? []), gridQuery_heroui_app_table_grid_1785520942124_65mkc, gridColumns_heroui_app_table_grid_1785520942124_65mkc, "server"), [gridQuery_heroui_app_table_grid_1785520942124_65mkc, gridColumns_heroui_app_table_grid_1785520942124_65mkc]);
  const gridApiTotal_heroui_app_table_grid_1785520942124_65mkc = React.useMemo(() => {
    const raw = raw_gridData_heroui_app_table_grid_1785520942124_65mkc;
    const value = readNestedContextValue((raw && typeof raw === 'object' ? raw as Record<string, unknown> : {}), "count");
    const parsed = typeof value === 'number' ? value : Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : 0;
  }, [raw_gridData_heroui_app_table_grid_1785520942124_65mkc]);
  const gridTotalCount_heroui_app_table_grid_1785520942124_65mkc = resolveDataGridTotalCount({ page: gridPage_heroui_app_table_grid_1785520942124_65mkc, pageSize: gridPageSize_heroui_app_table_grid_1785520942124_65mkc, total: gridApiTotal_heroui_app_table_grid_1785520942124_65mkc, gridQueryMode: "server" }, gridFilteredRows_heroui_app_table_grid_1785520942124_65mkc.length);
  const gridPaging_heroui_app_table_grid_1785520942124_65mkc = sliceDataGridRowsForDisplay(gridFilteredRows_heroui_app_table_grid_1785520942124_65mkc, gridPage_heroui_app_table_grid_1785520942124_65mkc, gridPageSize_heroui_app_table_grid_1785520942124_65mkc, gridTotalCount_heroui_app_table_grid_1785520942124_65mkc, "server");
  const handleGridQueryChange_heroui_app_table_grid_1785520942124_65mkc = React.useCallback((nextQuery: GridQueryState) => {
    setGridQuery_heroui_app_table_grid_1785520942124_65mkc(nextQuery);
    setGridPage_heroui_app_table_grid_1785520942124_65mkc(1);
    patchDesignerStore("gridQuery.sortBy", nextQuery.sort?.columnId ?? '');
    patchDesignerStore("gridQuery.sortDir", nextQuery.sort?.direction ?? '');
  }, [patchDesignerStore]);
  const handleGridPageChange_heroui_app_table_grid_1785520942124_65mkc = React.useCallback((nextPage: number) => {
    setGridPage_heroui_app_table_grid_1785520942124_65mkc(nextPage);
    patchDesignerStore("gridQuery.page", nextPage);
  }, [patchDesignerStore]);
  const handleGridPageSizeChange_heroui_app_table_grid_1785520942124_65mkc = React.useCallback((nextSize: number) => {
    setGridPageSize_heroui_app_table_grid_1785520942124_65mkc(nextSize);
    setGridPage_heroui_app_table_grid_1785520942124_65mkc(1);
    patchDesignerStore("gridQuery.pageSize", nextSize);
  }, [patchDesignerStore]);
  const handleGridSortByChange_heroui_app_table_grid_1785520942124_65mkc = React.useCallback((nextSortBy: string) => {
    setGridQuery_heroui_app_table_grid_1785520942124_65mkc((current: GridQueryState) => ({ ...current, sort: nextSortBy ? { columnId: nextSortBy, direction: current.sort?.direction ?? 'asc' } : null }));
  }, []);
  const handleGridToggleSortDirection_heroui_app_table_grid_1785520942124_65mkc = React.useCallback(() => {
    setGridQuery_heroui_app_table_grid_1785520942124_65mkc((current: GridQueryState) => (current.sort ? { ...current, sort: { ...current.sort, direction: current.sort.direction === 'asc' ? 'desc' : 'asc' } } : current));
  }, []);
  const searchDebounceTimer_heroui_app_table_grid_1785520942124_65mkc = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const handleGridSearchChange_heroui_app_table_grid_1785520942124_65mkc = React.useCallback((nextValue: string) => {
    setGridSearchInput_heroui_app_table_grid_1785520942124_65mkc(nextValue);
    if (searchDebounceTimer_heroui_app_table_grid_1785520942124_65mkc.current) {
      clearTimeout(searchDebounceTimer_heroui_app_table_grid_1785520942124_65mkc.current);
    }
    searchDebounceTimer_heroui_app_table_grid_1785520942124_65mkc.current = setTimeout(() => {
      setGridDebouncedSearch_heroui_app_table_grid_1785520942124_65mkc(nextValue);
      setGridPage_heroui_app_table_grid_1785520942124_65mkc(1);
      patchDesignerStore("gridToolbar.search", nextValue);
    }, 300);
  }, [patchDesignerStore]);

  const dataContext: Record<string, unknown> | null = null;
  const handleonClick_node_8366b1c3_7963_4de7_becc_2e247db499c7 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-3d800c2a-5398-4a47-a6b6-ccf19ef99889", false);
  }, [patchDesignerStore]);
  const handleonClick_node_e4e67fb2_08ff_451b_b1a6_b9fe5774452d = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_ms992gby_onvua = true;
      try {
        const response = await designerFetch(("/api/cms/comments/" + encodeURIComponent(String(designerStore?.selection?.id)) + ""), {
          method: "DELETE",
          headers: { 'Content-Type': 'application/json' },
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_ms992gby_onvua = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_ms992gby_onvua = false;
      }
      if (mutationOk_da_ms992gby_onvua) {
        patchDesignerStore("ui.visibility.node-3d800c2a-5398-4a47-a6b6-ccf19ef99889", false);
        toast("Deleted", { variant: "success", timeout: 4000 });
        await refresh_gridData_heroui_app_table_grid_1785520942124_65mkc();
      }
    })();
  }, [patchDesignerStore, refresh_gridData_heroui_app_table_grid_1785520942124_65mkc]);
  const handleonClick_node_cc06a41f_ea44_46bf_ba13_34aeba263b8d = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-74261e60-c42b-48b9-87e0-d7f22cde62c7", false);
  }, [patchDesignerStore]);
  const handleonClick_node_5070ed52_2126_4026_99d2_d8bd1d1eaea3 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_ms992gby_w4yy2 = true;
      try {
        const response = await designerFetch(("/api/cms/comments/" + encodeURIComponent(String(designerStore?.selection?.id)) + ""), {
          method: "PUT",
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({"statusCode":"101.002.006"}),
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_ms992gby_w4yy2 = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_ms992gby_w4yy2 = false;
      }
      if (mutationOk_da_ms992gby_w4yy2) {
        patchDesignerStore("ui.visibility.node-74261e60-c42b-48b9-87e0-d7f22cde62c7", false);
        toast("Comment approved", { variant: "success", timeout: 4000 });
        await refresh_gridData_heroui_app_table_grid_1785520942124_65mkc();
      }
    })();
  }, [patchDesignerStore, refresh_gridData_heroui_app_table_grid_1785520942124_65mkc]);
  const handleonClick_node_6b4838cc_869e_42b6_8c37_75009423ac23 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-db122a3a-5015-4504-a65d-87b68b67abfc", false);
  }, [patchDesignerStore]);
  const handleonClick_node_a8720662_2d5f_4da5_92fa_d98ad37b2c94 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_ms992gby_jltqd = true;
      try {
        const response = await designerFetch(("/api/cms/comments/" + encodeURIComponent(String(designerStore?.selection?.id)) + ""), {
          method: "PUT",
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({"statusCode":"101.002.007"}),
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_ms992gby_jltqd = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_ms992gby_jltqd = false;
      }
      if (mutationOk_da_ms992gby_jltqd) {
        patchDesignerStore("ui.visibility.node-db122a3a-5015-4504-a65d-87b68b67abfc", false);
        toast("Comment rejected", { variant: "success", timeout: 4000 });
        await refresh_gridData_heroui_app_table_grid_1785520942124_65mkc();
      }
    })();
  }, [patchDesignerStore, refresh_gridData_heroui_app_table_grid_1785520942124_65mkc]);
  const handleonClick_node_a4cd25de_3c3b_446a_9e9a_80770e060d9f = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-b7c9ec15-22f8-4305-ab31-f39b4efe3946", false);
  }, [patchDesignerStore]);
  const handleonClick_node_9e9b462b_fe1a_49b1_afd2_304d0d75081f = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_ms992gbz_qrglb = true;
      try {
        const response = await designerFetch(("/api/cms/comments/" + encodeURIComponent(String(designerStore?.selection?.id)) + ""), {
          method: "PUT",
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({"statusCode":"101.002.008"}),
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_ms992gbz_qrglb = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_ms992gbz_qrglb = false;
      }
      if (mutationOk_da_ms992gbz_qrglb) {
        patchDesignerStore("ui.visibility.node-b7c9ec15-22f8-4305-ab31-f39b4efe3946", false);
        toast("Comment marked as spam", { variant: "success", timeout: 4000 });
        await refresh_gridData_heroui_app_table_grid_1785520942124_65mkc();
      }
    })();
  }, [patchDesignerStore, refresh_gridData_heroui_app_table_grid_1785520942124_65mkc]);
  return (
    <>
      <Toast.Provider />
      <div className="space-y-3">
        <div className="flex w-full flex-col gap-2"><div className="flex items-center justify-between gap-2 border-b border-slate-200 bg-white px-2 py-1.5"><div className="flex items-center gap-2"><input type="text" value={gridSearchInput_heroui_app_table_grid_1785520942124_65mkc} onChange={(event) => handleGridSearchChange_heroui_app_table_grid_1785520942124_65mkc(event.target.value)} placeholder={"Search comments…"} className="h-8 rounded-md border border-slate-200 px-2 text-sm" /></div><div className="flex items-center gap-2"><button type="button" onClick={() => { void refresh_gridData_heroui_app_table_grid_1785520942124_65mkc(); }} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 px-3 text-xs font-medium text-slate-700 hover:bg-slate-50">Refresh</button></div></div><AppTableGrid className="flex h-full min-h-0 w-full flex-1 flex-col" presentation="auto" cardBelow="phone" cardVariant="list" columns={gridColumns_heroui_app_table_grid_1785520942124_65mkc} rows={gridPaging_heroui_app_table_grid_1785520942124_65mkc.displayRows} getRowKey={(row) => String((row as Record<string, unknown>)["id"] ?? '')} enableColumnLayout={false} columnLayout={gridColumnLayout_heroui_app_table_grid_1785520942124_65mkc} onColumnLayoutChange={setGridColumnLayout_heroui_app_table_grid_1785520942124_65mkc} isLoading={false} loadingMessage={"Loading comments…"} emptyMessage={"No comments found."} isEmpty={gridFilteredRows_heroui_app_table_grid_1785520942124_65mkc.length === 0} errorContent={gridFilteredRows_heroui_app_table_grid_1785520942124_65mkc.length === 0 ? undefined : "Could not load comments."} gridQueryMode={"server"} query={gridQuery_heroui_app_table_grid_1785520942124_65mkc} onQueryChange={handleGridQueryChange_heroui_app_table_grid_1785520942124_65mkc} onGridRowAction={handleGridRowAction_heroui_app_table_grid_1785520942124_65mkc} footer={<GridPagingFooter totalCount={gridTotalCount_heroui_app_table_grid_1785520942124_65mkc} safePage={gridPaging_heroui_app_table_grid_1785520942124_65mkc.safePage} pageSize={gridPageSize_heroui_app_table_grid_1785520942124_65mkc} onPageSizeChange={handleGridPageSizeChange_heroui_app_table_grid_1785520942124_65mkc} sortBy={gridQuery_heroui_app_table_grid_1785520942124_65mkc.sort?.columnId ?? ''} sortOptions={[{"value":"body","label":"Comment"},{"value":"authorDisplayName","label":"Author"},{"value":"statusCode","label":"Status"},{"value":"createdAt","label":"Created"}]} onSortByChange={handleGridSortByChange_heroui_app_table_grid_1785520942124_65mkc} sortDirection={gridQuery_heroui_app_table_grid_1785520942124_65mkc.sort?.direction ?? 'asc'} onToggleSortDirection={handleGridToggleSortDirection_heroui_app_table_grid_1785520942124_65mkc} showSortControls={false} totalPages={gridPaging_heroui_app_table_grid_1785520942124_65mkc.totalPages} pageNumbers={buildDataGridPageNumbers(gridPaging_heroui_app_table_grid_1785520942124_65mkc.safePage, gridPaging_heroui_app_table_grid_1785520942124_65mkc.totalPages)} onPageChange={handleGridPageChange_heroui_app_table_grid_1785520942124_65mkc} visibleInfiniteCount={gridListMode_heroui_app_table_grid_1785520942124_65mkc === 'infinite' ? gridPaging_heroui_app_table_grid_1785520942124_65mkc.displayRows.length : undefined} />} /></div>
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-3d800c2a-5398-4a47-a6b6-ccf19ef99889 === true) && (store.ui.visibility.node-3d800c2a-5398-4a47-a6b6-ccf19ef99889 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-3d800c2a-5398-4a47-a6b6-ccf19ef99889"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-3d800c2a-5398-4a47-a6b6-ccf19ef99889", false); } }} variant="blur"><Modal.Container><Modal.Dialog role="alertdialog" className="w-full max-w-md overflow-hidden rounded-xl border border-rose-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-rose-200 bg-rose-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-rose-800">Delete comment?</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-3d800c2a-5398-4a47-a6b6-ccf19ef99889", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <p className="block bg-white p-[15px] text-sm text-slate-700">Delete this comment? This cannot be undone.</p>
          <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
            <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_node_8366b1c3_7963_4de7_becc_2e247db499c7}>Cancel</Button>
            <Button icon="Trash2" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-rose-600 px-3 text-xs font-semibold text-white hover:bg-rose-700" variant="primary" size="md" href="#" target="_self" onClick={handleonClick_node_e4e67fb2_08ff_451b_b1a6_b9fe5774452d}>Delete</Button>
          </div>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-74261e60-c42b-48b9-87e0-d7f22cde62c7 === true) && (store.ui.visibility.node-74261e60-c42b-48b9-87e0-d7f22cde62c7 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-74261e60-c42b-48b9-87e0-d7f22cde62c7"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-74261e60-c42b-48b9-87e0-d7f22cde62c7", false); } }} variant="blur"><Modal.Container><Modal.Dialog role="alertdialog" className="w-full max-w-md overflow-hidden rounded-xl border border-rose-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-rose-200 bg-rose-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-rose-800">Approve comment?</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-74261e60-c42b-48b9-87e0-d7f22cde62c7", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <p className="block bg-white p-[15px] text-sm leading-relaxed text-slate-700">Approve this comment and make it available to public delivery?</p>
          <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
            <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_node_cc06a41f_ea44_46bf_ba13_34aeba263b8d}>Cancel</Button>
            <Button icon="Check" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" variant="primary" size="md" href="#" target="_self" onClick={handleonClick_node_5070ed52_2126_4026_99d2_d8bd1d1eaea3}>Approve</Button>
          </div>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-db122a3a-5015-4504-a65d-87b68b67abfc === true) && (store.ui.visibility.node-db122a3a-5015-4504-a65d-87b68b67abfc !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-db122a3a-5015-4504-a65d-87b68b67abfc"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-db122a3a-5015-4504-a65d-87b68b67abfc", false); } }} variant="blur"><Modal.Container><Modal.Dialog role="alertdialog" className="w-full max-w-md overflow-hidden rounded-xl border border-rose-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-rose-200 bg-rose-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-rose-800">Reject comment?</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-db122a3a-5015-4504-a65d-87b68b67abfc", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <p className="block bg-white p-[15px] text-sm leading-relaxed text-slate-700">Reject this comment? It will remain hidden from public delivery.</p>
          <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
            <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_node_6b4838cc_869e_42b6_8c37_75009423ac23}>Cancel</Button>
            <Button icon="Check" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" variant="primary" size="md" href="#" target="_self" onClick={handleonClick_node_a8720662_2d5f_4da5_92fa_d98ad37b2c94}>Reject</Button>
          </div>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-b7c9ec15-22f8-4305-ab31-f39b4efe3946 === true) && (store.ui.visibility.node-b7c9ec15-22f8-4305-ab31-f39b4efe3946 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-b7c9ec15-22f8-4305-ab31-f39b4efe3946"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-b7c9ec15-22f8-4305-ab31-f39b4efe3946", false); } }} variant="blur"><Modal.Container><Modal.Dialog role="alertdialog" className="w-full max-w-md overflow-hidden rounded-xl border border-rose-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-rose-200 bg-rose-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-rose-800">Mark as spam?</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-b7c9ec15-22f8-4305-ab31-f39b4efe3946", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <p className="block bg-white p-[15px] text-sm leading-relaxed text-slate-700">Mark this comment as spam? It will remain hidden from public delivery.</p>
          <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
            <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_node_a4cd25de_3c3b_446a_9e9a_80770e060d9f}>Cancel</Button>
            <Button icon="Check" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" variant="primary" size="md" href="#" target="_self" onClick={handleonClick_node_9e9b462b_fe1a_49b1_afd2_304d0d75081f}>Mark as spam</Button>
          </div>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
      </div>
    </>
  );
};
export default GeneratedComponent;
