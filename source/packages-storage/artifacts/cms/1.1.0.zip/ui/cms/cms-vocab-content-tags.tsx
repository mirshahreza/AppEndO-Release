import React from 'react';
import { buildAppTableGridColumns } from '@/domain/component-designer/DesignerRuntimeAppTableGrid';
import { applyClientGridQuery, EMPTY_GRID_QUERY, type GridQueryState } from '@/shared/lib/appTableGridQuery';
import { resolveDataGridTotalCount, sliceDataGridRowsForDisplay, buildDataGridPageNumbers } from '@/domain/component-designer/designerDataGridRuntime';
import { applyDesignerGridToolbarClientFilters } from '@/domain/component-designer/designerGridToolbarConfig';
import { createDefaultColumnLayout } from '@/shared/lib/appTableGridColumnLayout';
import { validateDesignerFieldNode } from '@/domain/component-designer/previewFieldValidation';
import { AppTableGrid, GridPagingFooter } from '@/shared/ui';
import { UiInput } from '@/shared/ui/HeroFieldControls';
import { Button, Modal, Switch, Toast, toast } from '@heroui/react';

const parseApiErrorMessage = async (response: Response): Promise<string> => {
  try {
    const payload = await response.json();
    if (payload && typeof payload === "object") {
      const record = payload as Record<string, unknown>;
      const message = record.message ?? record.error ?? record.detail;
      if (typeof message === "string" && message.trim().length > 0) {
        return message.trim();
      }
    }
  } catch {
    // fall through to status text
  }
  return response.statusText || `Request failed (${response.status})`;
};

const readBindingParamValue = (
  context: Record<string, unknown> | null | undefined,
  dataPath: string,
): unknown => {
  const segments = dataPath.split(".").map((segment) => segment.trim()).filter(Boolean);
  let cursor: unknown = context;
  for (const segment of segments) {
    if (cursor && typeof cursor === "object" && segment in (cursor as Record<string, unknown>)) {
      cursor = (cursor as Record<string, unknown>)[segment];
    } else {
      return undefined;
    }
  }
  return cursor;
};

const resolveBindingTemplateValue = (
  template: string,
  context: Record<string, unknown> | null | undefined,
  paramPaths: Record<string, string>,
): string =>
  template.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, paramName: string) => {
    const dataPath = paramPaths[paramName];
    if (!dataPath) {
      return "";
    }
    const cursor = readBindingParamValue(context, dataPath);
    return cursor === undefined || cursor === null ? "" : String(cursor);
  });

const resolveBindingUrl = (
  endpointTemplate: string,
  context: Record<string, unknown> | null | undefined,
  paramPaths: Record<string, string>,
): string => {
  const usedParamNames = new Set<string>();
  let resolvedPath = endpointTemplate.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, paramName: string) => {
    usedParamNames.add(paramName);
    const dataPath = paramPaths[paramName];
    if (!dataPath) {
      return "";
    }
    const cursor = readBindingParamValue(context, dataPath);
    return cursor === undefined || cursor === null ? "" : String(cursor);
  });
  for (const [paramName, dataPath] of Object.entries(paramPaths)) {
    if (usedParamNames.has(paramName)) {
      continue;
    }
    const colonParamPattern = new RegExp(`:${paramName}(?=/|$)`, "g");
    if (!colonParamPattern.test(resolvedPath)) {
      continue;
    }
    usedParamNames.add(paramName);
    const cursor = readBindingParamValue(context, dataPath);
    const text = cursor === undefined || cursor === null ? "" : String(cursor);
    resolvedPath = resolvedPath.replace(new RegExp(`:${paramName}(?=/|$)`, "g"), text);
  }
  const searchParams = new URLSearchParams();
  for (const [paramName, dataPath] of Object.entries(paramPaths)) {
    if (usedParamNames.has(paramName)) {
      continue;
    }
    const cursor = readBindingParamValue(context, dataPath);
    if (cursor === undefined || cursor === null) {
      continue;
    }
    const text = String(cursor).trim();
    if (text.length === 0) {
      continue;
    }
    searchParams.set(paramName, text);
  }
  const queryString = searchParams.toString();
  if (!queryString) {
    return resolvedPath;
  }
  return resolvedPath.includes("?") ? `${resolvedPath}&${queryString}` : `${resolvedPath}?${queryString}`;
};

const resolveBindingHeaders = (
  context: Record<string, unknown> | null | undefined,
  headerTemplates: Record<string, string>,
  paramPaths: Record<string, string>,
): Record<string, string> =>
  Object.fromEntries(
    Object.entries(headerTemplates).map(([key, template]) => [
      key,
      resolveBindingTemplateValue(template, context, paramPaths),
    ]),
  );

const setNestedPayloadValue = (target: Record<string, unknown>, path: string, value: unknown): void => {
  const segments = path.split(".").map((segment) => segment.trim()).filter(Boolean);
  if (segments.length === 0) {
    return;
  }
  let cursor: Record<string, unknown> = target;
  for (let index = 0; index < segments.length - 1; index += 1) {
    const segment = segments[index];
    const next = cursor[segment];
    if (!next || typeof next !== "object" || Array.isArray(next)) {
      cursor[segment] = {};
    }
    cursor = cursor[segment] as Record<string, unknown>;
  }
  cursor[segments[segments.length - 1]] = value;
};

const mapDesignerListBoxItems = (rawItems: unknown): Array<{ id: string; textValue: string }> => {
  const items = Array.isArray(rawItems) ? rawItems : [];
  return items
    .map((entry) => {
      if (!entry || typeof entry !== "object") {
        return null;
      }
      const record = entry as Record<string, unknown>;
      const id = String(record.id ?? "").trim();
      if (!id || id === "100" || id === "102") {
        return null;
      }
      const textValue = String(record.textValue ?? record.label ?? record.title ?? id).trim();
      return { id, textValue: textValue || id };
    })
    .filter((entry): entry is { id: string; textValue: string } => entry !== null);
};

const mapDesignerLovItems = (
  rawItems: unknown,
  returnColumn: string,
  displayColumn: string,
): Array<{ id: string; textValue: string }> => {
  const items = Array.isArray(rawItems) ? rawItems : [];
  return items
    .map((entry) => {
      if (!entry || typeof entry !== "object") {
        return null;
      }
      const record = entry as Record<string, unknown>;
      const id = String(record[returnColumn] ?? "").trim();
      if (!id) {
        return null;
      }
      const textValue = String(record[displayColumn] ?? id).trim();
      return { id, textValue: textValue || id };
    })
    .filter((entry): entry is { id: string; textValue: string } => entry !== null);
};

const collectRegionFormDataFromContainer = (
  container: ParentNode,
  formFieldNames: readonly string[],
): FormData => {
  const formData = new FormData();
  for (const formFieldName of formFieldNames) {
    const escapedName = formFieldName.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    const field = container.querySelector(`[name="${escapedName}"]`);
    if (!field) {
      continue;
    }
    if (field instanceof HTMLInputElement) {
      if (field.type === "checkbox" || field.type === "radio") {
        formData.set(formFieldName, field.checked ? "true" : "false");
      } else {
        formData.set(formFieldName, field.value);
      }
      continue;
    }
    if (field instanceof HTMLTextAreaElement || field instanceof HTMLSelectElement) {
      formData.set(formFieldName, field.value);
      continue;
    }
    formData.set(formFieldName, field.getAttribute("value") ?? "");
  }
  return formData;
};

const applyPayloadFieldTransform = (value: FormDataEntryValue | null, transform?: string): unknown => {
  const raw = value === null ? "" : String(value);
  switch (transform) {
    case "number": {
      const parsed = Number(raw);
      return Number.isFinite(parsed) ? parsed : raw;
    }
    case "boolean":
      return raw === "true" || raw === "1" || raw === "on";
    case "commaSeparatedArray":
      return raw.split(",").map((entry) => entry.trim()).filter(Boolean);
    default:
      return raw;
  }
};

// --- AUTH / TOKEN LIFECYCLE INJECTION POINT ---
// Register your application-wide 401 interceptor and token refresh handler here before production.
// Example: const designerFetch = createAuthenticatedFetch({ getAccessToken, refreshTokens, onSessionExpired });
const designerFetch: typeof fetch = fetch;

function useDataFetch<T>(url: string, options: { headers?: Record<string, string> } = {}) {
  const [data, setData] = React.useState<T | null>(null);
  const [isLoading, setIsLoading] = React.useState(Boolean(url));
  const [error, setError] = React.useState<string | null>(null);
  const [refreshNonce, setRefreshNonce] = React.useState(0);
  const headersKey = JSON.stringify(options.headers ?? {});

  const refresh = React.useCallback(async () => {
    setRefreshNonce((previous) => previous + 1);
  }, []);

  React.useEffect(() => {
    if (!url) {
      setData(null);
      setIsLoading(false);
      setError(null);
      return undefined;
    }

    let cancelled = false;
    const load = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const response = await designerFetch(url, {
          method: "GET",
          headers: options.headers,
        });
        if (!response.ok) {
          throw new Error(await parseApiErrorMessage(response));
        }
        const payload = (await response.json()) as T;
        if (!cancelled) {
          setData(payload);
        }
      } catch (loadError) {
        if (!cancelled) {
          setData(null);
          setError(loadError instanceof Error ? loadError.message : "Request failed");
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, [url, headersKey, refreshNonce]);

  return { data, isLoading, error, refresh };
}

const readNestedContextValue = (
  context: Record<string, unknown> | null | undefined,
  path: string,
): unknown => {
  const segments = path.split(".").map((segment) => segment.trim()).filter(Boolean);
  let cursor: unknown = context;
  for (const segment of segments) {
    if (cursor && typeof cursor === "object" && segment in (cursor as Record<string, unknown>)) {
      cursor = (cursor as Record<string, unknown>)[segment];
    } else {
      return undefined;
    }
  }
  return cursor;
};

const applyResponseDataPath = (
  payload: unknown,
  responseMapping?: { dataPath?: string; arrayPath?: string },
): unknown => {
  if (!responseMapping) {
    return payload;
  }
  const arrayPath = responseMapping.arrayPath?.trim();
  if (arrayPath) {
    const arrayValue = readNestedContextValue(
      payload && typeof payload === "object" ? payload as Record<string, unknown> : {},
      arrayPath,
    );
    if (Array.isArray(arrayValue)) {
      return arrayValue;
    }
  }
  const dataPath = responseMapping.dataPath?.trim();
  if (!dataPath || !payload || typeof payload !== "object") {
    return payload;
  }
  return readNestedContextValue(payload as Record<string, unknown>, dataPath);
};

const coerceApiRecordValue = (value: unknown): Record<string, unknown> | undefined => {
  if (value === undefined || value === null) {
    return undefined;
  }
  if (Array.isArray(value)) {
    return value.find(
      (entry): entry is Record<string, unknown> =>
        typeof entry === "object" && entry !== null && !Array.isArray(entry),
    );
  }
  if (typeof value === "object") {
    return value as Record<string, unknown>;
  }
  return undefined;
};

const transformApiRowsToChartData = (
  rows: Array<Record<string, unknown>>,
  mapping: { categoryField: string; categoryAs?: string; series: Array<{ apiField: string; seriesKey: string; aggregation?: string }> },
): Array<Record<string, string | number>> => {
  const categoryKey = mapping.categoryAs?.trim() || "label";
  const parseNum = (raw: unknown): number => {
    if (typeof raw === "number" && Number.isFinite(raw)) return raw;
    if (typeof raw === "string") { const p = Number(raw); return Number.isFinite(p) ? p : 0; }
    return 0;
  };
  const aggregate = (values: number[], agg: string): number => {
    if (values.length === 0) return 0;
    if (agg === "count") return values.length;
    if (agg === "avg") return values.reduce((s, v) => s + v, 0) / values.length;
    if (agg === "min") return Math.min(...values);
    if (agg === "max") return Math.max(...values);
    if (agg === "sum") return values.reduce((s, v) => s + v, 0);
    return values[0] ?? 0;
  };
  const needsGrouping = mapping.series.some((s) => s.aggregation && s.aggregation !== "none");
  if (!needsGrouping) {
    return rows.map((row) => {
      const chartRow: Record<string, string | number> = { [categoryKey]: String(row[mapping.categoryField] ?? "") };
      for (const series of mapping.series) { chartRow[series.seriesKey] = parseNum(row[series.apiField]); }
      return chartRow;
    });
  }
  const grouped = new Map<string, Array<Record<string, unknown>>>();
  for (const row of rows) {
    const cat = String(row[mapping.categoryField] ?? "");
    const bucket = grouped.get(cat);
    if (bucket) bucket.push(row); else grouped.set(cat, [row]);
  }
  return Array.from(grouped.entries()).map(([category, groupRows]) => {
    const chartRow: Record<string, string | number> = { [categoryKey]: category };
    for (const series of mapping.series) {
      const values = groupRows.map((r) => parseNum(r[series.apiField]));
      chartRow[series.seriesKey] = aggregate(values, series.aggregation ?? "sum");
    }
    return chartRow;
  });
};

const readVizStringField = (row: Record<string, unknown>, field: string, fallback = ""): string => {
  const value = row[field];
  if (value === undefined || value === null) return fallback;
  return String(value);
};

const transformApiRowsToTreeNodes = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "tree"; idField: string; labelField: string; parentIdField?: string },
): Array<{ id: string; label: string; children?: unknown[] }> => {
  const parentField = mapping.parentIdField?.trim();
  if (!parentField) {
    return rows.map((row, index) => ({
      id: readVizStringField(row, mapping.idField, `node-${index + 1}`),
      label: readVizStringField(row, mapping.labelField, `Item ${index + 1}`),
    }));
  }
  const nodeMap = new Map<string, { id: string; label: string; children: unknown[] }>();
  rows.forEach((row) => {
    const id = readVizStringField(row, mapping.idField);
    if (!id) return;
    nodeMap.set(id, { id, label: readVizStringField(row, mapping.labelField, id), children: [] });
  });
  const roots: Array<{ id: string; label: string; children?: unknown[] }> = [];
  rows.forEach((row) => {
    const id = readVizStringField(row, mapping.idField);
    if (!id) return;
    const node = nodeMap.get(id);
    if (!node) return;
    const parentId = readVizStringField(row, parentField);
    if (parentId && nodeMap.has(parentId)) {
      nodeMap.get(parentId)!.children.push(node);
    } else {
      roots.push(node);
    }
  });
  return roots;
};

const readVizNumberField = (row: Record<string, unknown>, field: string): number | undefined => {
  const value = row[field];
  const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(parsed) ? parsed : undefined;
};

const transformApiRowsToTimelineEvents = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "timeline" | "gantt"; idField?: string; titleField: string; startField: string; endField?: string; descriptionField?: string; progressField?: string },
): Array<{ id?: string; title: string; start: string; end?: string; description?: string; progress?: number }> =>
  rows.map((row, index) => {
    const progress = mapping.progressField ? readVizNumberField(row, mapping.progressField) : undefined;
    return {
      id: mapping.idField ? readVizStringField(row, mapping.idField, `evt-${index + 1}`) : `evt-${index + 1}`,
      title: readVizStringField(row, mapping.titleField, `Event ${index + 1}`),
      start: readVizStringField(row, mapping.startField),
      ...(mapping.endField ? { end: readVizStringField(row, mapping.endField) } : {}),
      ...(mapping.descriptionField ? { description: readVizStringField(row, mapping.descriptionField) } : {}),
      ...(progress !== undefined ? { progress } : {}),
    };
  });

const transformApiRowsToKanbanBoard = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "kanban"; cardIdField: string; cardTitleField: string; cardDescriptionField?: string; cardColumnField: string; columnOrder?: Array<{ id: string; title: string }> },
): { columns: Array<{ id: string; title: string; cards: Array<{ id: string; title: string; description?: string }> }> } => {
  const cardsByColumn = new Map<string, Array<{ id: string; title: string; description?: string }>>();
  rows.forEach((row, index) => {
    const columnKey = readVizStringField(row, mapping.cardColumnField, "default");
    const card = {
      id: readVizStringField(row, mapping.cardIdField, `card-${index + 1}`),
      title: readVizStringField(row, mapping.cardTitleField, `Card ${index + 1}`),
      ...(mapping.cardDescriptionField ? { description: readVizStringField(row, mapping.cardDescriptionField) } : {}),
    };
    cardsByColumn.set(columnKey, [...(cardsByColumn.get(columnKey) ?? []), card]);
  });
  const columnOrder = mapping.columnOrder && mapping.columnOrder.length > 0
    ? mapping.columnOrder
    : Array.from(cardsByColumn.keys()).map((key) => ({ id: key, title: key }));
  const columns = columnOrder.map((columnDef) => ({
    id: columnDef.id,
    title: columnDef.title,
    cards: cardsByColumn.get(columnDef.id) ?? cardsByColumn.get(columnDef.title) ?? [],
  }));
  cardsByColumn.forEach((cards, columnKey) => {
    if (!columns.some((column) => column.id === columnKey || column.title === columnKey)) {
      columns.push({ id: columnKey, title: columnKey, cards });
    }
  });
  return { columns };
};

const transformApiRowsToSheetData = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "sheet"; columns: Array<{ header: string; field: string }> },
): { columns: string[]; rows: string[][] } => ({
  columns: mapping.columns.map((column) => column.header),
  rows: rows.map((row) => mapping.columns.map((column) => readVizStringField(row, column.field))),
});

type EntityPickerOption = { id: string; textValue: string };
type EntityPickerFieldMapping = { returnField: string; displayField: string };

function normalizeEntityPickerItems(payload: unknown, mapping?: EntityPickerFieldMapping): EntityPickerOption[] {
  const returnField = mapping?.returnField?.trim() || "id";
  const displayField = mapping?.displayField?.trim() || "label";
  if (Array.isArray(payload)) {
    return payload
      .map((entry) => {
        if (!entry || typeof entry !== "object") {
          return null;
        }
        const record = entry as Record<string, unknown>;
        const mappedId = record[returnField];
        const id = typeof mappedId === "string" && mappedId.trim()
          ? mappedId.trim()
          : typeof record.id === "string" && record.id.trim()
            ? record.id.trim()
            : typeof record.value === "string" && record.value.trim()
              ? record.value.trim()
              : "";
        const mappedLabel = record[displayField];
        const textValue = typeof mappedLabel === "string" && mappedLabel.trim()
          ? mappedLabel.trim()
          : typeof record.textValue === "string" && record.textValue.trim()
            ? record.textValue.trim()
            : typeof record.label === "string" && record.label.trim()
              ? record.label.trim()
              : typeof record.name === "string" && record.name.trim()
                ? record.name.trim()
                : id;
        if (!id || !textValue) {
          return null;
        }
        return { id, textValue };
      })
      .filter((entry): entry is EntityPickerOption => entry !== null);
  }

  if (payload && typeof payload === "object") {
    const record = payload as Record<string, unknown>;
    const items = record.items ?? record.results ?? record.data;
    return normalizeEntityPickerItems(items, mapping);
  }

  return [];
}

function useEntityPickerOptions(entityRef: string, searchParam: string, mapping?: EntityPickerFieldMapping) {
  const [items, setItems] = React.useState<EntityPickerOption[]>([]);
  const [isLoading, setIsLoading] = React.useState(false);

  const loadOptions = React.useCallback(async (query: string) => {
    if (!entityRef) {
      setItems([]);
      return;
    }

    setIsLoading(true);
    try {
      const url = entityRef.startsWith("http")
        ? new URL(entityRef)
        : new URL(entityRef, window.location.origin);
      // Option A (parity audit items 31/32): Autocomplete is Select-based — no live typing.
      // Still honour an explicit non-empty query if a caller passes one, but initial load uses "".
      if (query.trim()) {
        url.searchParams.set(searchParam, query);
      }
      const response = await fetch(url.toString());
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      const payload = await response.json();
      setItems(normalizeEntityPickerItems(payload, mapping));
    } catch {
      setItems([]);
    } finally {
      setIsLoading(false);
    }
  }, [entityRef, searchParam, mapping?.returnField, mapping?.displayField]);

  React.useEffect(() => {
    void loadOptions("");
  }, [loadOptions]);

  return { items, isLoading, loadOptions };
}
function useDesignerStore<T extends Record<string, unknown>>(initial: T) {
  const [store, setStore] = React.useState<T>(initial);
  const patch = React.useCallback((path: string, value: unknown) => {
    setStore((previous) => {
      const next = { ...previous };
      setNestedPayloadValue(next, path, value);
      return next as T;
    });
  }, []);
  return { store, patch };
}
function evaluateDesignerCondition(
  designerStore: Record<string, unknown>,
  dataContext: Record<string, unknown> | null,
  scope: { item?: unknown; index?: number },
  condition: string,
): boolean {
  const trimmed = condition.trim();
  if (!trimmed) {
    return true;
  }
  try {
    const formatPathChain = (root: string, path: string): string => {
      const chain = path
        .split('.')
        .filter(Boolean)
        .map((segment) => {
          if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(segment)) {
            return `?.${segment}`;
          }
          return `?.[${JSON.stringify(segment)}]`;
        })
        .join('');
      return `(${root}${chain})`;
    };
    let compiled = trimmed
      .replace(/\bstore\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('designerStore', path))
      .replace(/\bdata\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('dataContext', path))
      .replace(/\bdataContext\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('dataContext', path));
    const evaluator = new Function('designerStore', 'dataContext', 'item', 'index', `return Boolean(${compiled});`);
    return Boolean(evaluator(designerStore, dataContext, scope.item, scope.index));
  } catch {
    return false;
  }
}

export const GeneratedComponent: React.FC = () => {
  const { store: designerStore, patch: patchDesignerStore } = useDesignerStore<Record<string, unknown>>({"selection":{"id":null}});
  const { data: raw_regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e, isLoading: isLoading_regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e, error: error_regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e, refresh: refresh_regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e } = useDataFetch<unknown>("/api/base-info", {});
  const regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e, {"dataPath":"items","arrayPath":"items","totalPath":"count"})), [raw_regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e]);
  const { data: raw_regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70, isLoading: isLoading_regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70, error: error_regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70, refresh: refresh_regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70 } = useDataFetch<unknown>(resolveBindingUrl("/api/base-info", designerStore, { "id": "selection.id" }), {});
  const regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70 = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70, {"dataPath":"items","arrayPath":"items","totalPath":"count"})), [raw_regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70]);
  const handleGridRowAction_heroui_app_table_grid_1785520943312_zeogd = React.useCallback((row: Record<string, unknown>, actionId: string) => {
    switch (actionId) {
      case "edit": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-7f0c8f8e-99fc-4ecc-b4b0-569fe1272bb5", true);
        return;
      }
      case "delete": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-265b49b4-8878-47f4-ac7d-5a0fbd9c6ca7", true);
        return;
      }
      default:
        return;
    }
  }, [patchDesignerStore]);
  const { data: raw_gridData_heroui_app_table_grid_1785520943312_zeogd, isLoading: isLoading_gridData_heroui_app_table_grid_1785520943312_zeogd, error: error_gridData_heroui_app_table_grid_1785520943312_zeogd, refresh: refresh_gridData_heroui_app_table_grid_1785520943312_zeogd } = useDataFetch<unknown>(resolveBindingUrl("/api/base-info/children?parentId=101.005&includeInactive=true", designerStore, { "search": "gridToolbar.search", "sortBy": "gridQuery.sortBy", "sortDir": "gridQuery.sortDir", "page": "gridQuery.page", "pageSize": "gridQuery.pageSize", "title": "gridQuery.filters.title" }), {});
  const gridData_heroui_app_table_grid_1785520943312_zeogd = React.useMemo(() => applyResponseDataPath(raw_gridData_heroui_app_table_grid_1785520943312_zeogd, {"dataPath":"items","arrayPath":"items","totalPath":"count"}), [raw_gridData_heroui_app_table_grid_1785520943312_zeogd]);
  const gridColumns_heroui_app_table_grid_1785520943312_zeogd = React.useMemo(() => buildAppTableGridColumns([{"key":"title","label":"Title","sort":true,"filter":true,"filterType":"text","cardRole":"title"},{"key":"actions","label":"","kind":"action-group","actions":[{"actionId":"edit","icon":"Pencil","intent":"edit","tooltip":"Edit","behavior":{"kind":"open-modal","modalNodeId":"node-7f0c8f8e-99fc-4ecc-b4b0-569fe1272bb5","primaryKeyField":"id","selectionStorePath":"selection.id"}},{"actionId":"delete","icon":"Trash2","intent":"delete","tooltip":"Delete","behavior":{"kind":"open-modal","modalNodeId":"node-265b49b4-8878-47f4-ac7d-5a0fbd9c6ca7","primaryKeyField":"id","selectionStorePath":"selection.id"}}],"cardRole":"actions","layoutHideable":false,"layoutResizable":false,"layoutReorderable":false,"width":"140px"}], "server", {
    mode: 'runtime',
    detailFlowRef: { current: null },
    rowActionHandlerRef: { current: handleGridRowAction_heroui_app_table_grid_1785520943312_zeogd },
    cellClickHandlerRef: { current: undefined },
    designerStoreRef: { current: designerStore },
  }), [designerStore, handleGridRowAction_heroui_app_table_grid_1785520943312_zeogd]);
  const [gridQuery_heroui_app_table_grid_1785520943312_zeogd, setGridQuery_heroui_app_table_grid_1785520943312_zeogd] = React.useState<GridQueryState>(() => ({ ...EMPTY_GRID_QUERY, sort: { columnId: "viewOrder", direction: 'asc' } }));
  const [gridPage_heroui_app_table_grid_1785520943312_zeogd, setGridPage_heroui_app_table_grid_1785520943312_zeogd] = React.useState(1);
  const [gridPageSize_heroui_app_table_grid_1785520943312_zeogd, setGridPageSize_heroui_app_table_grid_1785520943312_zeogd] = React.useState(50);
  const [gridListMode_heroui_app_table_grid_1785520943312_zeogd, setGridListMode_heroui_app_table_grid_1785520943312_zeogd] = React.useState<'paging' | 'infinite'>("paging");
  const [gridColumnLayout_heroui_app_table_grid_1785520943312_zeogd, setGridColumnLayout_heroui_app_table_grid_1785520943312_zeogd] = React.useState(() => createDefaultColumnLayout(gridColumns_heroui_app_table_grid_1785520943312_zeogd));
  const [gridSearchInput_heroui_app_table_grid_1785520943312_zeogd, setGridSearchInput_heroui_app_table_grid_1785520943312_zeogd] = React.useState('');
  const [gridDebouncedSearch_heroui_app_table_grid_1785520943312_zeogd, setGridDebouncedSearch_heroui_app_table_grid_1785520943312_zeogd] = React.useState('');
  const [gridRoleFilters_heroui_app_table_grid_1785520943312_zeogd, setGridRoleFilters_heroui_app_table_grid_1785520943312_zeogd] = React.useState<Record<string, boolean>>({});
  const gridFilteredRows_heroui_app_table_grid_1785520943312_zeogd = React.useMemo(() => applyClientGridQuery(((Array.isArray(gridData_heroui_app_table_grid_1785520943312_zeogd?.items) ? gridData_heroui_app_table_grid_1785520943312_zeogd?.items : []) ?? []), gridQuery_heroui_app_table_grid_1785520943312_zeogd, gridColumns_heroui_app_table_grid_1785520943312_zeogd, "server"), [gridQuery_heroui_app_table_grid_1785520943312_zeogd, gridColumns_heroui_app_table_grid_1785520943312_zeogd]);
  const gridApiTotal_heroui_app_table_grid_1785520943312_zeogd = React.useMemo(() => {
    const raw = raw_gridData_heroui_app_table_grid_1785520943312_zeogd;
    const value = readNestedContextValue((raw && typeof raw === 'object' ? raw as Record<string, unknown> : {}), "count");
    const parsed = typeof value === 'number' ? value : Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : 0;
  }, [raw_gridData_heroui_app_table_grid_1785520943312_zeogd]);
  const gridTotalCount_heroui_app_table_grid_1785520943312_zeogd = resolveDataGridTotalCount({ page: gridPage_heroui_app_table_grid_1785520943312_zeogd, pageSize: gridPageSize_heroui_app_table_grid_1785520943312_zeogd, total: gridApiTotal_heroui_app_table_grid_1785520943312_zeogd, gridQueryMode: "server" }, gridFilteredRows_heroui_app_table_grid_1785520943312_zeogd.length);
  const gridPaging_heroui_app_table_grid_1785520943312_zeogd = sliceDataGridRowsForDisplay(gridFilteredRows_heroui_app_table_grid_1785520943312_zeogd, gridPage_heroui_app_table_grid_1785520943312_zeogd, gridPageSize_heroui_app_table_grid_1785520943312_zeogd, gridTotalCount_heroui_app_table_grid_1785520943312_zeogd, "server");
  const handleGridQueryChange_heroui_app_table_grid_1785520943312_zeogd = React.useCallback((nextQuery: GridQueryState) => {
    setGridQuery_heroui_app_table_grid_1785520943312_zeogd(nextQuery);
    setGridPage_heroui_app_table_grid_1785520943312_zeogd(1);
    patchDesignerStore("gridQuery.sortBy", nextQuery.sort?.columnId ?? '');
    patchDesignerStore("gridQuery.sortDir", nextQuery.sort?.direction ?? '');
  }, [patchDesignerStore]);
  const handleGridPageChange_heroui_app_table_grid_1785520943312_zeogd = React.useCallback((nextPage: number) => {
    setGridPage_heroui_app_table_grid_1785520943312_zeogd(nextPage);
    patchDesignerStore("gridQuery.page", nextPage);
  }, [patchDesignerStore]);
  const handleGridPageSizeChange_heroui_app_table_grid_1785520943312_zeogd = React.useCallback((nextSize: number) => {
    setGridPageSize_heroui_app_table_grid_1785520943312_zeogd(nextSize);
    setGridPage_heroui_app_table_grid_1785520943312_zeogd(1);
    patchDesignerStore("gridQuery.pageSize", nextSize);
  }, [patchDesignerStore]);
  const handleGridSortByChange_heroui_app_table_grid_1785520943312_zeogd = React.useCallback((nextSortBy: string) => {
    setGridQuery_heroui_app_table_grid_1785520943312_zeogd((current: GridQueryState) => ({ ...current, sort: nextSortBy ? { columnId: nextSortBy, direction: current.sort?.direction ?? 'asc' } : null }));
  }, []);
  const handleGridToggleSortDirection_heroui_app_table_grid_1785520943312_zeogd = React.useCallback(() => {
    setGridQuery_heroui_app_table_grid_1785520943312_zeogd((current: GridQueryState) => (current.sort ? { ...current, sort: { ...current.sort, direction: current.sort.direction === 'asc' ? 'desc' : 'asc' } } : current));
  }, []);
  const searchDebounceTimer_heroui_app_table_grid_1785520943312_zeogd = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const handleGridSearchChange_heroui_app_table_grid_1785520943312_zeogd = React.useCallback((nextValue: string) => {
    setGridSearchInput_heroui_app_table_grid_1785520943312_zeogd(nextValue);
    if (searchDebounceTimer_heroui_app_table_grid_1785520943312_zeogd.current) {
      clearTimeout(searchDebounceTimer_heroui_app_table_grid_1785520943312_zeogd.current);
    }
    searchDebounceTimer_heroui_app_table_grid_1785520943312_zeogd.current = setTimeout(() => {
      setGridDebouncedSearch_heroui_app_table_grid_1785520943312_zeogd(nextValue);
      setGridPage_heroui_app_table_grid_1785520943312_zeogd(1);
      patchDesignerStore("gridToolbar.search", nextValue);
    }, 300);
  }, [patchDesignerStore]);

  const dataContext: Record<string, unknown> | null = regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e ?? null;
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [mutationError, setMutationError] = React.useState<string | null>(null);
  const handleonClick_node_dce48b7b_a33c_423d_b8ce_4820b5e58929 = React.useCallback(async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    let formData: FormData;
    const form = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : event.currentTarget.closest('form');
    if (form) {
      formData = new FormData(form);
    } else {
      const regionRoot = document.querySelector("[data-designer-node-id=\"node-0b538708-2cf4-485d-8808-39087d780b9e\"]");
      if (!regionRoot) {
        return;
      }
      formData = collectRegionFormDataFromContainer(regionRoot, ["node-1d392bf0-ba2d-4930-92fc-25706df5fc37","node-673b0a84-1021-4eae-8fb7-56ebe81aaf16","node-380bae29-8c44-4751-bfa0-6122e1ed50fd","node-28fc7293-0e5b-41ee-a3cc-fc9c72feaa0f","node-9ef84e65-5c7f-436e-b820-fcdab9c91655"]);
    }
    const fieldValidationEntries = [{"nodeId":"node-1d392bf0-ba2d-4930-92fc-25706df5fc37","formFieldName":"node-1d392bf0-ba2d-4930-92fc-25706df5fc37","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-673b0a84-1021-4eae-8fb7-56ebe81aaf16","formFieldName":"node-673b0a84-1021-4eae-8fb7-56ebe81aaf16","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-9ef84e65-5c7f-436e-b820-fcdab9c91655","formFieldName":"node-9ef84e65-5c7f-436e-b820-fcdab9c91655","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}}] as Array<{ nodeId: string; formFieldName: string; props: Record<string, unknown> }>;
    const fieldValidationErrors: Record<string, string> = {};
    for (const entry of fieldValidationEntries) {
      const rawValue = formData.get(entry.formFieldName);
      const validationMessage = validateDesignerFieldNode(entry.props, typeof rawValue === 'string' ? rawValue : '');
      if (validationMessage) {
        fieldValidationErrors[entry.nodeId] = validationMessage;
      }
    }
    if (Object.keys(fieldValidationErrors).length > 0) {
      setMutationError(Object.values(fieldValidationErrors).join(' '));
      return;
    }
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      payload["title"] = formData.get("node-1d392bf0-ba2d-4930-92fc-25706df5fc37") ?? '';
      payload["shortName"] = formData.get("node-673b0a84-1021-4eae-8fb7-56ebe81aaf16") ?? '';
      payload["viewOrder"] = applyPayloadFieldTransform(formData.get("node-380bae29-8c44-4751-bfa0-6122e1ed50fd"), "number");
      payload["isActive"] = applyPayloadFieldTransform(formData.get("node-28fc7293-0e5b-41ee-a3cc-fc9c72feaa0f"), "boolean");
      payload["parentId"] = formData.get("node-9ef84e65-5c7f-436e-b820-fcdab9c91655") ?? '';
      const method = regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e?.id != null && String(regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e?.id).length > 0 ? 'PUT' : 'POST';
      const url = (regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e?.id != null && String(regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e?.id).length > 0 ? (regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e?.id != null && String(regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e?.id).length > 0 ? "/api/base-info" + '/' + encodeURIComponent(String(regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e?.id)) : "/api/base-info") : "/api/base-info");
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      patchDesignerStore("ui.visibility.node-75fed522-0590-4958-bc0d-ab90a69a411c", false);
      toast("Saved successfully", { variant: "success", timeout: 4000 });
      await refresh_gridData_heroui_app_table_grid_1785520943312_zeogd();
      (document.querySelector("[data-designer-node-id=\"node-0b538708-2cf4-485d-8808-39087d780b9e\"]") as HTMLFormElement | null)?.reset?.();
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, [regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e]);
  const handleonClick_node_f915f751_b9a6_4b8f_b305_fc1fbec83a61 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-75fed522-0590-4958-bc0d-ab90a69a411c", false);
  }, [patchDesignerStore]);
  const handleonClick_node_48bb16d7_1d8b_484a_8533_261c2f754eb5 = React.useCallback(async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    let formData: FormData;
    const form = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : event.currentTarget.closest('form');
    if (form) {
      formData = new FormData(form);
    } else {
      const regionRoot = document.querySelector("[data-designer-node-id=\"node-f1d164ec-356c-41de-aab4-dfd119158f70\"]");
      if (!regionRoot) {
        return;
      }
      formData = collectRegionFormDataFromContainer(regionRoot, ["node-15b96f02-62fe-45d2-b477-a274677fc2d3","node-45ffe62b-f868-40e6-bfb5-ce11eeb16ab3","node-0848aa10-1629-460d-9769-4265917d5067","node-4103042f-27e3-45af-b624-d2b100eb4720","node-5f9208eb-a84b-40ff-b88f-3affb2904e65"]);
    }
    const fieldValidationEntries = [{"nodeId":"node-15b96f02-62fe-45d2-b477-a274677fc2d3","formFieldName":"node-15b96f02-62fe-45d2-b477-a274677fc2d3","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-45ffe62b-f868-40e6-bfb5-ce11eeb16ab3","formFieldName":"node-45ffe62b-f868-40e6-bfb5-ce11eeb16ab3","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-5f9208eb-a84b-40ff-b88f-3affb2904e65","formFieldName":"node-5f9208eb-a84b-40ff-b88f-3affb2904e65","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}}] as Array<{ nodeId: string; formFieldName: string; props: Record<string, unknown> }>;
    const fieldValidationErrors: Record<string, string> = {};
    for (const entry of fieldValidationEntries) {
      const rawValue = formData.get(entry.formFieldName);
      const validationMessage = validateDesignerFieldNode(entry.props, typeof rawValue === 'string' ? rawValue : '');
      if (validationMessage) {
        fieldValidationErrors[entry.nodeId] = validationMessage;
      }
    }
    if (Object.keys(fieldValidationErrors).length > 0) {
      setMutationError(Object.values(fieldValidationErrors).join(' '));
      return;
    }
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      payload["title"] = formData.get("node-15b96f02-62fe-45d2-b477-a274677fc2d3") ?? '';
      payload["shortName"] = formData.get("node-45ffe62b-f868-40e6-bfb5-ce11eeb16ab3") ?? '';
      payload["viewOrder"] = applyPayloadFieldTransform(formData.get("node-0848aa10-1629-460d-9769-4265917d5067"), "number");
      payload["isActive"] = applyPayloadFieldTransform(formData.get("node-4103042f-27e3-45af-b624-d2b100eb4720"), "boolean");
      payload["parentId"] = formData.get("node-5f9208eb-a84b-40ff-b88f-3affb2904e65") ?? '';
      const method = regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70?.id != null && String(regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70?.id).length > 0 ? 'PUT' : 'POST';
      const url = (regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70?.id != null && String(regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70?.id).length > 0 ? (regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70?.id != null && String(regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70?.id).length > 0 ? "/api/base-info" + '/' + encodeURIComponent(String(regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70?.id)) : "/api/base-info") : "/api/base-info");
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      patchDesignerStore("ui.visibility.node-7f0c8f8e-99fc-4ecc-b4b0-569fe1272bb5", false);
      toast("Saved successfully", { variant: "success", timeout: 4000 });
      await refresh_gridData_heroui_app_table_grid_1785520943312_zeogd();
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, [regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70]);
  const handleonClick_node_2e7a178e_cc60_421f_804b_03fd7fae62e6 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-7f0c8f8e-99fc-4ecc-b4b0-569fe1272bb5", false);
  }, [patchDesignerStore]);
  const handleonClick_node_06990176_ee28_4bcb_ae71_48288d0717b4 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-265b49b4-8878-47f4-ac7d-5a0fbd9c6ca7", false);
  }, [patchDesignerStore]);
  const handleonClick_node_f74e03e3_e498_49d7_bda8_d6c5b1b3e3d0 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_ms992h8z_k7728 = true;
      try {
        const response = await designerFetch(("/api/base-info/" + encodeURIComponent(String(designerStore?.selection?.id)) + ""), {
          method: "DELETE",
          headers: { 'Content-Type': 'application/json' },
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_ms992h8z_k7728 = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_ms992h8z_k7728 = false;
      }
      if (mutationOk_da_ms992h8z_k7728) {
        patchDesignerStore("ui.visibility.node-265b49b4-8878-47f4-ac7d-5a0fbd9c6ca7", false);
        toast("Deleted", { variant: "success", timeout: 4000 });
        await refresh_gridData_heroui_app_table_grid_1785520943312_zeogd();
      }
    })();
  }, [patchDesignerStore, refresh_gridData_heroui_app_table_grid_1785520943312_zeogd]);
  return (
    <>
      <Toast.Provider />
      <div className="space-y-3">
        {mutationError ? (
          <div className="rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700">
            {mutationError}
          </div>
        ) : null}
        <div className="flex w-full flex-col gap-2"><div className="flex items-center justify-between gap-2 border-b border-slate-200 bg-white px-2 py-1.5"><div className="flex items-center gap-2"><input type="text" value={gridSearchInput_heroui_app_table_grid_1785520943312_zeogd} onChange={(event) => handleGridSearchChange_heroui_app_table_grid_1785520943312_zeogd(event.target.value)} placeholder={"Search content tags…"} className="h-8 rounded-md border border-slate-200 px-2 text-sm" /></div><div className="flex items-center gap-2"><button type="button" onClick={() => { patchDesignerStore("selection.id", null); patchDesignerStore("ui.visibility.node-75fed522-0590-4958-bc0d-ab90a69a411c", true); }} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700">Create content tag</button><button type="button" onClick={() => { void refresh_gridData_heroui_app_table_grid_1785520943312_zeogd(); }} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 px-3 text-xs font-medium text-slate-700 hover:bg-slate-50">Refresh</button></div></div><AppTableGrid className="flex h-full min-h-0 w-full flex-1 flex-col" presentation="cards" cardBelow="phone" cardVariant="compact" columns={gridColumns_heroui_app_table_grid_1785520943312_zeogd} rows={gridPaging_heroui_app_table_grid_1785520943312_zeogd.displayRows} getRowKey={(row) => String((row as Record<string, unknown>)["id"] ?? '')} enableColumnLayout={false} columnLayout={gridColumnLayout_heroui_app_table_grid_1785520943312_zeogd} onColumnLayoutChange={setGridColumnLayout_heroui_app_table_grid_1785520943312_zeogd} isLoading={false} loadingMessage={"Loading content tags…"} emptyMessage={"No content tags found."} isEmpty={gridFilteredRows_heroui_app_table_grid_1785520943312_zeogd.length === 0} errorContent={gridFilteredRows_heroui_app_table_grid_1785520943312_zeogd.length === 0 ? undefined : "Could not load content tags."} gridQueryMode={"server"} query={gridQuery_heroui_app_table_grid_1785520943312_zeogd} onQueryChange={handleGridQueryChange_heroui_app_table_grid_1785520943312_zeogd} onGridRowAction={handleGridRowAction_heroui_app_table_grid_1785520943312_zeogd} footer={<GridPagingFooter totalCount={gridTotalCount_heroui_app_table_grid_1785520943312_zeogd} safePage={gridPaging_heroui_app_table_grid_1785520943312_zeogd.safePage} pageSize={gridPageSize_heroui_app_table_grid_1785520943312_zeogd} onPageSizeChange={handleGridPageSizeChange_heroui_app_table_grid_1785520943312_zeogd} sortBy={gridQuery_heroui_app_table_grid_1785520943312_zeogd.sort?.columnId ?? ''} sortOptions={[{"value":"title","label":"Title"}]} onSortByChange={handleGridSortByChange_heroui_app_table_grid_1785520943312_zeogd} sortDirection={gridQuery_heroui_app_table_grid_1785520943312_zeogd.sort?.direction ?? 'asc'} onToggleSortDirection={handleGridToggleSortDirection_heroui_app_table_grid_1785520943312_zeogd} showSortControls={false} totalPages={gridPaging_heroui_app_table_grid_1785520943312_zeogd.totalPages} pageNumbers={buildDataGridPageNumbers(gridPaging_heroui_app_table_grid_1785520943312_zeogd.safePage, gridPaging_heroui_app_table_grid_1785520943312_zeogd.totalPages)} onPageChange={handleGridPageChange_heroui_app_table_grid_1785520943312_zeogd} visibleInfiniteCount={gridListMode_heroui_app_table_grid_1785520943312_zeogd === 'infinite' ? gridPaging_heroui_app_table_grid_1785520943312_zeogd.displayRows.length : undefined} />} /></div>
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-75fed522-0590-4958-bc0d-ab90a69a411c === true) && (store.ui.visibility.node-75fed522-0590-4958-bc0d-ab90a69a411c !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-75fed522-0590-4958-bc0d-ab90a69a411c"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-75fed522-0590-4958-bc0d-ab90a69a411c", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Create Content Tag</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-75fed522-0590-4958-bc0d-ab90a69a411c", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <form className="flex min-h-0 flex-col gap-0 overflow-hidden bg-white" method="post" data-designer-node-id="node-0b538708-2cf4-485d-8808-39087d780b9e">
            <div className="flex flex-col gap-2 bg-white p-[15px]">
              <UiInput isRequired type="text" placeholder="Title" label="Title" size="sm" value={regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e?.title} name="node-1d392bf0-ba2d-4930-92fc-25706df5fc37" />
              <UiInput isRequired type="text" placeholder="Short Name" label="Short Name" size="sm" value={regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e?.shortName} name="node-673b0a84-1021-4eae-8fb7-56ebe81aaf16" />
              <UiInput type="number" placeholder="View Order" label="View Order" step={1} size="sm" value={regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e?.viewOrder} name="node-380bae29-8c44-4751-bfa0-6122e1ed50fd" />
              <Switch label="Is Active" aria-label="Is Active" size="md" isSelected={regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e?.isActive} name="node-28fc7293-0e5b-41ee-a3cc-fc9c72feaa0f"><Switch.Control><Switch.Thumb /></Switch.Control></Switch>
              <UiInput isRequired className="hidden" readOnly type="text" placeholder="Parent Id" label="Parent Id" defaultValue={101.005} size="sm" value={regionData_vocabItems_node_0b538708_2cf4_485d_8808_39087d780b9e?.parentId} name="node-9ef84e65-5c7f-436e-b820-fcdab9c91655" />
            </div>
            <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" onClick={handleonClick_node_f915f751_b9a6_4b8f_b305_fc1fbec83a61}>Cancel</Button>
              <Button type="submit" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" icon="Plus" variant="primary" size="md" href="#" target="_self" isDisabled={isSubmitting} onClick={handleonClick_node_dce48b7b_a33c_423d_b8ce_4820b5e58929}>Create Content Tag</Button>
            </div>
          </form>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-7f0c8f8e-99fc-4ecc-b4b0-569fe1272bb5 === true) && (store.ui.visibility.node-7f0c8f8e-99fc-4ecc-b4b0-569fe1272bb5 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-7f0c8f8e-99fc-4ecc-b4b0-569fe1272bb5"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-7f0c8f8e-99fc-4ecc-b4b0-569fe1272bb5", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Edit Content Tag</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-7f0c8f8e-99fc-4ecc-b4b0-569fe1272bb5", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <form className="flex min-h-0 flex-col gap-0 overflow-hidden bg-white" method="post" data-designer-node-id="node-f1d164ec-356c-41de-aab4-dfd119158f70">
            <div className="flex flex-col gap-2 bg-white p-[15px]">
              <UiInput isRequired type="text" placeholder="Title" label="Title" size="sm" value={regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70?.title} name="node-15b96f02-62fe-45d2-b477-a274677fc2d3" />
              <UiInput isRequired type="text" placeholder="Short Name" label="Short Name" size="sm" value={regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70?.shortName} name="node-45ffe62b-f868-40e6-bfb5-ce11eeb16ab3" />
              <UiInput type="number" placeholder="View Order" label="View Order" step={1} size="sm" value={regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70?.viewOrder} name="node-0848aa10-1629-460d-9769-4265917d5067" />
              <Switch label="Is Active" aria-label="Is Active" size="md" isSelected={regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70?.isActive} name="node-4103042f-27e3-45af-b624-d2b100eb4720"><Switch.Control><Switch.Thumb /></Switch.Control></Switch>
              <UiInput isRequired type="text" placeholder="Parent Id" label="Parent Id" size="sm" value={regionData_vocabItems_node_f1d164ec_356c_41de_aab4_dfd119158f70?.parentId} name="node-5f9208eb-a84b-40ff-b88f-3affb2904e65" />
            </div>
            <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" onClick={handleonClick_node_2e7a178e_cc60_421f_804b_03fd7fae62e6}>Cancel</Button>
              <Button type="submit" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" icon="Save" variant="primary" size="md" href="#" target="_self" isDisabled={isSubmitting} onClick={handleonClick_node_48bb16d7_1d8b_484a_8533_261c2f754eb5}>Save</Button>
            </div>
          </form>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-265b49b4-8878-47f4-ac7d-5a0fbd9c6ca7 === true) && (store.ui.visibility.node-265b49b4-8878-47f4-ac7d-5a0fbd9c6ca7 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-265b49b4-8878-47f4-ac7d-5a0fbd9c6ca7"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-265b49b4-8878-47f4-ac7d-5a0fbd9c6ca7", false); } }} variant="blur"><Modal.Container><Modal.Dialog role="alertdialog" className="w-full max-w-md overflow-hidden rounded-xl border border-rose-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-rose-200 bg-rose-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-rose-800">Delete Content Tag?</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-265b49b4-8878-47f4-ac7d-5a0fbd9c6ca7", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <p className="block bg-white p-[15px] text-sm text-slate-700">Delete this content tag? This cannot be undone.</p>
          <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
            <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_node_06990176_ee28_4bcb_ae71_48288d0717b4}>Cancel</Button>
            <Button icon="Trash2" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-rose-600 px-3 text-xs font-semibold text-white hover:bg-rose-700" variant="primary" size="md" href="#" target="_self" onClick={handleonClick_node_f74e03e3_e498_49d7_bda8_d6c5b1b3e3d0}>Delete</Button>
          </div>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
      </div>
    </>
  );
};
export default GeneratedComponent;
