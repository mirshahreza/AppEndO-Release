IF COL_LENGTH(N'dbo.hwy_nakhebin', N'phone1') IS NULL
  ALTER TABLE dbo.hwy_nakhebin ADD phone1 NVARCHAR(4000) NULL;
GO

IF COL_LENGTH(N'dbo.hwy_nakhebin', N'phone2') IS NULL
  ALTER TABLE dbo.hwy_nakhebin ADD phone2 NVARCHAR(4000) NULL;
GO
