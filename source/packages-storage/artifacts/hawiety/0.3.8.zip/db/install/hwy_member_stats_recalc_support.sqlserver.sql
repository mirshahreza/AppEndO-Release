-- Helper functions for dbo.hwy_member_stat_recalc_* (hwy_* naming only).

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER FUNCTION dbo.hwy_member_calc_profile_percentage (@member_id BIGINT)
RETURNS INT
AS
BEGIN
  IF @member_id IS NULL OR @member_id <= 0
    RETURN 0;

  DECLARE @filled INT = 0;
  DECLARE @total INT = 10;
  DECLARE @has_national_front BIT = 0;
  DECLARE @has_photo BIT = 0;

  SELECT @has_national_front = CASE
    WHEN EXISTS (
      SELECT 1
      FROM dbo.hwy_member_files f WITH (NOLOCK)
      INNER JOIN dbo.base_info kind WITH (NOLOCK) ON kind.id = f.file_kind_code
      INNER JOIN dbo.base_info cat WITH (NOLOCK) ON cat.id = kind.parent_id AND cat.title = N'Member File Kind'
      WHERE f.member_id = @member_id
        AND kind.short_name = N'national_card_front'
        AND f.content IS NOT NULL
    ) THEN 1 ELSE 0 END;

  SELECT @has_photo = CASE
    WHEN EXISTS (
      SELECT 1
      FROM dbo.hwy_member_files f WITH (NOLOCK)
      INNER JOIN dbo.base_info kind WITH (NOLOCK) ON kind.id = f.file_kind_code
      INNER JOIN dbo.base_info cat WITH (NOLOCK) ON cat.id = kind.parent_id AND cat.title = N'Member File Kind'
      WHERE f.member_id = @member_id
        AND kind.short_name = N'personal_photo'
        AND (f.content IS NOT NULL OR f.thumbnail_content IS NOT NULL)
    ) THEN 1 ELSE 0 END;

  SELECT @filled =
    (CASE WHEN NULLIF(LTRIM(RTRIM(first_name)), N'') IS NOT NULL THEN 1 ELSE 0 END) +
    (CASE WHEN NULLIF(LTRIM(RTRIM(father_name)), N'') IS NOT NULL THEN 1 ELSE 0 END) +
    (CASE WHEN NULLIF(LTRIM(RTRIM(family_name)), N'') IS NOT NULL THEN 1 ELSE 0 END) +
    (CASE WHEN NULLIF(LTRIM(RTRIM(username)), N'') IS NOT NULL THEN 1 ELSE 0 END) +
    (CASE WHEN phone1 IS NOT NULL AND LTRIM(RTRIM(phone1)) <> N'' THEN 1 ELSE 0 END) +
    (CASE WHEN national_id IS NOT NULL AND LTRIM(RTRIM(national_id)) <> N'' THEN 1 ELSE 0 END) +
    (CASE WHEN gender_code IS NOT NULL AND LTRIM(RTRIM(gender_code)) <> N'' THEN 1 ELSE 0 END) +
    (CASE WHEN membership_status_code IS NOT NULL AND LTRIM(RTRIM(membership_status_code)) <> N'' THEN 1 ELSE 0 END) +
    @has_national_front +
    @has_photo
  FROM dbo.hwy_members WITH (NOLOCK)
  WHERE id = @member_id;

  IF @filled IS NULL SET @filled = 0;
  RETURN (@filled * 100) / @total;
END;
GO

CREATE OR ALTER FUNCTION dbo.hwy_member_has_not_tosigh_older_than_x_days (@member_id BIGINT, @days INT)
RETURNS BIT
AS
BEGIN
  DECLARE @membership_on DATE;
  SELECT @membership_on = COALESCE(membership_on, CAST(created_at AS DATE))
  FROM dbo.hwy_members WITH (NOLOCK)
  WHERE id = @member_id;

  IF @membership_on IS NULL RETURN 1;
  IF DATEDIFF(DAY, @membership_on, CAST(GETDATE() AS DATE)) <= ISNULL(@days, 5) RETURN 1;
  RETURN 0;
END;
GO

CREATE OR ALTER FUNCTION dbo.hwy_member_select_points (@member_id BIGINT)
RETURNS @Points TABLE (points INT NOT NULL)
AS
BEGIN
  INSERT INTO @Points (points) VALUES (0);
  RETURN;
END;
GO

PRINT 'hwy member stats recalc support functions ready';
GO
