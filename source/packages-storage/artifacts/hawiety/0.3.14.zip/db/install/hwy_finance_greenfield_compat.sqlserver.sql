-- Snake_case dbo.hwy_members + finance legacy-shaped SQL (auto-generated procs/functions).
-- Idempotent. Run before hwy_finance_edge_* install batches.

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NOT NULL
   AND COL_LENGTH(N'dbo.hwy_members', N'gender_id') IS NULL
  ALTER TABLE dbo.hwy_members ADD gender_id INT NULL;
GO

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NOT NULL
   AND COL_LENGTH(N'dbo.hwy_members', N'gender_id') IS NOT NULL
BEGIN
  IF OBJECT_ID(N'dbo.base_info', N'U') IS NOT NULL
    AND COL_LENGTH(N'dbo.hwy_members', N'gender_code') IS NOT NULL
  BEGIN
    UPDATE m
    SET m.gender_id = COALESCE(m.gender_id, m.gender_legacy_id, TRY_CAST(bi.value AS INT))
    FROM dbo.hwy_members m
    LEFT JOIN dbo.base_info bi ON bi.id = m.gender_code
    WHERE m.gender_id IS NULL
      AND (m.gender_legacy_id IS NOT NULL OR m.gender_code IS NOT NULL);
  END
  ELSE IF COL_LENGTH(N'dbo.hwy_members', N'gender_legacy_id') IS NOT NULL
  BEGIN
    UPDATE dbo.hwy_members
    SET gender_id = COALESCE(gender_id, gender_legacy_id)
    WHERE gender_id IS NULL AND gender_legacy_id IS NOT NULL;
  END
END
GO

IF COL_LENGTH(N'dbo.hwy_members', N'membership_status') IS NULL
   AND (
     COL_LENGTH(N'dbo.hwy_members', N'membership_status_legacy') IS NOT NULL
     OR COL_LENGTH(N'dbo.hwy_members', N'membership_status_code') IS NOT NULL
   )
  ALTER TABLE dbo.hwy_members ADD membership_status AS COALESCE(
    membership_status_legacy,
    TRY_CAST(membership_status_code AS INT)
  );
GO

IF COL_LENGTH(N'dbo.hwy_members', N'device_os_type_id') IS NULL
   AND COL_LENGTH(N'dbo.hwy_members', N'device_os_type_legacy_id') IS NOT NULL
  ALTER TABLE dbo.hwy_members ADD device_os_type_id AS device_os_type_legacy_id;
GO

IF OBJECT_ID(N'dbo.base_user_roles', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.base_roles', N'U') IS NOT NULL
BEGIN
  EXEC(N'
    CREATE OR ALTER VIEW dbo.vw_hwy_platform_user_roles_finance AS
    SELECT
      ROW_NUMBER() OVER (ORDER BY ur.user_id, ur.role_name) AS id,
      ur.user_id AS user_id,
      TRY_CAST(REPLACE(ur.role_name, N''HWY_R_'', N'''') AS INT) AS role_id,
      CAST(1 AS BIT) AS approved,
      ur.created_at AS approved_on,
      ur.created_by AS created_by
    FROM dbo.base_user_roles ur
    INNER JOIN dbo.base_roles r ON r.name = ur.role_name
    WHERE ur.role_name LIKE N''HWY_R[_]%'';
  ');
END;
GO
