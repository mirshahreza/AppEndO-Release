SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF COL_LENGTH(N'dbo.hwy_activities', N'nb_only_kashafeh') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_activities ADD nb_only_kashafeh BIT NULL;
END;
GO

IF COL_LENGTH(N'dbo.hwy_activities', N'nb_allow_gov') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_activities ADD nb_allow_gov BIT NULL;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_activity_update_tajammoat
  @activity_id BIGINT,
  @title NVARCHAR(512),
  @note NVARCHAR(MAX) = NULL,
  @activity_date NVARCHAR(64) = NULL,
  @activity_subtype_code NVARCHAR(128) = NULL,
  @legacy_province_id INT = NULL,
  @nashat_location NVARCHAR(512) = NULL,
  @enable_self_announcement BIT,
  @require_submission_device_metadata BIT = NULL,
  @nb_location_lat NVARCHAR(128) = NULL,
  @nb_location_lon NVARCHAR(128) = NULL,
  @nb_max_distance_m INT = NULL,
  @nb_window_start_at DATETIME2 = NULL,
  @nb_window_end_at DATETIME2 = NULL,
  @nb_legacy_province_id NVARCHAR(128) = NULL,
  @nb_legacy_circle_id INT = NULL,
  @nb_legacy_maktab_id INT = NULL,
  @nb_legacy_region_id INT = NULL,
  @nb_legacy_gender_id INT = NULL,
  @nb_allowed_roles NVARCHAR(128) = NULL,
  @nb_organization_ids NVARCHAR(128) = NULL,
  @nb_only_kashafeh BIT = 0,
  @nb_allow_gov BIT = 0,
  @legacy_updated_by NVARCHAR(256)
AS
BEGIN
  SET NOCOUNT ON;

  IF NOT EXISTS (
    SELECT 1 FROM dbo.hwy_activities
    WHERE id = @activity_id AND activity_type_code = N'213915'
  )
    THROW 56300, N'Central activity not found.', 1;

  UPDATE dbo.hwy_activities
  SET
    title = @title,
    note = @note,
    activity_date = @activity_date,
    activity_subtype_code = @activity_subtype_code,
    legacy_province_id = @legacy_province_id,
    nashat_location = @nashat_location,
    enable_self_announcement = @enable_self_announcement,
    require_submission_device_metadata = @require_submission_device_metadata,
    nb_location_lat = @nb_location_lat,
    nb_location_lon = @nb_location_lon,
    nb_max_distance_m = @nb_max_distance_m,
    nb_window_start_at = @nb_window_start_at,
    nb_window_end_at = @nb_window_end_at,
    nb_legacy_province_id = @nb_legacy_province_id,
    nb_legacy_circle_id = @nb_legacy_circle_id,
    nb_legacy_maktab_id = @nb_legacy_maktab_id,
    nb_legacy_region_id = @nb_legacy_region_id,
    nb_legacy_gender_id = @nb_legacy_gender_id,
    nb_allowed_roles = @nb_allowed_roles,
    nb_organization_ids = @nb_organization_ids,
    nb_only_kashafeh = @nb_only_kashafeh,
    nb_allow_gov = @nb_allow_gov,
    legacy_updated_by = @legacy_updated_by,
    updated_at = SYSUTCDATETIME()
  WHERE id = @activity_id;
END;
GO
