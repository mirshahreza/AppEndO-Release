SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF OBJECT_ID(N'dbo.hwy_geo_responsibility_patch_history_events', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_geo_responsibility_patch_history_events (
    id                   UNIQUEIDENTIFIER NOT NULL
                           CONSTRAINT DF_hwy_geo_patch_hist_id DEFAULT NEWID() PRIMARY KEY,
    geo_level            NVARCHAR(16) NOT NULL,
    geo_base_info_id     NVARCHAR(128) NOT NULL,
    legacy_geo_id        INT NULL,
    legacy_source_key    NVARCHAR(200) NULL,
    event_kind           NVARCHAR(16) NOT NULL,
    event_at             DATETIME2 NOT NULL,
    member_id            BIGINT NULL,
    member_display_name  NVARCHAR(512) NULL,
    member_username      NVARCHAR(64) NULL,
    actor_display_name   NVARCHAR(512) NULL,
    actor_username       NVARCHAR(64) NULL,
    source               NVARCHAR(16) NOT NULL,
    request_id           UNIQUEIDENTIFIER NULL,
    CONSTRAINT CK_hwy_geo_patch_hist_kind CHECK (
      event_kind IN (N'nomination', N'confirmed', N'removed')
    ),
    CONSTRAINT CK_hwy_geo_patch_hist_source CHECK (
      source IN (N'legacy', N'studio')
    )
  );
END;
GO

IF NOT EXISTS (
  SELECT 1 FROM sys.indexes
  WHERE name = N'idx_hwy_geo_patch_hist_geo'
    AND object_id = OBJECT_ID(N'dbo.hwy_geo_responsibility_patch_history_events')
)
  CREATE INDEX idx_hwy_geo_patch_hist_geo
    ON dbo.hwy_geo_responsibility_patch_history_events (geo_level, geo_base_info_id, event_at DESC);
GO

IF NOT EXISTS (
  SELECT 1 FROM sys.indexes
  WHERE name = N'idx_hwy_geo_patch_hist_legacy_source_key'
    AND object_id = OBJECT_ID(N'dbo.hwy_geo_responsibility_patch_history_events')
)
  CREATE UNIQUE INDEX idx_hwy_geo_patch_hist_legacy_source_key
    ON dbo.hwy_geo_responsibility_patch_history_events (legacy_source_key)
    WHERE legacy_source_key IS NOT NULL;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_patch_history_list
  @geo_level NVARCHAR(16),
  @geo_base_info_id NVARCHAR(128),
  @legacy_geo_id INT = NULL
AS
BEGIN
  SET NOCOUNT ON;

  SELECT TOP (1000)
    event_kind AS eventKind,
    CONVERT(VARCHAR(33), event_at, 126) AS eventOn,
    CAST(member_id AS VARCHAR(32)) AS memberId,
    member_display_name AS memberDisplayName,
    member_username AS memberUsername,
    actor_display_name AS actorDisplayName,
    actor_username AS actorUsername,
    source
  FROM dbo.hwy_geo_responsibility_patch_history_events WITH (NOLOCK)
  WHERE geo_level = @geo_level
    AND (
      (
        @legacy_geo_id IS NOT NULL
        AND legacy_geo_id = @legacy_geo_id
      )
      OR (
        @legacy_geo_id IS NULL
        AND geo_base_info_id = @geo_base_info_id
      )
    )
  ORDER BY
    event_at DESC,
    CASE event_kind
      WHEN N'confirmed' THEN 2
      WHEN N'nomination' THEN 1
      ELSE 0
    END DESC;
END;
GO
