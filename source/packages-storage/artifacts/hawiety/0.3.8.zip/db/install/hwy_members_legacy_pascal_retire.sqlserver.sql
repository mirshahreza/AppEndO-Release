-- Migrate dbo.hwy_members physical PascalCase pipeline columns → snake_case; re-expose legacy names as computed aliases.

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NULL
BEGIN
  PRINT 'hwy_members_legacy_pascal_retire skipped — dbo.hwy_members missing';
END
ELSE
BEGIN
  DECLARE @member_object_id INT = OBJECT_ID(N'dbo.hwy_members');
  DECLARE @legacy SYSNAME;
  DECLARE @snake SYSNAME;
  DECLARE @sql NVARCHAR(MAX);

  IF EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE object_id = @member_object_id AND name = N'IX_HWY_Members_MembershipStatus_UserId'
  )
    DROP INDEX IX_HWY_Members_MembershipStatus_UserId ON dbo.hwy_members;

  DECLARE map_cursor CURSOR LOCAL FAST_FORWARD FOR
    SELECT legacy_name, snake_name
    FROM (VALUES
      (N'FirstName', N'first_name'),
      (N'FatherName', N'father_name'),
      (N'GrandFatherName', N'grandfather_name'),
      (N'LastName', N'family_name'),
      (N'UserName', N'username'),
      (N'UserId', N'user_id'),
      (N'Phone1', N'phone1'),
      (N'GenderId', N'gender_legacy_id'),
      (N'DeviceOsTypeId', N'device_os_type_legacy_id'),
      (N'NationalCode', N'national_id'),
      (N'CreatedOn', N'created_at'),
      (N'MembershipOn', N'membership_on'),
      (N'MembershipStatus', N'membership_status_legacy'),
      (N'MoarrefUserName', N'referrer_username'),
      (N'NakhebJoinProvinceId', N'nakheb_join_province_id'),
      (N'NakhebJoinCircleId', N'nakheb_join_circle_id'),
      (N'NakhebJoinTamvinId', N'nakheb_join_tamvin_id'),
      (N'NakhebJoinEghteraId', N'nakheb_join_eghtera_id'),
      (N'AreaLimitId', N'area_limit_id'),
      (N'AreaLimitProvinceId', N'area_limit_province_id'),
      (N'AreaLimitCircleId', N'area_limit_circle_id'),
      (N'AreaLimitTamvinId', N'area_limit_tamvin_id'),
      (N'EducationLevelId', N'education_level_legacy_id'),
      (N'CardFlowLastStatusId', N'card_flow_last_status_id'),
      (N'CardFlowVisibility', N'card_flow_visibility'),
      (N'CardFlowStartedBy', N'card_flow_started_by'),
      (N'CardFlowStartedOn', N'card_flow_started_on'),
      (N'Picture_FileName', N'picture_file_name'),
      (N'Picture_FileSize', N'picture_file_size'),
      (N'Picture_FileMime', N'picture_file_mime'),
      (N'Picture_FileBody', N'picture_file_body'),
      (N'Picture_FileBody_xs', N'picture_file_body_xs'),
      (N'NationalCard_Front_FileBody', N'national_card_front_file_body'),
      (N'NationalCard_Behind_FileBody', N'national_card_behind_file_body'),
      (N'NakhebCard_Front_FileBody', N'nakheb_card_front_file_body'),
      (N'MaskanCard_Front_FileBody', N'maskan_card_front_file_body'),
      (N'NakhebCard_Front_Approved', N'nakheb_card_front_approved'),
      (N'NationalCard_Front_Approved', N'national_card_front_approved'),
      (N'NationalCard_Behind_Approved', N'national_card_behind_approved'),
      (N'Picture_Approved', N'picture_approved'),
      (N'Oath_Approved', N'oath_approved'),
      (N'MaskanCard_Front_Approved', N'maskan_card_front_approved'),
      (N'Oath_FileSize', N'oath_file_size'),
      (N'Stat_FieldsCompleted', N'stat_fields_completed')
    ) AS m(legacy_name, snake_name);

  OPEN map_cursor;
  FETCH NEXT FROM map_cursor INTO @legacy, @snake;
  WHILE @@FETCH_STATUS = 0
  BEGIN
    DECLARE @legacy_exists BIT = 0;
    DECLARE @snake_exists BIT = 0;
    DECLARE @legacy_is_computed BIT = 0;

    SELECT
      @legacy_exists = 1,
      @legacy_is_computed = c.is_computed
    FROM sys.columns c
    WHERE c.object_id = @member_object_id
      AND c.name = @legacy COLLATE Latin1_General_CS_AS;

    SELECT @snake_exists = 1
    FROM sys.columns c
    WHERE c.object_id = @member_object_id
      AND c.name = @snake COLLATE Latin1_General_CS_AS;

    IF @legacy_exists = 1 AND @legacy_is_computed = 0 AND @snake_exists = 1
    BEGIN
      IF @snake = N'user_id' AND OBJECT_ID(N'dbo.base_users', N'U') IS NOT NULL
      BEGIN
        EXEC(N'
          UPDATE dbo.hwy_members
          SET user_id = UserId
          WHERE UserId IS NOT NULL
            AND user_id IS NULL
            AND EXISTS (SELECT 1 FROM dbo.base_users u WHERE u.id = UserId);
        ');
      END
      ELSE
      BEGIN
        SET @sql = N'
          UPDATE dbo.hwy_members
          SET ' + QUOTENAME(@snake) + N' = COALESCE(' + QUOTENAME(@snake) + N', ' + QUOTENAME(@legacy) + N')
          WHERE ' + QUOTENAME(@legacy) + N' IS NOT NULL;';
        EXEC sp_executesql @sql;
      END;
      SET @sql = N'ALTER TABLE dbo.hwy_members DROP COLUMN ' + QUOTENAME(@legacy) + N';';
      EXEC sp_executesql @sql;
    END
    ELSE IF @legacy_exists = 1 AND @legacy_is_computed = 0 AND @snake_exists = 0
    BEGIN
      SET @sql = N'EXEC sys.sp_rename N''dbo.hwy_members.' + REPLACE(@legacy, N'''', N'''''') + N''', N''' + REPLACE(@snake, N'''', N'''''') + N''', N''COLUMN'';';
      EXEC sp_executesql @sql;
    END
    ELSE IF @legacy_exists = 1 AND @legacy_is_computed = 1 AND @snake_exists = 1
    BEGIN
      SET @sql = N'ALTER TABLE dbo.hwy_members DROP COLUMN ' + QUOTENAME(@legacy) + N';';
      EXEC sp_executesql @sql;
    END;

    SELECT
      @legacy_exists = 0,
      @legacy_is_computed = 0,
      @snake_exists = 0;

    SELECT
      @legacy_exists = 1,
      @legacy_is_computed = c.is_computed
    FROM sys.columns c
    WHERE c.object_id = @member_object_id
      AND c.name = @legacy COLLATE Latin1_General_CS_AS;

    SELECT @snake_exists = 1
    FROM sys.columns c
    WHERE c.object_id = @member_object_id
      AND c.name = @snake COLLATE Latin1_General_CS_AS;

    IF @legacy_exists = 0 AND @snake_exists = 1
    BEGIN
      SET @sql = N'ALTER TABLE dbo.hwy_members ADD ' + QUOTENAME(@legacy) + N' AS (' + QUOTENAME(@snake) + N');';
      BEGIN TRY
        EXEC sp_executesql @sql;
      END TRY
      BEGIN CATCH
        IF ERROR_NUMBER() NOT IN (2705, 1911)
          THROW;
      END CATCH;
    END;

    FETCH NEXT FROM map_cursor INTO @legacy, @snake;
  END;
  CLOSE map_cursor;
  DEALLOCATE map_cursor;

  IF COL_LENGTH(N'dbo.hwy_members', N'membership_status_legacy') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM sys.indexes
       WHERE object_id = @member_object_id
         AND name = N'IX_hwy_members_membership_status_legacy_user_id_pipeline'
     )
  BEGIN
    CREATE NONCLUSTERED INDEX IX_hwy_members_membership_status_legacy_user_id_pipeline
      ON dbo.hwy_members (membership_status_legacy, user_id)
      INCLUDE (
        id, username, first_name, father_name, grandfather_name, family_name, phone1, gender_legacy_id,
        nakheb_join_province_id, nakheb_join_circle_id, nakheb_join_tamvin_id, nakheb_join_eghtera_id
      );
  END;

  PRINT 'hwy_members legacy PascalCase columns retired (snake_case physical + computed aliases)';
END
GO
