-- CMS package Phase 1 schema (SQL Server / T-SQL)
IF OBJECT_ID(N'dbo.cms_contents', N'U') IS NULL
BEGIN
  CREATE TABLE cms_contents (
    id                        BIGINT IDENTITY(1,1) PRIMARY KEY,
    content_type_code         NVARCHAR(1000) NULL REFERENCES base_info(id),
    language_code             NVARCHAR(1000) NULL REFERENCES base_info(id),
    slug                      NVARCHAR(1000) NULL,
    status_code               NVARCHAR(1000) NULL REFERENCES base_info(id),
    status_code_updated_at    DATETIME2 NULL,
    status_code_updated_by    BIGINT NULL REFERENCES base_users(id),
    title                     NVARCHAR(MAX) NULL,
    summary                   NVARCHAR(MAX) NULL,
    body                      NVARCHAR(MAX) NULL,
    body_format_code          NVARCHAR(1000) NULL REFERENCES base_info(id),
    seo_title                 NVARCHAR(MAX) NULL,
    seo_note                  NVARCHAR(MAX) NULL,
    published_at              DATETIME2 NULL,
    operator_note             NVARCHAR(MAX) NULL,
    comments_enabled          BIT NULL,
    comments_policy_code      NVARCHAR(1000) NULL REFERENCES base_info(id),
    comments_body_format_code NVARCHAR(1000) NULL REFERENCES base_info(id),
    created_by                BIGINT NULL REFERENCES base_users(id),
    created_at                DATETIME2 NULL DEFAULT GETDATE(),
    updated_by                BIGINT NULL REFERENCES base_users(id),
    updated_at                DATETIME2 NULL DEFAULT GETDATE()
  );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'uq_cms_contents_language_slug' AND object_id = OBJECT_ID('dbo.cms_contents'))
BEGIN
  CREATE UNIQUE INDEX uq_cms_contents_language_slug ON cms_contents (language_code, slug);
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_cms_contents_status_code' AND object_id = OBJECT_ID('dbo.cms_contents'))
BEGIN
  CREATE INDEX idx_cms_contents_status_code ON cms_contents (status_code);
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_cms_contents_content_type_code' AND object_id = OBJECT_ID('dbo.cms_contents'))
BEGIN
  CREATE INDEX idx_cms_contents_content_type_code ON cms_contents (content_type_code);
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_cms_contents_published_at' AND object_id = OBJECT_ID('dbo.cms_contents'))
BEGIN
  CREATE INDEX idx_cms_contents_published_at ON cms_contents (published_at);
END;

IF OBJECT_ID(N'dbo.cms_content_revisions', N'U') IS NULL
BEGIN
  CREATE TABLE cms_content_revisions (
    id            BIGINT IDENTITY(1,1) PRIMARY KEY,
    content_id    BIGINT NOT NULL REFERENCES cms_contents(id) ON DELETE CASCADE,
    revision_no   INT NOT NULL,
    title         NVARCHAR(MAX) NULL,
    summary       NVARCHAR(MAX) NULL,
    body          NVARCHAR(MAX) NULL,
    created_by    BIGINT NULL REFERENCES base_users(id) ON DELETE SET NULL,
    created_at    DATETIME2 NULL DEFAULT GETDATE(),
    CONSTRAINT uq_cms_content_revisions_content_rev UNIQUE (content_id, revision_no)
  );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_cms_content_revisions_content_id' AND object_id = OBJECT_ID('dbo.cms_content_revisions'))
BEGIN
  CREATE INDEX idx_cms_content_revisions_content_id ON cms_content_revisions (content_id);
END;

IF OBJECT_ID(N'dbo.cms_content_assets', N'U') IS NULL
BEGIN
  CREATE TABLE cms_content_assets (
    id            BIGINT IDENTITY(1,1) PRIMARY KEY,
    content_id    BIGINT NOT NULL REFERENCES cms_contents(id) ON DELETE CASCADE,
    [file]        VARBINARY(MAX) NOT NULL,
    file_xs       VARBINARY(MAX) NULL,
    file_size     INT NOT NULL,
    file_name     NVARCHAR(1000) NOT NULL,
    file_mime     NVARCHAR(1000) NOT NULL,
    sort_order    INT NOT NULL DEFAULT 0,
    sha256        NVARCHAR(1000) NOT NULL,
    created_by    BIGINT NULL REFERENCES base_users(id),
    created_at    DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_by    BIGINT NULL REFERENCES base_users(id),
    updated_at    DATETIME2 NOT NULL DEFAULT GETDATE()
  );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_cms_content_assets_content_id' AND object_id = OBJECT_ID('dbo.cms_content_assets'))
BEGIN
  CREATE INDEX idx_cms_content_assets_content_id ON cms_content_assets (content_id, sort_order);
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_cms_content_assets_sha256' AND object_id = OBJECT_ID('dbo.cms_content_assets'))
BEGIN
  CREATE INDEX idx_cms_content_assets_sha256 ON cms_content_assets (sha256);
END;

IF OBJECT_ID(N'dbo.cms_content_tags', N'U') IS NULL
BEGIN
  CREATE TABLE cms_content_tags (
    content_id    BIGINT NOT NULL REFERENCES cms_contents(id) ON DELETE CASCADE,
    tag_code      NVARCHAR(1000) NOT NULL REFERENCES base_info(id),
    CONSTRAINT pk_cms_content_tags PRIMARY KEY (content_id, tag_code)
  );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_cms_content_tags_tag_code' AND object_id = OBJECT_ID('dbo.cms_content_tags'))
BEGIN
  CREATE INDEX idx_cms_content_tags_tag_code ON cms_content_tags (tag_code);
END;

IF OBJECT_ID(N'dbo.cms_content_relations', N'U') IS NULL
BEGIN
  CREATE TABLE cms_content_relations (
    id              BIGINT IDENTITY(1,1) PRIMARY KEY,
    content_id_a    BIGINT NOT NULL REFERENCES cms_contents(id),
    content_id_b    BIGINT NOT NULL,
    note            NVARCHAR(MAX) NULL,
    CONSTRAINT ck_cms_content_relations_ordered CHECK (content_id_a < content_id_b),
    CONSTRAINT uq_cms_content_relations_pair UNIQUE (content_id_a, content_id_b),
    CONSTRAINT fk_cms_content_relations_b FOREIGN KEY (content_id_b) REFERENCES cms_contents(id)
  );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_cms_content_relations_a' AND object_id = OBJECT_ID('dbo.cms_content_relations'))
BEGIN
  CREATE INDEX idx_cms_content_relations_a ON cms_content_relations (content_id_a);
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_cms_content_relations_b' AND object_id = OBJECT_ID('dbo.cms_content_relations'))
BEGIN
  CREATE INDEX idx_cms_content_relations_b ON cms_content_relations (content_id_b);
END;

IF OBJECT_ID(N'dbo.cms_settings', N'U') IS NULL
BEGIN
  CREATE TABLE cms_settings (
    id                          BIGINT NOT NULL DEFAULT 1 PRIMARY KEY,
    comments_enabled            BIT NOT NULL,
    comments_policy_code        NVARCHAR(1000) NOT NULL REFERENCES base_info(id),
    comments_body_format_code   NVARCHAR(1000) NOT NULL,
    public_cache_ttl_seconds    INT NOT NULL DEFAULT 300,
    updated_by                  BIGINT NULL REFERENCES base_users(id) ON DELETE SET NULL,
    updated_at                  DATETIME2 NULL DEFAULT GETDATE(),
    CONSTRAINT ck_cms_settings_singleton CHECK (id = 1),
    CONSTRAINT fk_cms_settings_comments_body_format FOREIGN KEY (comments_body_format_code) REFERENCES base_info(id)
  );
END;

IF OBJECT_ID(N'dbo.cms_comments', N'U') IS NULL
BEGIN
  CREATE TABLE cms_comments (
    id                  BIGINT IDENTITY(1,1) PRIMARY KEY,
    content_id          BIGINT NOT NULL REFERENCES cms_contents(id) ON DELETE CASCADE,
    body                NVARCHAR(MAX) NOT NULL,
    body_format_code    NVARCHAR(1000) NOT NULL REFERENCES base_info(id),
    status_code         NVARCHAR(1000) NOT NULL,
    author_display_name NVARCHAR(1000) NULL,
    author_email        NVARCHAR(1000) NULL,
    created_by          BIGINT NULL REFERENCES base_users(id),
    created_at          DATETIME2 NULL DEFAULT GETDATE(),
    moderated_by        BIGINT NULL,
    moderated_at        DATETIME2 NULL,
    CONSTRAINT fk_cms_comments_status FOREIGN KEY (status_code) REFERENCES base_info(id),
    CONSTRAINT fk_cms_comments_moderated_by FOREIGN KEY (moderated_by) REFERENCES base_users(id)
  );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_cms_comments_content_id' AND object_id = OBJECT_ID('dbo.cms_comments'))
BEGIN
  CREATE INDEX idx_cms_comments_content_id ON cms_comments (content_id);
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_cms_comments_status_code' AND object_id = OBJECT_ID('dbo.cms_comments'))
BEGIN
  CREATE INDEX idx_cms_comments_status_code ON cms_comments (status_code);
END;
