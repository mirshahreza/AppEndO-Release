-- Card-flow denormalized columns on dbo.hwy_members (snake_case).

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NULL
BEGIN
  PRINT 'hwy_member_card_flow_columns skipped — dbo.hwy_members not present';
END
ELSE
BEGIN
  IF COL_LENGTH(N'dbo.hwy_members', N'card_flow_last_status_id') IS NULL
    ALTER TABLE dbo.hwy_members ADD card_flow_last_status_id BIGINT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'card_flow_visibility') IS NULL
    ALTER TABLE dbo.hwy_members ADD card_flow_visibility BIT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'card_flow_started_by') IS NULL
    ALTER TABLE dbo.hwy_members ADD card_flow_started_by NVARCHAR(256) NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'card_flow_started_on') IS NULL
    ALTER TABLE dbo.hwy_members ADD card_flow_started_on DATETIME2 NULL;
  PRINT 'hwy member card-flow columns ready';
END
GO
