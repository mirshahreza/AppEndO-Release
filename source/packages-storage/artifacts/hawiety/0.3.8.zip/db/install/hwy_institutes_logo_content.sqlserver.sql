-- Institute logo bytes (public chrome + admin grid), not a user-editable URL field.
IF COL_LENGTH(N'dbo.hwy_institutes', N'logo_content') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_institutes ADD logo_content VARBINARY(MAX) NULL;
END;
IF COL_LENGTH(N'dbo.hwy_institutes', N'logo_content_type') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_institutes ADD logo_content_type NVARCHAR(127) NULL;
END;
GO
