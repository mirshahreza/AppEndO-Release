SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_stat_recalc_require_member
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  IF @member_id IS NULL OR @member_id <= 0
    THROW 50400, N'member_id is required.', 1;
  IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NULL
    THROW 50400, N'hwy_members is not available on this database.', 1;
  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_members WITH (NOLOCK) WHERE id = @member_id)
    THROW 50404, N'Member not found.', 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_stat_recalc_profile_fields
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  EXEC dbo.hwy_member_stat_recalc_require_member @member_id = @member_id;

  DECLARE @pct INT = dbo.hwy_member_calc_profile_percentage(@member_id);

  UPDATE dbo.hwy_members
  SET stat_fields_completed = ISNULL(@pct, 0)
  WHERE id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_stat_recalc_membership_days
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  EXEC dbo.hwy_member_stat_recalc_require_member @member_id = @member_id;
  UPDATE dbo.hwy_members
  SET stat_days = ISNULL(
    DATEDIFF(
      DAY,
      COALESCE(membership_on, CAST(created_at AS DATE)),
      CAST(GETDATE() AS DATE)
    ),
    0
  )
  WHERE id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_stat_recalc_dorat_count
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  EXEC dbo.hwy_member_stat_recalc_require_member @member_id = @member_id;
  UPDATE dbo.hwy_members
  SET stat_dorat_count = ISNULL((
    SELECT COUNT(1)
    FROM dbo.hwy_course_attendances ca WITH (NOLOCK)
    INNER JOIN dbo.hwy_courses c WITH (NOLOCK) ON c.id = ca.course_id
    WHERE ca.member_id = @member_id
      AND c.status_code = N'215116'
  ), 0)
  WHERE id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_stat_recalc_kasb_count
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  EXEC dbo.hwy_member_stat_recalc_require_member @member_id = @member_id;
  UPDATE m
  SET stat_kasb_count = ISNULL((
    SELECT COUNT(1)
    FROM dbo.hwy_members r WITH (NOLOCK)
    WHERE r.referrer_username = m.username
      AND (
        r.membership_status_code = N'10851'
        OR TRY_CAST(r.membership_status_code AS INT) = 10851
        OR r.membership_status_code LIKE N'%10851%'
      )
  ), 0)
  FROM dbo.hwy_members m
  WHERE m.id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_stat_recalc_nashatat_count
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  EXEC dbo.hwy_member_stat_recalc_require_member @member_id = @member_id;
  UPDATE dbo.hwy_members
  SET stat_nashatat_count = ISNULL((
    SELECT COUNT(1)
    FROM dbo.hwy_activity_attendances aa WITH (NOLOCK)
    INNER JOIN dbo.hwy_activities a WITH (NOLOCK) ON a.id = aa.activity_id
    WHERE aa.member_id = @member_id
      AND (
        a.activity_type_code = N'213915'
        OR (ISNULL(a.activity_type_code, N'') <> N'213915' AND a.status_code = N'211314')
      )
  ), 0)
  WHERE id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_stat_recalc_moassesat_count
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  EXEC dbo.hwy_member_stat_recalc_require_member @member_id = @member_id;
  UPDATE dbo.hwy_members
  SET stat_moassesat_count = ISNULL((
    SELECT COUNT(1)
    FROM dbo.hwy_member_institutes mi WITH (NOLOCK)
    WHERE mi.member_id = @member_id
      AND NOT (
        ISNULL(mi.member_accepted, 0) = 0
        AND mi.join_path_code IN (
          SELECT bi.id
          FROM dbo.base_info bi WITH (NOLOCK)
          INNER JOIN dbo.base_info cat WITH (NOLOCK) ON cat.id = bi.parent_id
          WHERE cat.title = N'Institute Join Path' AND bi.short_name = N'invite'
        )
      )
  ), 0)
  WHERE id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_stat_recalc_interviews_2022_count
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  EXEC dbo.hwy_member_stat_recalc_require_member @member_id = @member_id;

  DECLARE @count INT = 0;
  IF OBJECT_ID(N'dbo.hwy_member_interviews_2022', N'U') IS NOT NULL
  BEGIN
    SELECT @count = COUNT(1)
    FROM dbo.hwy_member_interviews_2022 WITH (NOLOCK)
    WHERE member_id = @member_id;
  END;

  UPDATE dbo.hwy_members
  SET stat_interviews_2022_count = ISNULL(@count, 0)
  WHERE id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_stat_recalc_cards_count
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  EXEC dbo.hwy_member_stat_recalc_require_member @member_id = @member_id;

  DECLARE @count INT = 0;
  IF OBJECT_ID(N'dbo.hwy_member_card_printing_history', N'U') IS NOT NULL
  BEGIN
    SELECT @count = COUNT(1)
    FROM dbo.hwy_member_card_printing_history WITH (NOLOCK)
    WHERE member_id = @member_id;
  END;

  UPDATE dbo.hwy_members
  SET stat_cards_count = ISNULL(@count, 0)
  WHERE id = @member_id;
END;
GO

IF OBJECT_ID(N'dbo.hwy_member_stat_recalc_stat2_badge_gates', N'P') IS NOT NULL
  DROP PROCEDURE dbo.hwy_member_stat_recalc_stat2_badge_gates;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_stat_recalc_has_passed_all
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  EXEC dbo.hwy_member_stat_recalc_require_member @member_id = @member_id;

  DECLARE @passed_all BIT = 0;
  IF OBJECT_ID(N'dbo.hwy_member_passed_necessary_dorat', N'FN') IS NOT NULL
    SET @passed_all = ISNULL(dbo.hwy_member_passed_necessary_dorat(@member_id), 0);

  UPDATE dbo.hwy_members
  SET stat_has_passed_all = @passed_all
  WHERE id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_stat_recalc_has_not_tosigh_older_than_x_days
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  EXEC dbo.hwy_member_stat_recalc_require_member @member_id = @member_id;

  UPDATE dbo.hwy_members
  SET stat_has_not_tosigh_older_than_x_days = ISNULL(
    dbo.hwy_member_has_not_tosigh_older_than_x_days(@member_id, 5),
    0
  )
  WHERE id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_stat_recalc_document_assets
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  EXEC dbo.hwy_member_stat_recalc_require_member @member_id = @member_id;

  UPDATE dbo.hwy_members
  SET stat_vasaegh_count = ISNULL((
    SELECT COUNT(DISTINCT kind.short_name)
    FROM dbo.hwy_member_files f WITH (NOLOCK)
    INNER JOIN dbo.base_info kind WITH (NOLOCK) ON kind.id = f.file_kind_code
    INNER JOIN dbo.base_info cat WITH (NOLOCK) ON cat.id = kind.parent_id AND cat.title = N'Member File Kind'
    WHERE f.member_id = @member_id
      AND f.content IS NOT NULL
      AND kind.short_name IN (
        N'national_card_front',
        N'national_card_back',
        N'voter_card_front',
        N'residence_card_front'
      )
  ), 0)
  WHERE id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_stat_recalc_employee_flag
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  EXEC dbo.hwy_member_stat_recalc_require_member @member_id = @member_id;
  IF OBJECT_ID(N'dbo.AppEnd_Users_R_Roles', N'U') IS NULL
  BEGIN
    UPDATE dbo.hwy_members SET stat_is_employee = CAST(0 AS BIT) WHERE id = @member_id;
    RETURN;
  END;
  UPDATE m
  SET stat_is_employee = CAST(CASE WHEN EXISTS (
    SELECT 1
    FROM dbo.AppEnd_Users_R_Roles urr WITH (NOLOCK)
    WHERE urr.UserId = m.user_id AND urr.Approved = 1
  ) THEN 1 ELSE 0 END AS BIT)
  FROM dbo.hwy_members m
  WHERE m.id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_stat_recalc_area_mismatch_count
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  EXEC dbo.hwy_member_stat_recalc_require_member @member_id = @member_id;

  DECLARE @count INT = 0;
  IF OBJECT_ID(N'dbo.hwy_member_area_limits', N'U') IS NOT NULL
     AND OBJECT_ID(N'dbo.hwy_members', N'U') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'area_limit_id') IS NOT NULL
  BEGIN
    SELECT @count = COUNT(1)
    FROM dbo.hwy_member_area_limits al WITH (NOLOCK)
    INNER JOIN dbo.hwy_members lm WITH (NOLOCK) ON lm.id = al.member_id
    WHERE al.member_id = @member_id
      AND al.approved = 1
      AND (
        (lm.area_limit_id = 111323 AND lm.nakheb_join_tamvin_id != al.item_id)
        OR (lm.area_limit_id = 111324 AND lm.nakheb_join_eghtera_id != al.item_id)
      );
  END;

  UPDATE dbo.hwy_members
  SET stat_adam_tatbigh_count = ISNULL(@count, 0)
  WHERE id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_stat_recalc_points
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  EXEC dbo.hwy_member_stat_recalc_require_member @member_id = @member_id;
  UPDATE dbo.hwy_members
  SET stat_points = ISNULL((
    SELECT SUM(points) FROM dbo.hwy_member_select_points(@member_id)
  ), 0)
  WHERE id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_stats_recalc_all
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  EXEC dbo.hwy_member_stat_recalc_profile_fields @member_id = @member_id;
  EXEC dbo.hwy_member_stat_recalc_membership_days @member_id = @member_id;
  EXEC dbo.hwy_member_stat_recalc_dorat_count @member_id = @member_id;
  EXEC dbo.hwy_member_stat_recalc_kasb_count @member_id = @member_id;
  EXEC dbo.hwy_member_stat_recalc_nashatat_count @member_id = @member_id;
  EXEC dbo.hwy_member_stat_recalc_moassesat_count @member_id = @member_id;
  EXEC dbo.hwy_member_stat_recalc_interviews_2022_count @member_id = @member_id;
  EXEC dbo.hwy_member_stat_recalc_cards_count @member_id = @member_id;
  EXEC dbo.hwy_member_stat_recalc_has_passed_all @member_id = @member_id;
  EXEC dbo.hwy_member_stat_recalc_has_not_tosigh_older_than_x_days @member_id = @member_id;
  EXEC dbo.hwy_member_stat_recalc_document_assets @member_id = @member_id;
  EXEC dbo.hwy_member_stat_recalc_employee_flag @member_id = @member_id;
  EXEC dbo.hwy_member_stat_recalc_area_mismatch_count @member_id = @member_id;
  EXEC dbo.hwy_member_stat_recalc_points @member_id = @member_id;
END;
GO
