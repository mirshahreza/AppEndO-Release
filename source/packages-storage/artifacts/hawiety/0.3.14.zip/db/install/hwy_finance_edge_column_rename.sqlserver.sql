-- AUTO-GENERATED — run: npx tsx scripts/hwy-phase1/db/gen-hwy-finance-column-rename-sql.ts
-- Finance / masoolin edge columns → snake_case (idempotent).

-- hwy_payment_documents
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'Id'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'id'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.Id', N'id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedBy'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_by'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.CreatedBy', N'created_by', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_on'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.CreatedOn', N'created_on', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'DocYear'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'doc_year'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.DocYear', N'doc_year', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'DocMonth'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'doc_month'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.DocMonth', N'doc_month', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'DocProvinceId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'doc_province_id'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.DocProvinceId', N'doc_province_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'DocCircleId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'doc_circle_id'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.DocCircleId', N'doc_circle_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'DocGenderId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'doc_gender_id'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.DocGenderId', N'doc_gender_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'AreaOk'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'area_ok'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.AreaOk', N'area_ok', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'AreaOkBy'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'area_ok_by'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.AreaOkBy', N'area_ok_by', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'AreaOkOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'area_ok_on'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.AreaOkOn', N'area_ok_on', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'FinalOk'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'final_ok'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.FinalOk', N'final_ok', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'FinalOkBy'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'final_ok_by'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.FinalOkBy', N'final_ok_by', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'FinalOkOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'final_ok_on'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.FinalOkOn', N'final_ok_on', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'Closed'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'closed'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.Closed', N'closed', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'ClosedBy'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'closed_by'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.ClosedBy', N'closed_by', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'ClosedOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'closed_on'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.ClosedOn', N'closed_on', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'TotalMembersCount'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'total_members_count'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.TotalMembersCount', N'total_members_count', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'PayableMembersCountOk'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'payable_members_count_ok'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.PayableMembersCountOk', N'payable_members_count_ok', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'PayableMembersCountNok'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'payable_members_count_nok'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.PayableMembersCountNok', N'payable_members_count_nok', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'NotPayableMembersCount'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'not_payable_members_count'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.NotPayableMembersCount', N'not_payable_members_count', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'TotalAmount'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'total_amount'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.TotalAmount', N'total_amount', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'PayableAmountOk'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'payable_amount_ok'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.PayableAmountOk', N'payable_amount_ok', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'PayableAmountNok'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'payable_amount_nok'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.PayableAmountNok', N'payable_amount_nok', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'NotPayableAmount'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents')
    AND c.name COLLATE Latin1_General_CS_AS = N'not_payable_amount'
)
  EXEC sp_rename N'dbo.hwy_payment_documents.NotPayableAmount', N'not_payable_amount', N'COLUMN';
GO

-- hwy_payment_documents_members
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'Id'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'id'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.Id', N'id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'DocumentId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'document_id'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.DocumentId', N'document_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'MemberId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'member_id'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.MemberId', N'member_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'RoleId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'role_id'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.RoleId', N'role_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'PayAmount'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'pay_amount'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.PayAmount', N'pay_amount', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'Payable'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'payable'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.Payable', N'payable', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'PayableBy'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'payable_by'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.PayableBy', N'payable_by', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'PayableOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'payable_on'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.PayableOn', N'payable_on', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'PayableResonId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'payable_reason_id'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.PayableResonId', N'payable_reason_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'PayOk'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'pay_ok'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.PayOk', N'pay_ok', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'PayOkBy'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'pay_ok_by'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.PayOkBy', N'pay_ok_by', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'PayOkOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'pay_ok_on'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.PayOkOn', N'pay_ok_on', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedBy'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_by'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.CreatedBy', N'created_by', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_on'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.CreatedOn', N'created_on', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'NbLocationLat'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'nb_location_lat'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.NbLocationLat', N'nb_location_lat', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'NbLocationLon'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'nb_location_lon'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.NbLocationLon', N'nb_location_lon', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'NbSelfi_FileName'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'nb_selfi_file_name'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.NbSelfi_FileName', N'nb_selfi_file_name', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'NbSelfi_FileSize'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'nb_selfi_file_size'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.NbSelfi_FileSize', N'nb_selfi_file_size', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'NbSelfi_FileMime'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'nb_selfi_file_mime'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.NbSelfi_FileMime', N'nb_selfi_file_mime', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'NbSelfi_FileBody'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'nb_selfi_file_body'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.NbSelfi_FileBody', N'nb_selfi_file_body', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'NbSelfi_FileBody_xs'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'nb_selfi_file_body_xs'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.NbSelfi_FileBody_xs', N'nb_selfi_file_body_xs', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'NbDeviceOs'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'nb_device_os'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.NbDeviceOs', N'nb_device_os', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'NbDeviceId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'nb_device_id'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.NbDeviceId', N'nb_device_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'NbDeviceDateTime'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members')
    AND c.name COLLATE Latin1_General_CS_AS = N'nb_device_datetime'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members.NbDeviceDateTime', N'nb_device_datetime', N'COLUMN';
GO

-- hwy_payment_documents_members_pay_amount_log
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members_pay_amount_log')
    AND c.name COLLATE Latin1_General_CS_AS = N'Id'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members_pay_amount_log')
    AND c.name COLLATE Latin1_General_CS_AS = N'id'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members_pay_amount_log.Id', N'id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members_pay_amount_log')
    AND c.name COLLATE Latin1_General_CS_AS = N'PaymentId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members_pay_amount_log')
    AND c.name COLLATE Latin1_General_CS_AS = N'payment_id'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members_pay_amount_log.PaymentId', N'payment_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members_pay_amount_log')
    AND c.name COLLATE Latin1_General_CS_AS = N'OldPayAmount'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members_pay_amount_log')
    AND c.name COLLATE Latin1_General_CS_AS = N'old_pay_amount'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members_pay_amount_log.OldPayAmount', N'old_pay_amount', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members_pay_amount_log')
    AND c.name COLLATE Latin1_General_CS_AS = N'NewPayAmount'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members_pay_amount_log')
    AND c.name COLLATE Latin1_General_CS_AS = N'new_pay_amount'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members_pay_amount_log.NewPayAmount', N'new_pay_amount', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members_pay_amount_log')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedBy'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members_pay_amount_log')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_by'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members_pay_amount_log.CreatedBy', N'created_by', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members_pay_amount_log')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_payment_documents_members_pay_amount_log')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_on'
)
  EXEC sp_rename N'dbo.hwy_payment_documents_members_pay_amount_log.CreatedOn', N'created_on', N'COLUMN';
GO

-- hwy_masoolin_stars
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars')
    AND c.name COLLATE Latin1_General_CS_AS = N'Id'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars')
    AND c.name COLLATE Latin1_General_CS_AS = N'id'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars.Id', N'id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars')
    AND c.name COLLATE Latin1_General_CS_AS = N'MemberId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars')
    AND c.name COLLATE Latin1_General_CS_AS = N'member_id'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars.MemberId', N'member_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars')
    AND c.name COLLATE Latin1_General_CS_AS = N'CalcYear'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars')
    AND c.name COLLATE Latin1_General_CS_AS = N'calc_year'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars.CalcYear', N'calc_year', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars')
    AND c.name COLLATE Latin1_General_CS_AS = N'CalcMonth'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars')
    AND c.name COLLATE Latin1_General_CS_AS = N'calc_month'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars.CalcMonth', N'calc_month', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars')
    AND c.name COLLATE Latin1_General_CS_AS = N'StarCode'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars')
    AND c.name COLLATE Latin1_General_CS_AS = N'star_code'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars.StarCode', N'star_code', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars')
    AND c.name COLLATE Latin1_General_CS_AS = N'StarValue'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars')
    AND c.name COLLATE Latin1_General_CS_AS = N'star_value'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars.StarValue', N'star_value', N'COLUMN';
GO

-- hwy_masoolin_stars_history
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'Id'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'id'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_history.Id', N'id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'MemberId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'member_id'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_history.MemberId', N'member_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'CalcYear'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'calc_year'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_history.CalcYear', N'calc_year', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'CalcMonth'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'calc_month'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_history.CalcMonth', N'calc_month', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'StarCode'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'star_code'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_history.StarCode', N'star_code', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'StarValue'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'star_value'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_history.StarValue', N'star_value', N'COLUMN';
GO

-- hwy_masoolin_stars_current
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_current')
    AND c.name COLLATE Latin1_General_CS_AS = N'Id'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_current')
    AND c.name COLLATE Latin1_General_CS_AS = N'id'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_current.Id', N'id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_current')
    AND c.name COLLATE Latin1_General_CS_AS = N'MemberId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_current')
    AND c.name COLLATE Latin1_General_CS_AS = N'member_id'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_current.MemberId', N'member_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_current')
    AND c.name COLLATE Latin1_General_CS_AS = N'CalcYear'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_current')
    AND c.name COLLATE Latin1_General_CS_AS = N'calc_year'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_current.CalcYear', N'calc_year', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_current')
    AND c.name COLLATE Latin1_General_CS_AS = N'CalcMonth'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_current')
    AND c.name COLLATE Latin1_General_CS_AS = N'calc_month'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_current.CalcMonth', N'calc_month', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_current')
    AND c.name COLLATE Latin1_General_CS_AS = N'StarCode'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_current')
    AND c.name COLLATE Latin1_General_CS_AS = N'star_code'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_current.StarCode', N'star_code', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_current')
    AND c.name COLLATE Latin1_General_CS_AS = N'StarValue'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_current')
    AND c.name COLLATE Latin1_General_CS_AS = N'star_value'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_current.StarValue', N'star_value', N'COLUMN';
GO

-- hwy_masoolin_stars_overal
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_overal')
    AND c.name COLLATE Latin1_General_CS_AS = N'Id'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_overal')
    AND c.name COLLATE Latin1_General_CS_AS = N'id'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_overal.Id', N'id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_overal')
    AND c.name COLLATE Latin1_General_CS_AS = N'CalcYear'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_overal')
    AND c.name COLLATE Latin1_General_CS_AS = N'calc_year'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_overal.CalcYear', N'calc_year', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_overal')
    AND c.name COLLATE Latin1_General_CS_AS = N'CalcMonth'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_overal')
    AND c.name COLLATE Latin1_General_CS_AS = N'calc_month'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_overal.CalcMonth', N'calc_month', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_overal')
    AND c.name COLLATE Latin1_General_CS_AS = N'MemberId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_overal')
    AND c.name COLLATE Latin1_General_CS_AS = N'member_id'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_overal.MemberId', N'member_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_overal')
    AND c.name COLLATE Latin1_General_CS_AS = N'StarsSum'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_overal')
    AND c.name COLLATE Latin1_General_CS_AS = N'stars_sum'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_overal.StarsSum', N'stars_sum', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_overal')
    AND c.name COLLATE Latin1_General_CS_AS = N'LevelId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_overal')
    AND c.name COLLATE Latin1_General_CS_AS = N'level_id'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_overal.LevelId', N'level_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_overal')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_masoolin_stars_overal')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_on'
)
  EXEC sp_rename N'dbo.hwy_masoolin_stars_overal.CreatedOn', N'created_on', N'COLUMN';
GO

-- hwy_legacy_app_end_roles
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_legacy_app_end_roles')
    AND c.name COLLATE Latin1_General_CS_AS = N'Id'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_legacy_app_end_roles')
    AND c.name COLLATE Latin1_General_CS_AS = N'id'
)
  EXEC sp_rename N'dbo.hwy_legacy_app_end_roles.Id', N'id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_legacy_app_end_roles')
    AND c.name COLLATE Latin1_General_CS_AS = N'RoleName'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_legacy_app_end_roles')
    AND c.name COLLATE Latin1_General_CS_AS = N'role_name'
)
  EXEC sp_rename N'dbo.hwy_legacy_app_end_roles.RoleName', N'role_name', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_legacy_app_end_roles')
    AND c.name COLLATE Latin1_General_CS_AS = N'IsExecutive'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_legacy_app_end_roles')
    AND c.name COLLATE Latin1_General_CS_AS = N'is_executive'
)
  EXEC sp_rename N'dbo.hwy_legacy_app_end_roles.IsExecutive', N'is_executive', N'COLUMN';
GO

