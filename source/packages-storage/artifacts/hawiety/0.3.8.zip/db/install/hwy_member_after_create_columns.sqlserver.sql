SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF COL_LENGTH(N'dbo.hwy_members', N'tosigh_confirm_code') IS NULL
  ALTER TABLE dbo.hwy_members ADD tosigh_confirm_code INT NULL;
GO

PRINT 'hwy member after-create columns ready';
