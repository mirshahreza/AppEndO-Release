-- Greenfield: applicant tracking uses hwy_members.id (legacy tracking-code repo retired).
IF OBJECT_ID(N'dbo.hwy_tracking_codes', N'U') IS NOT NULL
  DROP TABLE dbo.hwy_tracking_codes;
GO
