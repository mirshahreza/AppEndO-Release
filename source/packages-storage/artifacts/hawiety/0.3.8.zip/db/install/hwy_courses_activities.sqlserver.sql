-- Hawiety courses (دورات) + activities (نشاطات) — legacy HWY_Dorat / HWY_Nashatat mirror
-- Opt-in only — never run from app bootstrap.

IF OBJECT_ID(N'dbo.hwy_activities', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_activities (
    id                          BIGINT NOT NULL PRIMARY KEY,
    title                       NVARCHAR(256) NULL,
    note                        NVARCHAR(512) NULL,
    activity_date               DATE NULL,
    activity_type_code          NVARCHAR(64) NULL,
    activity_subtype_code       NVARCHAR(64) NULL,
    legacy_province_id          INT NULL,
    legacy_region_province_id   INT NULL,
    legacy_region_circle_id     INT NULL,
    status_code                 NVARCHAR(64) NULL,
    status_note                 NVARCHAR(512) NULL,
    nashat_location             NVARCHAR(128) NULL,
    enable_self_announcement    BIT NULL,
    require_submission_device_metadata BIT NULL,
    nb_location_lat             NVARCHAR(128) NULL,
    nb_location_lon             NVARCHAR(128) NULL,
    nb_max_distance_m           INT NULL,
    nb_window_start_at          DATETIME2 NULL,
    nb_window_end_at            DATETIME2 NULL,
    nb_legacy_province_id       NVARCHAR(128) NULL,
    nb_legacy_circle_id         INT NULL,
    nb_legacy_maktab_id         INT NULL,
    nb_legacy_region_id         INT NULL,
    nb_legacy_gender_id         INT NULL,
    nb_allowed_roles            NVARCHAR(128) NULL,
    nb_organization_ids         NVARCHAR(128) NULL,
    legacy_created_by           NVARCHAR(64) NULL,
    legacy_updated_by           NVARCHAR(64) NULL,
    created_by                  BIGINT NULL,
    created_at                  DATETIME2 NOT NULL CONSTRAINT DF_hwy_activities_created_at DEFAULT SYSUTCDATETIME(),
    updated_at                  DATETIME2 NULL,
    CONSTRAINT FK_hwy_activities_created_by FOREIGN KEY (created_by) REFERENCES dbo.base_users(id)
  );
  CREATE INDEX IX_hwy_activities_date ON dbo.hwy_activities (activity_date DESC, id);
  CREATE INDEX IX_hwy_activities_type ON dbo.hwy_activities (activity_type_code, activity_subtype_code);
END;
GO

IF OBJECT_ID(N'dbo.hwy_activity_attendances', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_activity_attendances (
    id                        BIGINT NOT NULL PRIMARY KEY,
    member_id                 BIGINT NOT NULL,
    activity_id               BIGINT NOT NULL,
    rfid_batch                NVARCHAR(32) NULL,
    from_legacy_province_id   INT NULL,
    from_legacy_circle_id     INT NULL,
    nb_location_lat           NVARCHAR(128) NULL,
    nb_location_lon           NVARCHAR(128) NULL,
    selfie_file_name          NVARCHAR(128) NULL,
    selfie_mime               NVARCHAR(32) NULL,
    selfie_size_bytes         INT NULL,
    selfie_content            VARBINARY(MAX) NULL,
    nb_device_os              NVARCHAR(128) NULL,
    nb_device_id              NVARCHAR(128) NULL,
    nb_device_datetime        NVARCHAR(32) NULL,
    legacy_created_by         NVARCHAR(64) NULL,
    created_at                DATETIME2 NOT NULL,
    CONSTRAINT FK_hwy_activity_att_member FOREIGN KEY (member_id) REFERENCES dbo.hwy_members(id) ON DELETE CASCADE,
    CONSTRAINT FK_hwy_activity_att_activity FOREIGN KEY (activity_id) REFERENCES dbo.hwy_activities(id) ON DELETE CASCADE
  );
  CREATE INDEX IX_hwy_activity_att_member ON dbo.hwy_activity_attendances (member_id, created_at DESC);
  CREATE INDEX IX_hwy_activity_att_activity ON dbo.hwy_activity_attendances (activity_id, created_at DESC);
END;
GO

IF OBJECT_ID(N'dbo.hwy_courses', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_courses (
    id                      BIGINT NOT NULL PRIMARY KEY,
    trainer_member_id       BIGINT NULL,
    legacy_province_id      INT NULL,
    course_type_code        NVARCHAR(64) NULL,
    course_subtype_code     NVARCHAR(64) NULL,
    note                    NVARCHAR(512) NULL,
    course_date             DATE NULL,
    status_code             NVARCHAR(64) NULL,
    status_note             NVARCHAR(500) NULL,
    legacy_created_by       NVARCHAR(64) NULL,
    legacy_updated_by       NVARCHAR(64) NULL,
    legacy_status_changed_by NVARCHAR(64) NULL,
    status_changed_at       DATETIME2 NULL,
    created_by              BIGINT NULL,
    created_at              DATETIME2 NOT NULL,
    updated_at              DATETIME2 NULL,
    CONSTRAINT FK_hwy_courses_trainer FOREIGN KEY (trainer_member_id) REFERENCES dbo.hwy_members(id),
    CONSTRAINT FK_hwy_courses_created_by FOREIGN KEY (created_by) REFERENCES dbo.base_users(id)
  );
  CREATE INDEX IX_hwy_courses_date ON dbo.hwy_courses (course_date DESC, id);
  CREATE INDEX IX_hwy_courses_type ON dbo.hwy_courses (course_type_code, course_subtype_code);
END;
GO

IF OBJECT_ID(N'dbo.hwy_course_attendances', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_course_attendances (
    id                  BIGINT NOT NULL PRIMARY KEY,
    member_id           BIGINT NOT NULL,
    course_id           BIGINT NOT NULL,
    note                NVARCHAR(512) NULL,
    nb_location_lat     NVARCHAR(128) NULL,
    nb_location_lon     NVARCHAR(128) NULL,
    nb_device_os        NVARCHAR(128) NULL,
    nb_device_id        NVARCHAR(128) NULL,
    nb_device_datetime  NVARCHAR(32) NULL,
    legacy_created_by   NVARCHAR(64) NULL,
    legacy_updated_by   NVARCHAR(64) NULL,
    created_at          DATETIME2 NOT NULL,
    updated_at          DATETIME2 NULL,
    CONSTRAINT FK_hwy_course_att_member FOREIGN KEY (member_id) REFERENCES dbo.hwy_members(id) ON DELETE CASCADE,
    CONSTRAINT FK_hwy_course_att_course FOREIGN KEY (course_id) REFERENCES dbo.hwy_courses(id) ON DELETE CASCADE
  );
  CREATE INDEX IX_hwy_course_att_member ON dbo.hwy_course_attendances (member_id, created_at DESC);
  CREATE INDEX IX_hwy_course_att_course ON dbo.hwy_course_attendances (course_id, created_at DESC);
END;
GO

IF OBJECT_ID(N'dbo.hwy_activity_approval_steps', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_activity_approval_steps (
    id                  UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    activity_id         BIGINT NOT NULL,
    status_code         NVARCHAR(64) NULL,
    note                NVARCHAR(512) NULL,
    legacy_created_by   NVARCHAR(64) NULL,
    created_at          DATETIME2 NOT NULL,
    CONSTRAINT FK_hwy_activity_approval_activity FOREIGN KEY (activity_id) REFERENCES dbo.hwy_activities(id) ON DELETE CASCADE
  );
  CREATE INDEX IX_hwy_activity_approval_activity ON dbo.hwy_activity_approval_steps (activity_id, created_at DESC);
END;
GO

IF OBJECT_ID(N'dbo.hwy_course_approval_steps', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_course_approval_steps (
    id                  UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    course_id           BIGINT NOT NULL,
    status_code         NVARCHAR(64) NULL,
    note                NVARCHAR(1000) NULL,
    legacy_created_by   NVARCHAR(64) NULL,
    created_at          DATETIME2 NULL,
    CONSTRAINT FK_hwy_course_approval_course FOREIGN KEY (course_id) REFERENCES dbo.hwy_courses(id) ON DELETE CASCADE
  );
  CREATE INDEX IX_hwy_course_approval_course ON dbo.hwy_course_approval_steps (course_id, created_at DESC);
END;
GO

IF OBJECT_ID(N'dbo.hwy_activity_files', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_activity_files (
    id                  UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    activity_id         BIGINT NOT NULL,
    original_file_name  NVARCHAR(256) NOT NULL,
    mime                NVARCHAR(32) NULL,
    size_bytes          INT NOT NULL,
    content             VARBINARY(MAX) NULL,
    thumbnail_content   VARBINARY(MAX) NULL,
    legacy_created_by   NVARCHAR(64) NULL,
    created_at          DATETIME2 NOT NULL,
    CONSTRAINT FK_hwy_activity_files_activity FOREIGN KEY (activity_id) REFERENCES dbo.hwy_activities(id) ON DELETE CASCADE
  );
  CREATE INDEX IX_hwy_activity_files_activity ON dbo.hwy_activity_files (activity_id, created_at DESC);
END;
GO

IF OBJECT_ID(N'dbo.hwy_activities', N'U') IS NOT NULL
  AND COL_LENGTH(N'dbo.hwy_activities', N'require_submission_device_metadata') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_activities ADD require_submission_device_metadata BIT NULL;
END;
GO

IF OBJECT_ID(N'dbo.hwy_activity_attendances', N'U') IS NOT NULL
  AND COL_LENGTH(N'dbo.hwy_activity_attendances', N'selfie_content') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_activity_attendances ADD selfie_content VARBINARY(MAX) NULL;
END;
GO
