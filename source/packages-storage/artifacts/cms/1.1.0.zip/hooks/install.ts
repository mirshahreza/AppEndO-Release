export default async function installCmsNavigation(api: any) {
  const result = await api.navigation.addGroupWithItems({
    navigationId: 'studio',
    heading: 'CMS',
    items: [
      { pageKey: 'cms-contents-list', routePattern: 'cms/contents', label: 'Contents', icon: 'Newspaper', order: 1 },
      { pageKey: 'cms-comments', routePattern: 'cms/comments', label: 'Comments', icon: 'MessageSquare', order: 2 },
      { pageKey: 'cms-settings', routePattern: 'cms/settings', label: 'Settings', icon: 'Settings', order: 3 },
      { pageKey: 'cms-vocab-content-types', routePattern: 'cms/vocabulary/content-types', label: 'Content Types', icon: 'Tags', order: 4, separatorBefore: true },
      { pageKey: 'cms-vocab-languages', routePattern: 'cms/vocabulary/languages', label: 'Languages', icon: 'Globe', order: 5 },
      { pageKey: 'cms-vocab-content-tags', routePattern: 'cms/vocabulary/content-tags', label: 'Content Tags', icon: 'Tag', order: 6 },
    ],
  });
  api.log(`CMS navigation group ${result.groupCreated ? 'created' : 'merged'}, ${result.itemsAdded} item(s) added.`);
}
