import{c as r,s as o}from"./flowDiagram-HODETNUW-CeE7aSaN.js";import{_ as m}from"./mermaid.core-CgobNDXm.js";import"./dayjs.min-CrKCef5E.js";import"./chunk-5VM5RSS4-BCHSW4H_.js";import"./chunk-XXDRQBXY-C_wYGACn.js";import"./d3-selection-D5hwjrp8.js";import"./chunk-POPQ4Y6H--g7rVUPQ.js";import"./chunk-F27PBJKO-7YZ468a2.js";import"./DesignerFormFields-BKiQU2-d.js";import"./index-DIHG-h7Q.js";import"./react-vendor-DelaA65R.js";import"./tanstack-query-CQz7GcnD.js";import"./HeroFieldControls-DR4zCw5u.js";import"./trash-2-zmzTNMxq.js";import"./index-DLLvKHfV.js";import"./index-Dqp_Gt79.js";import"./loader-circle-D0DQ_czg.js";import"./triangle-alert-CjtwA9rD.js";import"./designerDatePickerConfig-BSFQIAhw.js";import"./CalendarDate-BqDpojlb.js";import"./lucide-react-CQdqI_cB.js";import"./lock-CnOcs5Zf.js";import"./bot-CUnfXOaj.js";import"./terminal-DkeUqCSm.js";import"./flask-conical-Bv7o5DLU.js";import"./id-card-BCNhUeHD.js";import"./mail-AcE3F4o1.js";import"./refresh-cw-B1UAwEsw.js";import"./index-BdgjMRiR.js";import"./channel-Cn08lmn4.js";import"./iconify-Cw1FXWvc.js";var i=m(t=>`${o(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),p=i,H=r({defaultLayout:"swimlane",styles:p});export{H as diagram};
