SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_files_list
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(f.id AS VARCHAR(32)) AS id,
    CAST(f.member_id AS VARCHAR(32)) AS member_id,
    f.file_kind_code AS file_kind_code,
    bk.short_name AS file_kind_slug,
    f.original_file_name AS original_file_name,
    f.mime AS mime,
    f.size_bytes AS size_bytes,
    f.is_approved AS is_approved,
    CASE WHEN f.thumbnail_content IS NULL THEN 0 ELSE 1 END AS has_thumbnail,
    f.created_at AS created_at
  FROM dbo.hwy_member_files f
  LEFT JOIN dbo.base_info bk ON bk.id= f.file_kind_code
  WHERE f.member_id = @member_id
  ORDER BY f.file_kind_code, f.id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_institutes_list
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(mi.id AS VARCHAR(32)) AS id,
    CAST(mi.member_id AS VARCHAR(32)) AS member_id,
    mi.institute_id AS institute_id,
    i.code AS institute_code,
    i.title_ar AS institute_title,
    mi.status_code AS status_code,
    mi.join_path_code AS join_path_code,
    mi.member_accepted AS member_accepted,
    mi.activated_at AS activated_at,
    mi.character_code AS character_code,
    mi.institute_state_code AS institute_state_code,
    mi.institute_state_note AS institute_state_note,
    mi.institute_state_updated_on AS institute_state_updated_on,
    CAST(mi.institute_state_updated_by AS VARCHAR(32)) AS institute_state_updated_by,
    u_state.username AS institute_state_updated_by_display,
    mi.current_org_employment_id AS current_org_employment_id,
    mi.current_org_employment_note AS current_org_employment_note,
    CAST(i.show_institute_character_in_dossier AS BIT) AS show_institute_character_in_dossier,
    mi.created_at AS created_at
  FROM dbo.hwy_member_institutes mi
  LEFT JOIN dbo.hwy_institutes i ON i.id= mi.institute_id
  LEFT JOIN dbo.base_users u_state ON u_state.id= mi.institute_state_updated_by
  WHERE mi.member_id = @member_id
  ORDER BY i.title_ar, mi.institute_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_notes_list
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(n.id AS VARCHAR(32)) AS id,
    CAST(n.member_id AS VARCHAR(32)) AS member_id,
    n.body AS body,
    n.subject_code AS subject_code,
    n.created_at AS created_at,
    CAST(n.created_by AS VARCHAR(32)) AS created_by
  FROM dbo.hwy_member_notes n
  WHERE n.member_id = @member_id
  ORDER BY n.created_at DESC, n.id DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_targhin_requests_list
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(t.id AS VARCHAR(32)) AS id,
    CAST(t.member_id AS VARCHAR(32)) AS member_id,
    t.request_reason_code AS request_reason_code,
    t.request_note AS request_note,
    t.status_code AS status_code,
    t.created_at AS created_at,
    CAST(t.created_by AS VARCHAR(32)) AS created_by,
    t.final_reason_code AS final_reason_code,
    t.final_note AS final_note,
    t.final_at AS final_at,
    CAST(t.final_by AS VARCHAR(32)) AS final_by
  FROM dbo.hwy_member_targhin_requests t
  WHERE t.member_id = @member_id
  ORDER BY t.created_at DESC, t.id DESC;
END;
GO

-- Retired: member summary dossier lines come from base_record_events (see backfill script).
IF OBJECT_ID(N'dbo.hwy_member_dossier_change_log_member', N'P') IS NOT NULL
  DROP PROCEDURE dbo.hwy_member_dossier_change_log_member;
GO

-- Retired: notes/files/institutes/targhin dossier reads now come from base_record_events (see backfill script).
IF OBJECT_ID(N'dbo.hwy_member_dossier_change_log_files', N'P') IS NOT NULL
  DROP PROCEDURE dbo.hwy_member_dossier_change_log_files;
GO
IF OBJECT_ID(N'dbo.hwy_member_dossier_change_log_notes', N'P') IS NOT NULL
  DROP PROCEDURE dbo.hwy_member_dossier_change_log_notes;
GO
IF OBJECT_ID(N'dbo.hwy_member_dossier_change_log_institutes', N'P') IS NOT NULL
  DROP PROCEDURE dbo.hwy_member_dossier_change_log_institutes;
GO
IF OBJECT_ID(N'dbo.hwy_member_dossier_change_log_targhin', N'P') IS NOT NULL
  DROP PROCEDURE dbo.hwy_member_dossier_change_log_targhin;
GO
IF OBJECT_ID(N'dbo.hwy_member_dossier_change_log_phone', N'P') IS NOT NULL
  DROP PROCEDURE dbo.hwy_member_dossier_change_log_phone;
GO
IF OBJECT_ID(N'dbo.hwy_member_dossier_change_log_phone_requests', N'P') IS NOT NULL
  DROP PROCEDURE dbo.hwy_member_dossier_change_log_phone_requests;
GO

IF OBJECT_ID(N'dbo.hwy_member_dossier_change_log_security', N'P') IS NOT NULL
  DROP PROCEDURE dbo.hwy_member_dossier_change_log_security;
GO

IF OBJECT_ID(N'dbo.hwy_member_dossier_change_log_tracking', N'P') IS NOT NULL
  DROP PROCEDURE dbo.hwy_member_dossier_change_log_tracking;
GO
IF OBJECT_ID(N'dbo.hwy_member_dossier_change_log_username_repo', N'P') IS NOT NULL
  DROP PROCEDURE dbo.hwy_member_dossier_change_log_username_repo;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_kasb_acquired_list
  @host_member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(km.id AS VARCHAR(32)) AS kasb_member_id,
    km.username AS kasb_username,
    CASE
      WHEN LTRIM(RTRIM(km.referrer_username)) = LTRIM(RTRIM(host.username)) THEN N'referrer'
      ELSE N'secondReferrer'
    END AS link_slot,
    CASE
      WHEN LTRIM(RTRIM(km.referrer_username)) = LTRIM(RTRIM(host.username))
        THEN CAST(km.referrer_relation_id AS VARCHAR(32))
      ELSE CAST(km.second_referrer_relation_id AS VARCHAR(32))
    END AS referrer_relation_id
  FROM dbo.hwy_members host
  INNER JOIN dbo.hwy_members km ON 1 = 1
  WHERE host.id = @host_member_id
    AND NULLIF(LTRIM(RTRIM(host.username)), N'') IS NOT NULL
    AND (
      LTRIM(RTRIM(km.referrer_username)) = LTRIM(RTRIM(host.username))
      OR LTRIM(RTRIM(km.second_referrer_username)) = LTRIM(RTRIM(host.username))
    )
  ORDER BY km.id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_nakhebin_join_candidates
  @member_id BIGINT,
  @match_first_name BIT = 1,
  @match_father_name BIT = 1,
  @match_grandfather_name BIT = 1,
  @match_birth_year BIT = 0,
  @match_family_code BIT = 0,
  @scope_region_geo_id NVARCHAR(128) = NULL,
  @row_limit INT = 100
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @scope_region_id NVARCHAR(128) = dbo.hwy_resolve_raw_geo_to_base_info_id(@scope_region_geo_id);

  DECLARE @firstname NVARCHAR(4000);
  DECLARE @fathername NVARCHAR(4000);
  DECLARE @grandfathername NVARCHAR(4000);
  DECLARE @birth_year NVARCHAR(32);
  DECLARE @family_code NVARCHAR(4000);

  SELECT
    @firstname = LTRIM(RTRIM(ISNULL(first_name, N''))),
    @fathername = LTRIM(RTRIM(ISNULL(father_name, N''))),
    @grandfathername = LTRIM(RTRIM(ISNULL(grandfather_name, N''))),
    @birth_year = LTRIM(RTRIM(ISNULL(CAST(birth_year AS NVARCHAR(32)), N''))),
    @family_code = LTRIM(RTRIM(ISNULL(family_code, N'')))
  FROM dbo.hwy_members
  WHERE id= @member_id;

  IF @@ROWCOUNT = 0
    THROW 57300, N'Member not found.', 1;

  SELECT TOP (@row_limit)
    CAST(n.id AS VARCHAR(32)) AS id,
    n.first_name AS first_name,
    n.father_name AS father_name,
    n.grandfather_name AS grandfather_name,
    n.family_name AS family_name,
    n.birth_year AS birth_year,
    n.family_code AS family_code,
    CAST(n.member_id AS VARCHAR(32)) AS linked_member_id
  FROM dbo.hwy_nakhebin n WITH (NOLOCK)
  WHERE
    (@match_first_name = 0 OR @firstname = N'' OR LTRIM(RTRIM(ISNULL(n.first_name, N''))) = @firstname)
    AND (@match_father_name = 0 OR @fathername = N'' OR LTRIM(RTRIM(ISNULL(n.father_name, N''))) = @fathername)
    AND (@match_grandfather_name = 0 OR @grandfathername = N'' OR LTRIM(RTRIM(ISNULL(n.grandfather_name, N''))) = @grandfathername)
    AND (@match_birth_year = 0 OR @birth_year = N'' OR LTRIM(RTRIM(ISNULL(n.birth_year, N''))) = @birth_year)
    AND (
      @match_family_code = 0
      OR @family_code = N''
      OR LTRIM(RTRIM(ISNULL(n.family_code, N''))) = @family_code
    )
    AND (
      @scope_region_id IS NULL
      OR LTRIM(RTRIM(ISNULL(n.region_id, N''))) = @scope_region_id
      OR (
        @scope_region_geo_id IS NOT NULL
        AND LTRIM(RTRIM(@scope_region_geo_id)) <> N''
        AND LTRIM(RTRIM(ISNULL(n.region_id, N''))) = LTRIM(RTRIM(@scope_region_geo_id))
      )
    )
  ORDER BY n.id ASC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_nakhebin_eghtera_region_list
  @province_raw NVARCHAR(128) = NULL,
  @ancestor_raw NVARCHAR(128) = NULL,
  @search_like NVARCHAR(256) = NULL,
  @offset INT = 0,
  @page_size INT = 100
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @province_id NVARCHAR(128) = dbo.hwy_resolve_raw_geo_to_base_info_id(@province_raw);
  DECLARE @ancestor_id NVARCHAR(128) = dbo.hwy_resolve_raw_geo_to_base_info_id(@ancestor_raw);
  DECLARE @patch_id NVARCHAR(128) = COALESCE(@ancestor_id, @province_id);
  DECLARE @safe_offset INT = CASE WHEN @offset IS NULL OR @offset < 0 THEN 0 ELSE @offset END;
  DECLARE @safe_page_size INT = CASE
    WHEN @page_size IS NULL OR @page_size < 1 THEN 100
    WHEN @page_size > 500 THEN 500
    ELSE @page_size
  END;

  SELECT
    gm.base_info_id AS geo_base_info_id,
    gm.legacy_id AS legacy_geo_id,
    dbo.hwy_geo_leaf_title(gm.base_info_id) AS title,
    COALESCE(
      NULLIF(LTRIM(RTRIM(dbo.hwy_base_info_iq_title_path(gm.base_info_id))), N''),
      NULLIF(LTRIM(RTRIM(b.title_path_ar)), N''),
      NULLIF(LTRIM(RTRIM(b.title_path_en)), N'')
    ) AS title_path
  FROM dbo.hwy_etl_geo_map gm
  INNER JOIN dbo.base_info b ON b.id= gm.base_info_id
  WHERE gm.legacy_kind = N'region'
    AND b.is_active = 1
    AND (
      @patch_id IS NULL
      OR dbo.hwy_base_info_patch_contains_node(@patch_id, gm.base_info_id) = 1
    )
    AND (
      @search_like IS NULL
      OR dbo.hwy_geo_leaf_title(gm.base_info_id) LIKE @search_like
      OR COALESCE(
        NULLIF(LTRIM(RTRIM(dbo.hwy_base_info_iq_title_path(gm.base_info_id))), N''),
        NULLIF(LTRIM(RTRIM(b.title_path_ar)), N''),
        NULLIF(LTRIM(RTRIM(b.title_path_en)), N'')
      ) LIKE @search_like
    )
  ORDER BY title ASC, gm.legacy_id ASC
  OFFSET @safe_offset ROWS FETCH NEXT @safe_page_size ROWS ONLY;
END;
GO
