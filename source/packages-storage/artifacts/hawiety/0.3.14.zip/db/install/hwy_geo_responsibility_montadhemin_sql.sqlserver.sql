-- Geo-responsibility «ادارة المرشحين» — legacy parity for required-course check.
-- Source: dbo.hwy_member_passed_necessary_dorat (legacy hwy_ref_members_dorat + hwy_ref_dorat, StatusId = 215116).
-- Opt-in — applied via ensureHwyMemberPassedNecessaryDoratSql (not app bootstrap).

CREATE OR ALTER FUNCTION dbo.hwy_member_passed_necessary_dorat(@member_id BIGINT)
RETURNS BIT
AS
BEGIN
  DECLARE @PassedAllDoratCount INT = (
    SELECT COUNT(DISTINCT c.course_subtype_code)
    FROM dbo.hwy_course_attendances ca WITH (NOLOCK)
    INNER JOIN dbo.hwy_courses c WITH (NOLOCK) ON c.id= ca.course_id
    INNER JOIN dbo.hwy_members m WITH (NOLOCK) ON m.id= ca.member_id
    WHERE ca.member_id = @member_id
      AND c.status_code = N'215116'
      AND c.course_subtype_code IN (
        N'11071',
        N'11152',
        CASE
          WHEN m.gender_code IN (N'100.1.1', N'10011') THEN N'11028'
          ELSE N'11072'
        END
      )
  );

  IF (@PassedAllDoratCount >= 3) RETURN 1;
  RETURN 0;
END;
GO
