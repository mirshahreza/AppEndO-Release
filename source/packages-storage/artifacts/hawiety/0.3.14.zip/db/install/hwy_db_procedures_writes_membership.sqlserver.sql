SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER FUNCTION dbo.hwy_resolve_membership_status_id(@short_name NVARCHAR(128))
RETURNS NVARCHAR(128)
AS
BEGIN
  DECLARE @id NVARCHAR(128);
  SELECT TOP 1 @id = bi.id
  FROM dbo.base_info bi WITH (NOLOCK)
  INNER JOIN dbo.base_info cat WITH (NOLOCK) ON cat.id= bi.parent_id
  WHERE cat.title = N'Membership Status'
    AND bi.short_name = @short_name;
  RETURN @id;
END;
GO

CREATE OR ALTER FUNCTION dbo.hwy_resolve_member_note_subject_id(@short_name NVARCHAR(128))
RETURNS NVARCHAR(128)
AS
BEGIN
  DECLARE @id NVARCHAR(128);
  SELECT TOP 1 @id = bi.id
  FROM dbo.base_info bi WITH (NOLOCK)
  INNER JOIN dbo.base_info cat WITH (NOLOCK) ON cat.id= bi.parent_id
  WHERE cat.title = N'Member Note Subject'
    AND bi.short_name = @short_name;
  RETURN @id;
END;
GO

/** Legacy hwy_ref_base_information Id=111255 (self-registration tracking SMS). */
CREATE OR ALTER FUNCTION dbo.hwy_registration_tracking_sms_template()
RETURNS NVARCHAR(512)
AS
BEGIN
  RETURN N'تم التسجيل رقم المتابعة:@TrackingCode
سيتم الاتصال بكم.
للتوثيق:@TosighConfirmCode';
END;
GO

CREATE OR ALTER FUNCTION dbo.hwy_apply_registration_sms_tokens(
  @template NVARCHAR(512),
  @tracking_code NVARCHAR(64),
  @tosigh_confirm_code INT
)
RETURNS NVARCHAR(512)
AS
BEGIN
  DECLARE @message NVARCHAR(512) = @template;
  SET @message = REPLACE(@message, N'@TrackingCode', @tracking_code);
  SET @message = REPLACE(@message, N'@TosighConfirmCode', CAST(@tosigh_confirm_code AS NVARCHAR(16)));
  RETURN @message;
END;
GO

CREATE OR ALTER FUNCTION dbo.hwy_resolve_nakhebin_link_type_id(@short_name NVARCHAR(128))
RETURNS NVARCHAR(128)
AS
BEGIN
  DECLARE @id NVARCHAR(128);
  SELECT TOP 1 @id = bi.id
  FROM dbo.base_info bi WITH (NOLOCK)
  INNER JOIN dbo.base_info cat WITH (NOLOCK) ON cat.id= bi.parent_id
  WHERE cat.title = N'Nakhebin Link Type'
    AND bi.short_name = @short_name;
  RETURN @id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_membership_apply_call_center_decision
  @member_id BIGINT,
  @action NVARCHAR(32),
  @decision_reason_code NVARCHAR(128) = NULL,
  @decision_note NVARCHAR(4000),
  @actor_user_id BIGINT = NULL,
  @clear_referrer BIT = NULL,
  @replace_referrer_username NVARCHAR(4000) = NULL,
  @replace_referrer_relation_id INT = NULL
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  DECLARE @current NVARCHAR(128);
  DECLARE @next NVARCHAR(128);
  DECLARE @action_norm NVARCHAR(32) = LOWER(LTRIM(RTRIM(@action)));
  DECLARE @note_subject NVARCHAR(128) = dbo.hwy_resolve_member_note_subject_id(N'call_center');
  DECLARE @nakhebin_id BIGINT;

  BEGIN TRAN;

  SELECT
    @current = membership_status_code,
    @nakhebin_id = nakhebin_id
  FROM dbo.hwy_members WITH (UPDLOCK, ROWLOCK)
  WHERE id= @member_id;

  IF @current IS NULL
  BEGIN
    ROLLBACK;
    THROW 57000, N'Member not found.', 1;
  END;

  IF @action_norm = N'approve'
  BEGIN
    IF @current <> dbo.hwy_resolve_membership_status_id(N'pending_call_center')
    BEGIN
      ROLLBACK;
      THROW 57001, N'Member is not pending call center review.', 1;
    END;
    IF @nakhebin_id IS NULL
    BEGIN
      ROLLBACK;
      THROW 57006, N'Call center approval requires a nakhebin link.', 1;
    END;
    SET @next = dbo.hwy_resolve_membership_status_id(N'pending_local');
  END
  ELSE IF @action_norm = N'reject'
  BEGIN
    IF @current <> dbo.hwy_resolve_membership_status_id(N'pending_call_center')
    BEGIN
      ROLLBACK;
      THROW 57001, N'Member is not pending call center review.', 1;
    END;
    IF @decision_reason_code IS NULL OR LTRIM(RTRIM(@decision_reason_code)) = N''
    BEGIN
      ROLLBACK;
      THROW 57002, N'Decision reason is required for rejection.', 1;
    END;
    SET @next = dbo.hwy_resolve_membership_status_id(N'rejected_call_center');
  END
  ELSE IF @action_norm = N'unreject'
  BEGIN
    IF @current <> dbo.hwy_resolve_membership_status_id(N'rejected_call_center')
    BEGIN
      ROLLBACK;
      THROW 57003, N'Member is not in call center rejected queue.', 1;
    END;
    SET @next = dbo.hwy_resolve_membership_status_id(N'pending_call_center');
  END
  ELSE
  BEGIN
    ROLLBACK;
    THROW 57004, N'Unsupported call center action.', 1;
  END;

  IF @next IS NULL
  BEGIN
    ROLLBACK;
    THROW 57005, N'Membership status vocabulary is not configured.', 1;
  END;

  UPDATE dbo.hwy_members
  SET
    membership_status_code = @next,
    membership_status_updated_on = SYSUTCDATETIME(),
    membership_status_updated_by = @actor_user_id,
    updated_at = SYSUTCDATETIME(),
    updated_by = @actor_user_id
  WHERE id= @member_id;

  IF @action_norm = N'approve' AND @clear_referrer = 1
  BEGIN
    UPDATE dbo.hwy_members
    SET
      referrer_username = NULL,
      referrer_relation_id = NULL,
      referrer_institute_id = NULL,
      updated_at = SYSUTCDATETIME(),
      updated_by = @actor_user_id
    WHERE id= @member_id;
  END
  ELSE IF @action_norm = N'approve'
    AND @replace_referrer_username IS NOT NULL
    AND LTRIM(RTRIM(@replace_referrer_username)) <> N''
  BEGIN
    DECLARE @prior_referrer NVARCHAR(4000);
    DECLARE @prior_relation INT;

    SELECT
      @prior_referrer = referrer_username,
      @prior_relation = referrer_relation_id
    FROM dbo.hwy_members WITH (UPDLOCK, ROWLOCK)
    WHERE id= @member_id;

    IF @prior_referrer IS NOT NULL AND LTRIM(RTRIM(@prior_referrer)) <> N''
    BEGIN
      UPDATE dbo.hwy_members
      SET
        referrer_username_deleted = @prior_referrer,
        referrer_relation_id_deleted = @prior_relation,
        referrer_username = LTRIM(RTRIM(@replace_referrer_username)),
        referrer_relation_id = @replace_referrer_relation_id,
        referrer_institute_id = NULL,
        updated_at = SYSUTCDATETIME(),
        updated_by = @actor_user_id
      WHERE id= @member_id;
    END
    ELSE
    BEGIN
      UPDATE dbo.hwy_members
      SET
        referrer_username = LTRIM(RTRIM(@replace_referrer_username)),
        referrer_relation_id = @replace_referrer_relation_id,
        referrer_institute_id = NULL,
        updated_at = SYSUTCDATETIME(),
        updated_by = @actor_user_id
      WHERE id= @member_id;
    END;
  END;

  INSERT INTO dbo.hwy_member_notes (member_id, body, subject_code, created_by)
  VALUES (
    @member_id,
    @decision_note,
    @note_subject,
    @actor_user_id
  );

  COMMIT;

  SELECT
    CAST(@member_id AS VARCHAR(32)) AS member_id,
    @action_norm AS action,
    @current AS previous_membership_status_code,
    @next AS membership_status_code;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_membership_apply_local_decision
  @member_id BIGINT,
  @action NVARCHAR(32),
  @decision_reason_code NVARCHAR(128) = NULL,
  @decision_note NVARCHAR(4000),
  @actor_user_id BIGINT = NULL,
  @password_hash NVARCHAR(256) = NULL,
  @tosigh_confirm_code INT = NULL
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  DECLARE @current NVARCHAR(128);
  DECLARE @next NVARCHAR(128);
  DECLARE @action_norm NVARCHAR(32) = LOWER(LTRIM(RTRIM(@action)));
  DECLARE @note_subject NVARCHAR(128) = dbo.hwy_resolve_member_note_subject_id(N'local_verification');
  DECLARE @set_membership_on BIT = 0;
  DECLARE @assign_user_id BIGINT = NULL;
  DECLARE @assign_username NVARCHAR(4000) = NULL;
  DECLARE @existing_user_id BIGINT = NULL;
  DECLARE @repo_row_id BIGINT = NULL;
  DECLARE @allocated_username NVARCHAR(4000) = NULL;
  DECLARE @phone1 NVARCHAR(500) = NULL;
  DECLARE @member_email NVARCHAR(256) = NULL;
  DECLARE @new_user_id BIGINT = NULL;
  DECLARE @stored_tosigh_confirm_code INT = NULL;

  BEGIN TRAN;

  SELECT
    @current = membership_status_code,
    @existing_user_id = user_id,
    @phone1 = phone1,
    @stored_tosigh_confirm_code = tosigh_confirm_code
  FROM dbo.hwy_members WITH (UPDLOCK, ROWLOCK)
  WHERE id= @member_id;

  IF @current IS NULL
  BEGIN
    ROLLBACK;
    THROW 57100, N'Member not found.', 1;
  END;

  IF @action_norm = N'approve'
  BEGIN
    IF @current <> dbo.hwy_resolve_membership_status_id(N'pending_local')
    BEGIN
      ROLLBACK;
      THROW 57101, N'Member is not pending local verification.', 1;
    END;
    IF @tosigh_confirm_code IS NULL
      OR @stored_tosigh_confirm_code IS NULL
      OR @stored_tosigh_confirm_code <= 0
      OR @tosigh_confirm_code <> @stored_tosigh_confirm_code
    BEGIN
      ROLLBACK;
      THROW 57109, N'Tosigh confirmation code is invalid.', 1;
    END;
    SET @next = dbo.hwy_resolve_membership_status_id(N'active');
    SET @set_membership_on = 1;

    IF @existing_user_id IS NULL
    BEGIN
      IF @password_hash IS NULL OR LTRIM(RTRIM(@password_hash)) = N''
      BEGIN
        ROLLBACK;
        THROW 57106, N'Password hash is required to activate a member account.', 1;
      END;

      SELECT TOP 1
        @repo_row_id = r.id,
        @allocated_username = r.username
      FROM dbo.hwy_username_repo r WITH (UPDLOCK, READPAST)
      WHERE r.member_id IS NULL
        AND r.released_at IS NULL
      ORDER BY NEWID();

      IF @repo_row_id IS NULL
      BEGIN
        ROLLBACK;
        THROW 57107, N'No membership numbers available in username repo.', 1;
      END;

      SET @member_email = N'member-' + CAST(@member_id AS NVARCHAR(20)) + N'@member.hawiety.local';

      INSERT INTO dbo.base_users (
        username, email, password_hash, is_builtin, locked, login_fail_count, mobile, created_at, updated_at
      )
      VALUES (
        @allocated_username,
        @member_email,
        @password_hash,
        0,
        0,
        0,
        @phone1,
        SYSUTCDATETIME(),
        SYSUTCDATETIME()
      );

      SET @new_user_id = CAST(SCOPE_IDENTITY() AS BIGINT);

      UPDATE dbo.hwy_username_repo
      SET
        member_id = @member_id,
        reserved_at = SYSUTCDATETIME()
      WHERE id= @repo_row_id
        AND member_id IS NULL;

      IF @@ROWCOUNT = 0
      BEGIN
        ROLLBACK;
        THROW 57108, N'Username repo row was claimed by another transaction.', 1;
      END;

      SET @assign_user_id = @new_user_id;
      SET @assign_username = @allocated_username;
    END;
  END
  ELSE IF @action_norm = N'reject_final'
  BEGIN
    IF @current <> dbo.hwy_resolve_membership_status_id(N'pending_local')
    BEGIN
      ROLLBACK;
      THROW 57101, N'Member is not pending local verification.', 1;
    END;
    IF @decision_reason_code IS NULL OR LTRIM(RTRIM(@decision_reason_code)) = N''
    BEGIN
      ROLLBACK;
      THROW 57102, N'Decision reason is required for rejection.', 1;
    END;
    SET @next = dbo.hwy_resolve_membership_status_id(N'rejected_local_verification');
  END
  ELSE IF @action_norm = N'reject_returnable'
  BEGIN
    IF @current <> dbo.hwy_resolve_membership_status_id(N'pending_local')
    BEGIN
      ROLLBACK;
      THROW 57101, N'Member is not pending local verification.', 1;
    END;
    IF @decision_reason_code IS NULL OR LTRIM(RTRIM(@decision_reason_code)) = N''
    BEGIN
      ROLLBACK;
      THROW 57102, N'Decision reason is required for rejection.', 1;
    END;
    SET @next = dbo.hwy_resolve_membership_status_id(N'rejected_local');
  END
  ELSE IF @action_norm = N'reject_verification_bank'
  BEGIN
    IF @current <> dbo.hwy_resolve_membership_status_id(N'rejected_local')
    BEGIN
      ROLLBACK;
      THROW 57110, N'Member is not in returnable local rejected queue.', 1;
    END;
    IF @decision_reason_code IS NULL OR LTRIM(RTRIM(@decision_reason_code)) = N''
    BEGIN
      ROLLBACK;
      THROW 57102, N'Decision reason is required for rejection.', 1;
    END;
    SET @next = dbo.hwy_resolve_membership_status_id(N'rejected_local_verification');
  END
  ELSE IF @action_norm = N'unreject'
  BEGIN
    IF @current NOT IN (
      dbo.hwy_resolve_membership_status_id(N'rejected_local'),
      dbo.hwy_resolve_membership_status_id(N'rejected_local_verification')
    )
    BEGIN
      ROLLBACK;
      THROW 57103, N'Member is not in local rejected queue.', 1;
    END;
    SET @next = dbo.hwy_resolve_membership_status_id(N'pending_local');
  END
  ELSE
  BEGIN
    ROLLBACK;
    THROW 57104, N'Unsupported local verification action.', 1;
  END;

  IF @next IS NULL
  BEGIN
    ROLLBACK;
    THROW 57105, N'Membership status vocabulary is not configured.', 1;
  END;

  UPDATE dbo.hwy_members
  SET
    membership_status_code = @next,
    membership_status_updated_on = SYSUTCDATETIME(),
    membership_status_updated_by = @actor_user_id,
    membership_on = CASE WHEN @set_membership_on = 1 THEN CAST(SYSUTCDATETIME() AS DATE) ELSE membership_on END,
    user_id = COALESCE(@assign_user_id, user_id),
    username = COALESCE(@assign_username, username),
    updated_at = SYSUTCDATETIME(),
    updated_by = @actor_user_id
  WHERE id= @member_id;

  INSERT INTO dbo.hwy_member_notes (member_id, body, subject_code, created_by)
  VALUES (
    @member_id,
    @decision_note,
    @note_subject,
    @actor_user_id
  );

  COMMIT;

  SELECT
    CAST(@member_id AS VARCHAR(32)) AS member_id,
    @action_norm AS action,
    @current AS previous_membership_status_code,
    @next AS membership_status_code,
    @assign_username AS assigned_username;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_nakhebin_link
  @member_id BIGINT,
  @nakhebin_id BIGINT,
  @nakhebin_link_type_code NVARCHAR(128) = NULL,
  @nakhebin_link_region_id NVARCHAR(128) = NULL,
  @actor_user_id BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_nakhebin WHERE id= @nakhebin_id)
    THROW 57200, N'Nakhebin record not found.', 1;

  BEGIN TRAN;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_members WHERE id= @member_id)
  BEGIN
    ROLLBACK;
    THROW 57201, N'Member not found.', 1;
  END;

  UPDATE dbo.hwy_members
  SET
    nakhebin_id = @nakhebin_id,
    nakhebin_link_type_code = COALESCE(@nakhebin_link_type_code, dbo.hwy_resolve_nakhebin_link_type_id(N'ballot')),
    nakhebin_link_problem_reason_id = NULL,
    nakhebin_link_problem_note = NULL,
    nakhebin_link_region_id = @nakhebin_link_region_id,
    updated_at = SYSUTCDATETIME(),
    updated_by = @actor_user_id
  WHERE id= @member_id;

  COMMIT;

  SELECT CAST(@member_id AS VARCHAR(32)) AS member_id, CAST(@nakhebin_id AS VARCHAR(32)) AS nakhebin_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_nakhebin_link_family
  @member_id BIGINT,
  @nakhebin_id BIGINT,
  @family_code NVARCHAR(4000) = NULL,
  @nakhebin_link_region_id NVARCHAR(128) = NULL,
  @actor_user_id BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_nakhebin WHERE id= @nakhebin_id)
    THROW 57200, N'Nakhebin record not found.', 1;

  UPDATE dbo.hwy_members
  SET
    nakhebin_id = @nakhebin_id,
    nakhebin_link_type_code = dbo.hwy_resolve_nakhebin_link_type_id(N'family'),
    nakhebin_link_problem_reason_id = NULL,
    nakhebin_link_problem_note = NULL,
    nakhebin_link_region_id = @nakhebin_link_region_id,
    family_code = @family_code,
    updated_at = SYSUTCDATETIME(),
    updated_by = @actor_user_id
  WHERE id= @member_id;

  IF @@ROWCOUNT = 0
    THROW 57201, N'Member not found.', 1;

  SELECT CAST(@member_id AS VARCHAR(32)) AS member_id, CAST(@nakhebin_id AS VARCHAR(32)) AS nakhebin_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_nakhebin_link_eghtera
  @member_id BIGINT,
  @nakhebin_id BIGINT,
  @nakhebin_link_region_id NVARCHAR(128) = NULL,
  @actor_user_id BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_nakhebin WHERE id= @nakhebin_id)
    THROW 57200, N'Nakhebin record not found.', 1;

  UPDATE dbo.hwy_members
  SET
    nakhebin_id = @nakhebin_id,
    nakhebin_link_type_code = dbo.hwy_resolve_nakhebin_link_type_id(N'electoral_center'),
    nakhebin_link_problem_reason_id = NULL,
    nakhebin_link_problem_note = NULL,
    nakhebin_link_region_id = @nakhebin_link_region_id,
    updated_at = SYSUTCDATETIME(),
    updated_by = @actor_user_id
  WHERE id= @member_id;

  IF @@ROWCOUNT = 0
    THROW 57201, N'Member not found.', 1;

  SELECT CAST(@member_id AS VARCHAR(32)) AS member_id, CAST(@nakhebin_id AS VARCHAR(32)) AS nakhebin_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_nakhebin_link_with_problem
  @member_id BIGINT,
  @nakhebin_id BIGINT,
  @link_type_short NVARCHAR(64),
  @nakhebin_link_problem_reason_id NVARCHAR(128),
  @nakhebin_link_problem_note NVARCHAR(4000) = NULL,
  @nakhebin_link_region_id NVARCHAR(128) = NULL,
  @actor_user_id BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  DECLARE @link_type_norm NVARCHAR(64) = LOWER(LTRIM(RTRIM(@link_type_short)));
  DECLARE @link_type_id NVARCHAR(128);

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_nakhebin WHERE id= @nakhebin_id)
    THROW 57200, N'Nakhebin record not found.', 1;

  IF @nakhebin_link_problem_reason_id IS NULL OR LTRIM(RTRIM(@nakhebin_link_problem_reason_id)) = N''
    THROW 57210, N'Nakhebin link problem reason is required.', 1;

  IF @link_type_norm = N'family'
    SET @link_type_id = dbo.hwy_resolve_nakhebin_link_type_id(N'family');
  ELSE IF @link_type_norm IN (N'electoral_center', N'eghtera')
    SET @link_type_id = dbo.hwy_resolve_nakhebin_link_type_id(N'electoral_center');
  ELSE
    THROW 57211, N'Unsupported nakhebin link type for problem link.', 1;

  UPDATE dbo.hwy_members
  SET
    nakhebin_id = @nakhebin_id,
    nakhebin_link_type_code = @link_type_id,
    nakhebin_link_problem_reason_id = @nakhebin_link_problem_reason_id,
    nakhebin_link_problem_note = @nakhebin_link_problem_note,
    nakhebin_link_region_id = @nakhebin_link_region_id,
    updated_at = SYSUTCDATETIME(),
    updated_by = @actor_user_id
  WHERE id= @member_id;

  IF @@ROWCOUNT = 0
    THROW 57201, N'Member not found.', 1;

  SELECT CAST(@member_id AS VARCHAR(32)) AS member_id, CAST(@nakhebin_id AS VARCHAR(32)) AS nakhebin_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_nakhebin_clear
  @member_id BIGINT,
  @actor_user_id BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;

  UPDATE dbo.hwy_members
  SET
    nakhebin_id = NULL,
    nakhebin_link_type_code = NULL,
    nakhebin_link_problem_reason_id = NULL,
    nakhebin_link_problem_note = NULL,
    nakhebin_link_region_id = NULL,
    family_code = NULL,
    updated_at = SYSUTCDATETIME(),
    updated_by = @actor_user_id
  WHERE id= @member_id;

  IF @@ROWCOUNT = 0
    THROW 57210, N'Member not found.', 1;

  SELECT CAST(@member_id AS VARCHAR(32)) AS member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_nakhebin_change_roghe
  @member_id BIGINT,
  @nakhebin_link_region_id NVARCHAR(128),
  @actor_user_id BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;

  UPDATE dbo.hwy_members
  SET
    nakhebin_link_region_id = @nakhebin_link_region_id,
    updated_at = SYSUTCDATETIME(),
    updated_by = @actor_user_id
  WHERE id= @member_id;

  IF @@ROWCOUNT = 0
    THROW 57211, N'Member not found.', 1;

  SELECT CAST(@member_id AS VARCHAR(32)) AS member_id, @nakhebin_link_region_id AS nakhebin_link_region_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_set_addr_eghtera
  @member_id BIGINT,
  @addr_region_id NVARCHAR(128) = NULL,
  @addr_circle_id NVARCHAR(128) = NULL,
  @addr_maktab_id NVARCHAR(128) = NULL,
  @actor_user_id BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;

  UPDATE dbo.hwy_members
  SET
    addr_region_id = @addr_region_id,
    addr_circle_id = @addr_circle_id,
    addr_maktab_id = @addr_maktab_id,
    updated_at = SYSUTCDATETIME(),
    updated_by = @actor_user_id
  WHERE id= @member_id;

  IF @@ROWCOUNT = 0
    THROW 57212, N'Member not found.', 1;

  SELECT CAST(@member_id AS VARCHAR(32)) AS member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_after_create
  @member_id BIGINT,
  @actor_user_id BIGINT = NULL,
  @skip_note_mirror BIT = 0
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  DECLARE @note NVARCHAR(MAX);
  DECLARE @phone1 NVARCHAR(500);
  DECLARE @tracking_code NVARCHAR(64);
  DECLARE @registration_channel_code NVARCHAR(128);
  DECLARE @channel_short NVARCHAR(128);
  DECLARE @subject_membership NVARCHAR(128);
  DECLARE @sms_message NVARCHAR(512);
  DECLARE @tosigh_confirm_code INT;
  DECLARE @template NVARCHAR(512);
  DECLARE @institute_id BIGINT;
  DECLARE @institute_active NVARCHAR(128);
  DECLARE @join_self NVARCHAR(128);

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_members WHERE id= @member_id)
    THROW 57300, N'Member not found.', 1;

  SELECT
    @note = m.note,
    @phone1 = m.phone1,
    @registration_channel_code = m.registration_channel_code,
    @tosigh_confirm_code = m.tosigh_confirm_code
  FROM dbo.hwy_members m
  WHERE m.id = @member_id;

  SET @tracking_code = CAST(@member_id AS NVARCHAR(32));

  IF @tosigh_confirm_code IS NULL OR @tosigh_confirm_code <= 0
    SET @tosigh_confirm_code = ABS(CHECKSUM(NEWID())) % 10000;

  SELECT @channel_short = bi.short_name
  FROM dbo.base_info bi
  WHERE bi.id = @registration_channel_code;

  SET @subject_membership = dbo.hwy_resolve_member_note_subject_id(N'membership');

  IF @skip_note_mirror = 0
     AND @subject_membership IS NOT NULL
     AND @note IS NOT NULL
     AND LTRIM(RTRIM(@note)) <> N''
     AND NOT EXISTS (
       SELECT 1
       FROM dbo.hwy_member_notes n
       WHERE n.member_id = @member_id
         AND n.subject_code = @subject_membership
         AND n.body = @note
     )
  BEGIN
    INSERT INTO dbo.hwy_member_notes (member_id, body, subject_code, created_by)
    VALUES (@member_id, @note, @subject_membership, @actor_user_id);
  END;

  SELECT @institute_id = i.id
  FROM dbo.hwy_institutes i
  INNER JOIN dbo.base_info bi ON bi.id= @registration_channel_code
  WHERE LOWER(i.code) = LOWER(bi.short_name)
    AND bi.short_name IN (N'hemam', N'mehani', N'gov', N'shabab', N'protectors', N'nokhab', N'alforat');

  IF @institute_id IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM dbo.hwy_member_institutes mi
       WHERE mi.member_id = @member_id AND mi.institute_id = @institute_id
     )
  BEGIN
    SELECT TOP 1 @institute_active = bi.id
    FROM dbo.base_info bi
    INNER JOIN dbo.base_info cat ON cat.id= bi.parent_id
    WHERE cat.title = N'Institute Membership Status' AND bi.short_name = N'active';

    SELECT TOP 1 @join_self = bi.id
    FROM dbo.base_info bi
    INNER JOIN dbo.base_info cat ON cat.id= bi.parent_id
    WHERE cat.title = N'Institute Join Path' AND bi.short_name = N'self_registration';

    IF @institute_active IS NOT NULL AND @join_self IS NOT NULL
    BEGIN
      INSERT INTO dbo.hwy_member_institutes (
        member_id, institute_id, status_code, join_path_code, member_accepted, created_at, updated_at
      ) VALUES (
        @member_id, @institute_id, @institute_active, @join_self, 1, SYSUTCDATETIME(), SYSUTCDATETIME()
      );
    END;
  END;

  SET @template = dbo.hwy_registration_tracking_sms_template();
  SET @sms_message = N'';

  IF @channel_short IS NULL OR @channel_short NOT IN (N'other_portal')
    SET @sms_message = dbo.hwy_apply_registration_sms_tokens(@template, @tracking_code, @tosigh_confirm_code);

  UPDATE dbo.hwy_members
  SET
    tosigh_confirm_code = @tosigh_confirm_code,
    updated_at = SYSUTCDATETIME(),
    updated_by = COALESCE(@actor_user_id, updated_by)
  WHERE id= @member_id;

  SELECT
    CAST(@member_id AS VARCHAR(32)) AS member_id,
    LTRIM(RTRIM(@phone1)) AS phone1,
    @sms_message AS sms_message;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_after_create_resend
  @member_id BIGINT,
  @actor_user_id BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @phone1 NVARCHAR(500);
  DECLARE @tracking_code NVARCHAR(64);
  DECLARE @tosigh_confirm_code INT;
  DECLARE @template NVARCHAR(512);
  DECLARE @sms_message NVARCHAR(512);

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_members WHERE id= @member_id)
    THROW 57301, N'Member not found.', 1;

  SELECT
    @phone1 = m.phone1,
    @tosigh_confirm_code = m.tosigh_confirm_code
  FROM dbo.hwy_members m
  WHERE m.id = @member_id;

  SET @tracking_code = CAST(@member_id AS NVARCHAR(32));

  IF @tosigh_confirm_code IS NULL OR @tosigh_confirm_code <= 0
    SET @tosigh_confirm_code = ABS(CHECKSUM(NEWID())) % 10000;

  SET @template = dbo.hwy_registration_tracking_sms_template();
  SET @sms_message = dbo.hwy_apply_registration_sms_tokens(@template, @tracking_code, @tosigh_confirm_code);

  UPDATE dbo.hwy_members
  SET
    tosigh_confirm_code = @tosigh_confirm_code,
    updated_at = SYSUTCDATETIME(),
    updated_by = COALESCE(@actor_user_id, updated_by)
  WHERE id= @member_id;

  SELECT
    CAST(@member_id AS VARCHAR(32)) AS member_id,
    LTRIM(RTRIM(@phone1)) AS phone1,
    @sms_message AS sms_message;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_registration_files_sync_approve_flags
  @member_id BIGINT,
  @personal_photo_approved BIT = NULL,
  @national_card_front_approved BIT = NULL,
  @national_card_back_approved BIT = NULL,
  @voter_card_front_approved BIT = NULL,
  @residence_card_front_approved BIT = NULL,
  @actor_user_id BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  BEGIN TRAN;

  DECLARE @kinds TABLE (short_name NVARCHAR(64), approved BIT NULL);
  INSERT INTO @kinds (short_name, approved) VALUES
    (N'personal_photo', @personal_photo_approved),
    (N'national_card_front', @national_card_front_approved),
    (N'national_card_back', @national_card_back_approved),
    (N'voter_card_front', @voter_card_front_approved),
    (N'residence_card_front', @residence_card_front_approved);

  UPDATE f
  SET
    is_approved = k.approved,
    updated_at = SYSUTCDATETIME(),
    updated_by = @actor_user_id
  FROM dbo.hwy_member_files f
  INNER JOIN dbo.base_info kind ON kind.id= f.file_kind_code
  INNER JOIN dbo.base_info cat ON cat.id= kind.parent_id AND cat.title = N'Member File Kind'
  INNER JOIN @kinds k ON k.short_name = kind.short_name
  WHERE f.member_id = @member_id
    AND k.approved IS NOT NULL;

  EXEC dbo.hwy_member_sync_registration_files_member_row @member_id = @member_id;

  COMMIT;

  SELECT CAST(@member_id AS VARCHAR(32)) AS member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_legacy_identity_link
  @member_id BIGINT,
  @legacy_member_id BIGINT,
  @actor_user_id BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_members WHERE id= @member_id)
    THROW 57400, N'Member not found.', 1;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_members WHERE id= @legacy_member_id)
    THROW 57401, N'Legacy member id not found.', 1;

  UPDATE dbo.hwy_members
  SET
    note = CONCAT(COALESCE(note, N''), N' [legacy_link:', CAST(@legacy_member_id AS NVARCHAR(32)), N']'),
    updated_at = SYSUTCDATETIME(),
    updated_by = @actor_user_id
  WHERE id= @member_id;

  SELECT CAST(@member_id AS VARCHAR(32)) AS member_id, CAST(@legacy_member_id AS VARCHAR(32)) AS legacy_member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_targhin_apply_direct
  @member_id BIGINT,
  @request_reason_code NVARCHAR(128),
  @decision_reason_code NVARCHAR(128),
  @decision_note NVARCHAR(4000),
  @actor_user_id BIGINT = NULL,
  @membership_status_code_on_apply NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  BEGIN TRAN;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_members WHERE id= @member_id)
  BEGIN
    ROLLBACK;
    THROW 57500, N'Member not found.', 1;
  END;

  INSERT INTO dbo.hwy_member_targhin_requests (
    member_id, request_reason_code, request_note, status_code,
    final_reason_code, final_note, final_by, final_at, created_by
  )
  VALUES (
    @member_id, @request_reason_code, @decision_note, N'approved',
    @decision_reason_code, @decision_note, @actor_user_id, SYSUTCDATETIME(), @actor_user_id
  );

  IF @membership_status_code_on_apply IS NOT NULL
  BEGIN
    UPDATE dbo.hwy_members
    SET
      membership_status_code = @membership_status_code_on_apply,
      membership_status_updated_on = SYSUTCDATETIME(),
      membership_status_updated_by = @actor_user_id
    WHERE id= @member_id;
  END;

  COMMIT;

  SELECT CAST(@member_id AS VARCHAR(32)) AS member_id, N'approved' AS status_code;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_targhin_remove_direct
  @member_id BIGINT,
  @decision_reason_code NVARCHAR(128),
  @decision_note NVARCHAR(4000),
  @actor_user_id BIGINT = NULL,
  @membership_status_code_on_remove NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  BEGIN TRAN;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_members WHERE id= @member_id)
  BEGIN
    ROLLBACK;
    THROW 57510, N'Member not found.', 1;
  END;

  INSERT INTO dbo.hwy_member_targhin_requests (
    member_id, request_reason_code, request_note, status_code,
    final_reason_code, final_note, final_by, final_at, created_by
  )
  VALUES (
    @member_id, @decision_reason_code, @decision_note, N'rejected',
    @decision_reason_code, @decision_note, @actor_user_id, SYSUTCDATETIME(), @actor_user_id
  );

  IF @membership_status_code_on_remove IS NOT NULL
  BEGIN
    UPDATE dbo.hwy_members
    SET
      membership_status_code = @membership_status_code_on_remove,
      membership_status_updated_on = SYSUTCDATETIME(),
      membership_status_updated_by = @actor_user_id
    WHERE id= @member_id;
  END;

  COMMIT;

  SELECT CAST(@member_id AS VARCHAR(32)) AS member_id, N'rejected' AS status_code;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_institute_respond_invite
  @member_id BIGINT,
  @institute_id BIGINT,
  @accept BIT,
  @active_status_code NVARCHAR(128),
  @removed_status_code NVARCHAR(128) = NULL,
  @actor_user_id BIGINT = NULL,
  @responded_at DATETIME2
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  BEGIN TRAN;

  IF NOT EXISTS (
    SELECT 1 FROM dbo.hwy_member_institutes
    WHERE member_id = @member_id AND institute_id = @institute_id
  )
  BEGIN
    ROLLBACK;
    THROW 57600, N'Institute membership row not found.', 1;
  END;

  UPDATE dbo.hwy_member_institutes
  SET
    member_accepted = @accept,
    member_responded_at = @responded_at,
    status_code = CASE WHEN @accept = 1 THEN @active_status_code ELSE COALESCE(@removed_status_code, status_code) END,
    activated_at = CASE WHEN @accept = 1 THEN @responded_at ELSE activated_at END,
    updated_at = @responded_at,
    updated_by = @actor_user_id
  WHERE member_id = @member_id AND institute_id = @institute_id;

  COMMIT;

  SELECT CAST(@member_id AS VARCHAR(32)) AS member_id, CAST(@institute_id AS VARCHAR(32)) AS institute_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_institute_clear_employment
  @member_id BIGINT,
  @institute_id BIGINT,
  @actor_user_id BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;

  UPDATE dbo.hwy_member_institutes
  SET
    current_org_employment_id = NULL,
    current_org_employment_note = NULL,
    updated_at = SYSUTCDATETIME(),
    updated_by = @actor_user_id
  WHERE member_id = @member_id AND institute_id = @institute_id;

  IF @@ROWCOUNT = 0
    THROW 57610, N'Institute membership row not found.', 1;

  SELECT CAST(@member_id AS VARCHAR(32)) AS member_id, CAST(@institute_id AS VARCHAR(32)) AS institute_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_kasb_link
  @member_id BIGINT,
  @kasb_member_id BIGINT,
  @referrer_relation_id INT = NULL,
  @actor_user_id BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  DECLARE @host_username NVARCHAR(4000);
  DECLARE @kasb_username NVARCHAR(4000);
  DECLARE @resolved_kasb_id BIGINT;
  DECLARE @existing_referrer NVARCHAR(4000);
  DECLARE @existing_second NVARCHAR(4000);

  SELECT @host_username = username
  FROM dbo.hwy_members
  WHERE id= @member_id;

  IF @host_username IS NULL
    THROW 57621, N'Member not found.', 1;

  SELECT @resolved_kasb_id = id, @kasb_username = username
  FROM dbo.hwy_members
  WHERE id= @kasb_member_id;

  IF @kasb_username IS NULL
  BEGIN
    SELECT @resolved_kasb_id = id, @kasb_username = username
    FROM dbo.hwy_members
    WHERE username= LTRIM(RTRIM(CAST(@kasb_member_id AS NVARCHAR(32))));
  END;

  IF @kasb_username IS NULL OR @resolved_kasb_id IS NULL
    THROW 57620, N'Kasb member not found.', 1;

  IF @resolved_kasb_id = @member_id
    THROW 57623, N'Member cannot link kasb to themselves.', 1;

  SELECT
    @existing_referrer = referrer_username,
    @existing_second = second_referrer_username
  FROM dbo.hwy_members
  WHERE id= @resolved_kasb_id;

  IF LTRIM(RTRIM(ISNULL(@existing_referrer, N''))) = LTRIM(RTRIM(@host_username))
  BEGIN
    UPDATE dbo.hwy_members
    SET
      referrer_relation_id = @referrer_relation_id,
      updated_at = SYSUTCDATETIME(),
      updated_by = @actor_user_id
    WHERE id= @resolved_kasb_id;
  END
  ELSE IF LTRIM(RTRIM(ISNULL(@existing_second, N''))) = LTRIM(RTRIM(@host_username))
  BEGIN
    UPDATE dbo.hwy_members
    SET
      second_referrer_relation_id = @referrer_relation_id,
      updated_at = SYSUTCDATETIME(),
      updated_by = @actor_user_id
    WHERE id= @resolved_kasb_id;
  END
  ELSE IF NULLIF(LTRIM(RTRIM(@existing_referrer)), N'') IS NULL
  BEGIN
    UPDATE dbo.hwy_members
    SET
      referrer_username = @host_username,
      referrer_relation_id = @referrer_relation_id,
      updated_at = SYSUTCDATETIME(),
      updated_by = @actor_user_id
    WHERE id= @resolved_kasb_id;
  END
  ELSE IF NULLIF(LTRIM(RTRIM(@existing_second)), N'') IS NULL
  BEGIN
    UPDATE dbo.hwy_members
    SET
      second_referrer_username = @host_username,
      second_referrer_relation_id = @referrer_relation_id,
      updated_at = SYSUTCDATETIME(),
      updated_by = @actor_user_id
    WHERE id= @resolved_kasb_id;
  END
  ELSE
    THROW 57626, N'Kasb member already has referrer slots filled.', 1;

  SELECT CAST(@member_id AS VARCHAR(32)) AS member_id, @kasb_username AS kasb_username;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_kasb_unlink
  @member_id BIGINT,
  @kasb_member_id BIGINT,
  @actor_user_id BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  DECLARE @host_username NVARCHAR(4000);
  DECLARE @resolved_kasb_id BIGINT = @kasb_member_id;

  SELECT @host_username = username
  FROM dbo.hwy_members
  WHERE id= @member_id;

  IF @host_username IS NULL
    THROW 57621, N'Member not found.', 1;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_members WHERE id= @resolved_kasb_id)
  BEGIN
    SELECT @resolved_kasb_id = id
    FROM dbo.hwy_members
    WHERE username= LTRIM(RTRIM(CAST(@kasb_member_id AS NVARCHAR(32))));
  END;

  IF @resolved_kasb_id IS NULL
    THROW 57620, N'Kasb member not found.', 1;

  UPDATE dbo.hwy_members
  SET
    referrer_username = CASE
      WHEN LTRIM(RTRIM(ISNULL(referrer_username, N''))) = LTRIM(RTRIM(@host_username)) THEN NULL
      ELSE referrer_username
    END,
    referrer_relation_id = CASE
      WHEN LTRIM(RTRIM(ISNULL(referrer_username, N''))) = LTRIM(RTRIM(@host_username)) THEN NULL
      ELSE referrer_relation_id
    END,
    second_referrer_username = CASE
      WHEN LTRIM(RTRIM(ISNULL(second_referrer_username, N''))) = LTRIM(RTRIM(@host_username)) THEN NULL
      ELSE second_referrer_username
    END,
    second_referrer_relation_id = CASE
      WHEN LTRIM(RTRIM(ISNULL(second_referrer_username, N''))) = LTRIM(RTRIM(@host_username)) THEN NULL
      ELSE second_referrer_relation_id
    END,
    updated_at = SYSUTCDATETIME(),
    updated_by = @actor_user_id
  WHERE id= @resolved_kasb_id
    AND (
      LTRIM(RTRIM(ISNULL(referrer_username, N''))) = LTRIM(RTRIM(@host_username))
      OR LTRIM(RTRIM(ISNULL(second_referrer_username, N''))) = LTRIM(RTRIM(@host_username))
    );

  IF @@ROWCOUNT = 0
    THROW 57625, N'Kasb link not found.', 1;

  SELECT CAST(@member_id AS VARCHAR(32)) AS member_id;
END;
GO
