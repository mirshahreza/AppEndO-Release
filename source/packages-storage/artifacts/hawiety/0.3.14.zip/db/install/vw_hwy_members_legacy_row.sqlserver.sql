-- Member row read surface (snake_case). Blobs prefer dbo.hwy_member_files; legacy VARBINARY on m.* is fallback for ETL-only rows.
-- Column order: keys → identity (+ birth) → contact → membership → pipeline geo/card → media → approvals → masooliat.

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER VIEW dbo.vw_hwy_members_legacy_row
AS
SELECT
  m.id,
  m.user_id,
  m.username,
  m.first_name,
  m.father_name,
  m.grandfather_name,
  m.family_name,
  COALESCE(m.gender_id, m.gender_legacy_id) AS gender_id,
  m.national_id,
  m.birth_year,
  m.device_os_type_legacy_id,
  m.phone1,
  m.phone2,
  m.created_at,
  m.membership_on,
  m.membership_status_legacy,
  m.membership_status_updated_on,
  m.referrer_username,
  m.nakheb_join_province_id,
  m.nakheb_join_circle_id,
  m.nakheb_join_tamvin_id,
  m.nakheb_join_eghtera_id,
  m.area_limit_id,
  m.area_limit_province_id,
  m.area_limit_circle_id,
  m.area_limit_tamvin_id,
  m.education_level_legacy_id,
  m.card_flow_last_status_id,
  m.card_flow_visibility,
  m.card_flow_started_by,
  m.card_flow_started_on,
  COALESCE(pic.original_file_name, m.picture_file_name) AS picture_file_name,
  COALESCE(pic.size_bytes, m.picture_file_size) AS picture_file_size,
  COALESCE(pic.mime, m.picture_file_mime) AS picture_file_mime,
  COALESCE(pic.content, m.picture_file_body) AS picture_file_body,
  COALESCE(pic.thumbnail_content, pic.content, m.picture_file_body_xs) AS picture_file_body_xs,
  COALESCE(ncf.content, m.national_card_front_file_body) AS national_card_front_file_body,
  COALESCE(ncb.content, m.national_card_behind_file_body) AS national_card_behind_file_body,
  COALESCE(vot.content, m.nakheb_card_front_file_body) AS nakheb_card_front_file_body,
  COALESCE(res.content, m.maskan_card_front_file_body) AS maskan_card_front_file_body,
  COALESCE(vot.is_approved, m.nakheb_card_front_approved) AS nakheb_card_front_approved,
  COALESCE(ncf.is_approved, m.national_card_front_approved) AS national_card_front_approved,
  COALESCE(ncb.is_approved, m.national_card_behind_approved) AS national_card_behind_approved,
  COALESCE(pic.is_approved, m.picture_approved) AS picture_approved,
  oath.is_approved AS oath_approved,
  COALESCE(res.is_approved, m.maskan_card_front_approved) AS maskan_card_front_approved,
  CASE
    WHEN oath.content IS NOT NULL OR ISNULL(oath.size_bytes, 0) > 0
      THEN COALESCE(oath.size_bytes, DATALENGTH(oath.content), 0)
    ELSE CAST(0 AS BIGINT)
  END AS oath_file_size,
  m.stat_fields_completed,
  m.chief_masool,
  m.masooliat_sum_stars,
  m.masooliat_level_id,
  m.masooliat_stars_calculated_on,
  m.masooliat_sum_stars_current,
  m.masooliat_level_id_current
FROM dbo.hwy_members m
OUTER APPLY dbo.hwy_member_registration_file_pick(m.id, N'personal_photo') pic
OUTER APPLY dbo.hwy_member_registration_file_pick(m.id, N'national_card_front') ncf
OUTER APPLY dbo.hwy_member_registration_file_pick(m.id, N'national_card_back') ncb
OUTER APPLY dbo.hwy_member_registration_file_pick(m.id, N'voter_card_front') vot
OUTER APPLY dbo.hwy_member_registration_file_pick(m.id, N'residence_card_front') res
OUTER APPLY dbo.hwy_member_registration_file_pick(m.id, N'oath_document') oath;
GO

PRINT 'vw_hwy_members_legacy_row ready';
GO
