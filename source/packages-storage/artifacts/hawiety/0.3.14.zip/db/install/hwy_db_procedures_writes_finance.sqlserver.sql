-- Payment document workflow (single-step mutations; greenfield dbo.hwy_*).

CREATE OR ALTER PROCEDURE dbo.hwy_payment_documents_send_to_area
  @document_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  UPDATE dbo.hwy_payment_documents
  SET area_ok = 0, area_ok_by = NULL, area_ok_on = NULL
  WHERE id= @document_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_payment_documents_send_to_mali
  @document_id BIGINT,
  @actor_user_name NVARCHAR(128)
AS
BEGIN
  SET NOCOUNT ON;
  UPDATE dbo.hwy_payment_documents
  SET area_ok = 1, area_ok_by = @actor_user_name, area_ok_on = GETDATE()
  WHERE id= @document_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_payment_documents_mark_final_ok
  @document_id BIGINT,
  @actor_user_name NVARCHAR(128)
AS
BEGIN
  SET NOCOUNT ON;
  UPDATE dbo.hwy_payment_documents
  SET final_ok = 1, final_ok_by = @actor_user_name, final_ok_on = GETDATE()
  WHERE id= @document_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_payment_documents_mark_closed
  @document_id BIGINT,
  @actor_user_name NVARCHAR(128)
AS
BEGIN
  SET NOCOUNT ON;
  UPDATE dbo.hwy_payment_documents
  SET closed = 1, closed_by = @actor_user_name, closed_on = GETDATE()
  WHERE id= @document_id;
END;
GO
