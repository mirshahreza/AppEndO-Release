-- AUTO-GENERATED — run: node scripts/hwy-phase1/gen-hwy-parity-column-rename-sql.mjs
-- Rename parity table columns to snake_case on AppEndO edge (idempotent).

-- hwy_member_area_limits
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_area_limits')
    AND c.name COLLATE Latin1_General_CS_AS = N'Id'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_area_limits')
    AND c.name COLLATE Latin1_General_CS_AS = N'id'
)
  EXEC sp_rename N'dbo.hwy_member_area_limits.Id', N'id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_area_limits')
    AND c.name COLLATE Latin1_General_CS_AS = N'MemberId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_area_limits')
    AND c.name COLLATE Latin1_General_CS_AS = N'member_id'
)
  EXEC sp_rename N'dbo.hwy_member_area_limits.MemberId', N'member_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_area_limits')
    AND c.name COLLATE Latin1_General_CS_AS = N'ItemId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_area_limits')
    AND c.name COLLATE Latin1_General_CS_AS = N'item_id'
)
  EXEC sp_rename N'dbo.hwy_member_area_limits.ItemId', N'item_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_area_limits')
    AND c.name COLLATE Latin1_General_CS_AS = N'Approved'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_area_limits')
    AND c.name COLLATE Latin1_General_CS_AS = N'approved'
)
  EXEC sp_rename N'dbo.hwy_member_area_limits.Approved', N'approved', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_area_limits')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedBy'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_area_limits')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_by'
)
  EXEC sp_rename N'dbo.hwy_member_area_limits.CreatedBy', N'created_by', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_area_limits')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_area_limits')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_on'
)
  EXEC sp_rename N'dbo.hwy_member_area_limits.CreatedOn', N'created_on', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_area_limits')
    AND c.name COLLATE Latin1_General_CS_AS = N'ApprovedBy'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_area_limits')
    AND c.name COLLATE Latin1_General_CS_AS = N'approved_by'
)
  EXEC sp_rename N'dbo.hwy_member_area_limits.ApprovedBy', N'approved_by', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_area_limits')
    AND c.name COLLATE Latin1_General_CS_AS = N'ApprovedOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_area_limits')
    AND c.name COLLATE Latin1_General_CS_AS = N'approved_on'
)
  EXEC sp_rename N'dbo.hwy_member_area_limits.ApprovedOn', N'approved_on', N'COLUMN';
GO

-- hwy_member_card_printing_flow_steps
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_flow_steps')
    AND c.name COLLATE Latin1_General_CS_AS = N'Id'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_flow_steps')
    AND c.name COLLATE Latin1_General_CS_AS = N'id'
)
  EXEC sp_rename N'dbo.hwy_member_card_printing_flow_steps.Id', N'id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_flow_steps')
    AND c.name COLLATE Latin1_General_CS_AS = N'MemberId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_flow_steps')
    AND c.name COLLATE Latin1_General_CS_AS = N'member_id'
)
  EXEC sp_rename N'dbo.hwy_member_card_printing_flow_steps.MemberId', N'member_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_flow_steps')
    AND c.name COLLATE Latin1_General_CS_AS = N'StepId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_flow_steps')
    AND c.name COLLATE Latin1_General_CS_AS = N'step_id'
)
  EXEC sp_rename N'dbo.hwy_member_card_printing_flow_steps.StepId', N'step_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_flow_steps')
    AND c.name COLLATE Latin1_General_CS_AS = N'ReasonId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_flow_steps')
    AND c.name COLLATE Latin1_General_CS_AS = N'reason_id'
)
  EXEC sp_rename N'dbo.hwy_member_card_printing_flow_steps.ReasonId', N'reason_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_flow_steps')
    AND c.name COLLATE Latin1_General_CS_AS = N'Note'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_flow_steps')
    AND c.name COLLATE Latin1_General_CS_AS = N'note'
)
  EXEC sp_rename N'dbo.hwy_member_card_printing_flow_steps.Note', N'note', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_flow_steps')
    AND c.name COLLATE Latin1_General_CS_AS = N'StepBy'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_flow_steps')
    AND c.name COLLATE Latin1_General_CS_AS = N'step_by'
)
  EXEC sp_rename N'dbo.hwy_member_card_printing_flow_steps.StepBy', N'step_by', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_flow_steps')
    AND c.name COLLATE Latin1_General_CS_AS = N'StepOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_flow_steps')
    AND c.name COLLATE Latin1_General_CS_AS = N'step_on'
)
  EXEC sp_rename N'dbo.hwy_member_card_printing_flow_steps.StepOn', N'step_on', N'COLUMN';
GO

-- hwy_member_card_printing_history
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'Id'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'id'
)
  EXEC sp_rename N'dbo.hwy_member_card_printing_history.Id', N'id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'MemberId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'member_id'
)
  EXEC sp_rename N'dbo.hwy_member_card_printing_history.MemberId', N'member_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'RFID'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'rfid'
)
  EXEC sp_rename N'dbo.hwy_member_card_printing_history.RFID', N'rfid', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedBy'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_by'
)
  EXEC sp_rename N'dbo.hwy_member_card_printing_history.CreatedBy', N'created_by', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_on'
)
  EXEC sp_rename N'dbo.hwy_member_card_printing_history.CreatedOn', N'created_on', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'TypeId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'type_id'
)
  EXEC sp_rename N'dbo.hwy_member_card_printing_history.TypeId', N'type_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'ExpirationDate'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_card_printing_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'expiration_date'
)
  EXEC sp_rename N'dbo.hwy_member_card_printing_history.ExpirationDate', N'expiration_date', N'COLUMN';
GO

-- hwy_member_interviews_2022
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'Id'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'id'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.Id', N'id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'MemberId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'member_id'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.MemberId', N'member_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'InterviewOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'interview_on'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.InterviewOn', N'interview_on', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'Karizma'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'karizma'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.Karizma', N'karizma', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'LikeToLearnMore'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'like_to_learn_more'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.LikeToLearnMore', N'like_to_learn_more', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'ShowIsFan'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'show_is_fan'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.ShowIsFan', N'show_is_fan', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'AbilityToMakeTeam'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'ability_to_make_team'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.AbilityToMakeTeam', N'ability_to_make_team', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'Ghodrat_Elec'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'ghodrat_elec'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.Ghodrat_Elec', N'ghodrat_elec', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'Knows_Masoolin'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'knows_masoolin'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.Knows_Masoolin', N'knows_masoolin', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'IsMotefaregh'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'is_motefaregh'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.IsMotefaregh', N'is_motefaregh', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'IsMotefaregh_Saat'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'is_motefaregh_saat'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.IsMotefaregh_Saat', N'is_motefaregh_saat', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'Note'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'note'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.Note', N'note', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'FinalResult'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'final_result'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.FinalResult', N'final_result', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'FinalResult_Back'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'final_result_back'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.FinalResult_Back', N'final_result_back', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'TempNoView'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'temp_no_view'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.TempNoView', N'temp_no_view', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'HasProblem'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'has_problem'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.HasProblem', N'has_problem', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'ProblemReason'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'problem_reason'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.ProblemReason', N'problem_reason', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'ProblemNote'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'problem_note'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.ProblemNote', N'problem_note', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedBy'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_by'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.CreatedBy', N'created_by', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_on'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022.CreatedOn', N'created_on', N'COLUMN';
GO

-- hwy_member_interviews_2022_hazerin
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022_hazerin')
    AND c.name COLLATE Latin1_General_CS_AS = N'Id'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022_hazerin')
    AND c.name COLLATE Latin1_General_CS_AS = N'id'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022_hazerin.Id', N'id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022_hazerin')
    AND c.name COLLATE Latin1_General_CS_AS = N'InterviewId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022_hazerin')
    AND c.name COLLATE Latin1_General_CS_AS = N'interview_id'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022_hazerin.InterviewId', N'interview_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022_hazerin')
    AND c.name COLLATE Latin1_General_CS_AS = N'HazerId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022_hazerin')
    AND c.name COLLATE Latin1_General_CS_AS = N'hazer_id'
)
  EXEC sp_rename N'dbo.hwy_member_interviews_2022_hazerin.HazerId', N'hazer_id', N'COLUMN';
GO

-- hwy_member_security_statuses
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_statuses')
    AND c.name COLLATE Latin1_General_CS_AS = N'Id'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_statuses')
    AND c.name COLLATE Latin1_General_CS_AS = N'id'
)
  EXEC sp_rename N'dbo.hwy_member_security_statuses.Id', N'id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_statuses')
    AND c.name COLLATE Latin1_General_CS_AS = N'MemberId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_statuses')
    AND c.name COLLATE Latin1_General_CS_AS = N'member_id'
)
  EXEC sp_rename N'dbo.hwy_member_security_statuses.MemberId', N'member_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_statuses')
    AND c.name COLLATE Latin1_General_CS_AS = N'FinalResult'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_statuses')
    AND c.name COLLATE Latin1_General_CS_AS = N'final_result'
)
  EXEC sp_rename N'dbo.hwy_member_security_statuses.FinalResult', N'final_result', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_statuses')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedBy'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_statuses')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_by'
)
  EXEC sp_rename N'dbo.hwy_member_security_statuses.CreatedBy', N'created_by', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_statuses')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_statuses')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_on'
)
  EXEC sp_rename N'dbo.hwy_member_security_statuses.CreatedOn', N'created_on', N'COLUMN';
GO

-- hwy_member_security_profile_history
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'Id'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'id'
)
  EXEC sp_rename N'dbo.hwy_member_security_profile_history.Id', N'id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'MemberId'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'member_id'
)
  EXEC sp_rename N'dbo.hwy_member_security_profile_history.MemberId', N'member_id', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'CanGetIdentityCard'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'can_get_identity_card'
)
  EXEC sp_rename N'dbo.hwy_member_security_profile_history.CanGetIdentityCard', N'can_get_identity_card', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'CanGetIdentityCard_Note'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'can_get_identity_card_note'
)
  EXEC sp_rename N'dbo.hwy_member_security_profile_history.CanGetIdentityCard_Note', N'can_get_identity_card_note', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'CanGetMasooliat'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'can_get_masooliat'
)
  EXEC sp_rename N'dbo.hwy_member_security_profile_history.CanGetMasooliat', N'can_get_masooliat', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'CanGetMasooliat_Note'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'can_get_masooliat_note'
)
  EXEC sp_rename N'dbo.hwy_member_security_profile_history.CanGetMasooliat_Note', N'can_get_masooliat_note', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'CanBeMemberOfAammeh'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'can_be_member_of_aammeh'
)
  EXEC sp_rename N'dbo.hwy_member_security_profile_history.CanBeMemberOfAammeh', N'can_be_member_of_aammeh', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'CanBeMemberOfAammeh_Note'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'can_be_member_of_aammeh_note'
)
  EXEC sp_rename N'dbo.hwy_member_security_profile_history.CanBeMemberOfAammeh_Note', N'can_be_member_of_aammeh_note', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'AllowsResponsibility'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'allows_responsibility'
)
  EXEC sp_rename N'dbo.hwy_member_security_profile_history.AllowsResponsibility', N'allows_responsibility', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'AllowsResponsibility_Note'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'allows_responsibility_note'
)
  EXEC sp_rename N'dbo.hwy_member_security_profile_history.AllowsResponsibility_Note', N'allows_responsibility_note', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedBy'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_by'
)
  EXEC sp_rename N'dbo.hwy_member_security_profile_history.CreatedBy', N'created_by', N'COLUMN';
IF EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'CreatedOn'
) AND NOT EXISTS (
  SELECT 1 FROM sys.columns c
  WHERE c.object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
    AND c.name COLLATE Latin1_General_CS_AS = N'created_on'
)
  EXEC sp_rename N'dbo.hwy_member_security_profile_history.CreatedOn', N'created_on', N'COLUMN';
GO

