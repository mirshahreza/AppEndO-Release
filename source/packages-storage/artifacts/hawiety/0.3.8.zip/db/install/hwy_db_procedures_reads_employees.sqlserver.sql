-- Legacy parity: HWY_Employees_List (Read_Employees) — registered members with ≥1 approved platform role.

CREATE OR ALTER FUNCTION dbo.hwy_employees_list_where_clause(
  @username NVARCHAR(128) = NULL,
  @phone NVARCHAR(64) = NULL,
  @first_name NVARCHAR(128) = NULL,
  @father_name NVARCHAR(128) = NULL,
  @grandfather_name NVARCHAR(128) = NULL,
  @last_name NVARCHAR(128) = NULL,
  @gender_id NVARCHAR(32) = NULL,
  @role_id NVARCHAR(32) = NULL,
  @v_province_id BIGINT = NULL,
  @v_circle_id BIGINT = NULL,
  @v_tamvin_id BIGINT = NULL,
  @v_has_ghasam NVARCHAR(8) = NULL,
  @v_area_has_problem NVARCHAR(8) = NULL,
  @v_fields_completed NVARCHAR(8) = NULL,
  @alias NVARCHAR(8) = N'M'
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
  DECLARE @w NVARCHAR(MAX) = N'';

  IF NULLIF(LTRIM(RTRIM(@username)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.username LIKE N''%'' + @p_username + N''%''';
  IF NULLIF(LTRIM(RTRIM(@phone)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.phone1 LIKE N''%'' + @p_phone + N''%''';
  IF NULLIF(LTRIM(RTRIM(@first_name)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.first_name LIKE N''%'' + @p_first_name + N''%''';
  IF NULLIF(LTRIM(RTRIM(@father_name)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.father_name LIKE N''%'' + @p_father_name + N''%''';
  IF NULLIF(LTRIM(RTRIM(@grandfather_name)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.grandfather_name LIKE N''%'' + @p_grandfather_name + N''%''';
  IF NULLIF(LTRIM(RTRIM(@last_name)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.family_name LIKE N''%'' + @p_last_name + N''%''';
  IF NULLIF(LTRIM(RTRIM(@gender_id)), N'') IS NOT NULL
    SET @w = @w + N' AND CAST(' + @alias + N'.gender_legacy_id AS NVARCHAR(32)) = @p_gender_id';

  IF NULLIF(LTRIM(RTRIM(@role_id)), N'') IS NOT NULL
    SET @w = @w + N' AND EXISTS (SELECT 1 FROM dbo.AppEnd_Users_R_Roles URR WITH (NOLOCK) WHERE URR.UserId = ' + @alias + N'.user_id AND CAST(URR.RoleId AS NVARCHAR(32)) = @p_role_id)';

  DECLARE @vp BIGINT = @v_province_id;
  IF @vp IS NOT NULL AND @vp <> -1
    SET @w = @w + N' AND (' + @alias + N'.area_limit_province_id = @p_v_province_id OR @p_v_province_id IN (SELECT al.item_id FROM dbo.hwy_member_area_limits al WITH (NOLOCK) WHERE al.member_id = ' + @alias + N'.id))';

  DECLARE @vc BIGINT = @v_circle_id;
  IF @vc IS NOT NULL AND @vc <> -1
    SET @w = @w + N' AND (' + @alias + N'.area_limit_circle_id = @p_v_circle_id OR @p_v_circle_id IN (SELECT al.item_id FROM dbo.hwy_member_area_limits al WITH (NOLOCK) WHERE al.member_id = ' + @alias + N'.id))';

  DECLARE @vt BIGINT = @v_tamvin_id;
  IF @vt IS NOT NULL AND @vt <> -1
    SET @w = @w + N' AND (' + @alias + N'.area_limit_tamvin_id = @p_v_tamvin_id OR @p_v_tamvin_id IN (SELECT al.item_id FROM dbo.hwy_member_area_limits al WITH (NOLOCK) WHERE al.member_id = ' + @alias + N'.id))';

  DECLARE @hg NVARCHAR(8) = NULLIF(LTRIM(RTRIM(@v_has_ghasam)), N'');
  IF @hg IS NOT NULL AND @hg <> N'-1'
  BEGIN
    IF @hg = N'0'
      SET @w = @w + N' AND (ISNULL(' + @alias + N'.oath_file_size, 0) = 0)';
    ELSE IF @hg = N'1'
      SET @w = @w + N' AND (ISNULL(' + @alias + N'.oath_file_size, 0) > 0)';
  END;

  DECLARE @ahp NVARCHAR(8) = NULLIF(LTRIM(RTRIM(@v_area_has_problem)), N'');
  IF @ahp = N'1'
    SET @w = @w + N' AND ISNULL(' + @alias + N'.area_limit_id, 0) <> 111321 AND NOT EXISTS (SELECT 1 FROM dbo.hwy_member_area_limits al WITH (NOLOCK) WHERE al.member_id = ' + @alias + N'.id)';

  DECLARE @fc NVARCHAR(8) = NULLIF(LTRIM(RTRIM(@v_fields_completed)), N'');
  IF @fc IS NOT NULL AND @fc <> N'-1'
  BEGIN
    IF @fc = N'1'
      SET @w = @w + N' AND ISNULL(' + @alias + N'.stat_fields_completed, 0) = 100';
    ELSE IF @fc = N'0'
      SET @w = @w + N' AND ISNULL(' + @alias + N'.stat_fields_completed, 0) < 100';
  END;

  RETURN @w;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_employees_list_count
  @username NVARCHAR(128) = NULL,
  @phone NVARCHAR(64) = NULL,
  @first_name NVARCHAR(128) = NULL,
  @father_name NVARCHAR(128) = NULL,
  @grandfather_name NVARCHAR(128) = NULL,
  @last_name NVARCHAR(128) = NULL,
  @gender_id NVARCHAR(32) = NULL,
  @role_id NVARCHAR(32) = NULL,
  @v_province_id BIGINT = -1,
  @v_circle_id BIGINT = -1,
  @v_tamvin_id BIGINT = -1,
  @v_has_ghasam NVARCHAR(8) = N'-1',
  @v_area_has_problem NVARCHAR(8) = N'-1',
  @v_fields_completed NVARCHAR(8) = N'-1'
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NULL
    THROW 50400, N'dbo.hwy_members is not available.', 1;

  DECLARE @where NVARCHAR(MAX) = dbo.hwy_employees_list_where_clause(
    @username, @phone, @first_name, @father_name, @grandfather_name, @last_name,
    @gender_id, @role_id, @v_province_id, @v_circle_id, @v_tamvin_id,
    @v_has_ghasam, @v_area_has_problem, @v_fields_completed, N'M');

  DECLARE @sql NVARCHAR(MAX) = N'
    SELECT COUNT(*) AS total
    FROM dbo.hwy_members M WITH (NOLOCK)
    WHERE M.membership_status_legacy = 10851
      AND M.user_id IS NOT NULL
      AND EXISTS (
        SELECT 1 FROM dbo.AppEnd_Users_R_Roles URR WITH (NOLOCK)
        WHERE URR.UserId = M.user_id AND URR.Approved = 1
      )' + @where;

  EXEC sp_executesql @sql,
    N'@p_username NVARCHAR(128), @p_phone NVARCHAR(64), @p_first_name NVARCHAR(128), @p_father_name NVARCHAR(128), @p_grandfather_name NVARCHAR(128), @p_last_name NVARCHAR(128), @p_gender_id NVARCHAR(32), @p_role_id NVARCHAR(32), @p_v_province_id BIGINT, @p_v_circle_id BIGINT, @p_v_tamvin_id BIGINT',
    @p_username = @username,
    @p_phone = @phone,
    @p_first_name = @first_name,
    @p_father_name = @father_name,
    @p_grandfather_name = @grandfather_name,
    @p_last_name = @last_name,
    @p_gender_id = @gender_id,
    @p_role_id = @role_id,
    @p_v_province_id = @v_province_id,
    @p_v_circle_id = @v_circle_id,
    @p_v_tamvin_id = @v_tamvin_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_employees_list
  @username NVARCHAR(128) = NULL,
  @phone NVARCHAR(64) = NULL,
  @first_name NVARCHAR(128) = NULL,
  @father_name NVARCHAR(128) = NULL,
  @grandfather_name NVARCHAR(128) = NULL,
  @last_name NVARCHAR(128) = NULL,
  @gender_id NVARCHAR(32) = NULL,
  @role_id NVARCHAR(32) = NULL,
  @v_province_id BIGINT = -1,
  @v_circle_id BIGINT = -1,
  @v_tamvin_id BIGINT = -1,
  @v_has_ghasam NVARCHAR(8) = N'-1',
  @v_area_has_problem NVARCHAR(8) = N'-1',
  @v_fields_completed NVARCHAR(8) = N'-1',
  @offset INT = 0,
  @page_size INT = 25
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NULL
    THROW 50400, N'dbo.hwy_members is not available.', 1;

  DECLARE @where NVARCHAR(MAX) = dbo.hwy_employees_list_where_clause(
    @username, @phone, @first_name, @father_name, @grandfather_name, @last_name,
    @gender_id, @role_id, @v_province_id, @v_circle_id, @v_tamvin_id,
    @v_has_ghasam, @v_area_has_problem, @v_fields_completed, N'M');

  DECLARE @sql NVARCHAR(MAX) = N'
;WITH filtered AS (
  SELECT M.*
  FROM dbo.hwy_members M WITH (NOLOCK)
  WHERE M.membership_status_legacy = 10851
    AND M.user_id IS NOT NULL
    AND EXISTS (
      SELECT 1 FROM dbo.AppEnd_Users_R_Roles URR WITH (NOLOCK)
      WHERE URR.UserId = M.user_id AND URR.Approved = 1
    )' + @where + N'
),
paged AS (
  SELECT f.*, COUNT(*) OVER() AS list_total
  FROM filtered f
  ORDER BY f.updated_at DESC, f.id DESC
  OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY
)
SELECT
  CAST(p.id AS VARCHAR(32)) AS id,
  vm.username AS username,
  CAST(p.user_id AS VARCHAR(32)) AS userId,
  p.first_name AS firstName,
  p.father_name AS fatherName,
  p.grandfather_name AS grandFatherName,
  p.family_name AS lastName,
  vm.display_full_name AS displayFullName,
  vm.avatar_url AS avatarUrl,
  vm.birth_year AS birthYear,
  vm.gender_code AS genderCode,
  vm.tracking_code AS trackingCode,
  p.phone1 AS phone1,
  CAST(p.gender_legacy_id AS VARCHAR(32)) AS genderId,
  (SELECT TOP 1 BI.title FROM dbo.hwy_ref_base_information BI WITH (NOLOCK) WHERE BI.id = p.gender_legacy_id) AS genderIdTitle,
  ISNULL(p.stat_fields_completed, 0) AS statFieldsCompleted,
  CASE WHEN ISNULL(p.oath_file_size, 0) > 0 THEN N''yes'' ELSE N''no'' END AS statOath,
  (SELECT TOP 1 URR.CreatedOn FROM dbo.AppEnd_Users_R_Roles URR WITH (NOLOCK) WHERE URR.UserId = p.user_id AND URR.Approved = 1 ORDER BY URR.CreatedOn DESC) AS masooliatRoleOn,
  (SELECT STRING_AGG(R.RoleName, N'' , '') FROM dbo.AppEnd_Users_R_Roles URR WITH (NOLOCK) INNER JOIN dbo.AppEnd_Roles R WITH (NOLOCK) ON R.Id = URR.RoleId WHERE URR.UserId = p.user_id AND URR.Approved = 1) AS rolesLimits,
  dbo.hwy_member_agg_area_limits(p.id) AS areasLimits,
  (SELECT STRING_AGG(bi.title, N'' , '') FROM dbo.hwy_ref_members_gender_limits gl WITH (NOLOCK) LEFT JOIN dbo.hwy_ref_base_information bi WITH (NOLOCK) ON bi.id = gl.item_id WHERE gl.member_id = p.id) AS genderLimits,
  CAST(NULL AS NVARCHAR(MAX)) AS orgLimits,
  CAST(NULL AS NVARCHAR(MAX)) AS uniLimits,
  CAST(NULL AS NVARCHAR(MAX)) AS jobL1Limits,
  CAST(NULL AS NVARCHAR(MAX)) AS ettehadLimits,
  (SELECT TOP 1 BI.title FROM dbo.hwy_ref_base_information BI WITH (NOLOCK) WHERE BI.id = p.nakheb_join_province_id) AS nakhebJoinProvinceName,
  (SELECT TOP 1 C.circle_name FROM dbo.hwy_ref_h_circles C WITH (NOLOCK) WHERE C.circle_id = p.nakheb_join_circle_id) AS nakhebJoinCircleName,
  (SELECT TOP 1 T.tamvin_name FROM dbo.hwy_ref_h_tamvinat T WITH (NOLOCK) WHERE T.tamvin_id = p.nakheb_join_tamvin_id) AS nakhebJoinTamvinName,
  (SELECT TOP 1 BI.title FROM dbo.hwy_ref_base_information BI WITH (NOLOCK) WHERE BI.id = p.nakheb_join_eghtera_id) AS nakhebJoinEghteraName,
  (SELECT TOP 1 BI.title FROM dbo.base_info BI WITH (NOLOCK) WHERE BI.id = p.education_level_code) AS educationLevelIdTitle,
  (SELECT TOP 1 BI.title FROM dbo.base_info BI WITH (NOLOCK) WHERE BI.id = p.job_type_code) AS jobTypeIdTitle,
  CONVERT(VARCHAR(32), p.membership_on, 126) AS membershipOn,
  CONVERT(VARCHAR(32), p.updated_at, 126) AS updatedOn,
  p.list_total AS listTotal
FROM paged p
LEFT JOIN dbo.vw_hwy_members vm WITH (NOLOCK) ON vm.id = CAST(p.id AS VARCHAR(32))';

  EXEC sp_executesql @sql,
    N'@offset INT, @page_size INT, @p_username NVARCHAR(128), @p_phone NVARCHAR(64), @p_first_name NVARCHAR(128), @p_father_name NVARCHAR(128), @p_grandfather_name NVARCHAR(128), @p_last_name NVARCHAR(128), @p_gender_id NVARCHAR(32), @p_role_id NVARCHAR(32), @p_v_province_id BIGINT, @p_v_circle_id BIGINT, @p_v_tamvin_id BIGINT',
    @offset = @offset,
    @page_size = @page_size,
    @p_username = @username,
    @p_phone = @phone,
    @p_first_name = @first_name,
    @p_father_name = @father_name,
    @p_grandfather_name = @grandfather_name,
    @p_last_name = @last_name,
    @p_gender_id = @gender_id,
    @p_role_id = @role_id,
    @p_v_province_id = @v_province_id,
    @p_v_circle_id = @v_circle_id,
    @p_v_tamvin_id = @v_tamvin_id;
END;
GO
