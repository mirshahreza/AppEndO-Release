-- Ensure localized title path columns exist (Prisma maps titlePath* → title_path_*).
-- Greenfield control plane keeps canonical `title` only; Hawiety dbo SQL still references legacy locale columns.
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF COL_LENGTH('dbo.base_info', 'title_en') IS NULL
  ALTER TABLE dbo.base_info ADD title_en NVARCHAR(MAX) NULL;
IF COL_LENGTH('dbo.base_info', 'title_fa') IS NULL
  ALTER TABLE dbo.base_info ADD title_fa NVARCHAR(MAX) NULL;
IF COL_LENGTH('dbo.base_info', 'title_ar') IS NULL
  ALTER TABLE dbo.base_info ADD title_ar NVARCHAR(MAX) NULL;
GO

IF COL_LENGTH('dbo.base_info', 'title_path_en') IS NULL
  ALTER TABLE dbo.base_info ADD title_path_en NVARCHAR(MAX) NULL;
IF COL_LENGTH('dbo.base_info', 'title_path_fa') IS NULL
  ALTER TABLE dbo.base_info ADD title_path_fa NVARCHAR(MAX) NULL;
IF COL_LENGTH('dbo.base_info', 'title_path_ar') IS NULL
  ALTER TABLE dbo.base_info ADD title_path_ar NVARCHAR(MAX) NULL;
GO

PRINT 'base_info title_path_* columns ready';
GO
