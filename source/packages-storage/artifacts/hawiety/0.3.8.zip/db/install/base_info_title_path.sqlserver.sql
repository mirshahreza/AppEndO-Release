-- Ensure localized title path columns exist (Prisma maps titlePath* → title_path_*).
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF COL_LENGTH('dbo.base_info', 'title_path_en') IS NULL
  ALTER TABLE dbo.base_info ADD title_path_en NVARCHAR(MAX) NULL;
IF COL_LENGTH('dbo.base_info', 'title_path_fa') IS NULL
  ALTER TABLE dbo.base_info ADD title_path_fa NVARCHAR(MAX) NULL;
IF COL_LENGTH('dbo.base_info', 'title_path_ar') IS NULL
  ALTER TABLE dbo.base_info ADD title_path_ar NVARCHAR(MAX) NULL;
GO

PRINT 'base_info title_path_* columns ready';
GO
