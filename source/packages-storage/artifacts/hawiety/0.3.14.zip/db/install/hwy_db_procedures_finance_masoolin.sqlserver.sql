-- AUTO-GENERATED — do not edit by hand
-- Source: MembersV2 via npm run hwy:gen-finance-procs
-- Standard names: dbo.hwy_* / dbo.vw_hwy_*

-- HWY_SP_Masoolin_CreateOrUpdateStars → hwy_masoolin_stars_create_or_update_month
CREATE OR ALTER PROCEDURE dbo.hwy_masoolin_stars_create_or_update_month 
	@YEAR INT,@MONTH INT
AS
BEGIN
	
	DECLARE @id BIGINT;
	DECLARE @C INT=1;

	DECLARE MasoolinCUR CURSOR
		FOR SELECT DISTINCT id FROM hwy_members WHERE user_id IN (SELECT URR.user_id FROM vw_hwy_platform_user_roles_finance URR WHERE approved=1 AND role_id IN(1000027,1000004,1000005)) --AND gender_id=10012
	OPEN MasoolinCUR
	FETCH NEXT FROM MasoolinCUR INTO @id

	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[HWY_SP_MasoolinCalcStars] @id,@YEAR,@MONTH,1,0;
		PRINT CAST(@C AS VARCHAR(4))  + ':' +  CAST(@id AS VARCHAR(16));
		SET @C = @C + 1;
		FETCH NEXT FROM MasoolinCUR INTO @id
	END
	CLOSE MasoolinCUR;
	DEALLOCATE MasoolinCUR;

	EXECUTE [dbo].[HWY_SP_H_Eghteraat_UpdateFlags] NULL;
	EXECUTE [dbo].[HWY_SP_H_Tamvinat_UpdateFlags] NULL;
	EXECUTE [dbo].[HWY_SP_H_Circles_UpdateFlags] NULL;
   
END
GO

-- HWY_SP_Masoolin_CreateOrUpdateStars_Current → hwy_masoolin_stars_create_or_update_current
CREATE OR ALTER PROCEDURE dbo.hwy_masoolin_stars_create_or_update_current 
AS
BEGIN

	DECLARE @YEAR  INT = YEAR(GETDATE());
	DECLARE @MONTH INT = MONTH(GETDATE());
	
	DECLARE @id BIGINT;
	DECLARE @C INT=1;

	DECLARE MasoolinCUR CURSOR
		FOR SELECT DISTINCT id FROM hwy_members WHERE user_id IN (SELECT URR.user_id FROM vw_hwy_platform_user_roles_finance URR WHERE approved=1 AND role_id IN(1000027,1000004,1000005)) --AND gender_id=10012
	OPEN MasoolinCUR
	FETCH NEXT FROM MasoolinCUR INTO @id

	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [dbo].[HWY_SP_MasoolinCalcStars] @id,@YEAR,@MONTH,1,1;
		PRINT CAST(@C AS VARCHAR(4))  + ':' +  CAST(@id AS VARCHAR(16));
		SET @C = @C + 1;
		FETCH NEXT FROM MasoolinCUR INTO @id
	END
	CLOSE MasoolinCUR;
	DEALLOCATE MasoolinCUR;

END
GO

-- HWY_SP_Masoolin_Performance → hwy_masoolin_performance_list
CREATE OR ALTER PROCEDURE dbo.hwy_masoolin_performance_list 
	@ActorId INT,@IsPublicKey BIT,@SelectedProvinces VARCHAR(256),@circle_id INT,@tamvin_id INT,@gender_id INT,@role_id INT,@BI1LevelId INT,@BI2LevelId INT,@BI3LevelId INT,@BICLevelId INT,
	@MoneyAmount1 VARCHAR(16),@MoneyAmount2 VARCHAR(16),@MoneyAmount3 VARCHAR(16),
	@user_name NVARCHAR(64),@payable VARCHAR(2),@ConfilictState VARCHAR(16),@SameRogheCount VARCHAR(16)
AS
BEGIN

DECLARE @area_limit_id INT;
DECLARE @AreaLimitProvinceId INT;
DECLARE @AreaLimitCircleId INT;

SELECT TOP 1 @area_limit_id=area_limit_id,@AreaLimitProvinceId= area_limit_province_id,@AreaLimitCircleId= area_limit_circle_id 
FROM HWY_VW_Members_NoAdmin 
WHERE id=@ActorId;

SELECT 
	T.member_id,role_name,gender_id,user_name,first_name,father_name,grand_father_name,last_name,phone1,SameRogheCount,
	area_limit_province_id,area_limit_circle_id,area_limit_tamvin_id,AreaLimitProvince,AreaLimitCircle,AreaLimitTamvin,AreaLimitCenterId,
	T.chief_masool,
	CAST((SELECT COUNT(*) FROM HWY_H_Masooliat_Removal_Requests RR WHERE RR.member_id=T.member_id AND RR.FinalActionResult IS NULL) AS BIT) AS has_remove_request,
	(
		CASE 
			WHEN LEN(AreaLimitCenterId)=6 THEN	(SELECT TOP 1 eghtera_name	FROM hwy_ref_h_eghteraat	WHERE eghtera_id	=AreaLimitCenterId)
			WHEN LEN(AreaLimitCenterId)=4 THEN	(SELECT TOP 1 tamvin_name	FROM hwy_ref_h_tamvinat		WHERE tamvin_id	=AreaLimitCenterId)
			ELSE								(SELECT TOP 1 circle_name	FROM hwy_ref_h_circles		WHERE circle_id	=AreaLimitCenterId)
		END
	) AreaLimitCenterName,
	S1.calc_year D1Y,S1.calc_month D1M,
	S2.calc_year D2Y,S2.calc_month D2M,
	S3.calc_year D3Y,S3.calc_month D3M,
	ISNULL(PM1.pay_amount,-1) PM1_PayAmount, 
	ISNULL(PM2.pay_amount,-1) PM2_PayAmount, 
	ISNULL(PM3.pay_amount,-1) PM3_PayAmount,
	S1.level_id S1_LevelId,ISNULL(BI1LevelId.title,'-') BI1LevelId_Title,ISNULL(S1.stars_sum,-1) S1_StarsSum,
	S2.level_id S2_LevelId,ISNULL(BI2LevelId.title,'-') BI2LevelId_Title,ISNULL(S2.stars_sum,-1) S2_StarsSum,
	S3.level_id S3_LevelId,ISNULL(BI3LevelId.title,'-') BI3LevelId_Title,ISNULL(S3.stars_sum,-1) S3_StarsSum,
	SC_LevelId,BICLevelId.title						   BICLevelId_Title,					   SC_StarsSum,
	(DATEDIFF(DAY, approved_on, GETDATE())) DaysInRole
FROM
(
	SELECT M.id member_id,role_id,role_name,gender_id,M.username user_name,M.first_name,M.father_name,M.grandfather_name grand_father_name,ISNULL(M.family_name,'') last_name,M.phone1,ISNULL(M.nakhebin_id,'') nakheb_id,
		M.chief_masool,
		area_limit_province_id,area_limit_circle_id,area_limit_tamvin_id ,
		BI_Province.title AreaLimitProvince,BI_Circles.circle_name AreaLimitCircle,BI_Tamvinat.tamvin_name AreaLimitTamvin,
		(SELECT TOP 1 TT.item_id FROM hwy_member_area_limits TT WHERE TT.member_id=M.id AND approved=1) AreaLimitCenterId,
		M.masooliat_level_id_current SC_LevelId,M.masooliat_sum_stars_current SC_StarsSum,
		URR.approved_on,
		(
			SELECT COUNT(*) FROM hwy_members MMMM 
			WHERE MMMM.area_limit_id IS NOT NULL AND MMMM.area_limit_id=M.area_limit_id 

					--AND (SELECT TOP 1 TTTT.role_id	FROM vw_hwy_platform_user_roles_finance TTTT WHERE TTTT.user_id=MMMM.user_id	AND TTTT.approved=1 AND TTTT.role_id IN (1000004,1000005,1000027)) IS NOT NULL
					--AND (SELECT TOP 1 AL.item_id		FROM hwy_member_area_limits AL WHERE AL.member_id=MMMM.id		AND AL.approved=1) IS NOT NULL

					AND 
						(SELECT TOP 1 AL.item_id		FROM hwy_member_area_limits AL WHERE AL.member_id=M.id			AND AL.approved=1)
						=
						(SELECT TOP 1 AL.item_id		FROM hwy_member_area_limits AL WHERE AL.member_id=MMMM.id		AND AL.approved=1)
					AND 
						(SELECT TOP 1 TTTT.role_id	FROM vw_hwy_platform_user_roles_finance TTTT WHERE TTTT.user_id=M.user_id		AND TTTT.approved=1 AND TTTT.role_id IN (1000004,1000005,1000027))
						=
						(SELECT TOP 1 TTTT.role_id	FROM vw_hwy_platform_user_roles_finance TTTT WHERE TTTT.user_id=MMMM.user_id	AND TTTT.approved=1 AND TTTT.role_id IN (1000004,1000005,1000027))

					AND MMMM.gender_id=M.gender_id
					AND MMMM.chief_masool=1	
		) SameRogheCount
	FROM hwy_members M
	LEFT OUTER JOIN vw_hwy_platform_user_roles_finance URR		ON URR.user_id=M.user_id
	LEFT OUTER JOIN vw_hwy_platform_roles					ON vw_hwy_platform_roles.id=URR.role_id

	LEFT OUTER JOIN hwy_ref_base_information BI_GenderId ON BI_GenderId.id=M.gender_id

	LEFT OUTER JOIN hwy_ref_base_information BI_Province ON BI_Province.id=M.area_limit_province_id
	LEFT OUTER JOIN hwy_ref_h_circles		BI_Circles	ON BI_Circles.circle_id=M.area_limit_circle_id
	LEFT OUTER JOIN hwy_ref_h_tamvinat		BI_Tamvinat ON BI_Tamvinat.tamvin_id=M.area_limit_tamvin_id

	WHERE role_id IN (1000004,1000005,1000027) AND approved=1
) T
LEFT OUTER JOIN vw_hwy_payment_documents_members_m1 PM1 ON PM1.member_id=T.member_id
LEFT OUTER JOIN vw_hwy_payment_documents_members_m2 PM2 ON PM2.member_id=T.member_id
LEFT OUTER JOIN vw_hwy_payment_documents_members_m3 PM3 ON PM3.member_id=T.member_id

LEFT OUTER JOIN vw_hwy_masoolin_stars_overal_m1 S1 ON S1.member_id=T.member_id
LEFT OUTER JOIN vw_hwy_masoolin_stars_overal_m2 S2 ON S2.member_id=T.member_id
LEFT OUTER JOIN vw_hwy_masoolin_stars_overal_m3 S3 ON S3.member_id=T.member_id

LEFT OUTER JOIN hwy_ref_base_information BI1LevelId ON BI1LevelId.id=S1.level_id
LEFT OUTER JOIN hwy_ref_base_information BI2LevelId ON BI2LevelId.id=S2.level_id
LEFT OUTER JOIN hwy_ref_base_information BI3LevelId ON BI3LevelId.id=S3.level_id
LEFT OUTER JOIN hwy_ref_base_information BICLevelId ON BICLevelId.id=SC_LevelId

WHERE 
			(@gender_id=0	OR gender_id				=	@gender_id) 
		AND (@SelectedProvinces=''	OR area_limit_province_id	IN	(SELECT items FROM DBO.Split2(@SelectedProvinces,',')))
		AND (@circle_id=0	OR area_limit_circle_id=	@circle_id)
		AND (@tamvin_id=0	OR area_limit_tamvin_id=	@tamvin_id)

		AND (@BI1LevelId=0	OR S1.level_id=@BI1LevelId)
		AND (@BI2LevelId=0	OR S2.level_id=@BI2LevelId)
		AND (@BI3LevelId=0	OR S3.level_id=@BI3LevelId)
		AND (@BICLevelId=0	OR SC_LevelId=@BICLevelId)

		AND (@role_id=0	OR T.role_id=@role_id)

		AND
		(
			(@IsPublicKey=1)
			OR
			(@area_limit_id=111321)
			OR
			(@area_limit_id=111322 AND area_limit_province_id	IN (SELECT A.item_id FROM hwy_member_area_limits A WHERE A.member_id=@ActorId))
			OR
			(@area_limit_id=111325 AND area_limit_circle_id		IN (SELECT A.item_id FROM hwy_member_area_limits A WHERE A.member_id=@ActorId))

			OR
			(
				@area_limit_id=111325 AND 
				(SELECT TOP 1 A.item_id FROM hwy_member_area_limits A WHERE A.member_id=T.member_id) IN (SELECT A.item_id FROM hwy_member_area_limits A WHERE A.member_id=@ActorId)
			)

		)

		AND
		(
			(@IsPublicKey=1)
			OR
			(gender_id IN (SELECT GL.item_id FROM hwy_ref_members_gender_limits GL WHERE GL.member_id=@ActorId))
		)		
			
		AND
		(
			@user_name='' OR T.user_name=@user_name
		)

		AND
		(
			@MoneyAmount1='MoneyAmount1' 
			OR 
			(@MoneyAmount1='Blank' AND PM1.pay_amount IS NULL)
			OR 
			(@MoneyAmount1='Zero' AND PM1.pay_amount=0) 
			OR 
			(@MoneyAmount1='BlankAndZero' AND (PM1.pay_amount=0 OR PM1.pay_amount IS NULL))
			OR 
			(@MoneyAmount1='UpperZero' AND ISNULL(PM1.pay_amount,0)>0)
		)

		AND
		(
			@MoneyAmount2='MoneyAmount2' 
			OR 
			(@MoneyAmount2='Blank' AND PM2.pay_amount IS NULL)
			OR 
			(@MoneyAmount2='Zero' AND PM2.pay_amount=0) 
			OR 
			(@MoneyAmount2='BlankAndZero' AND (PM2.pay_amount=0 OR PM2.pay_amount IS NULL))
			OR 
			(@MoneyAmount2='UpperZero' AND ISNULL(PM2.pay_amount,0)>0)
		)

		AND
		(
			@MoneyAmount3='MoneyAmount3' 
			OR 
			(@MoneyAmount3='Blank' AND PM3.pay_amount IS NULL)
			OR 
			(@MoneyAmount3='Zero' AND PM3.pay_amount=0) 
			OR 
			(@MoneyAmount3='BlankAndZero' AND (PM3.pay_amount=0 OR PM3.pay_amount IS NULL))
			OR 
			(@MoneyAmount3='UpperZero' AND ISNULL(PM3.pay_amount,0)>0)
		)

		AND
		(
			@payable='' OR (@payable='0' AND T.chief_masool=0) OR (@payable='1' AND T.chief_masool=1)
		)

		AND
		(
			@ConfilictState='' OR (@ConfilictState='Conflict' AND SameRogheCount>1) OR (@ConfilictState='NoConfilict' AND SameRogheCount<2) 
		)

		AND
		(
			@SameRogheCount='' OR (@SameRogheCount='Zero' AND SameRogheCount=0) OR (@SameRogheCount='One' AND SameRogheCount=1) OR (@SameRogheCount='MoreThanZero' AND SameRogheCount>0) OR (@SameRogheCount='MoreThanOne' AND SameRogheCount>1) 
		)



ORDER BY area_limit_province_id,area_limit_circle_id,area_limit_tamvin_id,AreaLimitProvince,AreaLimitCircle,AreaLimitTamvin,AreaLimitCenterId,T.member_id
--ORDER BY S1_StarsSum DESC
END
GO

-- HWY_SP_Masoolin_PerformanceExport → hwy_masoolin_performance_export
CREATE OR ALTER PROCEDURE dbo.hwy_masoolin_performance_export
AS
BEGIN

    SET NOCOUNT ON;

    DECLARE @cols NVARCHAR(MAX);
    DECLARE @query NVARCHAR(MAX);

    -- Build dynamic month-year columns ordered from newest to oldest
    SELECT @cols =
        STUFF((
            SELECT
                ',' + QUOTENAME(YearMonth)
            FROM
            (
                SELECT DISTINCT
                    CAST(CalcYear AS VARCHAR(4)) + '-' +
                    RIGHT('00' + CAST(CalcMonth AS VARCHAR(2)), 2) AS year_month,
                    calc_year,
                    calc_month
                FROM [MembersV2].[dbo].[hwy_masoolin_stars_overal]
            ) x
            ORDER BY calc_year DESC, calc_month DESC
            FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'),1,1,'');

    -- Main dynamic pivot query
    SET @query = '
    SELECT *
    FROM
    (
        SELECT
            StarsOveral.member_id,

            MB.username,

            -- Indicates whether the member is a main responsible person
            MB.chief_masool AS main_masool,

            BI.title AS gender,

            -- Build full name
            LTRIM(RTRIM(
                ISNULL(MB.first_name, '''') + '' '' +
                ISNULL(MB.father_name, '''') + '' '' +
                ISNULL(MB.grandfather_name, '''') + '' '' +
                ISNULL(MB.last_name, '''')
            )) AS full_name,

            BI_Province.title AS area_limit_province,
            BI_Circles.circle_name AS area_limit_circle,
            BI_Tamvinat.tamvin_name AS area_limit_tamvin,

            -- Resolve area limit center name dynamically
            (
		        CASE 
			        WHEN LEN(AL.item_id)=6 THEN
                        (
                            SELECT TOP 1 eghtera_name
                            FROM hwy_ref_h_eghteraat
                            WHERE eghtera_id = AL.item_id
                        )

			        WHEN LEN(AL.item_id)=4 THEN
                        (
                            SELECT TOP 1 tamvin_name
                            FROM hwy_ref_h_tamvinat
                            WHERE tamvin_id = AL.item_id
                        )

			        ELSE
                        (
                            SELECT TOP 1 circle_name
                            FROM hwy_ref_h_circles
                            WHERE circle_id = AL.item_id
                        )
		        END
	        ) AS area_limit_center_name,

            MB_Level.title AS level_title,

            -- Aggregate member roles
            DBO.HWY_FN_Agg_Roles(MB.user_id) AS roles,

            -- Number of days since role approval
            DATEDIFF(DAY, approved_on, GETDATE()) AS days_in_role,

            -- Aggregate organizations
            DBO.HWY_FN_Agg_Orgs(MB.id) AS orgs,

            -- Dynamic pivot column key
            CAST(CalcYear AS VARCHAR(4)) + ''-'' +
            RIGHT(''00'' + CAST(CalcMonth AS VARCHAR(2)), 2) AS year_month,

            stars_sum

        FROM hwy_masoolin_stars_overal StarsOveral

        LEFT JOIN HWY_VW_Members_NoAdmin MB
            ON MB.id= StarsOveral.member_id

        LEFT JOIN hwy_ref_base_information MB_Level
            ON MB_Level.id= MB.area_limit_id

        LEFT JOIN hwy_ref_base_information BI
            ON BI.id= MB.gender_id

	    LEFT OUTER JOIN hwy_ref_base_information BI_Province
            ON BI_Province.id= MB.area_limit_province_id

	    LEFT OUTER JOIN hwy_ref_h_circles BI_Circles
            ON BI_Circles.circle_id = MB.area_limit_circle_id

	    LEFT OUTER JOIN hwy_ref_h_tamvinat BI_Tamvinat
            ON BI_Tamvinat.tamvin_id = MB.area_limit_tamvin_id

	    LEFT OUTER JOIN hwy_member_area_limits AL
            ON AL.member_id = MB.id
           AND AL.approved = 1

        -- Filter only target roles
        WHERE MB.user_id IN
        (
            SELECT URR.user_id
            FROM vw_hwy_platform_user_roles_finance URR
            WHERE URR.approved = 1
              AND role_id IN (1000004,1000005,1000027)
        )

    ) src

    PIVOT
    (
        MAX(StarsSum)
        FOR YearMonth IN (' + @cols + ')
    ) p

    ORDER BY member_id;
    ';

    EXEC sp_executesql @query;

END
GO

-- HWY_SP_MasoolinCalcStars → hwy_masoolin_stars_recalc_member
CREATE OR ALTER PROCEDURE dbo.hwy_masoolin_stars_recalc_member 
	@member_id BIGINT, @CalYear INT, @CalMonth INT, @WriteToDb BIT , @ToCurrent BIT
AS
BEGIN
	SET NOCOUNT ON;

	IF (@WriteToDb IS NULL) SET @WriteToDb = 1;
	IF (@ToCurrent IS NULL) SET @ToCurrent = 0;
	
	DECLARE @CalcDateTime DATETIME=GETDATE();

	IF(@CalYear IS NULL)	SET @CalYear =	YEAR(DATEADD(MONTH,-1,@CalcDateTime));
	IF(@CalMonth IS NULL)	SET @CalMonth = MONTH(DATEADD(MONTH,-1,@CalcDateTime));


	DECLARE @StartD				DATETIME = DBO.[HWY_FN_StartOrEndOfMonth] (@CalYear,@CalMonth,-1);
	DECLARE @EndD				DATETIME = DBO.[HWY_FN_StartOrEndOfMonth] (@CalYear,@CalMonth,1);

	DECLARE @Str01 INT=-1,@Str02 INT=-1,@Str03 INT=-1,@Str04 INT=-1,@Str05 INT=-1,@Str06 INT=-1,@Str07 INT=-1,@Str08 INT=-1,@Str09 INT=-1,@Str10 INT=-1; 
	DECLARE @StrCode01 INT=214977,@StrCode02 INT=214978,@StrCode03 INT=214979,@StrCode04 INT=214980,@StrCode05 INT=214981,@StrCode06 INT=214982,@StrCode07 INT=214983,@StrCode08 INT=214984,@StrCode09 INT=214985,@StrCode10 INT=214992; 
	
	DECLARE @user_name			NVARCHAR(64);
	DECLARE @user_id				INT;
	DECLARE @gender_id			INT;
	DECLARE @FieldsCompleted	INT;

	DECLARE @role_id				INT;
	DECLARE @AreaProvinceId		INT;
	DECLARE @AreaCircleId		INT;
	DECLARE @AreaTamvinId		INT;
	DECLARE @AreaId				INT;

	DECLARE @TamvinatCount				INT; 
	DECLARE @EghteraatCount				INT; 
	DECLARE @NewMembersCount			INT; 
	DECLARE @NashatatCreatedAndApproved INT; 
	DECLARE @Profiles30DaysWaited		INT; 									   
	DECLARE @TamvinatHasApprovedCount	INT; 
	DECLARE @EghteraatHasApprovedCount	INT; 
	DECLARE @NashatatParticipate		INT;
	DECLARE @PassedSocialActivities		BIT;

	SELECT TOP 1
		@user_id=user_id,@user_name=username,@gender_id=gender_id,@FieldsCompleted= stat_fields_completed,
		@AreaProvinceId= area_limit_province_id,@AreaCircleId= area_limit_circle_id,@AreaTamvinId= area_limit_tamvin_id
	FROM hwy_members WHERE id=@member_id;

	SELECT TOP 1 @AreaId=item_id FROM hwy_member_area_limits WHERE approved=1 AND member_id=@member_id;
	SELECT TOP 1 @role_id=role_id FROM vw_hwy_platform_user_roles_finance WHERE approved=1 AND user_id=@user_id AND role_id IN (1000004,1000005,1000027);

	SET @PassedSocialActivities = CAST(ISNULL(
			(SELECT COUNT(*) FROM HWY_Members_SocialScreensHeaders SS 
			WHERE member_id=@member_id AND TheYear=@CalYear AND TheMonth=@CalMonth 
				AND (SS.FinalApproved=1 OR (SS.MemberApproved=1 AND (SELECT COUNT(*) FROM HWY_Members_SocialScreens S WHERE S.HeaderId=SS.id)>9))
				AND SS.FinalApproved!=0
			),0) AS BIT);

	IF(@AreaId IS NOT NULL AND @role_id IS NOT NULL) 
	BEGIN

		IF(@role_id=1000027) --Circle And Ghiadeh
		BEGIN
			SET @TamvinatCount				= (SELECT COUNT(*) FROM hwy_ref_h_tamvinat		WHERE ISNULL(deleted,0)=0 AND circle_id=@AreaId);
			SET @EghteraatCount				= (SELECT COUNT(*) FROM hwy_ref_h_eghteraat		WHERE ISNULL(deleted,0)=0 AND circle_id=@AreaId AND aam_count>0 AND is_new=0);
			SET @NewMembersCount			= (SELECT COUNT(*) FROM hwy_members			WHERE membership_status=10851 AND gender_id IN (SELECT L.item_id FROM hwy_ref_members_gender_limits L WHERE L.member_id=@member_id) AND nakheb_join_circle_id=@AreaId AND membership_on>=@StartD AND membership_on<=@EndD);
			SET @NashatatCreatedAndApproved = (SELECT COUNT(*) FROM HWY_Nashatat		WHERE NashatSubTypeId=111381 AND created_by=@user_name AND StatusId=211314 AND StatusChangedOn>=@StartD AND StatusChangedOn<=@EndD);
			SET @Profiles30DaysWaited		= (SELECT COUNT(*) FROM hwy_members			WHERE gender_id IN (SELECT L.item_id FROM hwy_ref_members_gender_limits L WHERE L.member_id=@member_id) AND (ISNUMERIC(birth_year)=1 AND birth_year<=YEAR(GETDATE())-18) AND nakheb_join_circle_id=@AreaId AND membership_status=10853 AND device_os_type_id NOT IN (215002,214928,214934,214959,213991) AND membership_status_updated_on<(DATEADD(DAY,-30,@EndD)));
			
			DECLARE @K BIGINT = (SELECT TOP 1 id FROM hwy_members			WHERE gender_id IN (SELECT L.item_id FROM hwy_ref_members_gender_limits L WHERE L.member_id=@member_id) AND (ISNUMERIC(birth_year)=1 AND birth_year<=YEAR(GETDATE())-18) AND nakheb_join_circle_id=@AreaId AND membership_status=10853 AND device_os_type_id NOT IN (215002,214928,214934,214959,213991) AND membership_status_updated_on<(DATEADD(DAY,-30,@EndD)));
			
			PRINT @K; 

			IF(@gender_id=10011)
			BEGIN
				SET @TamvinatHasApprovedCount	= (SELECT COUNT(*) FROM hwy_ref_h_tamvinat		WHERE ISNULL(deleted,0)=0 AND circle_id=@AreaId AND flag_male_executives_just_approved IS NOT NULL)
				SET @EghteraatHasApprovedCount	= (SELECT COUNT(*) FROM hwy_ref_h_eghteraat		WHERE ISNULL(deleted,0)=0 AND circle_id=@AreaId AND flag_male_executives_just_approved IS NOT NULL AND aam_count>0 AND is_new=0)
			END
			ELSE
			BEGIN
				SET @TamvinatHasApprovedCount	= (SELECT COUNT(*) FROM hwy_ref_h_tamvinat		WHERE ISNULL(deleted,0)=0 AND circle_id=@AreaId AND flag_female_executives_just_approved IS NOT NULL)
				SET @EghteraatHasApprovedCount	= (SELECT COUNT(*) FROM hwy_ref_h_eghteraat		WHERE ISNULL(deleted,0)=0 AND circle_id=@AreaId AND flag_female_executives_just_approved IS NOT NULL AND aam_count>0 AND is_new=0)
			END

			IF(@gender_id=10011)
			BEGIN
				IF(@FieldsCompleted				=	100					)	SET @Str01 = 20	ELSE SET @Str01=0; 
				IF(@TamvinatHasApprovedCount	>=	@TamvinatCount/2	)	SET @Str02 = 3	ELSE SET @Str02=0;
				IF(@TamvinatHasApprovedCount	>=	@TamvinatCount		)	SET @Str03 = 13	ELSE SET @Str03=0;
				IF(@EghteraatHasApprovedCount	>=	@EghteraatCount/2	)	SET @Str04 = 10	ELSE SET @Str04=0;
				IF(@EghteraatHasApprovedCount	>=	@EghteraatCount		)	SET @Str05 = 13	ELSE SET @Str05=0;
				IF(@NewMembersCount				>=	@TamvinatCount		)	SET @Str06 = 7	ELSE SET @Str06=0;
				--SET @Str06 = 7;
				IF(@Profiles30DaysWaited		=	0					)	SET @Str07 = 7	ELSE SET @Str07=0;
				IF(@NashatatCreatedAndApproved	>=	3					)	SET @Str08 = 20	ELSE SET @Str08=0;
				IF(@PassedSocialActivities		=	1					)	SET @Str10 = 7	ELSE SET @Str10=0;
			END
			ELSE
			BEGIN
				IF(@FieldsCompleted				=	100					)	SET @Str01 = 15	ELSE SET @Str01=0; 
				IF(@TamvinatHasApprovedCount	>=	@TamvinatCount/2	)	SET @Str02 = 15	ELSE SET @Str02=0;
				IF(@TamvinatHasApprovedCount	>=	@TamvinatCount		)	SET @Str03 = 10	ELSE SET @Str03=0;
				SET @Str04=0;
				SET @Str05=0;
				IF(@NewMembersCount				>=	@TamvinatCount/2	)	SET @Str06 = 15	ELSE SET @Str06=0;
				--SET @Str06 = 15;				
				IF(@Profiles30DaysWaited		=	0					)	SET @Str07 = 15	ELSE SET @Str07=0;


				IF(@AreaProvinceId=10102) -- Baghdad
				BEGIN
					SET @NashatatParticipate		=	(SELECT COUNT(*) FROM HWY_Nashatat N	WHERE NashatSubTypeId=111381 AND CreatedBy!=@user_name AND StatusId=211314 AND CreatedOn>=@StartD AND CreatedOn<=@EndD AND @member_id IN (SELECT member_id FROM HWY_Members_Nashatat WHERE NashatId=N.id));

					IF(@NashatatCreatedAndApproved	>=	1											)	SET @Str08 = 10	ELSE SET @Str08=0;
					IF(@NashatatParticipate			>=	1 OR @NashatatCreatedAndApproved	>=	2	)	SET @Str09 = 5	ELSE SET @Str09=0;
				END
				ELSE
				BEGIN
					IF(@NashatatCreatedAndApproved	>=	2				)	SET @Str08 = 15	ELSE SET @Str08=0;
				END

				IF(@PassedSocialActivities		=	1					)	SET @Str10 = 15	ELSE SET @Str10=0;
			END

		END

		IF(@role_id=1000004) --Maktab
		BEGIN
			SET @EghteraatCount				= (SELECT COUNT(*) FROM hwy_ref_h_eghteraat		WHERE ISNULL(deleted,0)=0 AND tamvin_id=@AreaId AND aam_count>0 AND is_new=0);
			SET @NewMembersCount			= (SELECT COUNT(*) FROM hwy_members			WHERE membership_status=10851 AND gender_id IN (SELECT L.item_id FROM hwy_ref_members_gender_limits L WHERE L.member_id=@member_id) AND nakheb_join_tamvin_id=@AreaId AND membership_on>=@StartD AND membership_on<=@EndD);
			SET @NashatatCreatedAndApproved = (SELECT COUNT(*) FROM HWY_Nashatat		WHERE NashatSubTypeId IN(111381,213919,111391,213920) AND created_by=@user_name AND StatusId=211314 AND CreatedOn>=@StartD AND CreatedOn<=@EndD);
			SET @Profiles30DaysWaited		= (SELECT COUNT(*) FROM hwy_members			WHERE gender_id IN (SELECT L.item_id FROM hwy_ref_members_gender_limits L WHERE L.member_id=@member_id) AND (ISNUMERIC(birth_year)=1 AND birth_year<=YEAR(GETDATE())-18) AND nakheb_join_tamvin_id=@AreaId AND membership_status=10853 AND device_os_type_id NOT IN(215002,214928,214934,214959,213991) AND membership_status_updated_on<(DATEADD(DAY,-30,@EndD)));

			IF(@gender_id=10011)
			BEGIN
				SET @EghteraatHasApprovedCount	= (SELECT COUNT(*) FROM hwy_ref_h_eghteraat		WHERE ISNULL(deleted,0)=0 AND tamvin_id=@AreaId AND flag_male_executives_just_approved		IS NOT NULL AND aam_count>0 AND is_new=0);
			END
			ELSE
			BEGIN
				SET @EghteraatHasApprovedCount	= (SELECT COUNT(*) FROM hwy_ref_h_eghteraat		WHERE ISNULL(deleted,0)=0 AND tamvin_id=@AreaId AND flag_female_executives_just_approved	IS NOT NULL AND aam_count>0 AND is_new=0);
			END


			IF(@gender_id=10011)
			BEGIN
				IF(@FieldsCompleted				=	100					)	SET @Str01 = 20 ELSE SET @Str01=0; 
				IF(@EghteraatHasApprovedCount	>=	@EghteraatCount/2	)	SET @Str04 = 17	ELSE SET @Str04=0;
				IF(@EghteraatHasApprovedCount	>=	@EghteraatCount		)	SET @Str05 = 17	ELSE SET @Str05=0;
				IF(@NewMembersCount				>=	2					)	SET @Str06 = 15	ELSE SET @Str06=0;
				--SET @Str06 = 15;
				IF(@Profiles30DaysWaited		=	0					)	SET @Str07 = 7	ELSE SET @Str07=0;
				IF(@NashatatCreatedAndApproved	>=	2					)	SET @Str08 = 17	ELSE SET @Str08=0;
				IF(@PassedSocialActivities		=	1					)	SET @Str10 = 7	ELSE SET @Str10=0;
			END
			ELSE
			BEGIN
				SET @NashatatParticipate		=	(SELECT COUNT(*) FROM HWY_Nashatat N	WHERE NashatSubTypeId=111381 AND StatusId=211314 AND CreatedOn>=@StartD AND CreatedOn<=@EndD AND @member_id IN (SELECT member_id FROM HWY_Members_Nashatat WHERE NashatId=N.id));
				
				IF(@FieldsCompleted				=	100					)	SET @Str01 = 20 ELSE SET @Str01=0; 
				IF(@NewMembersCount				>=	1					)	SET @Str06 = 20	ELSE SET @Str06=0;
				--SET @Str06 = 20;
				IF(@Profiles30DaysWaited		=	0					)	SET @Str07 = 20	ELSE SET @Str07=0;
				IF(@NashatatParticipate			>=	1					)	SET @Str09 = 30	ELSE SET @Str09=0;
				IF(@PassedSocialActivities		=	1					)	SET @Str10 = 10	ELSE SET @Str10=0;
			END

		END

		IF(@role_id=1000005) -- Mantagheh
		BEGIN
			SET @NewMembersCount				= (SELECT COUNT(*) FROM hwy_members		WHERE membership_status=10851 AND gender_id IN (SELECT L.item_id FROM hwy_ref_members_gender_limits L WHERE L.member_id=@member_id) AND nakheb_join_eghtera_id=@AreaId AND membership_on>=@StartD AND membership_on<=@EndD);
			SET @Profiles30DaysWaited			= (SELECT COUNT(*) FROM hwy_members		WHERE gender_id IN (SELECT L.item_id FROM hwy_ref_members_gender_limits L WHERE L.member_id=@member_id) AND (ISNUMERIC(birth_year)=1 AND birth_year<=YEAR(GETDATE())-18) AND nakheb_join_eghtera_id=@AreaId AND membership_status=10853 AND device_os_type_id NOT IN(215002,214928,214934,214959,213991) AND membership_status_updated_on<(DATEADD(DAY,-30,@EndD)));
			SET @NashatatParticipate			= (SELECT COUNT(*) FROM HWY_Nashatat N	WHERE NashatSubTypeId=111381 AND StatusId=211314 AND CreatedOn>=@StartD AND CreatedOn<=@EndD AND @member_id IN (SELECT member_id FROM HWY_Members_Nashatat WHERE NashatId=N.id));
			
			IF(@gender_id=10011)
			BEGIN
				IF(@FieldsCompleted				=	100					)	SET @Str01 = 20	ELSE SET @Str01=0; 
				IF(@NewMembersCount				>=	1					)	SET @Str06 = 30	ELSE SET @Str06=0;
				--SET @Str06 = 30;
				IF(@Profiles30DaysWaited		=	0					)	SET @Str07 = 20	ELSE SET @Str07=0;
				IF(@NashatatParticipate			>=	2					)	SET @Str09 = 20	ELSE SET @Str09=0;
				IF(@PassedSocialActivities		=	1					)	SET @Str10 = 10	ELSE SET @Str10=0;
			END
		END

	END


	IF(@WriteToDb=1)
	BEGIN
		IF(@ToCurrent=0)
		BEGIN
			DELETE hwy_masoolin_stars WHERE member_id=@member_id AND calc_year=@CalYear AND calc_month=@CalMonth;

			INSERT INTO hwy_masoolin_stars
				(member_id,calc_year,calc_month,star_code,star_value)

			SELECT  
				@member_id,@CalYear,@CalMonth,star_code,star_value
			FROM 
			(
				SELECT @StrCode01 AS star_code,@Str01 AS star_value UNION ALL
				SELECT @StrCode02,@Str02 UNION ALL
				SELECT @StrCode03,@Str03 UNION ALL
				SELECT @StrCode04,@Str04 UNION ALL
				SELECT @StrCode05,@Str05 UNION ALL
				SELECT @StrCode06,@Str06 UNION ALL
				SELECT @StrCode07,@Str07 UNION ALL
				SELECT @StrCode08,@Str08 UNION ALL
				SELECT @StrCode09,@Str09 UNION ALL
				SELECT @StrCode10,@Str10
			) TTT
			WHERE star_value>-1;
		END
		ELSE
		BEGIN
			DELETE hwy_masoolin_stars_current WHERE member_id=@member_id AND calc_year=@CalYear AND calc_month=@CalMonth;

			INSERT INTO hwy_masoolin_stars_current
				(member_id,calc_year,calc_month,star_code,star_value)

			SELECT  
				@member_id,@CalYear,@CalMonth,star_code,star_value
			FROM 
			(
				SELECT @StrCode01 AS star_code,@Str01 AS star_value UNION ALL
				SELECT @StrCode02,@Str02 UNION ALL
				SELECT @StrCode03,@Str03 UNION ALL
				SELECT @StrCode04,@Str04 UNION ALL
				SELECT @StrCode05,@Str05 UNION ALL
				SELECT @StrCode06,@Str06 UNION ALL
				SELECT @StrCode07,@Str07 UNION ALL
				SELECT @StrCode08,@Str08 UNION ALL
				SELECT @StrCode09,@Str09 UNION ALL
				SELECT @StrCode10,@Str10
			) TTT
			WHERE star_value>-1;
		END

	END
	ELSE
	BEGIN
		SELECT @CalYear AS calc_year,@CalMonth AS calc_month,TTT.star_code,B.title AS star_title,TTT.star_value
		FROM 
		(
			SELECT @StrCode01 AS star_code,@Str01 AS star_value UNION ALL
			SELECT @StrCode02,@Str02 UNION ALL
			SELECT @StrCode03,@Str03 UNION ALL
			SELECT @StrCode04,@Str04 UNION ALL
			SELECT @StrCode05,@Str05 UNION ALL
			SELECT @StrCode06,@Str06 UNION ALL
			SELECT @StrCode07,@Str07 UNION ALL
			SELECT @StrCode08,@Str08 UNION ALL
			SELECT @StrCode09,@Str09 UNION ALL
			SELECT @StrCode10,@Str10
		) TTT
		LEFT OUTER JOIN hwy_ref_base_information B ON B.id= TTT.star_code
		WHERE TTT.star_value>-1
		;
	END


	IF(@Str01<0) SET @Str01=0;
	IF(@Str02<0) SET @Str02=0;
	IF(@Str03<0) SET @Str03=0;
	IF(@Str04<0) SET @Str04=0;
	IF(@Str05<0) SET @Str05=0;
	IF(@Str06<0) SET @Str06=0;
	IF(@Str07<0) SET @Str07=0;
	IF(@Str08<0) SET @Str08=0;
	IF(@Str09<0) SET @Str09=0;
	IF(@Str10<0) SET @Str10=0;


	DECLARE @StarsSum	INT = @Str01+@Str02+@Str03+@Str04+@Str05+@Str06+@Str07+@Str08+@Str09+@Str10;
	DECLARE @LevelId	INT = 214987;

	IF(@gender_id=10011)
	BEGIN
		IF(@StarsSum>=30 AND @StarsSum<50)	SET @LevelId		=214988;
		IF(@StarsSum>=50 AND @StarsSum<70)	SET @LevelId		=214989;
		IF(@StarsSum>=70 AND @StarsSum<100) SET @LevelId		=214990;
		IF(@StarsSum=100)					SET @LevelId		=214991;
	END
	ELSE
	BEGIN
		IF(@StarsSum>=20 AND @StarsSum<50)	SET @LevelId		=214988;
		IF(@StarsSum>=50 AND @StarsSum<70)	SET @LevelId		=214989;
		IF(@StarsSum>=70 AND @StarsSum<100) SET @LevelId		=214990;
		IF(@StarsSum=100)					SET @LevelId		=214991;
	END

	IF(@WriteToDb=1)
	BEGIN
		IF(@ToCurrent=0)
		BEGIN
			UPDATE hwy_members SET masooliat_sum_stars=@StarsSum,masooliat_level_id=@LevelId, masooliat_stars_calculated_on = @CalcDateTime WHERE id=@member_id;
			DELETE hwy_masoolin_stars_overal WHERE member_id=@member_id AND calc_year=@CalYear AND calc_month=@CalMonth;
			INSERT INTO hwy_masoolin_stars_overal (calc_year,calc_month,member_id,stars_sum,level_id,created_on) VALUES (@CalYear,@CalMonth,@member_id,@StarsSum,@LevelId,@CalcDateTime);
		END
		ELSE
		BEGIN
			UPDATE hwy_members SET masooliat_sum_stars_current=@StarsSum,masooliat_level_id_current=@LevelId WHERE id=@member_id;
			--DELETE hwy_masoolin_stars_overal WHERE member_id=@member_id AND calc_year=@CalYear AND calc_month=@CalMonth;
			--INSERT INTO hwy_masoolin_stars_overal (calc_year,calc_month,member_id,stars_sum,level_id,created_on) VALUES (@CalYear,@CalMonth,@member_id,@StarsSum,@LevelId,@CalcDateTime);
		END
	END
	ELSE
	BEGIN
		SELECT @StarsSum MasooliatSumStars,@LevelId MasooliatLevelId , (SELECT TOP 1 title FROM hwy_ref_base_information WHERE id=@LevelId) MasooliatLevelId_Title;
	END

END
GO

-- HWY_SP_MasoolinGetStars → hwy_masoolin_stars_get
CREATE OR ALTER PROCEDURE dbo.hwy_masoolin_stars_get 
	@member_id BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @LastYear INT;
	DECLARE @LastMonth INT;

	SELECT TOP 1 @LastYear= calc_year,@LastMonth= calc_month FROM hwy_masoolin_stars WHERE member_id=@member_id ORDER BY calc_year DESC,calc_month DESC;

	SELECT calc_year,calc_month,star_code,title StarTitle,star_value
	FROM hwy_masoolin_stars 
	LEFT OUTER JOIN hwy_ref_base_information B ON B.id= star_code
	WHERE hwy_masoolin_stars.member_id=@member_id AND calc_year=@LastYear AND calc_month=@LastMonth;
	
END
GO

-- HWY_SP_MasoolinGetStarsHistory → hwy_masoolin_stars_get_history
CREATE OR ALTER PROCEDURE dbo.hwy_masoolin_stars_get_history 
	@member_id BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT calc_year,calc_month,stars_sum,B.title LevelId_Title
		,
		(
			SELECT star_code,title StarTitle,star_value
			FROM hwy_masoolin_stars T
			LEFT OUTER JOIN hwy_ref_base_information B ON B.id= star_code
			WHERE T.member_id=@member_id AND T.calc_year=hwy_masoolin_stars_overal.calc_year AND T.calc_month=hwy_masoolin_stars_overal.calc_month
			FOR JSON PATH
		) StarsDetails
	FROM hwy_masoolin_stars_overal LEFT OUTER JOIN hwy_ref_base_information B ON B.id= level_id 
	WHERE member_id=@member_id 
	ORDER BY calc_year DESC,calc_month DESC
	;

	
END
GO

-- HWY_SP_Masoolin_SetAsMainPayable → hwy_masoolin_set_as_main_payable
CREATE OR ALTER PROCEDURE dbo.hwy_masoolin_set_as_main_payable 
	@member_id INT
AS
BEGIN

DECLARE @SameRoghe TABLE
(
	id INT,user_name NVARCHAR(64),first_name NVARCHAR(64),father_name NVARCHAR(64),grand_father_name NVARCHAR(64),last_name NVARCHAR(64),phone1 VARCHAR(64),payable BIT,approved_on DATETIME
)

	DECLARE @MID BIGINT;
	DECLARE @AreaId INT = (SELECT TOP 1 item_id FROM hwy_member_area_limits WHERE member_id=@member_id);

	INSERT INTO @SameRoghe
	SELECT * FROM [dbo].[HWY_UFN_SameRogheMembers] (@member_id);

	DECLARE MasoolinCUR CURSOR
		FOR SELECT id FROM @SameRoghe
	OPEN MasoolinCUR
	FETCH NEXT FROM MasoolinCUR INTO @MID

	WHILE @@FETCH_STATUS = 0
	BEGIN

		IF(@member_id=@MID) UPDATE hwy_members SET chief_masool=1 WHERE id=@MID;
		ELSE UPDATE hwy_members SET chief_masool=0 WHERE id=@MID;
		
		FETCH NEXT FROM MasoolinCUR INTO @MID

	END
	CLOSE MasoolinCUR;
	DEALLOCATE MasoolinCUR;

	IF(LEN(@AreaId)=4) EXEC DBO.HWY_SP_H_Tamvinat_UpdateFlags @AreaId;
	IF(LEN(@AreaId)=6) EXEC DBO.HWY_SP_H_Eghteraat_UpdateFlags @AreaId;
	IF(LEN(@AreaId)=7) EXEC DBO.HWY_SP_H_Circles_UpdateFlags @AreaId;

END
GO

-- HWY_SP_Masoolin_Performance_Process → hwy_masoolin_performance_process
CREATE OR ALTER PROCEDURE dbo.hwy_masoolin_performance_process
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #Tmp
    (
        member_id BIGINT, role_name NVARCHAR(200), gender_id INT, user_name NVARCHAR(200),
        first_name NVARCHAR(200), father_name NVARCHAR(200), grand_father_name NVARCHAR(200),
        last_name NVARCHAR(200), phone1 NVARCHAR(50), SameRagbatCount INT,

        area_limit_province_id INT, area_limit_circle_id INT, AreaLimitTanzimId INT,
        AreaLimitProvinceTitle NVARCHAR(200), AreaLimitCircleTitle NVARCHAR(200),
        AreaLimitTanzimTitle NVARCHAR(200), AreaLimitCenterName NVARCHAR(200),

        payable DECIMAL(18,2), HasRemoveRequest BIT, AreaLimitCenterName2 NVARCHAR(200),

        D1Y INT, D1M INT, D2Y INT, D2M INT, D3Y INT, D3M INT,

        PM1_PayAmount DECIMAL(18,2), PM2_PayAmount DECIMAL(18,2), PM3_PayAmount DECIMAL(18,2),

        S1_LevelId INT, B1LevelId_Title NVARCHAR(200), S1_StarsSum INT,
        S2_LevelId INT, B2LevelId_Title NVARCHAR(200), S2_StarsSum INT,
        S3_LevelId INT, B3LevelId_Title NVARCHAR(200), S3_StarsSum INT,

        DaysInRole INT
    );

    CREATE TABLE #Result
    (
        ResultType NVARCHAR(20),

        member_id BIGINT, role_name NVARCHAR(200), gender_id INT, user_name NVARCHAR(200),
        first_name NVARCHAR(200), father_name NVARCHAR(200), grand_father_name NVARCHAR(200),
        last_name NVARCHAR(200), phone1 NVARCHAR(50), SameRagbatCount INT,

        area_limit_province_id INT, area_limit_circle_id INT, AreaLimitTanzimId INT,
        AreaLimitProvinceTitle NVARCHAR(200), AreaLimitCircleTitle NVARCHAR(200),
        AreaLimitTanzimTitle NVARCHAR(200), AreaLimitCenterName NVARCHAR(200),

        payable DECIMAL(18,2), HasRemoveRequest BIT, AreaLimitCenterName2 NVARCHAR(200),

        D1Y INT, D1M INT, D2Y INT, D2M INT, D3Y INT, D3M INT,

        PM1_PayAmount DECIMAL(18,2), PM2_PayAmount DECIMAL(18,2), PM3_PayAmount DECIMAL(18,2),

        S1_LevelId INT, B1LevelId_Title NVARCHAR(200), S1_StarsSum INT,
        S2_LevelId INT, B2LevelId_Title NVARCHAR(200), S2_StarsSum INT,
        S3_LevelId INT, B3LevelId_Title NVARCHAR(200), S3_StarsSum INT,

        DaysInRole INT
    );

    CREATE TABLE #SameRoghe
    (
        id BIGINT, user_name NVARCHAR(200), first_name NVARCHAR(200), father_name NVARCHAR(200),
        grand_father_name NVARCHAR(200), last_name NVARCHAR(200), phone1 NVARCHAR(50),
        payable DECIMAL(18,2), approved_on DATETIME
    );

    TRUNCATE TABLE #Tmp;

    INSERT INTO #Tmp EXEC [dbo].[HWY_SP_Masoolin_Performance] 1000000,1,'',0,0,0,0,0,0,0,'MoneyAmount','','','','Zero';
    INSERT INTO #Result SELECT 'Zero', * FROM #Tmp;

    TRUNCATE TABLE #Tmp;

    INSERT INTO #Tmp EXEC [dbo].[HWY_SP_Masoolin_Performance] 1000000,1,'',0,0,0,0,0,0,0,'MoneyAmount','','','','MoreThanOne';
    INSERT INTO #Result SELECT 'MoreThanOne', * FROM #Tmp;

    DECLARE @TotalCount INT = (SELECT COUNT(*) FROM #Result);

    PRINT (@TotalCount);

    DECLARE @ResultType NVARCHAR(20),@member_id BIGINT,@first_name NVARCHAR(200),@last_name NVARCHAR(200),@phone1 NVARCHAR(50),@MainId BIGINT;

    DECLARE cur CURSOR FAST_FORWARD FOR
    SELECT ResultType, member_id, first_name, last_name, phone1 FROM #Result;

    OPEN cur;

    FETCH NEXT FROM cur INTO @ResultType, @member_id, @first_name, @last_name, @phone1;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        TRUNCATE TABLE #SameRoghe;
        INSERT INTO #SameRoghe SELECT * FROM dbo.HWY_UFN_SameRogheMembers(@member_id);

        SELECT TOP 1 @MainId = id FROM #SameRoghe ORDER BY approved_on ASC;

        PRINT @MainId;

        IF @MainId IS NOT NULL
        BEGIN

            IF @ResultType = 'Zero'
            BEGIN
                PRINT CONCAT('ZERO => ', @member_id, ' | ', @first_name, ' ', @last_name);
                EXEC dbo.HWY_SP_Masoolin_SetAsMainPayable @MainId;
            END
            ELSE
            BEGIN
                PRINT CONCAT('MORE THAN ONE => ', @member_id, ' | ', @first_name, ' ', @last_name);
                EXEC dbo.HWY_SP_Masoolin_SetAsMainPayable @MainId;
            END

        END

        FETCH NEXT FROM cur INTO @ResultType, @member_id, @first_name, @last_name, @phone1;
    END

    CLOSE cur;
    DEALLOCATE cur;

    DROP TABLE #Tmp;
    DROP TABLE #Result;
    DROP TABLE #SameRoghe;
END
GO

