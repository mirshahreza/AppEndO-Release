-- Drop PascalCase computed alias columns from dbo.hwy_members (legacy SQL uses vw_hwy_members_legacy_row).

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NULL
BEGIN
  PRINT 'hwy_members_drop_pascal_computed_aliases skipped — table missing';
END
ELSE
BEGIN
  DECLARE @name SYSNAME;
  DECLARE @sql NVARCHAR(400);

  DECLARE drop_cursor CURSOR LOCAL FAST_FORWARD FOR
    SELECT c.name
    FROM sys.columns c
    WHERE c.object_id = OBJECT_ID(N'dbo.hwy_members')
      AND c.is_computed = 1
      AND c.name COLLATE Latin1_General_CS_AS IN (
        N'FirstName', N'FatherName', N'GrandFatherName', N'LastName',
        N'UserId', N'GenderId', N'DeviceOsTypeId', N'NationalCode',
        N'CreatedOn', N'MembershipOn', N'MembershipStatus', N'MoarrefUserName',
        N'NakhebJoinProvinceId', N'NakhebJoinCircleId', N'NakhebJoinTamvinId', N'NakhebJoinEghteraId',
        N'AreaLimitId', N'AreaLimitProvinceId', N'AreaLimitCircleId', N'AreaLimitTamvinId',
        N'EducationLevelId', N'CardFlowLastStatusId', N'CardFlowVisibility',
        N'CardFlowStartedBy', N'CardFlowStartedOn',
        N'Picture_FileName', N'Picture_FileSize', N'Picture_FileMime',
        N'Picture_FileBody', N'Picture_FileBody_xs',
        N'NationalCard_Front_FileBody', N'NationalCard_Behind_FileBody',
        N'NakhebCard_Front_FileBody', N'MaskanCard_Front_FileBody',
        N'NakhebCard_Front_Approved', N'NationalCard_Front_Approved',
        N'NationalCard_Behind_Approved', N'MaskanCard_Front_Approved',
        N'Oath_FileSize', N'Stat_FieldsCompleted'
      );

  OPEN drop_cursor;
  FETCH NEXT FROM drop_cursor INTO @name;
  WHILE @@FETCH_STATUS = 0
  BEGIN
    SET @sql = N'ALTER TABLE dbo.hwy_members DROP COLUMN ' + QUOTENAME(@name) + N';';
    BEGIN TRY
      EXEC sp_executesql @sql;
    END TRY
    BEGIN CATCH
      IF ERROR_NUMBER() NOT IN (4924, 5074)
        THROW;
    END CATCH;
    FETCH NEXT FROM drop_cursor INTO @name;
  END;
  CLOSE drop_cursor;
  DEALLOCATE drop_cursor;

  PRINT 'hwy_members PascalCase computed aliases dropped';
END;
GO
