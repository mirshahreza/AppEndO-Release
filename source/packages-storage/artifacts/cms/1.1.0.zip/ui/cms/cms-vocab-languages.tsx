import React from 'react';
import { buildAppTableGridColumns } from '@/domain/component-designer/DesignerRuntimeAppTableGrid';
import { applyClientGridQuery, EMPTY_GRID_QUERY, type GridQueryState } from '@/shared/lib/appTableGridQuery';
import { resolveDataGridTotalCount, sliceDataGridRowsForDisplay, buildDataGridPageNumbers } from '@/domain/component-designer/designerDataGridRuntime';
import { applyDesignerGridToolbarClientFilters } from '@/domain/component-designer/designerGridToolbarConfig';
import { createDefaultColumnLayout } from '@/shared/lib/appTableGridColumnLayout';
import { validateDesignerFieldNode } from '@/domain/component-designer/previewFieldValidation';
import { AppTableGrid, GridPagingFooter } from '@/shared/ui';
import { UiInput } from '@/shared/ui/HeroFieldControls';
import { Button, Modal, Switch, Toast, toast } from '@heroui/react';

const parseApiErrorMessage = async (response: Response): Promise<string> => {
  try {
    const payload = await response.json();
    if (payload && typeof payload === "object") {
      const record = payload as Record<string, unknown>;
      const message = record.message ?? record.error ?? record.detail;
      if (typeof message === "string" && message.trim().length > 0) {
        return message.trim();
      }
    }
  } catch {
    // fall through to status text
  }
  return response.statusText || `Request failed (${response.status})`;
};

const readBindingParamValue = (
  context: Record<string, unknown> | null | undefined,
  dataPath: string,
): unknown => {
  const segments = dataPath.split(".").map((segment) => segment.trim()).filter(Boolean);
  let cursor: unknown = context;
  for (const segment of segments) {
    if (cursor && typeof cursor === "object" && segment in (cursor as Record<string, unknown>)) {
      cursor = (cursor as Record<string, unknown>)[segment];
    } else {
      return undefined;
    }
  }
  return cursor;
};

const resolveBindingTemplateValue = (
  template: string,
  context: Record<string, unknown> | null | undefined,
  paramPaths: Record<string, string>,
): string =>
  template.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, paramName: string) => {
    const dataPath = paramPaths[paramName];
    if (!dataPath) {
      return "";
    }
    const cursor = readBindingParamValue(context, dataPath);
    return cursor === undefined || cursor === null ? "" : String(cursor);
  });

const resolveBindingUrl = (
  endpointTemplate: string,
  context: Record<string, unknown> | null | undefined,
  paramPaths: Record<string, string>,
): string => {
  const usedParamNames = new Set<string>();
  let resolvedPath = endpointTemplate.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, paramName: string) => {
    usedParamNames.add(paramName);
    const dataPath = paramPaths[paramName];
    if (!dataPath) {
      return "";
    }
    const cursor = readBindingParamValue(context, dataPath);
    return cursor === undefined || cursor === null ? "" : String(cursor);
  });
  for (const [paramName, dataPath] of Object.entries(paramPaths)) {
    if (usedParamNames.has(paramName)) {
      continue;
    }
    const colonParamPattern = new RegExp(`:${paramName}(?=/|$)`, "g");
    if (!colonParamPattern.test(resolvedPath)) {
      continue;
    }
    usedParamNames.add(paramName);
    const cursor = readBindingParamValue(context, dataPath);
    const text = cursor === undefined || cursor === null ? "" : String(cursor);
    resolvedPath = resolvedPath.replace(new RegExp(`:${paramName}(?=/|$)`, "g"), text);
  }
  const searchParams = new URLSearchParams();
  for (const [paramName, dataPath] of Object.entries(paramPaths)) {
    if (usedParamNames.has(paramName)) {
      continue;
    }
    const cursor = readBindingParamValue(context, dataPath);
    if (cursor === undefined || cursor === null) {
      continue;
    }
    const text = String(cursor).trim();
    if (text.length === 0) {
      continue;
    }
    searchParams.set(paramName, text);
  }
  const queryString = searchParams.toString();
  if (!queryString) {
    return resolvedPath;
  }
  return resolvedPath.includes("?") ? `${resolvedPath}&${queryString}` : `${resolvedPath}?${queryString}`;
};

const resolveBindingHeaders = (
  context: Record<string, unknown> | null | undefined,
  headerTemplates: Record<string, string>,
  paramPaths: Record<string, string>,
): Record<string, string> =>
  Object.fromEntries(
    Object.entries(headerTemplates).map(([key, template]) => [
      key,
      resolveBindingTemplateValue(template, context, paramPaths),
    ]),
  );

const setNestedPayloadValue = (target: Record<string, unknown>, path: string, value: unknown): void => {
  const segments = path.split(".").map((segment) => segment.trim()).filter(Boolean);
  if (segments.length === 0) {
    return;
  }
  let cursor: Record<string, unknown> = target;
  for (let index = 0; index < segments.length - 1; index += 1) {
    const segment = segments[index];
    const next = cursor[segment];
    if (!next || typeof next !== "object" || Array.isArray(next)) {
      cursor[segment] = {};
    }
    cursor = cursor[segment] as Record<string, unknown>;
  }
  cursor[segments[segments.length - 1]] = value;
};

const mapDesignerListBoxItems = (rawItems: unknown): Array<{ id: string; textValue: string }> => {
  const items = Array.isArray(rawItems) ? rawItems : [];
  return items
    .map((entry) => {
      if (!entry || typeof entry !== "object") {
        return null;
      }
      const record = entry as Record<string, unknown>;
      const id = String(record.id ?? "").trim();
      if (!id || id === "100" || id === "102") {
        return null;
      }
      const textValue = String(record.textValue ?? record.label ?? record.title ?? id).trim();
      return { id, textValue: textValue || id };
    })
    .filter((entry): entry is { id: string; textValue: string } => entry !== null);
};

const mapDesignerLovItems = (
  rawItems: unknown,
  returnColumn: string,
  displayColumn: string,
): Array<{ id: string; textValue: string }> => {
  const items = Array.isArray(rawItems) ? rawItems : [];
  return items
    .map((entry) => {
      if (!entry || typeof entry !== "object") {
        return null;
      }
      const record = entry as Record<string, unknown>;
      const id = String(record[returnColumn] ?? "").trim();
      if (!id) {
        return null;
      }
      const textValue = String(record[displayColumn] ?? id).trim();
      return { id, textValue: textValue || id };
    })
    .filter((entry): entry is { id: string; textValue: string } => entry !== null);
};

const collectRegionFormDataFromContainer = (
  container: ParentNode,
  formFieldNames: readonly string[],
): FormData => {
  const formData = new FormData();
  for (const formFieldName of formFieldNames) {
    const escapedName = formFieldName.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    const field = container.querySelector(`[name="${escapedName}"]`);
    if (!field) {
      continue;
    }
    if (field instanceof HTMLInputElement) {
      if (field.type === "checkbox" || field.type === "radio") {
        formData.set(formFieldName, field.checked ? "true" : "false");
      } else {
        formData.set(formFieldName, field.value);
      }
      continue;
    }
    if (field instanceof HTMLTextAreaElement || field instanceof HTMLSelectElement) {
      formData.set(formFieldName, field.value);
      continue;
    }
    formData.set(formFieldName, field.getAttribute("value") ?? "");
  }
  return formData;
};

const applyPayloadFieldTransform = (value: FormDataEntryValue | null, transform?: string): unknown => {
  const raw = value === null ? "" : String(value);
  switch (transform) {
    case "number": {
      const parsed = Number(raw);
      return Number.isFinite(parsed) ? parsed : raw;
    }
    case "boolean":
      return raw === "true" || raw === "1" || raw === "on";
    case "commaSeparatedArray":
      return raw.split(",").map((entry) => entry.trim()).filter(Boolean);
    default:
      return raw;
  }
};

// --- AUTH / TOKEN LIFECYCLE INJECTION POINT ---
// Register your application-wide 401 interceptor and token refresh handler here before production.
// Example: const designerFetch = createAuthenticatedFetch({ getAccessToken, refreshTokens, onSessionExpired });
const designerFetch: typeof fetch = fetch;

function useDataFetch<T>(url: string, options: { headers?: Record<string, string> } = {}) {
  const [data, setData] = React.useState<T | null>(null);
  const [isLoading, setIsLoading] = React.useState(Boolean(url));
  const [error, setError] = React.useState<string | null>(null);
  const [refreshNonce, setRefreshNonce] = React.useState(0);
  const headersKey = JSON.stringify(options.headers ?? {});

  const refresh = React.useCallback(async () => {
    setRefreshNonce((previous) => previous + 1);
  }, []);

  React.useEffect(() => {
    if (!url) {
      setData(null);
      setIsLoading(false);
      setError(null);
      return undefined;
    }

    let cancelled = false;
    const load = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const response = await designerFetch(url, {
          method: "GET",
          headers: options.headers,
        });
        if (!response.ok) {
          throw new Error(await parseApiErrorMessage(response));
        }
        const payload = (await response.json()) as T;
        if (!cancelled) {
          setData(payload);
        }
      } catch (loadError) {
        if (!cancelled) {
          setData(null);
          setError(loadError instanceof Error ? loadError.message : "Request failed");
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, [url, headersKey, refreshNonce]);

  return { data, isLoading, error, refresh };
}

const readNestedContextValue = (
  context: Record<string, unknown> | null | undefined,
  path: string,
): unknown => {
  const segments = path.split(".").map((segment) => segment.trim()).filter(Boolean);
  let cursor: unknown = context;
  for (const segment of segments) {
    if (cursor && typeof cursor === "object" && segment in (cursor as Record<string, unknown>)) {
      cursor = (cursor as Record<string, unknown>)[segment];
    } else {
      return undefined;
    }
  }
  return cursor;
};

const applyResponseDataPath = (
  payload: unknown,
  responseMapping?: { dataPath?: string; arrayPath?: string },
): unknown => {
  if (!responseMapping) {
    return payload;
  }
  const arrayPath = responseMapping.arrayPath?.trim();
  if (arrayPath) {
    const arrayValue = readNestedContextValue(
      payload && typeof payload === "object" ? payload as Record<string, unknown> : {},
      arrayPath,
    );
    if (Array.isArray(arrayValue)) {
      return arrayValue;
    }
  }
  const dataPath = responseMapping.dataPath?.trim();
  if (!dataPath || !payload || typeof payload !== "object") {
    return payload;
  }
  return readNestedContextValue(payload as Record<string, unknown>, dataPath);
};

const coerceApiRecordValue = (value: unknown): Record<string, unknown> | undefined => {
  if (value === undefined || value === null) {
    return undefined;
  }
  if (Array.isArray(value)) {
    return value.find(
      (entry): entry is Record<string, unknown> =>
        typeof entry === "object" && entry !== null && !Array.isArray(entry),
    );
  }
  if (typeof value === "object") {
    return value as Record<string, unknown>;
  }
  return undefined;
};

const transformApiRowsToChartData = (
  rows: Array<Record<string, unknown>>,
  mapping: { categoryField: string; categoryAs?: string; series: Array<{ apiField: string; seriesKey: string; aggregation?: string }> },
): Array<Record<string, string | number>> => {
  const categoryKey = mapping.categoryAs?.trim() || "label";
  const parseNum = (raw: unknown): number => {
    if (typeof raw === "number" && Number.isFinite(raw)) return raw;
    if (typeof raw === "string") { const p = Number(raw); return Number.isFinite(p) ? p : 0; }
    return 0;
  };
  const aggregate = (values: number[], agg: string): number => {
    if (values.length === 0) return 0;
    if (agg === "count") return values.length;
    if (agg === "avg") return values.reduce((s, v) => s + v, 0) / values.length;
    if (agg === "min") return Math.min(...values);
    if (agg === "max") return Math.max(...values);
    if (agg === "sum") return values.reduce((s, v) => s + v, 0);
    return values[0] ?? 0;
  };
  const needsGrouping = mapping.series.some((s) => s.aggregation && s.aggregation !== "none");
  if (!needsGrouping) {
    return rows.map((row) => {
      const chartRow: Record<string, string | number> = { [categoryKey]: String(row[mapping.categoryField] ?? "") };
      for (const series of mapping.series) { chartRow[series.seriesKey] = parseNum(row[series.apiField]); }
      return chartRow;
    });
  }
  const grouped = new Map<string, Array<Record<string, unknown>>>();
  for (const row of rows) {
    const cat = String(row[mapping.categoryField] ?? "");
    const bucket = grouped.get(cat);
    if (bucket) bucket.push(row); else grouped.set(cat, [row]);
  }
  return Array.from(grouped.entries()).map(([category, groupRows]) => {
    const chartRow: Record<string, string | number> = { [categoryKey]: category };
    for (const series of mapping.series) {
      const values = groupRows.map((r) => parseNum(r[series.apiField]));
      chartRow[series.seriesKey] = aggregate(values, series.aggregation ?? "sum");
    }
    return chartRow;
  });
};

const readVizStringField = (row: Record<string, unknown>, field: string, fallback = ""): string => {
  const value = row[field];
  if (value === undefined || value === null) return fallback;
  return String(value);
};

const transformApiRowsToTreeNodes = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "tree"; idField: string; labelField: string; parentIdField?: string },
): Array<{ id: string; label: string; children?: unknown[] }> => {
  const parentField = mapping.parentIdField?.trim();
  if (!parentField) {
    return rows.map((row, index) => ({
      id: readVizStringField(row, mapping.idField, `node-${index + 1}`),
      label: readVizStringField(row, mapping.labelField, `Item ${index + 1}`),
    }));
  }
  const nodeMap = new Map<string, { id: string; label: string; children: unknown[] }>();
  rows.forEach((row) => {
    const id = readVizStringField(row, mapping.idField);
    if (!id) return;
    nodeMap.set(id, { id, label: readVizStringField(row, mapping.labelField, id), children: [] });
  });
  const roots: Array<{ id: string; label: string; children?: unknown[] }> = [];
  rows.forEach((row) => {
    const id = readVizStringField(row, mapping.idField);
    if (!id) return;
    const node = nodeMap.get(id);
    if (!node) return;
    const parentId = readVizStringField(row, parentField);
    if (parentId && nodeMap.has(parentId)) {
      nodeMap.get(parentId)!.children.push(node);
    } else {
      roots.push(node);
    }
  });
  return roots;
};

const readVizNumberField = (row: Record<string, unknown>, field: string): number | undefined => {
  const value = row[field];
  const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(parsed) ? parsed : undefined;
};

const transformApiRowsToTimelineEvents = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "timeline" | "gantt"; idField?: string; titleField: string; startField: string; endField?: string; descriptionField?: string; progressField?: string },
): Array<{ id?: string; title: string; start: string; end?: string; description?: string; progress?: number }> =>
  rows.map((row, index) => {
    const progress = mapping.progressField ? readVizNumberField(row, mapping.progressField) : undefined;
    return {
      id: mapping.idField ? readVizStringField(row, mapping.idField, `evt-${index + 1}`) : `evt-${index + 1}`,
      title: readVizStringField(row, mapping.titleField, `Event ${index + 1}`),
      start: readVizStringField(row, mapping.startField),
      ...(mapping.endField ? { end: readVizStringField(row, mapping.endField) } : {}),
      ...(mapping.descriptionField ? { description: readVizStringField(row, mapping.descriptionField) } : {}),
      ...(progress !== undefined ? { progress } : {}),
    };
  });

const transformApiRowsToKanbanBoard = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "kanban"; cardIdField: string; cardTitleField: string; cardDescriptionField?: string; cardColumnField: string; columnOrder?: Array<{ id: string; title: string }> },
): { columns: Array<{ id: string; title: string; cards: Array<{ id: string; title: string; description?: string }> }> } => {
  const cardsByColumn = new Map<string, Array<{ id: string; title: string; description?: string }>>();
  rows.forEach((row, index) => {
    const columnKey = readVizStringField(row, mapping.cardColumnField, "default");
    const card = {
      id: readVizStringField(row, mapping.cardIdField, `card-${index + 1}`),
      title: readVizStringField(row, mapping.cardTitleField, `Card ${index + 1}`),
      ...(mapping.cardDescriptionField ? { description: readVizStringField(row, mapping.cardDescriptionField) } : {}),
    };
    cardsByColumn.set(columnKey, [...(cardsByColumn.get(columnKey) ?? []), card]);
  });
  const columnOrder = mapping.columnOrder && mapping.columnOrder.length > 0
    ? mapping.columnOrder
    : Array.from(cardsByColumn.keys()).map((key) => ({ id: key, title: key }));
  const columns = columnOrder.map((columnDef) => ({
    id: columnDef.id,
    title: columnDef.title,
    cards: cardsByColumn.get(columnDef.id) ?? cardsByColumn.get(columnDef.title) ?? [],
  }));
  cardsByColumn.forEach((cards, columnKey) => {
    if (!columns.some((column) => column.id === columnKey || column.title === columnKey)) {
      columns.push({ id: columnKey, title: columnKey, cards });
    }
  });
  return { columns };
};

const transformApiRowsToSheetData = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "sheet"; columns: Array<{ header: string; field: string }> },
): { columns: string[]; rows: string[][] } => ({
  columns: mapping.columns.map((column) => column.header),
  rows: rows.map((row) => mapping.columns.map((column) => readVizStringField(row, column.field))),
});

type EntityPickerOption = { id: string; textValue: string };
type EntityPickerFieldMapping = { returnField: string; displayField: string };

function normalizeEntityPickerItems(payload: unknown, mapping?: EntityPickerFieldMapping): EntityPickerOption[] {
  const returnField = mapping?.returnField?.trim() || "id";
  const displayField = mapping?.displayField?.trim() || "label";
  if (Array.isArray(payload)) {
    return payload
      .map((entry) => {
        if (!entry || typeof entry !== "object") {
          return null;
        }
        const record = entry as Record<string, unknown>;
        const mappedId = record[returnField];
        const id = typeof mappedId === "string" && mappedId.trim()
          ? mappedId.trim()
          : typeof record.id === "string" && record.id.trim()
            ? record.id.trim()
            : typeof record.value === "string" && record.value.trim()
              ? record.value.trim()
              : "";
        const mappedLabel = record[displayField];
        const textValue = typeof mappedLabel === "string" && mappedLabel.trim()
          ? mappedLabel.trim()
          : typeof record.textValue === "string" && record.textValue.trim()
            ? record.textValue.trim()
            : typeof record.label === "string" && record.label.trim()
              ? record.label.trim()
              : typeof record.name === "string" && record.name.trim()
                ? record.name.trim()
                : id;
        if (!id || !textValue) {
          return null;
        }
        return { id, textValue };
      })
      .filter((entry): entry is EntityPickerOption => entry !== null);
  }

  if (payload && typeof payload === "object") {
    const record = payload as Record<string, unknown>;
    const items = record.items ?? record.results ?? record.data;
    return normalizeEntityPickerItems(items, mapping);
  }

  return [];
}

function useEntityPickerOptions(entityRef: string, searchParam: string, mapping?: EntityPickerFieldMapping) {
  const [items, setItems] = React.useState<EntityPickerOption[]>([]);
  const [isLoading, setIsLoading] = React.useState(false);

  const loadOptions = React.useCallback(async (query: string) => {
    if (!entityRef) {
      setItems([]);
      return;
    }

    setIsLoading(true);
    try {
      const url = entityRef.startsWith("http")
        ? new URL(entityRef)
        : new URL(entityRef, window.location.origin);
      // Option A (parity audit items 31/32): Autocomplete is Select-based — no live typing.
      // Still honour an explicit non-empty query if a caller passes one, but initial load uses "".
      if (query.trim()) {
        url.searchParams.set(searchParam, query);
      }
      const response = await fetch(url.toString());
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      const payload = await response.json();
      setItems(normalizeEntityPickerItems(payload, mapping));
    } catch {
      setItems([]);
    } finally {
      setIsLoading(false);
    }
  }, [entityRef, searchParam, mapping?.returnField, mapping?.displayField]);

  React.useEffect(() => {
    void loadOptions("");
  }, [loadOptions]);

  return { items, isLoading, loadOptions };
}
function useDesignerStore<T extends Record<string, unknown>>(initial: T) {
  const [store, setStore] = React.useState<T>(initial);
  const patch = React.useCallback((path: string, value: unknown) => {
    setStore((previous) => {
      const next = { ...previous };
      setNestedPayloadValue(next, path, value);
      return next as T;
    });
  }, []);
  return { store, patch };
}
function evaluateDesignerCondition(
  designerStore: Record<string, unknown>,
  dataContext: Record<string, unknown> | null,
  scope: { item?: unknown; index?: number },
  condition: string,
): boolean {
  const trimmed = condition.trim();
  if (!trimmed) {
    return true;
  }
  try {
    const formatPathChain = (root: string, path: string): string => {
      const chain = path
        .split('.')
        .filter(Boolean)
        .map((segment) => {
          if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(segment)) {
            return `?.${segment}`;
          }
          return `?.[${JSON.stringify(segment)}]`;
        })
        .join('');
      return `(${root}${chain})`;
    };
    let compiled = trimmed
      .replace(/\bstore\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('designerStore', path))
      .replace(/\bdata\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('dataContext', path))
      .replace(/\bdataContext\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('dataContext', path));
    const evaluator = new Function('designerStore', 'dataContext', 'item', 'index', `return Boolean(${compiled});`);
    return Boolean(evaluator(designerStore, dataContext, scope.item, scope.index));
  } catch {
    return false;
  }
}

export const GeneratedComponent: React.FC = () => {
  const { store: designerStore, patch: patchDesignerStore } = useDesignerStore<Record<string, unknown>>({"selection":{"id":null}});
  const { data: raw_regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872, isLoading: isLoading_regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872, error: error_regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872, refresh: refresh_regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872 } = useDataFetch<unknown>("/api/base-info", {});
  const regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872 = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872, {"dataPath":"items","arrayPath":"items","totalPath":"count"})), [raw_regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872]);
  const { data: raw_regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32, isLoading: isLoading_regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32, error: error_regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32, refresh: refresh_regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32 } = useDataFetch<unknown>(resolveBindingUrl("/api/base-info", designerStore, { "id": "selection.id" }), {});
  const regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32 = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32, {"dataPath":"items","arrayPath":"items","totalPath":"count"})), [raw_regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32]);
  const handleGridRowAction_heroui_app_table_grid_1785520943018_yqq7u = React.useCallback((row: Record<string, unknown>, actionId: string) => {
    switch (actionId) {
      case "edit": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-014b3e3d-e3d2-4a96-91e1-863ecf77a2cb", true);
        return;
      }
      case "delete": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-1b34d765-157f-4185-a0e3-7d22b3515380", true);
        return;
      }
      default:
        return;
    }
  }, [patchDesignerStore]);
  const { data: raw_gridData_heroui_app_table_grid_1785520943018_yqq7u, isLoading: isLoading_gridData_heroui_app_table_grid_1785520943018_yqq7u, error: error_gridData_heroui_app_table_grid_1785520943018_yqq7u, refresh: refresh_gridData_heroui_app_table_grid_1785520943018_yqq7u } = useDataFetch<unknown>(resolveBindingUrl("/api/base-info/children?parentId=101.004&includeInactive=true", designerStore, { "search": "gridToolbar.search", "sortBy": "gridQuery.sortBy", "sortDir": "gridQuery.sortDir", "page": "gridQuery.page", "pageSize": "gridQuery.pageSize", "title": "gridQuery.filters.title", "shortName": "gridQuery.filters.shortName", "isActive": "gridQuery.filters.isActive" }), {});
  const gridData_heroui_app_table_grid_1785520943018_yqq7u = React.useMemo(() => applyResponseDataPath(raw_gridData_heroui_app_table_grid_1785520943018_yqq7u, {"dataPath":"items","arrayPath":"items","totalPath":"count"}), [raw_gridData_heroui_app_table_grid_1785520943018_yqq7u]);
  const gridColumns_heroui_app_table_grid_1785520943018_yqq7u = React.useMemo(() => buildAppTableGridColumns([{"key":"title","label":"Title","sort":true,"filter":true,"filterType":"text","cardRole":"title"},{"key":"shortName","label":"Short name","sort":true,"filter":true,"filterType":"text","cardRole":"field"},{"key":"viewOrder","label":"Order","sort":true,"cardRole":"meta"},{"key":"isActive","label":"Active","sort":true,"filter":true,"filterType":"boolean","cellKind":"boolean-icon","cardRole":"meta"},{"key":"actions","label":"","kind":"action-group","actions":[{"actionId":"edit","icon":"Pencil","intent":"edit","tooltip":"Edit","behavior":{"kind":"open-modal","modalNodeId":"node-014b3e3d-e3d2-4a96-91e1-863ecf77a2cb","primaryKeyField":"id","selectionStorePath":"selection.id"}},{"actionId":"delete","icon":"Trash2","intent":"delete","tooltip":"Delete","behavior":{"kind":"open-modal","modalNodeId":"node-1b34d765-157f-4185-a0e3-7d22b3515380","primaryKeyField":"id","selectionStorePath":"selection.id"}}],"cardRole":"actions","layoutHideable":false,"layoutResizable":false,"layoutReorderable":false,"width":"140px"}], "server", {
    mode: 'runtime',
    detailFlowRef: { current: null },
    rowActionHandlerRef: { current: handleGridRowAction_heroui_app_table_grid_1785520943018_yqq7u },
    cellClickHandlerRef: { current: undefined },
    designerStoreRef: { current: designerStore },
  }), [designerStore, handleGridRowAction_heroui_app_table_grid_1785520943018_yqq7u]);
  const [gridQuery_heroui_app_table_grid_1785520943018_yqq7u, setGridQuery_heroui_app_table_grid_1785520943018_yqq7u] = React.useState<GridQueryState>(() => ({ ...EMPTY_GRID_QUERY, sort: { columnId: "viewOrder", direction: 'asc' } }));
  const [gridPage_heroui_app_table_grid_1785520943018_yqq7u, setGridPage_heroui_app_table_grid_1785520943018_yqq7u] = React.useState(1);
  const [gridPageSize_heroui_app_table_grid_1785520943018_yqq7u, setGridPageSize_heroui_app_table_grid_1785520943018_yqq7u] = React.useState(50);
  const [gridListMode_heroui_app_table_grid_1785520943018_yqq7u, setGridListMode_heroui_app_table_grid_1785520943018_yqq7u] = React.useState<'paging' | 'infinite'>("paging");
  const [gridColumnLayout_heroui_app_table_grid_1785520943018_yqq7u, setGridColumnLayout_heroui_app_table_grid_1785520943018_yqq7u] = React.useState(() => createDefaultColumnLayout(gridColumns_heroui_app_table_grid_1785520943018_yqq7u));
  const [gridSearchInput_heroui_app_table_grid_1785520943018_yqq7u, setGridSearchInput_heroui_app_table_grid_1785520943018_yqq7u] = React.useState('');
  const [gridDebouncedSearch_heroui_app_table_grid_1785520943018_yqq7u, setGridDebouncedSearch_heroui_app_table_grid_1785520943018_yqq7u] = React.useState('');
  const [gridRoleFilters_heroui_app_table_grid_1785520943018_yqq7u, setGridRoleFilters_heroui_app_table_grid_1785520943018_yqq7u] = React.useState<Record<string, boolean>>({});
  const gridFilteredRows_heroui_app_table_grid_1785520943018_yqq7u = React.useMemo(() => applyClientGridQuery(((Array.isArray(gridData_heroui_app_table_grid_1785520943018_yqq7u?.items) ? gridData_heroui_app_table_grid_1785520943018_yqq7u?.items : []) ?? []), gridQuery_heroui_app_table_grid_1785520943018_yqq7u, gridColumns_heroui_app_table_grid_1785520943018_yqq7u, "server"), [gridQuery_heroui_app_table_grid_1785520943018_yqq7u, gridColumns_heroui_app_table_grid_1785520943018_yqq7u]);
  const gridApiTotal_heroui_app_table_grid_1785520943018_yqq7u = React.useMemo(() => {
    const raw = raw_gridData_heroui_app_table_grid_1785520943018_yqq7u;
    const value = readNestedContextValue((raw && typeof raw === 'object' ? raw as Record<string, unknown> : {}), "count");
    const parsed = typeof value === 'number' ? value : Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : 0;
  }, [raw_gridData_heroui_app_table_grid_1785520943018_yqq7u]);
  const gridTotalCount_heroui_app_table_grid_1785520943018_yqq7u = resolveDataGridTotalCount({ page: gridPage_heroui_app_table_grid_1785520943018_yqq7u, pageSize: gridPageSize_heroui_app_table_grid_1785520943018_yqq7u, total: gridApiTotal_heroui_app_table_grid_1785520943018_yqq7u, gridQueryMode: "server" }, gridFilteredRows_heroui_app_table_grid_1785520943018_yqq7u.length);
  const gridPaging_heroui_app_table_grid_1785520943018_yqq7u = sliceDataGridRowsForDisplay(gridFilteredRows_heroui_app_table_grid_1785520943018_yqq7u, gridPage_heroui_app_table_grid_1785520943018_yqq7u, gridPageSize_heroui_app_table_grid_1785520943018_yqq7u, gridTotalCount_heroui_app_table_grid_1785520943018_yqq7u, "server");
  const handleGridQueryChange_heroui_app_table_grid_1785520943018_yqq7u = React.useCallback((nextQuery: GridQueryState) => {
    setGridQuery_heroui_app_table_grid_1785520943018_yqq7u(nextQuery);
    setGridPage_heroui_app_table_grid_1785520943018_yqq7u(1);
    patchDesignerStore("gridQuery.sortBy", nextQuery.sort?.columnId ?? '');
    patchDesignerStore("gridQuery.sortDir", nextQuery.sort?.direction ?? '');
  }, [patchDesignerStore]);
  const handleGridPageChange_heroui_app_table_grid_1785520943018_yqq7u = React.useCallback((nextPage: number) => {
    setGridPage_heroui_app_table_grid_1785520943018_yqq7u(nextPage);
    patchDesignerStore("gridQuery.page", nextPage);
  }, [patchDesignerStore]);
  const handleGridPageSizeChange_heroui_app_table_grid_1785520943018_yqq7u = React.useCallback((nextSize: number) => {
    setGridPageSize_heroui_app_table_grid_1785520943018_yqq7u(nextSize);
    setGridPage_heroui_app_table_grid_1785520943018_yqq7u(1);
    patchDesignerStore("gridQuery.pageSize", nextSize);
  }, [patchDesignerStore]);
  const handleGridSortByChange_heroui_app_table_grid_1785520943018_yqq7u = React.useCallback((nextSortBy: string) => {
    setGridQuery_heroui_app_table_grid_1785520943018_yqq7u((current: GridQueryState) => ({ ...current, sort: nextSortBy ? { columnId: nextSortBy, direction: current.sort?.direction ?? 'asc' } : null }));
  }, []);
  const handleGridToggleSortDirection_heroui_app_table_grid_1785520943018_yqq7u = React.useCallback(() => {
    setGridQuery_heroui_app_table_grid_1785520943018_yqq7u((current: GridQueryState) => (current.sort ? { ...current, sort: { ...current.sort, direction: current.sort.direction === 'asc' ? 'desc' : 'asc' } } : current));
  }, []);
  const searchDebounceTimer_heroui_app_table_grid_1785520943018_yqq7u = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const handleGridSearchChange_heroui_app_table_grid_1785520943018_yqq7u = React.useCallback((nextValue: string) => {
    setGridSearchInput_heroui_app_table_grid_1785520943018_yqq7u(nextValue);
    if (searchDebounceTimer_heroui_app_table_grid_1785520943018_yqq7u.current) {
      clearTimeout(searchDebounceTimer_heroui_app_table_grid_1785520943018_yqq7u.current);
    }
    searchDebounceTimer_heroui_app_table_grid_1785520943018_yqq7u.current = setTimeout(() => {
      setGridDebouncedSearch_heroui_app_table_grid_1785520943018_yqq7u(nextValue);
      setGridPage_heroui_app_table_grid_1785520943018_yqq7u(1);
      patchDesignerStore("gridToolbar.search", nextValue);
    }, 300);
  }, [patchDesignerStore]);

  const dataContext: Record<string, unknown> | null = regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872 ?? null;
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [mutationError, setMutationError] = React.useState<string | null>(null);
  const handleonClick_node_c8dc13e0_4488_4d13_80be_f02e21c2de60 = React.useCallback(async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    let formData: FormData;
    const form = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : event.currentTarget.closest('form');
    if (form) {
      formData = new FormData(form);
    } else {
      const regionRoot = document.querySelector("[data-designer-node-id=\"node-d641efb1-e03d-4f7f-b1f4-02dd0fc56872\"]");
      if (!regionRoot) {
        return;
      }
      formData = collectRegionFormDataFromContainer(regionRoot, ["node-dafedd58-7c9c-47ec-98f4-e06ad60e346d","node-56dfb439-cf5f-4a6d-932a-c6da2948748d","node-8c4ea843-48fd-4cf0-8ee4-3a5030b6aa32","node-d5ca1ca1-6d0a-402d-93d9-295acb4ec05c","node-5494ed18-5d8c-4d6c-a2ff-150e13b55957"]);
    }
    const fieldValidationEntries = [{"nodeId":"node-dafedd58-7c9c-47ec-98f4-e06ad60e346d","formFieldName":"node-dafedd58-7c9c-47ec-98f4-e06ad60e346d","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-56dfb439-cf5f-4a6d-932a-c6da2948748d","formFieldName":"node-56dfb439-cf5f-4a6d-932a-c6da2948748d","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-5494ed18-5d8c-4d6c-a2ff-150e13b55957","formFieldName":"node-5494ed18-5d8c-4d6c-a2ff-150e13b55957","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}}] as Array<{ nodeId: string; formFieldName: string; props: Record<string, unknown> }>;
    const fieldValidationErrors: Record<string, string> = {};
    for (const entry of fieldValidationEntries) {
      const rawValue = formData.get(entry.formFieldName);
      const validationMessage = validateDesignerFieldNode(entry.props, typeof rawValue === 'string' ? rawValue : '');
      if (validationMessage) {
        fieldValidationErrors[entry.nodeId] = validationMessage;
      }
    }
    if (Object.keys(fieldValidationErrors).length > 0) {
      setMutationError(Object.values(fieldValidationErrors).join(' '));
      return;
    }
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      payload["title"] = formData.get("node-dafedd58-7c9c-47ec-98f4-e06ad60e346d") ?? '';
      payload["shortName"] = formData.get("node-56dfb439-cf5f-4a6d-932a-c6da2948748d") ?? '';
      payload["viewOrder"] = applyPayloadFieldTransform(formData.get("node-8c4ea843-48fd-4cf0-8ee4-3a5030b6aa32"), "number");
      payload["isActive"] = applyPayloadFieldTransform(formData.get("node-d5ca1ca1-6d0a-402d-93d9-295acb4ec05c"), "boolean");
      payload["parentId"] = formData.get("node-5494ed18-5d8c-4d6c-a2ff-150e13b55957") ?? '';
      const method = regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872?.id != null && String(regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872?.id).length > 0 ? 'PUT' : 'POST';
      const url = (regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872?.id != null && String(regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872?.id).length > 0 ? (regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872?.id != null && String(regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872?.id).length > 0 ? "/api/base-info" + '/' + encodeURIComponent(String(regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872?.id)) : "/api/base-info") : "/api/base-info");
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      patchDesignerStore("ui.visibility.node-23017f4d-31df-40e1-8717-1467403af480", false);
      toast("Saved successfully", { variant: "success", timeout: 4000 });
      await refresh_gridData_heroui_app_table_grid_1785520943018_yqq7u();
      (document.querySelector("[data-designer-node-id=\"node-d641efb1-e03d-4f7f-b1f4-02dd0fc56872\"]") as HTMLFormElement | null)?.reset?.();
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, [regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872]);
  const handleonClick_node_6d684f86_9720_4183_985a_914c8958e33f = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-23017f4d-31df-40e1-8717-1467403af480", false);
  }, [patchDesignerStore]);
  const handleonClick_node_e012f2f8_72ff_40fd_9db8_1207b4e192c1 = React.useCallback(async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    let formData: FormData;
    const form = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : event.currentTarget.closest('form');
    if (form) {
      formData = new FormData(form);
    } else {
      const regionRoot = document.querySelector("[data-designer-node-id=\"node-9d3f7cd5-44d3-4d76-952f-ac1a64520c32\"]");
      if (!regionRoot) {
        return;
      }
      formData = collectRegionFormDataFromContainer(regionRoot, ["node-c40e65d2-873b-4b30-90cb-4bd142efefa2","node-2a5e8470-0cc2-4667-abe7-39845a2c15dd","node-2ff96993-35f5-48fa-a7e1-567e5cbd01cc","node-814a86a9-7395-4279-92f9-0cd0aea52d7b","node-34dec69d-8c6a-4c37-aebb-eb5f02f2f5cd"]);
    }
    const fieldValidationEntries = [{"nodeId":"node-c40e65d2-873b-4b30-90cb-4bd142efefa2","formFieldName":"node-c40e65d2-873b-4b30-90cb-4bd142efefa2","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-2a5e8470-0cc2-4667-abe7-39845a2c15dd","formFieldName":"node-2a5e8470-0cc2-4667-abe7-39845a2c15dd","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-34dec69d-8c6a-4c37-aebb-eb5f02f2f5cd","formFieldName":"node-34dec69d-8c6a-4c37-aebb-eb5f02f2f5cd","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}}] as Array<{ nodeId: string; formFieldName: string; props: Record<string, unknown> }>;
    const fieldValidationErrors: Record<string, string> = {};
    for (const entry of fieldValidationEntries) {
      const rawValue = formData.get(entry.formFieldName);
      const validationMessage = validateDesignerFieldNode(entry.props, typeof rawValue === 'string' ? rawValue : '');
      if (validationMessage) {
        fieldValidationErrors[entry.nodeId] = validationMessage;
      }
    }
    if (Object.keys(fieldValidationErrors).length > 0) {
      setMutationError(Object.values(fieldValidationErrors).join(' '));
      return;
    }
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      payload["title"] = formData.get("node-c40e65d2-873b-4b30-90cb-4bd142efefa2") ?? '';
      payload["shortName"] = formData.get("node-2a5e8470-0cc2-4667-abe7-39845a2c15dd") ?? '';
      payload["viewOrder"] = applyPayloadFieldTransform(formData.get("node-2ff96993-35f5-48fa-a7e1-567e5cbd01cc"), "number");
      payload["isActive"] = applyPayloadFieldTransform(formData.get("node-814a86a9-7395-4279-92f9-0cd0aea52d7b"), "boolean");
      payload["parentId"] = formData.get("node-34dec69d-8c6a-4c37-aebb-eb5f02f2f5cd") ?? '';
      const method = regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32?.id != null && String(regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32?.id).length > 0 ? 'PUT' : 'POST';
      const url = (regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32?.id != null && String(regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32?.id).length > 0 ? (regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32?.id != null && String(regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32?.id).length > 0 ? "/api/base-info" + '/' + encodeURIComponent(String(regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32?.id)) : "/api/base-info") : "/api/base-info");
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      patchDesignerStore("ui.visibility.node-014b3e3d-e3d2-4a96-91e1-863ecf77a2cb", false);
      toast("Saved successfully", { variant: "success", timeout: 4000 });
      await refresh_gridData_heroui_app_table_grid_1785520943018_yqq7u();
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, [regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32]);
  const handleonClick_node_ce438bd0_1be9_4c27_8a72_b1575769f627 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-014b3e3d-e3d2-4a96-91e1-863ecf77a2cb", false);
  }, [patchDesignerStore]);
  const handleonClick_node_87a9ca20_7c4c_4794_9502_3a8bd6b4bb88 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-1b34d765-157f-4185-a0e3-7d22b3515380", false);
  }, [patchDesignerStore]);
  const handleonClick_node_b4e8c281_9683_40c2_97f8_c0eb0462af38 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_ms992h0t_3kkv6 = true;
      try {
        const response = await designerFetch(("/api/base-info/" + encodeURIComponent(String(designerStore?.selection?.id)) + ""), {
          method: "DELETE",
          headers: { 'Content-Type': 'application/json' },
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_ms992h0t_3kkv6 = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_ms992h0t_3kkv6 = false;
      }
      if (mutationOk_da_ms992h0t_3kkv6) {
        patchDesignerStore("ui.visibility.node-1b34d765-157f-4185-a0e3-7d22b3515380", false);
        toast("Deleted", { variant: "success", timeout: 4000 });
        await refresh_gridData_heroui_app_table_grid_1785520943018_yqq7u();
      }
    })();
  }, [patchDesignerStore, refresh_gridData_heroui_app_table_grid_1785520943018_yqq7u]);
  return (
    <>
      <Toast.Provider />
      <div className="space-y-3">
        {mutationError ? (
          <div className="rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700">
            {mutationError}
          </div>
        ) : null}
        <div className="flex w-full flex-col gap-2"><div className="flex items-center justify-between gap-2 border-b border-slate-200 bg-white px-2 py-1.5"><div className="flex items-center gap-2"><input type="text" value={gridSearchInput_heroui_app_table_grid_1785520943018_yqq7u} onChange={(event) => handleGridSearchChange_heroui_app_table_grid_1785520943018_yqq7u(event.target.value)} placeholder={"Search languages…"} className="h-8 rounded-md border border-slate-200 px-2 text-sm" /></div><div className="flex items-center gap-2"><button type="button" onClick={() => { patchDesignerStore("selection.id", null); patchDesignerStore("ui.visibility.node-23017f4d-31df-40e1-8717-1467403af480", true); }} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700">Create language</button><button type="button" onClick={() => { void refresh_gridData_heroui_app_table_grid_1785520943018_yqq7u(); }} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 px-3 text-xs font-medium text-slate-700 hover:bg-slate-50">Refresh</button></div></div><AppTableGrid className="flex h-full min-h-0 w-full flex-1 flex-col" presentation="cards" cardBelow="phone" cardVariant="catalog" columns={gridColumns_heroui_app_table_grid_1785520943018_yqq7u} rows={gridPaging_heroui_app_table_grid_1785520943018_yqq7u.displayRows} getRowKey={(row) => String((row as Record<string, unknown>)["id"] ?? '')} enableColumnLayout={false} columnLayout={gridColumnLayout_heroui_app_table_grid_1785520943018_yqq7u} onColumnLayoutChange={setGridColumnLayout_heroui_app_table_grid_1785520943018_yqq7u} isLoading={false} loadingMessage={"Loading languages…"} emptyMessage={"No languages found."} isEmpty={gridFilteredRows_heroui_app_table_grid_1785520943018_yqq7u.length === 0} errorContent={gridFilteredRows_heroui_app_table_grid_1785520943018_yqq7u.length === 0 ? undefined : "Could not load languages."} gridQueryMode={"server"} query={gridQuery_heroui_app_table_grid_1785520943018_yqq7u} onQueryChange={handleGridQueryChange_heroui_app_table_grid_1785520943018_yqq7u} onGridRowAction={handleGridRowAction_heroui_app_table_grid_1785520943018_yqq7u} footer={<GridPagingFooter totalCount={gridTotalCount_heroui_app_table_grid_1785520943018_yqq7u} safePage={gridPaging_heroui_app_table_grid_1785520943018_yqq7u.safePage} pageSize={gridPageSize_heroui_app_table_grid_1785520943018_yqq7u} onPageSizeChange={handleGridPageSizeChange_heroui_app_table_grid_1785520943018_yqq7u} sortBy={gridQuery_heroui_app_table_grid_1785520943018_yqq7u.sort?.columnId ?? ''} sortOptions={[{"value":"title","label":"Title"},{"value":"shortName","label":"Short name"},{"value":"viewOrder","label":"Order"},{"value":"isActive","label":"Active"}]} onSortByChange={handleGridSortByChange_heroui_app_table_grid_1785520943018_yqq7u} sortDirection={gridQuery_heroui_app_table_grid_1785520943018_yqq7u.sort?.direction ?? 'asc'} onToggleSortDirection={handleGridToggleSortDirection_heroui_app_table_grid_1785520943018_yqq7u} showSortControls={false} totalPages={gridPaging_heroui_app_table_grid_1785520943018_yqq7u.totalPages} pageNumbers={buildDataGridPageNumbers(gridPaging_heroui_app_table_grid_1785520943018_yqq7u.safePage, gridPaging_heroui_app_table_grid_1785520943018_yqq7u.totalPages)} onPageChange={handleGridPageChange_heroui_app_table_grid_1785520943018_yqq7u} visibleInfiniteCount={gridListMode_heroui_app_table_grid_1785520943018_yqq7u === 'infinite' ? gridPaging_heroui_app_table_grid_1785520943018_yqq7u.displayRows.length : undefined} />} /></div>
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-23017f4d-31df-40e1-8717-1467403af480 === true) && (store.ui.visibility.node-23017f4d-31df-40e1-8717-1467403af480 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-23017f4d-31df-40e1-8717-1467403af480"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-23017f4d-31df-40e1-8717-1467403af480", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Create Language</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-23017f4d-31df-40e1-8717-1467403af480", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <form className="flex min-h-0 flex-col gap-0 overflow-hidden bg-white" method="post" data-designer-node-id="node-d641efb1-e03d-4f7f-b1f4-02dd0fc56872">
            <div className="flex flex-col gap-2 bg-white p-[15px]">
              <UiInput isRequired type="text" placeholder="Title" label="Title" size="sm" value={regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872?.title} name="node-dafedd58-7c9c-47ec-98f4-e06ad60e346d" />
              <UiInput isRequired type="text" placeholder="Short Name" label="Short Name" size="sm" value={regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872?.shortName} name="node-56dfb439-cf5f-4a6d-932a-c6da2948748d" />
              <UiInput type="number" placeholder="View Order" label="View Order" step={1} size="sm" value={regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872?.viewOrder} name="node-8c4ea843-48fd-4cf0-8ee4-3a5030b6aa32" />
              <Switch label="Is Active" aria-label="Is Active" size="md" isSelected={regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872?.isActive} name="node-d5ca1ca1-6d0a-402d-93d9-295acb4ec05c"><Switch.Control><Switch.Thumb /></Switch.Control></Switch>
              <UiInput isRequired className="hidden" readOnly type="text" placeholder="Parent Id" label="Parent Id" defaultValue={101.004} size="sm" value={regionData_vocabItems_node_d641efb1_e03d_4f7f_b1f4_02dd0fc56872?.parentId} name="node-5494ed18-5d8c-4d6c-a2ff-150e13b55957" />
            </div>
            <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" onClick={handleonClick_node_6d684f86_9720_4183_985a_914c8958e33f}>Cancel</Button>
              <Button type="submit" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" icon="Plus" variant="primary" size="md" href="#" target="_self" isDisabled={isSubmitting} onClick={handleonClick_node_c8dc13e0_4488_4d13_80be_f02e21c2de60}>Create Language</Button>
            </div>
          </form>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-014b3e3d-e3d2-4a96-91e1-863ecf77a2cb === true) && (store.ui.visibility.node-014b3e3d-e3d2-4a96-91e1-863ecf77a2cb !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-014b3e3d-e3d2-4a96-91e1-863ecf77a2cb"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-014b3e3d-e3d2-4a96-91e1-863ecf77a2cb", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Edit Language</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-014b3e3d-e3d2-4a96-91e1-863ecf77a2cb", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <form className="flex min-h-0 flex-col gap-0 overflow-hidden bg-white" method="post" data-designer-node-id="node-9d3f7cd5-44d3-4d76-952f-ac1a64520c32">
            <div className="flex flex-col gap-2 bg-white p-[15px]">
              <UiInput isRequired type="text" placeholder="Title" label="Title" size="sm" value={regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32?.title} name="node-c40e65d2-873b-4b30-90cb-4bd142efefa2" />
              <UiInput isRequired type="text" placeholder="Short Name" label="Short Name" size="sm" value={regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32?.shortName} name="node-2a5e8470-0cc2-4667-abe7-39845a2c15dd" />
              <UiInput type="number" placeholder="View Order" label="View Order" step={1} size="sm" value={regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32?.viewOrder} name="node-2ff96993-35f5-48fa-a7e1-567e5cbd01cc" />
              <Switch label="Is Active" aria-label="Is Active" size="md" isSelected={regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32?.isActive} name="node-814a86a9-7395-4279-92f9-0cd0aea52d7b"><Switch.Control><Switch.Thumb /></Switch.Control></Switch>
              <UiInput isRequired type="text" placeholder="Parent Id" label="Parent Id" size="sm" value={regionData_vocabItems_node_9d3f7cd5_44d3_4d76_952f_ac1a64520c32?.parentId} name="node-34dec69d-8c6a-4c37-aebb-eb5f02f2f5cd" />
            </div>
            <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" onClick={handleonClick_node_ce438bd0_1be9_4c27_8a72_b1575769f627}>Cancel</Button>
              <Button type="submit" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" icon="Save" variant="primary" size="md" href="#" target="_self" isDisabled={isSubmitting} onClick={handleonClick_node_e012f2f8_72ff_40fd_9db8_1207b4e192c1}>Save</Button>
            </div>
          </form>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-1b34d765-157f-4185-a0e3-7d22b3515380 === true) && (store.ui.visibility.node-1b34d765-157f-4185-a0e3-7d22b3515380 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-1b34d765-157f-4185-a0e3-7d22b3515380"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-1b34d765-157f-4185-a0e3-7d22b3515380", false); } }} variant="blur"><Modal.Container><Modal.Dialog role="alertdialog" className="w-full max-w-md overflow-hidden rounded-xl border border-rose-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-rose-200 bg-rose-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-rose-800">Delete Language?</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-1b34d765-157f-4185-a0e3-7d22b3515380", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <p className="block bg-white p-[15px] text-sm text-slate-700">Delete this language? This cannot be undone.</p>
          <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
            <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_node_87a9ca20_7c4c_4794_9502_3a8bd6b4bb88}>Cancel</Button>
            <Button icon="Trash2" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-rose-600 px-3 text-xs font-semibold text-white hover:bg-rose-700" variant="primary" size="md" href="#" target="_self" onClick={handleonClick_node_b4e8c281_9683_40c2_97f8_c0eb0462af38}>Delete</Button>
          </div>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
      </div>
    </>
  );
};
export default GeneratedComponent;
