SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF COL_LENGTH(N'dbo.hwy_members', N'second_referrer_relation_id') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_members ADD second_referrer_relation_id INT NULL;
END;
GO

IF OBJECT_ID(N'dbo.hwy_member_kasb_links', N'U') IS NOT NULL
BEGIN
  UPDATE m
  SET
    second_referrer_username = COALESCE(NULLIF(LTRIM(RTRIM(m.second_referrer_username)), N''), k.kasb_username),
    second_referrer_relation_id = COALESCE(m.second_referrer_relation_id, k.referrer_relation_id)
  FROM dbo.hwy_members m
  INNER JOIN (
    SELECT member_id, kasb_username, referrer_relation_id,
      ROW_NUMBER() OVER (PARTITION BY member_id ORDER BY id DESC) AS rn
    FROM dbo.hwy_member_kasb_links
  ) k ON k.member_id = m.id AND k.rn = 1;

  DROP TABLE dbo.hwy_member_kasb_links;
END;
GO
