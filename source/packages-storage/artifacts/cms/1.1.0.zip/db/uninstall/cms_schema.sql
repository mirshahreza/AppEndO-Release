-- CMS package Phase 1 uninstall (SQL Server / T-SQL)
DROP TABLE IF EXISTS cms_comments;
DROP TABLE IF EXISTS cms_settings;
DROP TABLE IF EXISTS cms_content_relations;
DROP TABLE IF EXISTS cms_content_tags;
DROP TABLE IF EXISTS cms_content_assets;
DROP TABLE IF EXISTS cms_content_revisions;
DROP TABLE IF EXISTS cms_contents;
