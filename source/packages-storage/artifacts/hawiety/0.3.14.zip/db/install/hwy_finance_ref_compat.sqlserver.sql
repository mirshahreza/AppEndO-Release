-- Drop PascalCase computed alias columns on finance / ref tables (snake_case physical only).

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

DECLARE @drop TABLE (object_name SYSNAME, column_name SYSNAME);
INSERT INTO @drop (object_name, column_name)
VALUES
  (N'hwy_ref_base_information', N'ViewOrder'),
  (N'hwy_ref_base_information', N'ParentId'),
  (N'hwy_masoolin_stars', N'MemberId'),
  (N'hwy_masoolin_stars', N'CalcYear'),
  (N'hwy_masoolin_stars', N'CalcMonth'),
  (N'hwy_masoolin_stars', N'StarCode'),
  (N'hwy_masoolin_stars', N'StarValue'),
  (N'hwy_masoolin_stars_overal', N'MemberId'),
  (N'hwy_masoolin_stars_overal', N'CalcYear'),
  (N'hwy_masoolin_stars_overal', N'CalcMonth'),
  (N'hwy_masoolin_stars_overal', N'StarsSum'),
  (N'hwy_masoolin_stars_overal', N'LevelId'),
  (N'hwy_masoolin_stars_current', N'MemberId'),
  (N'hwy_masoolin_stars_current', N'CalcYear'),
  (N'hwy_masoolin_stars_current', N'CalcMonth'),
  (N'hwy_masoolin_stars_current', N'StarCode'),
  (N'hwy_masoolin_stars_current', N'StarValue'),
  (N'hwy_members', N'MasooliatLevelId'),
  (N'hwy_members', N'AreaLimitProvinceId'),
  (N'hwy_members', N'AreaLimitCircleId'),
  (N'hwy_members', N'AreaLimitTamvinId'),
  (N'hwy_members', N'Stat_FieldsCompleted');

DECLARE @object_name SYSNAME;
DECLARE @column_name SYSNAME;
DECLARE @sql NVARCHAR(500);

DECLARE c CURSOR LOCAL FAST_FORWARD FOR
  SELECT object_name, column_name FROM @drop;

OPEN c;
FETCH NEXT FROM c INTO @object_name, @column_name;
WHILE @@FETCH_STATUS = 0
BEGIN
  IF OBJECT_ID(N'dbo.' + @object_name, N'U') IS NOT NULL
     AND COL_LENGTH(N'dbo.' + @object_name, @column_name) IS NOT NULL
  BEGIN
    SET @sql = N'ALTER TABLE dbo.' + QUOTENAME(@object_name) + N' DROP COLUMN ' + QUOTENAME(@column_name) + N';';
    BEGIN TRY
      EXEC sp_executesql @sql;
    END TRY
    BEGIN CATCH
      IF ERROR_NUMBER() NOT IN (4924, 5074)
        THROW;
    END CATCH;
  END;
  FETCH NEXT FROM c INTO @object_name, @column_name;
END;
CLOSE c;
DEALLOCATE c;

PRINT 'hwy_finance_ref_compat — Pascal computed aliases dropped';
GO
