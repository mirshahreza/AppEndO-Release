import React from 'react';
import { useNavigate } from 'react-router-dom';
import { buildAppTableGridColumns } from '@/domain/component-designer/DesignerRuntimeAppTableGrid';
import { applyClientGridQuery, EMPTY_GRID_QUERY, type GridQueryState } from '@/shared/lib/appTableGridQuery';
import { resolveDataGridTotalCount, sliceDataGridRowsForDisplay, buildDataGridPageNumbers } from '@/domain/component-designer/designerDataGridRuntime';
import { applyDesignerGridToolbarClientFilters } from '@/domain/component-designer/designerGridToolbarConfig';
import { createDefaultColumnLayout } from '@/shared/lib/appTableGridColumnLayout';
import { AppTableGrid, GridPagingFooter } from '@/shared/ui';
import { UiSelect } from '@/shared/ui/HeroFieldControls';
import { Button, Modal, Toast, toast } from '@heroui/react';

const parseApiErrorMessage = async (response: Response): Promise<string> => {
  try {
    const payload = await response.json();
    if (payload && typeof payload === "object") {
      const record = payload as Record<string, unknown>;
      const message = record.message ?? record.error ?? record.detail;
      if (typeof message === "string" && message.trim().length > 0) {
        return message.trim();
      }
    }
  } catch {
    // fall through to status text
  }
  return response.statusText || `Request failed (${response.status})`;
};

const readBindingParamValue = (
  context: Record<string, unknown> | null | undefined,
  dataPath: string,
): unknown => {
  const segments = dataPath.split(".").map((segment) => segment.trim()).filter(Boolean);
  let cursor: unknown = context;
  for (const segment of segments) {
    if (cursor && typeof cursor === "object" && segment in (cursor as Record<string, unknown>)) {
      cursor = (cursor as Record<string, unknown>)[segment];
    } else {
      return undefined;
    }
  }
  return cursor;
};

const resolveBindingTemplateValue = (
  template: string,
  context: Record<string, unknown> | null | undefined,
  paramPaths: Record<string, string>,
): string =>
  template.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, paramName: string) => {
    const dataPath = paramPaths[paramName];
    if (!dataPath) {
      return "";
    }
    const cursor = readBindingParamValue(context, dataPath);
    return cursor === undefined || cursor === null ? "" : String(cursor);
  });

const resolveBindingUrl = (
  endpointTemplate: string,
  context: Record<string, unknown> | null | undefined,
  paramPaths: Record<string, string>,
): string => {
  const usedParamNames = new Set<string>();
  let resolvedPath = endpointTemplate.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, paramName: string) => {
    usedParamNames.add(paramName);
    const dataPath = paramPaths[paramName];
    if (!dataPath) {
      return "";
    }
    const cursor = readBindingParamValue(context, dataPath);
    return cursor === undefined || cursor === null ? "" : String(cursor);
  });
  for (const [paramName, dataPath] of Object.entries(paramPaths)) {
    if (usedParamNames.has(paramName)) {
      continue;
    }
    const colonParamPattern = new RegExp(`:${paramName}(?=/|$)`, "g");
    if (!colonParamPattern.test(resolvedPath)) {
      continue;
    }
    usedParamNames.add(paramName);
    const cursor = readBindingParamValue(context, dataPath);
    const text = cursor === undefined || cursor === null ? "" : String(cursor);
    resolvedPath = resolvedPath.replace(new RegExp(`:${paramName}(?=/|$)`, "g"), text);
  }
  const searchParams = new URLSearchParams();
  for (const [paramName, dataPath] of Object.entries(paramPaths)) {
    if (usedParamNames.has(paramName)) {
      continue;
    }
    const cursor = readBindingParamValue(context, dataPath);
    if (cursor === undefined || cursor === null) {
      continue;
    }
    const text = String(cursor).trim();
    if (text.length === 0) {
      continue;
    }
    searchParams.set(paramName, text);
  }
  const queryString = searchParams.toString();
  if (!queryString) {
    return resolvedPath;
  }
  return resolvedPath.includes("?") ? `${resolvedPath}&${queryString}` : `${resolvedPath}?${queryString}`;
};

const resolveBindingHeaders = (
  context: Record<string, unknown> | null | undefined,
  headerTemplates: Record<string, string>,
  paramPaths: Record<string, string>,
): Record<string, string> =>
  Object.fromEntries(
    Object.entries(headerTemplates).map(([key, template]) => [
      key,
      resolveBindingTemplateValue(template, context, paramPaths),
    ]),
  );

const setNestedPayloadValue = (target: Record<string, unknown>, path: string, value: unknown): void => {
  const segments = path.split(".").map((segment) => segment.trim()).filter(Boolean);
  if (segments.length === 0) {
    return;
  }
  let cursor: Record<string, unknown> = target;
  for (let index = 0; index < segments.length - 1; index += 1) {
    const segment = segments[index];
    const next = cursor[segment];
    if (!next || typeof next !== "object" || Array.isArray(next)) {
      cursor[segment] = {};
    }
    cursor = cursor[segment] as Record<string, unknown>;
  }
  cursor[segments[segments.length - 1]] = value;
};

const mapDesignerListBoxItems = (rawItems: unknown): Array<{ id: string; textValue: string }> => {
  const items = Array.isArray(rawItems) ? rawItems : [];
  return items
    .map((entry) => {
      if (!entry || typeof entry !== "object") {
        return null;
      }
      const record = entry as Record<string, unknown>;
      const id = String(record.id ?? "").trim();
      if (!id || id === "100" || id === "102") {
        return null;
      }
      const textValue = String(record.textValue ?? record.label ?? record.title ?? id).trim();
      return { id, textValue: textValue || id };
    })
    .filter((entry): entry is { id: string; textValue: string } => entry !== null);
};

const mapDesignerLovItems = (
  rawItems: unknown,
  returnColumn: string,
  displayColumn: string,
): Array<{ id: string; textValue: string }> => {
  const items = Array.isArray(rawItems) ? rawItems : [];
  return items
    .map((entry) => {
      if (!entry || typeof entry !== "object") {
        return null;
      }
      const record = entry as Record<string, unknown>;
      const id = String(record[returnColumn] ?? "").trim();
      if (!id) {
        return null;
      }
      const textValue = String(record[displayColumn] ?? id).trim();
      return { id, textValue: textValue || id };
    })
    .filter((entry): entry is { id: string; textValue: string } => entry !== null);
};

const collectRegionFormDataFromContainer = (
  container: ParentNode,
  formFieldNames: readonly string[],
): FormData => {
  const formData = new FormData();
  for (const formFieldName of formFieldNames) {
    const escapedName = formFieldName.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    const field = container.querySelector(`[name="${escapedName}"]`);
    if (!field) {
      continue;
    }
    if (field instanceof HTMLInputElement) {
      if (field.type === "checkbox" || field.type === "radio") {
        formData.set(formFieldName, field.checked ? "true" : "false");
      } else {
        formData.set(formFieldName, field.value);
      }
      continue;
    }
    if (field instanceof HTMLTextAreaElement || field instanceof HTMLSelectElement) {
      formData.set(formFieldName, field.value);
      continue;
    }
    formData.set(formFieldName, field.getAttribute("value") ?? "");
  }
  return formData;
};

const applyPayloadFieldTransform = (value: FormDataEntryValue | null, transform?: string): unknown => {
  const raw = value === null ? "" : String(value);
  switch (transform) {
    case "number": {
      const parsed = Number(raw);
      return Number.isFinite(parsed) ? parsed : raw;
    }
    case "boolean":
      return raw === "true" || raw === "1" || raw === "on";
    case "commaSeparatedArray":
      return raw.split(",").map((entry) => entry.trim()).filter(Boolean);
    default:
      return raw;
  }
};

// --- AUTH / TOKEN LIFECYCLE INJECTION POINT ---
// Register your application-wide 401 interceptor and token refresh handler here before production.
// Example: const designerFetch = createAuthenticatedFetch({ getAccessToken, refreshTokens, onSessionExpired });
const designerFetch: typeof fetch = fetch;

function useDataFetch<T>(url: string, options: { headers?: Record<string, string> } = {}) {
  const [data, setData] = React.useState<T | null>(null);
  const [isLoading, setIsLoading] = React.useState(Boolean(url));
  const [error, setError] = React.useState<string | null>(null);
  const [refreshNonce, setRefreshNonce] = React.useState(0);
  const headersKey = JSON.stringify(options.headers ?? {});

  const refresh = React.useCallback(async () => {
    setRefreshNonce((previous) => previous + 1);
  }, []);

  React.useEffect(() => {
    if (!url) {
      setData(null);
      setIsLoading(false);
      setError(null);
      return undefined;
    }

    let cancelled = false;
    const load = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const response = await designerFetch(url, {
          method: "GET",
          headers: options.headers,
        });
        if (!response.ok) {
          throw new Error(await parseApiErrorMessage(response));
        }
        const payload = (await response.json()) as T;
        if (!cancelled) {
          setData(payload);
        }
      } catch (loadError) {
        if (!cancelled) {
          setData(null);
          setError(loadError instanceof Error ? loadError.message : "Request failed");
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, [url, headersKey, refreshNonce]);

  return { data, isLoading, error, refresh };
}

const readNestedContextValue = (
  context: Record<string, unknown> | null | undefined,
  path: string,
): unknown => {
  const segments = path.split(".").map((segment) => segment.trim()).filter(Boolean);
  let cursor: unknown = context;
  for (const segment of segments) {
    if (cursor && typeof cursor === "object" && segment in (cursor as Record<string, unknown>)) {
      cursor = (cursor as Record<string, unknown>)[segment];
    } else {
      return undefined;
    }
  }
  return cursor;
};

const applyResponseDataPath = (
  payload: unknown,
  responseMapping?: { dataPath?: string; arrayPath?: string },
): unknown => {
  if (!responseMapping) {
    return payload;
  }
  const arrayPath = responseMapping.arrayPath?.trim();
  if (arrayPath) {
    const arrayValue = readNestedContextValue(
      payload && typeof payload === "object" ? payload as Record<string, unknown> : {},
      arrayPath,
    );
    if (Array.isArray(arrayValue)) {
      return arrayValue;
    }
  }
  const dataPath = responseMapping.dataPath?.trim();
  if (!dataPath || !payload || typeof payload !== "object") {
    return payload;
  }
  return readNestedContextValue(payload as Record<string, unknown>, dataPath);
};

const coerceApiRecordValue = (value: unknown): Record<string, unknown> | undefined => {
  if (value === undefined || value === null) {
    return undefined;
  }
  if (Array.isArray(value)) {
    return value.find(
      (entry): entry is Record<string, unknown> =>
        typeof entry === "object" && entry !== null && !Array.isArray(entry),
    );
  }
  if (typeof value === "object") {
    return value as Record<string, unknown>;
  }
  return undefined;
};

const transformApiRowsToChartData = (
  rows: Array<Record<string, unknown>>,
  mapping: { categoryField: string; categoryAs?: string; series: Array<{ apiField: string; seriesKey: string; aggregation?: string }> },
): Array<Record<string, string | number>> => {
  const categoryKey = mapping.categoryAs?.trim() || "label";
  const parseNum = (raw: unknown): number => {
    if (typeof raw === "number" && Number.isFinite(raw)) return raw;
    if (typeof raw === "string") { const p = Number(raw); return Number.isFinite(p) ? p : 0; }
    return 0;
  };
  const aggregate = (values: number[], agg: string): number => {
    if (values.length === 0) return 0;
    if (agg === "count") return values.length;
    if (agg === "avg") return values.reduce((s, v) => s + v, 0) / values.length;
    if (agg === "min") return Math.min(...values);
    if (agg === "max") return Math.max(...values);
    if (agg === "sum") return values.reduce((s, v) => s + v, 0);
    return values[0] ?? 0;
  };
  const needsGrouping = mapping.series.some((s) => s.aggregation && s.aggregation !== "none");
  if (!needsGrouping) {
    return rows.map((row) => {
      const chartRow: Record<string, string | number> = { [categoryKey]: String(row[mapping.categoryField] ?? "") };
      for (const series of mapping.series) { chartRow[series.seriesKey] = parseNum(row[series.apiField]); }
      return chartRow;
    });
  }
  const grouped = new Map<string, Array<Record<string, unknown>>>();
  for (const row of rows) {
    const cat = String(row[mapping.categoryField] ?? "");
    const bucket = grouped.get(cat);
    if (bucket) bucket.push(row); else grouped.set(cat, [row]);
  }
  return Array.from(grouped.entries()).map(([category, groupRows]) => {
    const chartRow: Record<string, string | number> = { [categoryKey]: category };
    for (const series of mapping.series) {
      const values = groupRows.map((r) => parseNum(r[series.apiField]));
      chartRow[series.seriesKey] = aggregate(values, series.aggregation ?? "sum");
    }
    return chartRow;
  });
};

const readVizStringField = (row: Record<string, unknown>, field: string, fallback = ""): string => {
  const value = row[field];
  if (value === undefined || value === null) return fallback;
  return String(value);
};

const transformApiRowsToTreeNodes = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "tree"; idField: string; labelField: string; parentIdField?: string },
): Array<{ id: string; label: string; children?: unknown[] }> => {
  const parentField = mapping.parentIdField?.trim();
  if (!parentField) {
    return rows.map((row, index) => ({
      id: readVizStringField(row, mapping.idField, `node-${index + 1}`),
      label: readVizStringField(row, mapping.labelField, `Item ${index + 1}`),
    }));
  }
  const nodeMap = new Map<string, { id: string; label: string; children: unknown[] }>();
  rows.forEach((row) => {
    const id = readVizStringField(row, mapping.idField);
    if (!id) return;
    nodeMap.set(id, { id, label: readVizStringField(row, mapping.labelField, id), children: [] });
  });
  const roots: Array<{ id: string; label: string; children?: unknown[] }> = [];
  rows.forEach((row) => {
    const id = readVizStringField(row, mapping.idField);
    if (!id) return;
    const node = nodeMap.get(id);
    if (!node) return;
    const parentId = readVizStringField(row, parentField);
    if (parentId && nodeMap.has(parentId)) {
      nodeMap.get(parentId)!.children.push(node);
    } else {
      roots.push(node);
    }
  });
  return roots;
};

const readVizNumberField = (row: Record<string, unknown>, field: string): number | undefined => {
  const value = row[field];
  const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(parsed) ? parsed : undefined;
};

const transformApiRowsToTimelineEvents = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "timeline" | "gantt"; idField?: string; titleField: string; startField: string; endField?: string; descriptionField?: string; progressField?: string },
): Array<{ id?: string; title: string; start: string; end?: string; description?: string; progress?: number }> =>
  rows.map((row, index) => {
    const progress = mapping.progressField ? readVizNumberField(row, mapping.progressField) : undefined;
    return {
      id: mapping.idField ? readVizStringField(row, mapping.idField, `evt-${index + 1}`) : `evt-${index + 1}`,
      title: readVizStringField(row, mapping.titleField, `Event ${index + 1}`),
      start: readVizStringField(row, mapping.startField),
      ...(mapping.endField ? { end: readVizStringField(row, mapping.endField) } : {}),
      ...(mapping.descriptionField ? { description: readVizStringField(row, mapping.descriptionField) } : {}),
      ...(progress !== undefined ? { progress } : {}),
    };
  });

const transformApiRowsToKanbanBoard = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "kanban"; cardIdField: string; cardTitleField: string; cardDescriptionField?: string; cardColumnField: string; columnOrder?: Array<{ id: string; title: string }> },
): { columns: Array<{ id: string; title: string; cards: Array<{ id: string; title: string; description?: string }> }> } => {
  const cardsByColumn = new Map<string, Array<{ id: string; title: string; description?: string }>>();
  rows.forEach((row, index) => {
    const columnKey = readVizStringField(row, mapping.cardColumnField, "default");
    const card = {
      id: readVizStringField(row, mapping.cardIdField, `card-${index + 1}`),
      title: readVizStringField(row, mapping.cardTitleField, `Card ${index + 1}`),
      ...(mapping.cardDescriptionField ? { description: readVizStringField(row, mapping.cardDescriptionField) } : {}),
    };
    cardsByColumn.set(columnKey, [...(cardsByColumn.get(columnKey) ?? []), card]);
  });
  const columnOrder = mapping.columnOrder && mapping.columnOrder.length > 0
    ? mapping.columnOrder
    : Array.from(cardsByColumn.keys()).map((key) => ({ id: key, title: key }));
  const columns = columnOrder.map((columnDef) => ({
    id: columnDef.id,
    title: columnDef.title,
    cards: cardsByColumn.get(columnDef.id) ?? cardsByColumn.get(columnDef.title) ?? [],
  }));
  cardsByColumn.forEach((cards, columnKey) => {
    if (!columns.some((column) => column.id === columnKey || column.title === columnKey)) {
      columns.push({ id: columnKey, title: columnKey, cards });
    }
  });
  return { columns };
};

const transformApiRowsToSheetData = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "sheet"; columns: Array<{ header: string; field: string }> },
): { columns: string[]; rows: string[][] } => ({
  columns: mapping.columns.map((column) => column.header),
  rows: rows.map((row) => mapping.columns.map((column) => readVizStringField(row, column.field))),
});

type EntityPickerOption = { id: string; textValue: string };
type EntityPickerFieldMapping = { returnField: string; displayField: string };

function normalizeEntityPickerItems(payload: unknown, mapping?: EntityPickerFieldMapping): EntityPickerOption[] {
  const returnField = mapping?.returnField?.trim() || "id";
  const displayField = mapping?.displayField?.trim() || "label";
  if (Array.isArray(payload)) {
    return payload
      .map((entry) => {
        if (!entry || typeof entry !== "object") {
          return null;
        }
        const record = entry as Record<string, unknown>;
        const mappedId = record[returnField];
        const id = typeof mappedId === "string" && mappedId.trim()
          ? mappedId.trim()
          : typeof record.id === "string" && record.id.trim()
            ? record.id.trim()
            : typeof record.value === "string" && record.value.trim()
              ? record.value.trim()
              : "";
        const mappedLabel = record[displayField];
        const textValue = typeof mappedLabel === "string" && mappedLabel.trim()
          ? mappedLabel.trim()
          : typeof record.textValue === "string" && record.textValue.trim()
            ? record.textValue.trim()
            : typeof record.label === "string" && record.label.trim()
              ? record.label.trim()
              : typeof record.name === "string" && record.name.trim()
                ? record.name.trim()
                : id;
        if (!id || !textValue) {
          return null;
        }
        return { id, textValue };
      })
      .filter((entry): entry is EntityPickerOption => entry !== null);
  }

  if (payload && typeof payload === "object") {
    const record = payload as Record<string, unknown>;
    const items = record.items ?? record.results ?? record.data;
    return normalizeEntityPickerItems(items, mapping);
  }

  return [];
}

function useEntityPickerOptions(entityRef: string, searchParam: string, mapping?: EntityPickerFieldMapping) {
  const [items, setItems] = React.useState<EntityPickerOption[]>([]);
  const [isLoading, setIsLoading] = React.useState(false);

  const loadOptions = React.useCallback(async (query: string) => {
    if (!entityRef) {
      setItems([]);
      return;
    }

    setIsLoading(true);
    try {
      const url = entityRef.startsWith("http")
        ? new URL(entityRef)
        : new URL(entityRef, window.location.origin);
      // Option A (parity audit items 31/32): Autocomplete is Select-based — no live typing.
      // Still honour an explicit non-empty query if a caller passes one, but initial load uses "".
      if (query.trim()) {
        url.searchParams.set(searchParam, query);
      }
      const response = await fetch(url.toString());
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      const payload = await response.json();
      setItems(normalizeEntityPickerItems(payload, mapping));
    } catch {
      setItems([]);
    } finally {
      setIsLoading(false);
    }
  }, [entityRef, searchParam, mapping?.returnField, mapping?.displayField]);

  React.useEffect(() => {
    void loadOptions("");
  }, [loadOptions]);

  return { items, isLoading, loadOptions };
}
function useDesignerStore<T extends Record<string, unknown>>(initial: T) {
  const [store, setStore] = React.useState<T>(initial);
  const patch = React.useCallback((path: string, value: unknown) => {
    setStore((previous) => {
      const next = { ...previous };
      setNestedPayloadValue(next, path, value);
      return next as T;
    });
  }, []);
  return { store, patch };
}
function evaluateDesignerCondition(
  designerStore: Record<string, unknown>,
  dataContext: Record<string, unknown> | null,
  scope: { item?: unknown; index?: number },
  condition: string,
): boolean {
  const trimmed = condition.trim();
  if (!trimmed) {
    return true;
  }
  try {
    const formatPathChain = (root: string, path: string): string => {
      const chain = path
        .split('.')
        .filter(Boolean)
        .map((segment) => {
          if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(segment)) {
            return `?.${segment}`;
          }
          return `?.[${JSON.stringify(segment)}]`;
        })
        .join('');
      return `(${root}${chain})`;
    };
    let compiled = trimmed
      .replace(/\bstore\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('designerStore', path))
      .replace(/\bdata\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('dataContext', path))
      .replace(/\bdataContext\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('dataContext', path));
    const evaluator = new Function('designerStore', 'dataContext', 'item', 'index', `return Boolean(${compiled});`);
    return Boolean(evaluator(designerStore, dataContext, scope.item, scope.index));
  } catch {
    return false;
  }
}

export const GeneratedComponent: React.FC = () => {
  const navigate = useNavigate();
  const { store: designerStore, patch: patchDesignerStore } = useDesignerStore<Record<string, unknown>>({"selection":{"id":null}});
  const handleGridRowAction_heroui_app_table_grid_1785520939402_2gu1c = React.useCallback((row: Record<string, unknown>, actionId: string) => {
    switch (actionId) {
      case "edit": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        navigate(("/studio/cms/contents/edit/" + encodeURIComponent(String(designerStore?.selection?.id ?? ''))), { replace: false });
        return;
      }
      case "revisions": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.heroui-modal-1785520939387-u0dar", true);
        return;
      }
      case "comments": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.heroui-modal-1785520939394-ig434", true);
        return;
      }
      case "archive": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-4e676c0a-096b-41e9-be18-f03246f4f4b6", true);
        return;
      }
      case "delete": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-dfd12d6e-29e9-41db-a93f-32574afec1f5", true);
        return;
      }
      default:
        return;
    }
  }, [patchDesignerStore, navigate]);
  const { data: raw_gridData_heroui_app_table_grid_1785520939390_fj2y4, isLoading: isLoading_gridData_heroui_app_table_grid_1785520939390_fj2y4, error: error_gridData_heroui_app_table_grid_1785520939390_fj2y4, refresh: refresh_gridData_heroui_app_table_grid_1785520939390_fj2y4 } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/revisions", designerStore, { "filter[contentId]": "selection.id" }), {});
  const gridData_heroui_app_table_grid_1785520939390_fj2y4 = React.useMemo(() => applyResponseDataPath(raw_gridData_heroui_app_table_grid_1785520939390_fj2y4, {"dataPath":"data","arrayPath":"data","totalPath":"count"}), [raw_gridData_heroui_app_table_grid_1785520939390_fj2y4]);
  const { data: raw_gridData_heroui_app_table_grid_1785520939398_1odjv, isLoading: isLoading_gridData_heroui_app_table_grid_1785520939398_1odjv, error: error_gridData_heroui_app_table_grid_1785520939398_1odjv, refresh: refresh_gridData_heroui_app_table_grid_1785520939398_1odjv } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/comments", designerStore, { "filter[contentId]": "selection.id" }), {});
  const gridData_heroui_app_table_grid_1785520939398_1odjv = React.useMemo(() => applyResponseDataPath(raw_gridData_heroui_app_table_grid_1785520939398_1odjv, {"dataPath":"data","arrayPath":"data","totalPath":"count"}), [raw_gridData_heroui_app_table_grid_1785520939398_1odjv]);
  const { data: raw_gridData_heroui_app_table_grid_1785520939402_2gu1c, isLoading: isLoading_gridData_heroui_app_table_grid_1785520939402_2gu1c, error: error_gridData_heroui_app_table_grid_1785520939402_2gu1c, refresh: refresh_gridData_heroui_app_table_grid_1785520939402_2gu1c } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/contents", designerStore, { "search": "gridToolbar.search", "sortBy": "gridQuery.sortBy", "sortDir": "gridQuery.sortDir", "page": "gridQuery.page", "pageSize": "gridQuery.pageSize", "title": "gridQuery.filters.title", "slug": "gridQuery.filters.slug", "publishedAtFrom": "gridQuery.filters.publishedAt.from", "publishedAtTo": "gridQuery.filters.publishedAt.to", "updatedAtFrom": "gridQuery.filters.updatedAt.from", "updatedAtTo": "gridQuery.filters.updatedAt.to", "view": "static:summary" }), {});
  const gridData_heroui_app_table_grid_1785520939402_2gu1c = React.useMemo(() => applyResponseDataPath(raw_gridData_heroui_app_table_grid_1785520939402_2gu1c, {"dataPath":"data","arrayPath":"data","totalPath":"count"}), [raw_gridData_heroui_app_table_grid_1785520939402_2gu1c]);
  const gridColumns_heroui_app_table_grid_1785520939390_fj2y4 = React.useMemo(() => buildAppTableGridColumns([{"key":"revisionNo","label":"#","sort":true},{"key":"title","label":"Title"},{"key":"summary","label":"Summary"},{"key":"body","label":"Body"}], "client", {
    mode: 'runtime',
    detailFlowRef: { current: null },
    rowActionHandlerRef: { current: undefined },
    cellClickHandlerRef: { current: undefined },
    designerStoreRef: { current: designerStore },
  }), [designerStore]);
  const [gridQuery_heroui_app_table_grid_1785520939390_fj2y4, setGridQuery_heroui_app_table_grid_1785520939390_fj2y4] = React.useState<GridQueryState>(() => ({ ...EMPTY_GRID_QUERY, sort: { columnId: "revisionNo", direction: 'asc' } }));
  const [gridPage_heroui_app_table_grid_1785520939390_fj2y4, setGridPage_heroui_app_table_grid_1785520939390_fj2y4] = React.useState(1);
  const [gridPageSize_heroui_app_table_grid_1785520939390_fj2y4, setGridPageSize_heroui_app_table_grid_1785520939390_fj2y4] = React.useState(50);
  const [gridListMode_heroui_app_table_grid_1785520939390_fj2y4, setGridListMode_heroui_app_table_grid_1785520939390_fj2y4] = React.useState<'paging' | 'infinite'>("paging");
  const [gridColumnLayout_heroui_app_table_grid_1785520939390_fj2y4, setGridColumnLayout_heroui_app_table_grid_1785520939390_fj2y4] = React.useState(() => createDefaultColumnLayout(gridColumns_heroui_app_table_grid_1785520939390_fj2y4));
  const gridFilteredRows_heroui_app_table_grid_1785520939390_fj2y4 = React.useMemo(() => applyClientGridQuery(((Array.isArray(gridData_heroui_app_table_grid_1785520939390_fj2y4?.data) ? gridData_heroui_app_table_grid_1785520939390_fj2y4?.data : []) ?? []), gridQuery_heroui_app_table_grid_1785520939390_fj2y4, gridColumns_heroui_app_table_grid_1785520939390_fj2y4, "client"), [gridQuery_heroui_app_table_grid_1785520939390_fj2y4, gridColumns_heroui_app_table_grid_1785520939390_fj2y4]);
  const gridApiTotal_heroui_app_table_grid_1785520939390_fj2y4 = React.useMemo(() => {
    const raw = raw_gridData_heroui_app_table_grid_1785520939390_fj2y4;
    const value = readNestedContextValue((raw && typeof raw === 'object' ? raw as Record<string, unknown> : {}), "count");
    const parsed = typeof value === 'number' ? value : Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : 0;
  }, [raw_gridData_heroui_app_table_grid_1785520939390_fj2y4]);
  const gridTotalCount_heroui_app_table_grid_1785520939390_fj2y4 = resolveDataGridTotalCount({ page: gridPage_heroui_app_table_grid_1785520939390_fj2y4, pageSize: gridPageSize_heroui_app_table_grid_1785520939390_fj2y4, total: gridApiTotal_heroui_app_table_grid_1785520939390_fj2y4, gridQueryMode: "client" }, gridFilteredRows_heroui_app_table_grid_1785520939390_fj2y4.length);
  const gridPaging_heroui_app_table_grid_1785520939390_fj2y4 = sliceDataGridRowsForDisplay(gridFilteredRows_heroui_app_table_grid_1785520939390_fj2y4, gridPage_heroui_app_table_grid_1785520939390_fj2y4, gridPageSize_heroui_app_table_grid_1785520939390_fj2y4, gridTotalCount_heroui_app_table_grid_1785520939390_fj2y4, "client");
  const handleGridQueryChange_heroui_app_table_grid_1785520939390_fj2y4 = React.useCallback((nextQuery: GridQueryState) => {
    setGridQuery_heroui_app_table_grid_1785520939390_fj2y4(nextQuery);
    setGridPage_heroui_app_table_grid_1785520939390_fj2y4(1);
  }, [patchDesignerStore]);
  const handleGridPageChange_heroui_app_table_grid_1785520939390_fj2y4 = React.useCallback((nextPage: number) => {
    setGridPage_heroui_app_table_grid_1785520939390_fj2y4(nextPage);
  }, [patchDesignerStore]);
  const handleGridPageSizeChange_heroui_app_table_grid_1785520939390_fj2y4 = React.useCallback((nextSize: number) => {
    setGridPageSize_heroui_app_table_grid_1785520939390_fj2y4(nextSize);
    setGridPage_heroui_app_table_grid_1785520939390_fj2y4(1);
  }, [patchDesignerStore]);
  const handleGridSortByChange_heroui_app_table_grid_1785520939390_fj2y4 = React.useCallback((nextSortBy: string) => {
    setGridQuery_heroui_app_table_grid_1785520939390_fj2y4((current: GridQueryState) => ({ ...current, sort: nextSortBy ? { columnId: nextSortBy, direction: current.sort?.direction ?? 'asc' } : null }));
  }, []);
  const handleGridToggleSortDirection_heroui_app_table_grid_1785520939390_fj2y4 = React.useCallback(() => {
    setGridQuery_heroui_app_table_grid_1785520939390_fj2y4((current: GridQueryState) => (current.sort ? { ...current, sort: { ...current.sort, direction: current.sort.direction === 'asc' ? 'desc' : 'asc' } } : current));
  }, []);

  const gridColumns_heroui_app_table_grid_1785520939398_1odjv = React.useMemo(() => buildAppTableGridColumns([{"key":"authorDisplayName","label":"Author","sort":true},{"key":"body","label":"Comment"},{"key":"statusCode","label":"Status","cellKind":"status-badge","cellFields":{"labelField":"statusCodeTitle","labelFallbackField":"statusCode","htmlField":"statusCodeUiHtml"}},{"key":"createdAt","label":"Submitted","sort":true,"cellKind":"date"}], "client", {
    mode: 'runtime',
    detailFlowRef: { current: null },
    rowActionHandlerRef: { current: undefined },
    cellClickHandlerRef: { current: undefined },
    designerStoreRef: { current: designerStore },
  }), [designerStore]);
  const [gridQuery_heroui_app_table_grid_1785520939398_1odjv, setGridQuery_heroui_app_table_grid_1785520939398_1odjv] = React.useState<GridQueryState>(() => ({ ...EMPTY_GRID_QUERY, sort: { columnId: "createdAt", direction: 'asc' } }));
  const [gridPage_heroui_app_table_grid_1785520939398_1odjv, setGridPage_heroui_app_table_grid_1785520939398_1odjv] = React.useState(1);
  const [gridPageSize_heroui_app_table_grid_1785520939398_1odjv, setGridPageSize_heroui_app_table_grid_1785520939398_1odjv] = React.useState(50);
  const [gridListMode_heroui_app_table_grid_1785520939398_1odjv, setGridListMode_heroui_app_table_grid_1785520939398_1odjv] = React.useState<'paging' | 'infinite'>("paging");
  const [gridColumnLayout_heroui_app_table_grid_1785520939398_1odjv, setGridColumnLayout_heroui_app_table_grid_1785520939398_1odjv] = React.useState(() => createDefaultColumnLayout(gridColumns_heroui_app_table_grid_1785520939398_1odjv));
  const gridFilteredRows_heroui_app_table_grid_1785520939398_1odjv = React.useMemo(() => applyClientGridQuery(((Array.isArray(gridData_heroui_app_table_grid_1785520939398_1odjv?.data) ? gridData_heroui_app_table_grid_1785520939398_1odjv?.data : []) ?? []), gridQuery_heroui_app_table_grid_1785520939398_1odjv, gridColumns_heroui_app_table_grid_1785520939398_1odjv, "client"), [gridQuery_heroui_app_table_grid_1785520939398_1odjv, gridColumns_heroui_app_table_grid_1785520939398_1odjv]);
  const gridApiTotal_heroui_app_table_grid_1785520939398_1odjv = React.useMemo(() => {
    const raw = raw_gridData_heroui_app_table_grid_1785520939398_1odjv;
    const value = readNestedContextValue((raw && typeof raw === 'object' ? raw as Record<string, unknown> : {}), "count");
    const parsed = typeof value === 'number' ? value : Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : 0;
  }, [raw_gridData_heroui_app_table_grid_1785520939398_1odjv]);
  const gridTotalCount_heroui_app_table_grid_1785520939398_1odjv = resolveDataGridTotalCount({ page: gridPage_heroui_app_table_grid_1785520939398_1odjv, pageSize: gridPageSize_heroui_app_table_grid_1785520939398_1odjv, total: gridApiTotal_heroui_app_table_grid_1785520939398_1odjv, gridQueryMode: "client" }, gridFilteredRows_heroui_app_table_grid_1785520939398_1odjv.length);
  const gridPaging_heroui_app_table_grid_1785520939398_1odjv = sliceDataGridRowsForDisplay(gridFilteredRows_heroui_app_table_grid_1785520939398_1odjv, gridPage_heroui_app_table_grid_1785520939398_1odjv, gridPageSize_heroui_app_table_grid_1785520939398_1odjv, gridTotalCount_heroui_app_table_grid_1785520939398_1odjv, "client");
  const handleGridQueryChange_heroui_app_table_grid_1785520939398_1odjv = React.useCallback((nextQuery: GridQueryState) => {
    setGridQuery_heroui_app_table_grid_1785520939398_1odjv(nextQuery);
    setGridPage_heroui_app_table_grid_1785520939398_1odjv(1);
  }, [patchDesignerStore]);
  const handleGridPageChange_heroui_app_table_grid_1785520939398_1odjv = React.useCallback((nextPage: number) => {
    setGridPage_heroui_app_table_grid_1785520939398_1odjv(nextPage);
  }, [patchDesignerStore]);
  const handleGridPageSizeChange_heroui_app_table_grid_1785520939398_1odjv = React.useCallback((nextSize: number) => {
    setGridPageSize_heroui_app_table_grid_1785520939398_1odjv(nextSize);
    setGridPage_heroui_app_table_grid_1785520939398_1odjv(1);
  }, [patchDesignerStore]);
  const handleGridSortByChange_heroui_app_table_grid_1785520939398_1odjv = React.useCallback((nextSortBy: string) => {
    setGridQuery_heroui_app_table_grid_1785520939398_1odjv((current: GridQueryState) => ({ ...current, sort: nextSortBy ? { columnId: nextSortBy, direction: current.sort?.direction ?? 'asc' } : null }));
  }, []);
  const handleGridToggleSortDirection_heroui_app_table_grid_1785520939398_1odjv = React.useCallback(() => {
    setGridQuery_heroui_app_table_grid_1785520939398_1odjv((current: GridQueryState) => (current.sort ? { ...current, sort: { ...current.sort, direction: current.sort.direction === 'asc' ? 'desc' : 'asc' } } : current));
  }, []);

  const gridColumns_heroui_app_table_grid_1785520939402_2gu1c = React.useMemo(() => buildAppTableGridColumns([{"key":"title","label":"Title","sort":true,"filter":true,"filterType":"text","cellKind":"link","cellFields":{"labelField":"title","hrefTemplate":"/studio/cms/contents/edit/{id}"},"cardRole":"title"},{"key":"slug","label":"Slug","sort":true,"filter":true,"filterType":"text","cardRole":"field"},{"key":"contentTypeCode","label":"Type","sort":true,"cellKind":"lookup","cellFields":{"labelField":"contentTypeCodeTitle","labelFallbackField":"contentTypeCode"},"cardRole":"field"},{"key":"languageCode","label":"Language","sort":true,"cellKind":"lookup","cellFields":{"labelField":"languageCodeTitle","labelFallbackField":"languageCode"},"cardRole":"field"},{"key":"statusCode","label":"Status","sort":true,"cellKind":"status-badge","cellFields":{"labelField":"statusCodeTitle","labelFallbackField":"statusCode","htmlField":"statusCodeUiHtml"},"cardRole":"meta"},{"key":"publishedAt","label":"Published","sort":true,"filter":true,"filterType":"dateRange","cellKind":"date","cardRole":"meta"},{"key":"updatedAt","label":"Updated","sort":true,"filter":true,"filterType":"dateRange","cellKind":"date","cardRole":"meta","hideBelow":"lg"},{"key":"actions","label":"","kind":"action-group","actions":[{"actionId":"edit","icon":"Pencil","intent":"edit","tooltip":"Edit","behavior":{"kind":"navigate","navigateTarget":"/studio/cms/contents/edit/{selection.id}","navigateReplace":false}},{"actionId":"revisions","icon":"History","intent":"view","tooltip":"Revision history","behavior":{"kind":"open-modal","modalNodeId":"heroui-modal-1785520939387-u0dar","primaryKeyField":"id","selectionStorePath":"selection.id"}},{"actionId":"comments","icon":"MessageSquare","intent":"utility","tooltip":"Submitted comments","behavior":{"kind":"open-modal","modalNodeId":"heroui-modal-1785520939394-ig434","primaryKeyField":"id","selectionStorePath":"selection.id"}},{"actionId":"archive","icon":"Archive","intent":"warning","tooltip":"Archive","behavior":{"kind":"open-modal","modalNodeId":"node-4e676c0a-096b-41e9-be18-f03246f4f4b6","primaryKeyField":"id","selectionStorePath":"selection.id"},"disabledWhen":{"preset":"expression","expression":"row.statusCode === '101.002.004'"}},{"actionId":"delete","icon":"Trash2","intent":"delete","tooltip":"Delete","behavior":{"kind":"open-modal","modalNodeId":"node-dfd12d6e-29e9-41db-a93f-32574afec1f5","primaryKeyField":"id","selectionStorePath":"selection.id"}}],"cardRole":"actions","layoutHideable":false,"layoutResizable":false,"layoutReorderable":false,"width":"140px"}], "server", {
    mode: 'runtime',
    detailFlowRef: { current: null },
    rowActionHandlerRef: { current: handleGridRowAction_heroui_app_table_grid_1785520939402_2gu1c },
    cellClickHandlerRef: { current: undefined },
    designerStoreRef: { current: designerStore },
  }), [designerStore, handleGridRowAction_heroui_app_table_grid_1785520939402_2gu1c]);
  const [gridQuery_heroui_app_table_grid_1785520939402_2gu1c, setGridQuery_heroui_app_table_grid_1785520939402_2gu1c] = React.useState<GridQueryState>(() => ({ ...EMPTY_GRID_QUERY, sort: { columnId: "updatedAt", direction: 'asc' } }));
  const [gridPage_heroui_app_table_grid_1785520939402_2gu1c, setGridPage_heroui_app_table_grid_1785520939402_2gu1c] = React.useState(1);
  const [gridPageSize_heroui_app_table_grid_1785520939402_2gu1c, setGridPageSize_heroui_app_table_grid_1785520939402_2gu1c] = React.useState(50);
  const [gridListMode_heroui_app_table_grid_1785520939402_2gu1c, setGridListMode_heroui_app_table_grid_1785520939402_2gu1c] = React.useState<'paging' | 'infinite'>("paging");
  const [gridColumnLayout_heroui_app_table_grid_1785520939402_2gu1c, setGridColumnLayout_heroui_app_table_grid_1785520939402_2gu1c] = React.useState(() => createDefaultColumnLayout(gridColumns_heroui_app_table_grid_1785520939402_2gu1c));
  const [gridSearchInput_heroui_app_table_grid_1785520939402_2gu1c, setGridSearchInput_heroui_app_table_grid_1785520939402_2gu1c] = React.useState('');
  const [gridDebouncedSearch_heroui_app_table_grid_1785520939402_2gu1c, setGridDebouncedSearch_heroui_app_table_grid_1785520939402_2gu1c] = React.useState('');
  const [gridRoleFilters_heroui_app_table_grid_1785520939402_2gu1c, setGridRoleFilters_heroui_app_table_grid_1785520939402_2gu1c] = React.useState<Record<string, boolean>>({});
  const gridFilteredRows_heroui_app_table_grid_1785520939402_2gu1c = React.useMemo(() => applyClientGridQuery(((Array.isArray(gridData_heroui_app_table_grid_1785520939402_2gu1c?.data) ? gridData_heroui_app_table_grid_1785520939402_2gu1c?.data : []) ?? []), gridQuery_heroui_app_table_grid_1785520939402_2gu1c, gridColumns_heroui_app_table_grid_1785520939402_2gu1c, "server"), [gridQuery_heroui_app_table_grid_1785520939402_2gu1c, gridColumns_heroui_app_table_grid_1785520939402_2gu1c]);
  const gridApiTotal_heroui_app_table_grid_1785520939402_2gu1c = React.useMemo(() => {
    const raw = raw_gridData_heroui_app_table_grid_1785520939402_2gu1c;
    const value = readNestedContextValue((raw && typeof raw === 'object' ? raw as Record<string, unknown> : {}), "count");
    const parsed = typeof value === 'number' ? value : Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : 0;
  }, [raw_gridData_heroui_app_table_grid_1785520939402_2gu1c]);
  const gridTotalCount_heroui_app_table_grid_1785520939402_2gu1c = resolveDataGridTotalCount({ page: gridPage_heroui_app_table_grid_1785520939402_2gu1c, pageSize: gridPageSize_heroui_app_table_grid_1785520939402_2gu1c, total: gridApiTotal_heroui_app_table_grid_1785520939402_2gu1c, gridQueryMode: "server" }, gridFilteredRows_heroui_app_table_grid_1785520939402_2gu1c.length);
  const gridPaging_heroui_app_table_grid_1785520939402_2gu1c = sliceDataGridRowsForDisplay(gridFilteredRows_heroui_app_table_grid_1785520939402_2gu1c, gridPage_heroui_app_table_grid_1785520939402_2gu1c, gridPageSize_heroui_app_table_grid_1785520939402_2gu1c, gridTotalCount_heroui_app_table_grid_1785520939402_2gu1c, "server");
  const handleGridQueryChange_heroui_app_table_grid_1785520939402_2gu1c = React.useCallback((nextQuery: GridQueryState) => {
    setGridQuery_heroui_app_table_grid_1785520939402_2gu1c(nextQuery);
    setGridPage_heroui_app_table_grid_1785520939402_2gu1c(1);
    patchDesignerStore("gridQuery.sortBy", nextQuery.sort?.columnId ?? '');
    patchDesignerStore("gridQuery.sortDir", nextQuery.sort?.direction ?? '');
  }, [patchDesignerStore]);
  const handleGridPageChange_heroui_app_table_grid_1785520939402_2gu1c = React.useCallback((nextPage: number) => {
    setGridPage_heroui_app_table_grid_1785520939402_2gu1c(nextPage);
    patchDesignerStore("gridQuery.page", nextPage);
  }, [patchDesignerStore]);
  const handleGridPageSizeChange_heroui_app_table_grid_1785520939402_2gu1c = React.useCallback((nextSize: number) => {
    setGridPageSize_heroui_app_table_grid_1785520939402_2gu1c(nextSize);
    setGridPage_heroui_app_table_grid_1785520939402_2gu1c(1);
    patchDesignerStore("gridQuery.pageSize", nextSize);
  }, [patchDesignerStore]);
  const handleGridSortByChange_heroui_app_table_grid_1785520939402_2gu1c = React.useCallback((nextSortBy: string) => {
    setGridQuery_heroui_app_table_grid_1785520939402_2gu1c((current: GridQueryState) => ({ ...current, sort: nextSortBy ? { columnId: nextSortBy, direction: current.sort?.direction ?? 'asc' } : null }));
  }, []);
  const handleGridToggleSortDirection_heroui_app_table_grid_1785520939402_2gu1c = React.useCallback(() => {
    setGridQuery_heroui_app_table_grid_1785520939402_2gu1c((current: GridQueryState) => (current.sort ? { ...current, sort: { ...current.sort, direction: current.sort.direction === 'asc' ? 'desc' : 'asc' } } : current));
  }, []);
  const searchDebounceTimer_heroui_app_table_grid_1785520939402_2gu1c = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const handleGridSearchChange_heroui_app_table_grid_1785520939402_2gu1c = React.useCallback((nextValue: string) => {
    setGridSearchInput_heroui_app_table_grid_1785520939402_2gu1c(nextValue);
    if (searchDebounceTimer_heroui_app_table_grid_1785520939402_2gu1c.current) {
      clearTimeout(searchDebounceTimer_heroui_app_table_grid_1785520939402_2gu1c.current);
    }
    searchDebounceTimer_heroui_app_table_grid_1785520939402_2gu1c.current = setTimeout(() => {
      setGridDebouncedSearch_heroui_app_table_grid_1785520939402_2gu1c(nextValue);
      setGridPage_heroui_app_table_grid_1785520939402_2gu1c(1);
      patchDesignerStore("gridToolbar.search", nextValue);
    }, 300);
  }, [patchDesignerStore]);

  const dataContext: Record<string, unknown> | null = null;
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [mutationError, setMutationError] = React.useState<string | null>(null);
  const handleonClick_node_ca552387_2ffe_428b_b9b2_61925ccfe2fe = React.useCallback(async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    let formData: FormData;
    const form = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : event.currentTarget.closest('form');
    if (form) {
      formData = new FormData(form);
    } else {
      const regionRoot = document.querySelector("[data-designer-node-id=\"node-862a5ee3-7600-45b7-9313-d57651dd629c\"]");
      if (!regionRoot) {
        return;
      }
      formData = collectRegionFormDataFromContainer(regionRoot, []);
    }
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      const method = 'POST';
      const url = "/api/cms/contents";
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      const mutationResponse = await response.clone().json().catch(() => null);
      patchDesignerStore("response", mutationResponse);
      toast("Saved successfully", { variant: "success", timeout: 4000 });
      navigate(("/studio/cms/contents/edit/" + encodeURIComponent(String(mutationResponse?.data?.id ?? ''))), { replace: false });
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, []);
  const handleonClick_node_1edb2487_685a_45e5_8a2f_3752cca97338 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-39265dbc-13c8-4c8e-adf7-12d789e6d06b", false);
  }, [patchDesignerStore]);
  const handleonClick_node_20fe5ce4_c882_4d1c_b608_a59036a9800f = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-dfd12d6e-29e9-41db-a93f-32574afec1f5", false);
  }, [patchDesignerStore]);
  const handleonClick_node_15718504_3a1e_4cb5_8de1_fa35476636dd = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_ms992e8h_gdrzx = true;
      try {
        const response = await designerFetch(("/api/cms/contents/" + encodeURIComponent(String(designerStore?.selection?.id)) + ""), {
          method: "DELETE",
          headers: { 'Content-Type': 'application/json' },
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_ms992e8h_gdrzx = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_ms992e8h_gdrzx = false;
      }
      if (mutationOk_da_ms992e8h_gdrzx) {
        patchDesignerStore("ui.visibility.node-dfd12d6e-29e9-41db-a93f-32574afec1f5", false);
        toast("Deleted", { variant: "success", timeout: 4000 });
        await refresh_gridData_heroui_app_table_grid_1785520939402_2gu1c();
      }
    })();
  }, [patchDesignerStore, refresh_gridData_heroui_app_table_grid_1785520939402_2gu1c]);
  const handleonClick_node_87a4850b_871c_4ae0_aeac_aa54ebde3849 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-4e676c0a-096b-41e9-be18-f03246f4f4b6", false);
  }, [patchDesignerStore]);
  const handleonClick_node_4657f5c6_571d_44fb_aea0_e24df551208e = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_ms992e8j_gswgl = true;
      try {
        const response = await designerFetch(("/api/cms/contents/" + encodeURIComponent(String(designerStore?.selection?.id)) + ""), {
          method: "PUT",
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({"statusCode":"101.002.004","publishedAt":null}),
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_ms992e8j_gswgl = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_ms992e8j_gswgl = false;
      }
      if (mutationOk_da_ms992e8j_gswgl) {
        patchDesignerStore("ui.visibility.node-4e676c0a-096b-41e9-be18-f03246f4f4b6", false);
        toast("Content archived", { variant: "success", timeout: 4000 });
        await refresh_gridData_heroui_app_table_grid_1785520939402_2gu1c();
      }
    })();
  }, [patchDesignerStore, refresh_gridData_heroui_app_table_grid_1785520939402_2gu1c]);
  const [isOpen_heroui_modal_1785520939387_u0dar, setIsOpen_heroui_modal_1785520939387_u0dar] = React.useState(false);
  const [isOpen_heroui_modal_1785520939394_ig434, setIsOpen_heroui_modal_1785520939394_ig434] = React.useState(false);
  return (
    <>
      <Toast.Provider />
      <div className="space-y-3">
        {mutationError ? (
          <div className="rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700">
            {mutationError}
          </div>
        ) : null}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "ui.visibility.heroui-modal-1785520939387-u0dar === true") && (
          <Modal><Modal.Backdrop isOpen={isOpen_heroui_modal_1785520939387_u0dar} onOpenChange={setIsOpen_heroui_modal_1785520939387_u0dar} variant="blur"><Modal.Container size="xl" scroll="inside"><Modal.Dialog className="w-full max-w-5xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Revision history</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => setIsOpen_heroui_modal_1785520939387_u0dar(false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <div className="flex min-h-[30rem] min-w-0 flex-col overflow-hidden bg-white p-[15px]">
            <AppTableGrid className="flex h-full min-h-0 w-full flex-1 flex-col" presentation="auto" cardBelow="phone" cardVariant="list" columns={gridColumns_heroui_app_table_grid_1785520939390_fj2y4} rows={gridPaging_heroui_app_table_grid_1785520939390_fj2y4.displayRows} getRowKey={(row) => String((row as Record<string, unknown>)["id"] ?? '')} enableColumnLayout={false} columnLayout={gridColumnLayout_heroui_app_table_grid_1785520939390_fj2y4} onColumnLayoutChange={setGridColumnLayout_heroui_app_table_grid_1785520939390_fj2y4} isLoading={false} loadingMessage={"Loading revisions…"} emptyMessage={"No revisions found."} isEmpty={gridFilteredRows_heroui_app_table_grid_1785520939390_fj2y4.length === 0} errorContent={gridFilteredRows_heroui_app_table_grid_1785520939390_fj2y4.length === 0 ? undefined : "Could not load revisions."} gridQueryMode={"client"} query={gridQuery_heroui_app_table_grid_1785520939390_fj2y4} onQueryChange={handleGridQueryChange_heroui_app_table_grid_1785520939390_fj2y4} footer={<GridPagingFooter totalCount={gridTotalCount_heroui_app_table_grid_1785520939390_fj2y4} safePage={gridPaging_heroui_app_table_grid_1785520939390_fj2y4.safePage} pageSize={gridPageSize_heroui_app_table_grid_1785520939390_fj2y4} onPageSizeChange={handleGridPageSizeChange_heroui_app_table_grid_1785520939390_fj2y4} sortBy={gridQuery_heroui_app_table_grid_1785520939390_fj2y4.sort?.columnId ?? ''} sortOptions={[{"value":"revisionNo","label":"#"}]} onSortByChange={handleGridSortByChange_heroui_app_table_grid_1785520939390_fj2y4} sortDirection={gridQuery_heroui_app_table_grid_1785520939390_fj2y4.sort?.direction ?? 'asc'} onToggleSortDirection={handleGridToggleSortDirection_heroui_app_table_grid_1785520939390_fj2y4} showSortControls={false} totalPages={gridPaging_heroui_app_table_grid_1785520939390_fj2y4.totalPages} pageNumbers={buildDataGridPageNumbers(gridPaging_heroui_app_table_grid_1785520939390_fj2y4.safePage, gridPaging_heroui_app_table_grid_1785520939390_fj2y4.totalPages)} onPageChange={handleGridPageChange_heroui_app_table_grid_1785520939390_fj2y4} visibleInfiniteCount={gridListMode_heroui_app_table_grid_1785520939390_fj2y4 === 'infinite' ? gridPaging_heroui_app_table_grid_1785520939390_fj2y4.displayRows.length : undefined} />} />
          </div>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "ui.visibility.heroui-modal-1785520939394-ig434 === true") && (
          <Modal><Modal.Backdrop isOpen={isOpen_heroui_modal_1785520939394_ig434} onOpenChange={setIsOpen_heroui_modal_1785520939394_ig434} variant="blur"><Modal.Container size="xl" scroll="inside"><Modal.Dialog className="w-full max-w-5xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Submitted comments</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => setIsOpen_heroui_modal_1785520939394_ig434(false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <div className="flex min-h-[30rem] min-w-0 flex-col overflow-hidden bg-white p-[15px]">
            <AppTableGrid className="flex h-full min-h-0 w-full flex-1 flex-col" presentation="auto" cardBelow="phone" cardVariant="list" columns={gridColumns_heroui_app_table_grid_1785520939398_1odjv} rows={gridPaging_heroui_app_table_grid_1785520939398_1odjv.displayRows} getRowKey={(row) => String((row as Record<string, unknown>)["id"] ?? '')} enableColumnLayout={false} columnLayout={gridColumnLayout_heroui_app_table_grid_1785520939398_1odjv} onColumnLayoutChange={setGridColumnLayout_heroui_app_table_grid_1785520939398_1odjv} isLoading={false} loadingMessage={"Loading comments…"} emptyMessage={"No comments found."} isEmpty={gridFilteredRows_heroui_app_table_grid_1785520939398_1odjv.length === 0} errorContent={gridFilteredRows_heroui_app_table_grid_1785520939398_1odjv.length === 0 ? undefined : "Could not load comments."} gridQueryMode={"client"} query={gridQuery_heroui_app_table_grid_1785520939398_1odjv} onQueryChange={handleGridQueryChange_heroui_app_table_grid_1785520939398_1odjv} footer={<GridPagingFooter totalCount={gridTotalCount_heroui_app_table_grid_1785520939398_1odjv} safePage={gridPaging_heroui_app_table_grid_1785520939398_1odjv.safePage} pageSize={gridPageSize_heroui_app_table_grid_1785520939398_1odjv} onPageSizeChange={handleGridPageSizeChange_heroui_app_table_grid_1785520939398_1odjv} sortBy={gridQuery_heroui_app_table_grid_1785520939398_1odjv.sort?.columnId ?? ''} sortOptions={[{"value":"authorDisplayName","label":"Author"},{"value":"createdAt","label":"Submitted"}]} onSortByChange={handleGridSortByChange_heroui_app_table_grid_1785520939398_1odjv} sortDirection={gridQuery_heroui_app_table_grid_1785520939398_1odjv.sort?.direction ?? 'asc'} onToggleSortDirection={handleGridToggleSortDirection_heroui_app_table_grid_1785520939398_1odjv} showSortControls={false} totalPages={gridPaging_heroui_app_table_grid_1785520939398_1odjv.totalPages} pageNumbers={buildDataGridPageNumbers(gridPaging_heroui_app_table_grid_1785520939398_1odjv.safePage, gridPaging_heroui_app_table_grid_1785520939398_1odjv.totalPages)} onPageChange={handleGridPageChange_heroui_app_table_grid_1785520939398_1odjv} visibleInfiniteCount={gridListMode_heroui_app_table_grid_1785520939398_1odjv === 'infinite' ? gridPaging_heroui_app_table_grid_1785520939398_1odjv.displayRows.length : undefined} />} />
          </div>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        <div className="flex w-full flex-col gap-2"><div className="flex items-center justify-between gap-2 border-b border-slate-200 bg-white px-2 py-1.5"><div className="flex items-center gap-2"><input type="text" value={gridSearchInput_heroui_app_table_grid_1785520939402_2gu1c} onChange={(event) => handleGridSearchChange_heroui_app_table_grid_1785520939402_2gu1c(event.target.value)} placeholder={"Search contents…"} className="h-8 rounded-md border border-slate-200 px-2 text-sm" /></div><div className="flex items-center gap-2"><button type="button" onClick={() => { patchDesignerStore("selection.id", null); patchDesignerStore("ui.visibility.node-39265dbc-13c8-4c8e-adf7-12d789e6d06b", true); }} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700">Create content</button><button type="button" onClick={() => { void refresh_gridData_heroui_app_table_grid_1785520939402_2gu1c(); }} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 px-3 text-xs font-medium text-slate-700 hover:bg-slate-50">Refresh</button></div></div><AppTableGrid className="flex h-full min-h-0 w-full flex-1 flex-col" presentation="auto" cardBelow="phone" cardVariant="list" columns={gridColumns_heroui_app_table_grid_1785520939402_2gu1c} rows={gridPaging_heroui_app_table_grid_1785520939402_2gu1c.displayRows} getRowKey={(row) => String((row as Record<string, unknown>)["id"] ?? '')} enableColumnLayout={false} columnLayout={gridColumnLayout_heroui_app_table_grid_1785520939402_2gu1c} onColumnLayoutChange={setGridColumnLayout_heroui_app_table_grid_1785520939402_2gu1c} isLoading={false} loadingMessage={"Loading records…"} emptyMessage={"No records found."} isEmpty={gridFilteredRows_heroui_app_table_grid_1785520939402_2gu1c.length === 0} errorContent={gridFilteredRows_heroui_app_table_grid_1785520939402_2gu1c.length === 0 ? undefined : "Could not load records."} gridQueryMode={"server"} query={gridQuery_heroui_app_table_grid_1785520939402_2gu1c} onQueryChange={handleGridQueryChange_heroui_app_table_grid_1785520939402_2gu1c} onGridRowAction={handleGridRowAction_heroui_app_table_grid_1785520939402_2gu1c} footer={<GridPagingFooter totalCount={gridTotalCount_heroui_app_table_grid_1785520939402_2gu1c} safePage={gridPaging_heroui_app_table_grid_1785520939402_2gu1c.safePage} pageSize={gridPageSize_heroui_app_table_grid_1785520939402_2gu1c} onPageSizeChange={handleGridPageSizeChange_heroui_app_table_grid_1785520939402_2gu1c} sortBy={gridQuery_heroui_app_table_grid_1785520939402_2gu1c.sort?.columnId ?? ''} sortOptions={[{"value":"title","label":"Title"},{"value":"slug","label":"Slug"},{"value":"contentTypeCode","label":"Type"},{"value":"languageCode","label":"Language"},{"value":"statusCode","label":"Status"},{"value":"publishedAt","label":"Published"},{"value":"updatedAt","label":"Updated"}]} onSortByChange={handleGridSortByChange_heroui_app_table_grid_1785520939402_2gu1c} sortDirection={gridQuery_heroui_app_table_grid_1785520939402_2gu1c.sort?.direction ?? 'asc'} onToggleSortDirection={handleGridToggleSortDirection_heroui_app_table_grid_1785520939402_2gu1c} showSortControls={false} totalPages={gridPaging_heroui_app_table_grid_1785520939402_2gu1c.totalPages} pageNumbers={buildDataGridPageNumbers(gridPaging_heroui_app_table_grid_1785520939402_2gu1c.safePage, gridPaging_heroui_app_table_grid_1785520939402_2gu1c.totalPages)} onPageChange={handleGridPageChange_heroui_app_table_grid_1785520939402_2gu1c} visibleInfiniteCount={gridListMode_heroui_app_table_grid_1785520939402_2gu1c === 'infinite' ? gridPaging_heroui_app_table_grid_1785520939402_2gu1c.displayRows.length : undefined} />} /></div>
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-39265dbc-13c8-4c8e-adf7-12d789e6d06b === true) && (store.ui.visibility.node-39265dbc-13c8-4c8e-adf7-12d789e6d06b !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-39265dbc-13c8-4c8e-adf7-12d789e6d06b"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-39265dbc-13c8-4c8e-adf7-12d789e6d06b", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Create content</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-39265dbc-13c8-4c8e-adf7-12d789e6d06b", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <form className="flex flex-col gap-3 bg-white p-[15px]" method="post" data-designer-node-id="node-862a5ee3-7600-45b7-9313-d57651dd629c">
            <div className="flex flex-col gap-2 bg-white p-[15px]">
              <UiSelect name="contentTypeCode" isRequired className="w-full" placeholder="Select content type…" label="Content Type" size="sm"><option value="101.001.001">Article</option><option value="101.001.002">News</option><option value="101.001.003">Announcement</option><option value="101.001.004">Gallery</option></UiSelect>
              <UiSelect name="languageCode" isRequired className="w-full" placeholder="Select language…" label="Language" size="sm"><option value="101.004.001">English</option><option value="101.004.002">Persian</option><option value="101.004.003">Arabic</option></UiSelect>
              <UiSelect name="bodyFormatCode" isRequired className="w-full" placeholder="Select body format…" label="Body format" size="sm"><option value="101.003.001">Plain</option><option value="101.003.002">Markdown</option><option value="101.003.003">HTML</option></UiSelect>
            </div>
            <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" onClick={handleonClick_node_1edb2487_685a_45e5_8a2f_3752cca97338}>Cancel</Button>
              <Button type="submit" className="inline-flex h-8 w-fit self-end items-center rounded-md bg-indigo-600 px-3 text-sm font-semibold text-white hover:bg-indigo-700" icon="Plus" variant="primary" size="md" href="#" target="_self" isDisabled={isSubmitting} onClick={handleonClick_node_ca552387_2ffe_428b_b9b2_61925ccfe2fe}>Create content</Button>
            </div>
          </form>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-dfd12d6e-29e9-41db-a93f-32574afec1f5 === true) && (store.ui.visibility.node-dfd12d6e-29e9-41db-a93f-32574afec1f5 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-dfd12d6e-29e9-41db-a93f-32574afec1f5"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-dfd12d6e-29e9-41db-a93f-32574afec1f5", false); } }} variant="blur"><Modal.Container><Modal.Dialog role="alertdialog" className="w-full max-w-md overflow-hidden rounded-xl border border-rose-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-rose-200 bg-rose-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-rose-800">Delete content?</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-dfd12d6e-29e9-41db-a93f-32574afec1f5", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <p className="block bg-white p-[15px] text-sm text-slate-700">Delete this content? This cannot be undone.</p>
          <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
            <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_node_20fe5ce4_c882_4d1c_b608_a59036a9800f}>Cancel</Button>
            <Button icon="Trash2" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-rose-600 px-3 text-xs font-semibold text-white hover:bg-rose-700" variant="primary" size="md" href="#" target="_self" onClick={handleonClick_node_15718504_3a1e_4cb5_8de1_fa35476636dd}>Delete</Button>
          </div>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-4e676c0a-096b-41e9-be18-f03246f4f4b6 === true) && (store.ui.visibility.node-4e676c0a-096b-41e9-be18-f03246f4f4b6 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-4e676c0a-096b-41e9-be18-f03246f4f4b6"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-4e676c0a-096b-41e9-be18-f03246f4f4b6", false); } }} variant="blur"><Modal.Container><Modal.Dialog role="alertdialog" className="w-full max-w-md overflow-hidden rounded-xl border border-rose-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-rose-200 bg-rose-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-rose-800">Archive content?</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-4e676c0a-096b-41e9-be18-f03246f4f4b6", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <p className="block bg-white p-[15px] text-sm leading-relaxed text-slate-700">Archive this content? It will no longer appear in published delivery.</p>
          <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
            <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_node_87a4850b_871c_4ae0_aeac_aa54ebde3849}>Cancel</Button>
            <Button icon="Check" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" variant="primary" size="md" href="#" target="_self" onClick={handleonClick_node_4657f5c6_571d_44fb_aea0_e24df551208e}>Archive</Button>
          </div>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
      </div>
    </>
  );
};
export default GeneratedComponent;
