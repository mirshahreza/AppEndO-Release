-- CMS package Phase 1 schema (SQL Server)
-- Opt-in only — never run from app bootstrap / controlPlaneSeed.
-- Idempotent: guarded by OBJECT_ID / sys.indexes checks.

IF OBJECT_ID(N'dbo.cms_contents', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.cms_contents (
    id                        BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    content_type_code         NVARCHAR(1000) NULL,
    language_code             NVARCHAR(1000) NULL,
    slug                      NVARCHAR(1000) NULL,
    status_code               NVARCHAR(1000) NULL,
    status_code_updated_at    DATETIME2 NULL,
    status_code_updated_by    BIGINT NULL,
    title                     NVARCHAR(MAX) NULL,
    summary                   NVARCHAR(MAX) NULL,
    body                      NVARCHAR(MAX) NULL,
    body_format_code          NVARCHAR(1000) NULL,
    seo_title                 NVARCHAR(MAX) NULL,
    seo_note                  NVARCHAR(MAX) NULL,
    published_at              DATETIME2 NULL,
    operator_note             NVARCHAR(MAX) NULL,
    comments_enabled          BIT NULL,
    comments_policy_code      NVARCHAR(1000) NULL,
    comments_body_format_code NVARCHAR(1000) NULL,
    parent_content_id         BIGINT NULL,
    author_display_name       NVARCHAR(MAX) NULL,
    author_email              NVARCHAR(MAX) NULL,
    moderated_by              BIGINT NULL,
    moderated_at              DATETIME2 NULL,
    created_by                BIGINT NULL,
    created_at                DATETIME2 NULL CONSTRAINT DF_cms_contents_created_at DEFAULT SYSUTCDATETIME(),
    updated_by                BIGINT NULL,
    updated_at                DATETIME2 NULL CONSTRAINT DF_cms_contents_updated_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_cms_contents_content_type FOREIGN KEY (content_type_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_cms_contents_language FOREIGN KEY (language_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_cms_contents_status FOREIGN KEY (status_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_cms_contents_body_format FOREIGN KEY (body_format_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_cms_contents_comments_policy FOREIGN KEY (comments_policy_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_cms_contents_comments_body_format FOREIGN KEY (comments_body_format_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_cms_contents_parent FOREIGN KEY (parent_content_id) REFERENCES dbo.cms_contents(id),
    CONSTRAINT FK_cms_contents_status_updated_by FOREIGN KEY (status_code_updated_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_cms_contents_created_by FOREIGN KEY (created_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_cms_contents_updated_by FOREIGN KEY (updated_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_cms_contents_moderated_by FOREIGN KEY (moderated_by) REFERENCES dbo.base_users(id)
  );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'uq_cms_contents_language_slug' AND object_id = OBJECT_ID(N'dbo.cms_contents'))
  CREATE UNIQUE INDEX uq_cms_contents_language_slug ON dbo.cms_contents (language_code, slug);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_contents_status_code' AND object_id = OBJECT_ID(N'dbo.cms_contents'))
  CREATE INDEX idx_cms_contents_status_code ON dbo.cms_contents (status_code);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_contents_content_type_code' AND object_id = OBJECT_ID(N'dbo.cms_contents'))
  CREATE INDEX idx_cms_contents_content_type_code ON dbo.cms_contents (content_type_code);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_contents_published_at' AND object_id = OBJECT_ID(N'dbo.cms_contents'))
  CREATE INDEX idx_cms_contents_published_at ON dbo.cms_contents (published_at);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_contents_parent_content_id' AND object_id = OBJECT_ID(N'dbo.cms_contents'))
  CREATE INDEX idx_cms_contents_parent_content_id ON dbo.cms_contents (parent_content_id);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_contents_parent_content_type' AND object_id = OBJECT_ID(N'dbo.cms_contents'))
  CREATE INDEX idx_cms_contents_parent_content_type ON dbo.cms_contents (parent_content_id, content_type_code);
GO

IF OBJECT_ID(N'dbo.cms_content_revisions', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.cms_content_revisions (
    id            BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    content_id    BIGINT NOT NULL,
    revision_no   INT NOT NULL,
    title         NVARCHAR(MAX) NULL,
    summary       NVARCHAR(MAX) NULL,
    body          NVARCHAR(MAX) NULL,
    created_by    BIGINT NULL,
    created_at    DATETIME2 NULL CONSTRAINT DF_cms_content_revisions_created_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_cms_content_revisions_content FOREIGN KEY (content_id) REFERENCES dbo.cms_contents(id) ON DELETE CASCADE,
    CONSTRAINT FK_cms_content_revisions_created_by FOREIGN KEY (created_by) REFERENCES dbo.base_users(id),
    CONSTRAINT uq_cms_content_revisions_content_rev UNIQUE (content_id, revision_no)
  );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_content_revisions_content_id' AND object_id = OBJECT_ID(N'dbo.cms_content_revisions'))
  CREATE INDEX idx_cms_content_revisions_content_id ON dbo.cms_content_revisions (content_id);
GO

IF OBJECT_ID(N'dbo.cms_content_assets', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.cms_content_assets (
    id            BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    content_id    BIGINT NOT NULL,
    [file]        VARBINARY(MAX) NOT NULL,
    file_xs       VARBINARY(MAX) NULL,
    file_size     INT NOT NULL,
    file_name     NVARCHAR(1000) NOT NULL,
    file_mime     NVARCHAR(1000) NOT NULL,
    sort_order    INT NOT NULL CONSTRAINT DF_cms_content_assets_sort_order DEFAULT 0,
    sha256        NVARCHAR(1000) NOT NULL,
    created_by    BIGINT NULL,
    created_at    DATETIME2 NOT NULL CONSTRAINT DF_cms_content_assets_created_at DEFAULT SYSUTCDATETIME(),
    updated_by    BIGINT NULL,
    updated_at    DATETIME2 NOT NULL CONSTRAINT DF_cms_content_assets_updated_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_cms_content_assets_content FOREIGN KEY (content_id) REFERENCES dbo.cms_contents(id) ON DELETE CASCADE,
    CONSTRAINT FK_cms_content_assets_created_by FOREIGN KEY (created_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_cms_content_assets_updated_by FOREIGN KEY (updated_by) REFERENCES dbo.base_users(id)
  );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_content_assets_content_id' AND object_id = OBJECT_ID(N'dbo.cms_content_assets'))
  CREATE INDEX idx_cms_content_assets_content_id ON dbo.cms_content_assets (content_id, sort_order);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_content_assets_sha256' AND object_id = OBJECT_ID(N'dbo.cms_content_assets'))
  CREATE INDEX idx_cms_content_assets_sha256 ON dbo.cms_content_assets (sha256);
GO

IF OBJECT_ID(N'dbo.cms_content_tags', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.cms_content_tags (
    content_id    BIGINT NOT NULL,
    tag_code      NVARCHAR(1000) NOT NULL,
    CONSTRAINT PK_cms_content_tags PRIMARY KEY (content_id, tag_code),
    CONSTRAINT FK_cms_content_tags_content FOREIGN KEY (content_id) REFERENCES dbo.cms_contents(id) ON DELETE CASCADE,
    CONSTRAINT FK_cms_content_tags_tag FOREIGN KEY (tag_code) REFERENCES dbo.base_info(id)
  );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_content_tags_tag_code' AND object_id = OBJECT_ID(N'dbo.cms_content_tags'))
  CREATE INDEX idx_cms_content_tags_tag_code ON dbo.cms_content_tags (tag_code);
GO

IF OBJECT_ID(N'dbo.cms_content_relations', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.cms_content_relations (
    id              BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    content_id_a    BIGINT NOT NULL,
    content_id_b    BIGINT NOT NULL,
    note            NVARCHAR(MAX) NULL,
    CONSTRAINT FK_cms_content_relations_a FOREIGN KEY (content_id_a) REFERENCES dbo.cms_contents(id) ON DELETE CASCADE,
    CONSTRAINT FK_cms_content_relations_b FOREIGN KEY (content_id_b) REFERENCES dbo.cms_contents(id),
    CONSTRAINT ck_cms_content_relations_ordered CHECK (content_id_a < content_id_b),
    CONSTRAINT uq_cms_content_relations_pair UNIQUE (content_id_a, content_id_b)
  );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_content_relations_a' AND object_id = OBJECT_ID(N'dbo.cms_content_relations'))
  CREATE INDEX idx_cms_content_relations_a ON dbo.cms_content_relations (content_id_a);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_content_relations_b' AND object_id = OBJECT_ID(N'dbo.cms_content_relations'))
  CREATE INDEX idx_cms_content_relations_b ON dbo.cms_content_relations (content_id_b);
GO

IF OBJECT_ID(N'dbo.cms_settings', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.cms_settings (
    id                          BIGINT NOT NULL CONSTRAINT PK_cms_settings PRIMARY KEY,
    comments_enabled            BIT NOT NULL,
    comments_policy_code        NVARCHAR(1000) NOT NULL,
    comments_body_format_code   NVARCHAR(1000) NOT NULL,
    public_cache_ttl_seconds    INT NOT NULL CONSTRAINT DF_cms_settings_public_cache_ttl_seconds DEFAULT 300,
    updated_by                  BIGINT NULL,
    updated_at                  DATETIME2 NULL CONSTRAINT DF_cms_settings_updated_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT ck_cms_settings_singleton CHECK (id = 1),
    CONSTRAINT FK_cms_settings_comments_policy FOREIGN KEY (comments_policy_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_cms_settings_comments_body_format FOREIGN KEY (comments_body_format_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_cms_settings_updated_by FOREIGN KEY (updated_by) REFERENCES dbo.base_users(id)
  );
END;
GO

-- Captured 43 row(s) from base_info on 2026-11-09T08:57:42.597Z
-- WHERE (title = 'CMS' OR title_en = 'CMS')
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101', NULL, N'CMS', NULL, NULL, NULL, NULL, 200, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, '2026-09-17T16:13:34.434Z', N'1000000', '2026-11-06T20:28:53.368Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.001', N'101', N'Content Types', NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, '2026-09-17T16:13:34.516Z', N'1000000', '2026-11-06T20:28:53.392Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.002', N'101', N'Statuses', NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, 2, 1, NULL, NULL, '2026-09-17T16:13:35.199Z', N'1000000', '2026-11-06T20:28:53.553Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.003', N'101', N'Body Formats', NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, 3, 1, NULL, NULL, '2026-09-17T16:13:35.688Z', N'1000000', '2026-11-06T20:28:53.647Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.004', N'101', N'Languages', NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, NULL, NULL, 4, 1, NULL, NULL, '2026-09-17T16:13:35.924Z', N'1000000', '2026-11-06T20:28:53.711Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.005', N'101', N'Content Tags', NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL, NULL, NULL, 5, 1, NULL, NULL, '2026-09-17T16:13:36.133Z', N'1000000', '2026-11-06T20:28:53.760Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.006', N'101', N'Comment Policies', NULL, NULL, NULL, NULL, 6, NULL, NULL, NULL, NULL, NULL, 6, 1, NULL, NULL, '2026-09-17T16:13:37.221Z', N'1000000', '2026-11-06T20:28:53.959Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.001.001', N'101.001', N'Article', NULL, NULL, NULL, N'article', 1, NULL, NULL, NULL, NULL, NULL, 1, 1, N'#0ea5e9', N'<i data-lucide="Newspaper"></i>', '2026-09-17T16:13:34.590Z', N'1000000', '2026-11-06T20:28:53.425Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.001.002', N'101.001', N'News', NULL, NULL, NULL, N'news', 2, NULL, NULL, NULL, NULL, NULL, 2, 1, N'#6366f1', N'<i data-lucide="Rss"></i>', '2026-09-17T16:13:34.663Z', N'1000000', '2026-11-06T20:28:53.449Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.001.003', N'101.001', N'Announcement', NULL, NULL, NULL, N'announcement', 3, NULL, NULL, NULL, NULL, NULL, 3, 1, N'#f59e0b', N'<i data-lucide="Megaphone"></i>', '2026-09-17T16:13:34.727Z', N'1000000', '2026-11-06T20:28:53.466Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.001.004', N'101.001', N'Gallery', NULL, NULL, NULL, N'gallery', 4, NULL, NULL, NULL, NULL, NULL, 4, 1, N'#8b5cf6', N'<i data-lucide="Images"></i>', '2026-09-17T16:13:34.793Z', N'1000000', '2026-11-06T20:28:53.481Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.001.005', N'101.001', N'Comment', NULL, NULL, NULL, N'comment', 5, NULL, NULL, NULL, NULL, NULL, 5, 1, N'#14b8a6', N'<i data-lucide="MessageSquare"></i>', '2026-09-17T16:13:34.851Z', N'1000000', '2026-11-06T20:28:53.492Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.001.006', N'101.001', N'Page', NULL, NULL, NULL, N'page', 6, NULL, NULL, NULL, NULL, NULL, 6, 1, N'#0f766e', N'<i data-lucide="FileText"></i>', '2026-09-17T16:13:34.940Z', N'1000000', '2026-11-06T20:28:53.505Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.001.007', N'101.001', N'Fragment', NULL, NULL, NULL, N'fragment', 7, NULL, NULL, NULL, NULL, NULL, 7, 1, N'#64748b', N'<i data-lucide="Puzzle"></i>', '2026-09-17T16:13:35.032Z', N'1000000', '2026-11-06T20:28:53.521Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.001.008', N'101.001', N'How to', NULL, NULL, NULL, N'howto', 8, NULL, NULL, NULL, NULL, NULL, 8, 1, N'#0369a1', N'<i data-lucide="ListChecks"></i>', '2026-09-17T16:13:35.126Z', N'1000000', '2026-11-06T20:28:53.538Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.002.001', N'101.002', N'Draft', NULL, NULL, NULL, N'draft', 1, N'Work in progress. Not visible on the public site.', NULL, NULL, NULL, NULL, 1, 1, N'#94a3b8', N'<i data-lucide="FilePenLine"></i>', '2026-09-17T16:13:35.279Z', N'1000000', '2026-11-06T20:28:53.566Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.002.002', N'101.002', N'In Review', NULL, NULL, NULL, N'in_review', 2, N'Awaiting editorial review before it can be published.', NULL, NULL, NULL, NULL, 2, 1, N'#6366f1', N'<i data-lucide="Eye"></i>', '2026-09-17T16:13:35.406Z', N'1000000', '2026-11-06T20:28:53.581Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.002.003', N'101.002', N'Published', NULL, NULL, NULL, N'published', 3, N'Live and visible to public readers.', NULL, NULL, NULL, NULL, 3, 1, N'#047857', N'<i data-lucide="CheckCircle2"></i>', '2026-09-17T16:13:35.490Z', N'1000000', '2026-11-06T20:28:53.593Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.002.004', N'101.002', N'Archived', NULL, NULL, NULL, N'archived', 4, N'Retired from the public site; kept for history.', NULL, NULL, NULL, NULL, 4, 1, N'#64748b', N'<i data-lucide="Archive"></i>', '2026-09-17T16:13:35.558Z', N'1000000', '2026-11-06T20:28:53.605Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.002.005', N'101.002', N'Rejected', NULL, NULL, NULL, N'rejected', 5, N'Declined in review; not for publication.', NULL, NULL, NULL, NULL, 5, 1, N'#f43f5e', N'<i data-lucide="XCircle"></i>', '2026-09-17T16:13:35.622Z', N'1000000', '2026-11-06T20:28:53.619Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.003.001', N'101.003', N'HTML', NULL, NULL, NULL, N'html', 1, NULL, NULL, NULL, NULL, NULL, 1, 1, N'#f97316', NULL, '2026-09-17T16:13:35.755Z', N'1000000', '2026-11-06T20:28:53.667Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.003.002', N'101.003', N'Markdown', NULL, NULL, NULL, N'markdown', 2, NULL, NULL, NULL, NULL, NULL, 2, 1, N'#6366f1', NULL, '2026-09-17T16:13:35.813Z', N'1000000', '2026-11-06T20:28:53.680Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.003.003', N'101.003', N'Plain', NULL, NULL, NULL, N'plain', 3, NULL, NULL, NULL, NULL, NULL, 3, 1, N'#64748b', NULL, '2026-09-17T16:13:35.865Z', N'1000000', '2026-11-06T20:28:53.693Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.004.001', N'101.004', N'English', NULL, NULL, NULL, N'en', 1, NULL, NULL, NULL, NULL, NULL, 1, 1, N'#3b82f6', N'<i data-lucide="Languages"></i>', '2026-09-17T16:13:35.975Z', N'1000000', '2026-11-06T20:28:53.728Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.004.002', N'101.004', N'Persian', NULL, NULL, NULL, N'fa', 2, NULL, NULL, NULL, NULL, NULL, 2, 1, N'#0d9488', N'<i data-lucide="Languages"></i>', '2026-09-17T16:13:36.030Z', N'1000000', '2026-11-06T20:28:53.741Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.004.003', N'101.004', N'Arabic', NULL, NULL, NULL, N'ar', 3, NULL, NULL, NULL, NULL, NULL, 3, 1, N'#d97706', N'<i data-lucide="Languages"></i>', '2026-09-17T16:13:36.077Z', N'1000000', '2026-11-06T20:28:53.748Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.005.001', N'101.005', N'Featured', NULL, NULL, NULL, N'featured', 1, NULL, NULL, NULL, NULL, NULL, 1, 1, N'#047857', N'<i data-lucide="BadgeCheck"></i>', '2026-09-17T16:13:36.177Z', N'1000000', '2026-11-06T20:28:53.767Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.005.002', N'101.005', N'Platform', NULL, NULL, NULL, N'platform', 2, NULL, NULL, NULL, NULL, NULL, 2, 1, N'#0f766e', N'<i data-lucide="AppWindow"></i>', '2026-09-17T16:13:36.234Z', N'1000000', '2026-11-06T20:28:53.780Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.005.003', N'101.005', N'Studio', NULL, NULL, NULL, N'studio', 3, NULL, NULL, NULL, NULL, NULL, 3, 1, N'#0ea5e9', N'<i data-lucide="Building2"></i>', '2026-09-17T16:13:36.297Z', N'1000000', '2026-11-06T20:28:53.794Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.005.004', N'101.005', N'Identity', NULL, NULL, NULL, N'identity', 4, NULL, NULL, NULL, NULL, NULL, 4, 1, N'#6366f1', N'<i data-lucide="Shield"></i>', '2026-09-17T16:13:36.350Z', N'1000000', '2026-11-06T20:28:53.807Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.005.005', N'101.005', N'Data', NULL, NULL, NULL, N'data', 5, NULL, NULL, NULL, NULL, NULL, 5, 1, N'#0284c7', N'<i data-lucide="Database"></i>', '2026-09-17T16:13:36.396Z', N'1000000', '2026-11-06T20:28:53.813Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.005.006', N'101.005', N'Workflows', NULL, NULL, NULL, N'workflows', 6, NULL, NULL, NULL, NULL, NULL, 6, 1, N'#065f46', N'<i data-lucide="Workflow"></i>', '2026-09-17T16:13:36.449Z', N'1000000', '2026-11-06T20:28:53.819Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.005.007', N'101.005', N'Functions', NULL, NULL, NULL, N'functions', 7, NULL, NULL, NULL, NULL, NULL, 7, 1, N'#0d9488', N'<i data-lucide="FunctionSquare"></i>', '2026-09-17T16:13:36.510Z', N'1000000', '2026-11-06T20:28:53.830Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.005.008', N'101.005', N'Design', NULL, NULL, NULL, N'design', 8, NULL, NULL, NULL, NULL, NULL, 8, 1, N'#8b5cf6', N'<i data-lucide="PenTool"></i>', '2026-09-17T16:13:36.574Z', N'1000000', '2026-11-06T20:28:53.841Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.005.009', N'101.005', N'Packages', NULL, NULL, NULL, N'packages', 9, NULL, NULL, NULL, NULL, NULL, 9, 1, N'#7c3aed', N'<i data-lucide="Package"></i>', '2026-09-17T16:13:36.650Z', N'1000000', '2026-11-06T20:28:53.853Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.005.010', N'101.005', N'Operations', NULL, NULL, NULL, N'operations', 10, NULL, NULL, NULL, NULL, NULL, 10, 1, N'#f59e0b', N'<i data-lucide="Settings"></i>', '2026-09-17T16:13:36.719Z', N'1000000', '2026-11-06T20:28:53.871Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.005.011', N'101.005', N'AI', NULL, NULL, NULL, N'ai', 11, NULL, NULL, NULL, NULL, NULL, 11, 1, N'#a855f7', N'<i data-lucide="Sparkles"></i>', '2026-09-17T16:13:36.790Z', N'1000000', '2026-11-06T20:28:53.886Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.005.012', N'101.005', N'Security', NULL, NULL, NULL, N'security', 12, NULL, NULL, NULL, NULL, NULL, 12, 1, N'#f43f5e', N'<i data-lucide="Lock"></i>', '2026-09-17T16:13:36.890Z', N'1000000', '2026-11-06T20:28:53.900Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.005.013', N'101.005', N'Install', NULL, NULL, NULL, N'install', 13, NULL, NULL, NULL, NULL, NULL, 13, 1, N'#ea580c', N'<i data-lucide="Rocket"></i>', '2026-09-17T16:13:36.976Z', N'1000000', '2026-11-06T20:28:53.913Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.005.014', N'101.005', N'Front office', NULL, NULL, NULL, N'front_office', 14, NULL, NULL, NULL, NULL, NULL, 14, 1, N'#2563eb', N'<i data-lucide="Globe"></i>', '2026-09-17T16:13:37.081Z', N'1000000', '2026-11-06T20:28:53.928Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.005.015', N'101.005', N'How to', NULL, NULL, NULL, N'howto', 15, NULL, NULL, NULL, NULL, NULL, 15, 1, N'#0369a1', N'<i data-lucide="ListChecks"></i>', '2026-09-17T16:13:37.158Z', N'1000000', '2026-11-06T20:28:53.941Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.006.001', N'101.006', N'Automatic', NULL, NULL, NULL, N'auto', 1, NULL, NULL, NULL, NULL, NULL, 1, 1, N'#f59e0b', N'<i data-lucide="Zap"></i>', '2026-09-17T16:13:37.274Z', N'1000000', '2026-11-06T20:28:53.972Z', NULL, NULL, NULL, NULL, NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by], [title_path], [title_path_en], [title_path_fa], [title_path_ar]) VALUES (N'101.006.002', N'101.006', N'Approve', NULL, NULL, NULL, N'approve', 2, NULL, NULL, NULL, NULL, NULL, 2, 1, N'#047857', N'<i data-lucide="ShieldCheck"></i>', '2026-09-17T16:13:37.329Z', N'1000000', '2026-11-06T20:28:53.984Z', NULL, NULL, NULL, NULL, NULL);
