-- Hawiety (HWY) Phase 1 schema (SQL Server)
-- Opt-in only — never run from app bootstrap / controlPlaneSeed.

IF OBJECT_ID(N'dbo.hwy_institutes', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_institutes (
    id                         INT NOT NULL PRIMARY KEY,
    code                       NVARCHAR(4000) NULL,
    title_ar                   NVARCHAR(MAX) NOT NULL,
    is_active                  BIT NOT NULL CONSTRAINT DF_hwy_institutes_is_active DEFAULT 1,
    allows_self_registration   BIT NOT NULL CONSTRAINT DF_hwy_institutes_allows_self_registration DEFAULT 0,
    allows_invite              BIT NOT NULL CONSTRAINT DF_hwy_institutes_allows_invite DEFAULT 1,
    invite_expires_after_days  INT NULL,
    hide_member_phones         BIT NOT NULL CONSTRAINT DF_hwy_institutes_hide_member_phones DEFAULT 0,
    has_dedicated_list         BIT NOT NULL CONSTRAINT DF_hwy_institutes_has_dedicated_list DEFAULT 0,
    logo_url                   NVARCHAR(4000) NULL,
    logo_content               VARBINARY(MAX) NULL,
    logo_content_type          NVARCHAR(127) NULL,
    note                       NVARCHAR(MAX) NULL,
    created_by                 BIGINT NULL,
    created_at                 DATETIME2 NOT NULL CONSTRAINT DF_hwy_institutes_created_at DEFAULT SYSUTCDATETIME(),
    updated_by                 BIGINT NULL,
    updated_at                 DATETIME2 NOT NULL CONSTRAINT DF_hwy_institutes_updated_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_hwy_institutes_created_by FOREIGN KEY (created_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_hwy_institutes_updated_by FOREIGN KEY (updated_by) REFERENCES dbo.base_users(id)
  );
END;
GO

IF OBJECT_ID(N'dbo.hwy_nakhebin', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_nakhebin (
    id               BIGINT NOT NULL PRIMARY KEY,
    family_code      NVARCHAR(4000) NULL,
    first_name       NVARCHAR(MAX) NULL,
    father_name      NVARCHAR(MAX) NULL,
    grandfather_name NVARCHAR(MAX) NULL,
    family_name      NVARCHAR(MAX) NULL,
    birth_year       NVARCHAR(4000) NULL,
    gender_code      NVARCHAR(1000) NULL,
    phone1           NVARCHAR(4000) NULL,
    phone2           NVARCHAR(4000) NULL,
    region_id        NVARCHAR(128) NULL,
    maktab_id        NVARCHAR(128) NULL,
    member_id        BIGINT NULL,
    voted_on_2021    NVARCHAR(4000) NULL,
    voted_on_2023    NVARCHAR(4000) NULL,
    voted_on_2025    NVARCHAR(4000) NULL,
    created_at       DATETIME2 NOT NULL CONSTRAINT DF_hwy_nakhebin_created_at DEFAULT SYSUTCDATETIME(),
    updated_at       DATETIME2 NOT NULL CONSTRAINT DF_hwy_nakhebin_updated_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_hwy_nakhebin_gender_code FOREIGN KEY (gender_code) REFERENCES dbo.base_info(id)
  );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_hwy_nakhebin_member_id' AND object_id = OBJECT_ID(N'dbo.hwy_nakhebin'))
  CREATE INDEX idx_hwy_nakhebin_member_id ON dbo.hwy_nakhebin (member_id);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_hwy_nakhebin_family_code' AND object_id = OBJECT_ID(N'dbo.hwy_nakhebin'))
  CREATE INDEX idx_hwy_nakhebin_family_code ON dbo.hwy_nakhebin (family_code);
GO

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_members (
    id                                BIGINT NOT NULL PRIMARY KEY,
    user_id                           BIGINT NULL,
    username                          NVARCHAR(4000) NULL,
    first_name                        NVARCHAR(MAX) NULL,
    father_name                       NVARCHAR(MAX) NULL,
    grandfather_name                  NVARCHAR(MAX) NULL,
    family_name                       NVARCHAR(MAX) NULL,
    nickname                          NVARCHAR(MAX) NULL,
    gender_code                       NVARCHAR(1000) NULL,
    birth_year                        NVARCHAR(4000) NULL,
    birth_month                       NVARCHAR(4000) NULL,
    birth_day                         NVARCHAR(4000) NULL,
    national_id                       NVARCHAR(4000) NULL,
    phone1                            NVARCHAR(4000) NULL,
    phone2                            NVARCHAR(4000) NULL,
    email                             NVARCHAR(4000) NULL,
    facebook_id                       NVARCHAR(4000) NULL,
    twitter_id                        NVARCHAR(4000) NULL,
    tiktok_id                         NVARCHAR(4000) NULL,
    great_grandfather_name            NVARCHAR(MAX) NULL,
    mother_first_name                 NVARCHAR(MAX) NULL,
    mother_father_name                NVARCHAR(MAX) NULL,
    mother_grandfather_name           NVARCHAR(MAX) NULL,
    addr_province_id                  NVARCHAR(128) NULL,
    addr_district_id                  BIGINT NULL,
    addr_subdistrict_id               BIGINT NULL,
    addr_quarter_name                 NVARCHAR(MAX) NULL,
    addr_quarter_no                   NVARCHAR(4000) NULL,
    addr_alley_no                     NVARCHAR(4000) NULL,
    addr_house_no                     NVARCHAR(4000) NULL,
    addr_nearest_landmark             NVARCHAR(MAX) NULL,
    addr_most_important_place         NVARCHAR(MAX) NULL,
    addr_maktab_id                    NVARCHAR(128) NULL,
    addr_region_id                    NVARCHAR(128) NULL,
    addr_circle_id                    NVARCHAR(128) NULL,
    nakhebin_id                       BIGINT NULL,
    nakhebin_link_type_code           NVARCHAR(1000) NULL,
    nakhebin_link_problem_reason_id   INT NULL,
    nakhebin_link_problem_note        NVARCHAR(MAX) NULL,
    nakhebin_link_region_id           NVARCHAR(128) NULL,
    family_code                       NVARCHAR(4000) NULL,
    voted_on_2021                     NVARCHAR(4000) NULL,
    voted_on_2023                     NVARCHAR(4000) NULL,
    voted_on_2025                     NVARCHAR(4000) NULL,
    membership_status_code            NVARCHAR(1000) NULL,
    registration_channel_code         NVARCHAR(1000) NULL,
    membership_status_updated_on        DATETIME2 NULL,
    membership_status_updated_by        BIGINT NULL,
    membership_on                     DATE NULL,
    referrer_username                 NVARCHAR(4000) NULL,
    referrer_relation_id              INT NULL,
    referrer_institute_id             INT NULL,
    referrer_username_deleted         NVARCHAR(4000) NULL,
    referrer_relation_id_deleted      INT NULL,
    second_referrer_username          NVARCHAR(4000) NULL,
    education_level_code              NVARCHAR(1000) NULL,
    education_level_in_code           NVARCHAR(1000) NULL,
    education_entry_year              NVARCHAR(4000) NULL,
    education_branch                  NVARCHAR(MAX) NULL,
    education_school                  NVARCHAR(MAX) NULL,
    education_end_year                NVARCHAR(4000) NULL,
    education_university_code         NVARCHAR(1000) NULL,
    education_university_faculty_code NVARCHAR(1000) NULL,
    job_type_code                     NVARCHAR(1000) NULL,
    job_place                         NVARCHAR(MAX) NULL,
    mehani_union_code                 NVARCHAR(1000) NULL,
    mehani_union_degree_code          NVARCHAR(1000) NULL,
    mehani_membership_expires_on      DATE NULL,
    chief_masool                        BIT NULL,
    masooliat_sum_stars                 INT NULL,
    masooliat_level_id                  INT NULL,
    masooliat_stars_calculated_on       DATETIME NULL,
    masooliat_sum_stars_current         INT NULL,
    masooliat_level_id_current          INT NULL,
    note                              NVARCHAR(MAX) NULL,
    created_by                        BIGINT NULL,
    created_at                        DATETIME2 NOT NULL CONSTRAINT DF_hwy_members_created_at DEFAULT SYSUTCDATETIME(),
    updated_by                        BIGINT NULL,
    updated_at                        DATETIME2 NOT NULL CONSTRAINT DF_hwy_members_updated_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_hwy_members_user_id FOREIGN KEY (user_id) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_hwy_members_gender_code FOREIGN KEY (gender_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_members_nakhebin_id FOREIGN KEY (nakhebin_id) REFERENCES dbo.hwy_nakhebin(id) ON DELETE SET NULL,
    CONSTRAINT FK_hwy_members_nakhebin_link_type_code FOREIGN KEY (nakhebin_link_type_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_members_membership_status_code FOREIGN KEY (membership_status_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_members_registration_channel_code FOREIGN KEY (registration_channel_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_members_membership_status_updated_by FOREIGN KEY (membership_status_updated_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_hwy_members_education_level_code FOREIGN KEY (education_level_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_members_education_level_in_code FOREIGN KEY (education_level_in_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_members_education_university_code FOREIGN KEY (education_university_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_members_education_university_faculty_code FOREIGN KEY (education_university_faculty_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_members_job_type_code FOREIGN KEY (job_type_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_members_mehani_union_code FOREIGN KEY (mehani_union_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_members_mehani_union_degree_code FOREIGN KEY (mehani_union_degree_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_members_created_by FOREIGN KEY (created_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_hwy_members_updated_by FOREIGN KEY (updated_by) REFERENCES dbo.base_users(id)
  );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_hwy_members_membership_status' AND object_id = OBJECT_ID(N'dbo.hwy_members'))
  CREATE INDEX idx_hwy_members_membership_status ON dbo.hwy_members (membership_status_code);
GO

IF EXISTS (SELECT 1 FROM sys.key_constraints WHERE name = N'UQ_hwy_members_user_id' AND parent_object_id = OBJECT_ID(N'dbo.hwy_members'))
  ALTER TABLE dbo.hwy_members DROP CONSTRAINT UQ_hwy_members_user_id;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UQ_hwy_members_user_id' AND object_id = OBJECT_ID(N'dbo.hwy_members'))
  CREATE UNIQUE INDEX UQ_hwy_members_user_id ON dbo.hwy_members (user_id) WHERE user_id IS NOT NULL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_hwy_members_phone1' AND object_id = OBJECT_ID(N'dbo.hwy_members'))
  CREATE INDEX idx_hwy_members_phone1 ON dbo.hwy_members (phone1);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_hwy_members_nakhebin_id' AND object_id = OBJECT_ID(N'dbo.hwy_members'))
  CREATE INDEX idx_hwy_members_nakhebin_id ON dbo.hwy_members (nakhebin_id);
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_hwy_nakhebin_member_id')
BEGIN
  ALTER TABLE dbo.hwy_nakhebin
    ADD CONSTRAINT FK_hwy_nakhebin_member_id
    FOREIGN KEY (member_id) REFERENCES dbo.hwy_members(id) ON DELETE SET NULL;
END;
GO

IF OBJECT_ID(N'dbo.hwy_member_institutes', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_member_institutes (
    id                          BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    member_id                   BIGINT NOT NULL,
    institute_id                INT NOT NULL,
    status_code                 NVARCHAR(1000) NULL,
    join_path_code              NVARCHAR(1000) NULL,
    invited_by                  BIGINT NULL,
    invited_at                  DATETIME2 NULL,
    member_responded_at         DATETIME2 NULL,
    member_accepted             BIT NULL,
    activated_at                DATETIME2 NULL,
    character_code              NVARCHAR(1000) NULL,
    institute_state_code        NVARCHAR(1000) NULL,
    institute_state_note        NVARCHAR(MAX) NULL,
    institute_state_updated_on  DATETIME2 NULL,
    institute_state_updated_by  BIGINT NULL,
    current_org_employment_id   INT NULL,
    current_org_employment_note NVARCHAR(MAX) NULL,
    created_by                  BIGINT NULL,
    created_at                  DATETIME2 NOT NULL CONSTRAINT DF_hwy_member_institutes_created_at DEFAULT SYSUTCDATETIME(),
    updated_by                  BIGINT NULL,
    updated_at                  DATETIME2 NOT NULL CONSTRAINT DF_hwy_member_institutes_updated_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT UQ_hwy_member_institutes_member_institute UNIQUE (member_id, institute_id),
    CONSTRAINT FK_hwy_member_institutes_member_id FOREIGN KEY (member_id) REFERENCES dbo.hwy_members(id) ON DELETE CASCADE,
    CONSTRAINT FK_hwy_member_institutes_institute_id FOREIGN KEY (institute_id) REFERENCES dbo.hwy_institutes(id),
    CONSTRAINT FK_hwy_member_institutes_status_code FOREIGN KEY (status_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_member_institutes_join_path_code FOREIGN KEY (join_path_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_member_institutes_invited_by FOREIGN KEY (invited_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_hwy_member_institutes_character_code FOREIGN KEY (character_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_member_institutes_institute_state_code FOREIGN KEY (institute_state_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_member_institutes_institute_state_updated_by FOREIGN KEY (institute_state_updated_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_hwy_member_institutes_created_by FOREIGN KEY (created_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_hwy_member_institutes_updated_by FOREIGN KEY (updated_by) REFERENCES dbo.base_users(id)
  );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_hwy_member_institutes_institute' AND object_id = OBJECT_ID(N'dbo.hwy_member_institutes'))
  CREATE INDEX idx_hwy_member_institutes_institute ON dbo.hwy_member_institutes (institute_id);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_hwy_member_institutes_scope' AND object_id = OBJECT_ID(N'dbo.hwy_member_institutes'))
  CREATE INDEX idx_hwy_member_institutes_scope ON dbo.hwy_member_institutes (institute_id, status_code) INCLUDE (member_id);
GO

IF OBJECT_ID(N'dbo.hwy_member_files', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_member_files (
    id                 BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    member_id          BIGINT NOT NULL,
    file_kind_code     NVARCHAR(1000) NOT NULL,
    original_file_name NVARCHAR(MAX) NULL,
    mime               NVARCHAR(4000) NULL,
    size_bytes         BIGINT NULL,
    checksum           NVARCHAR(4000) NULL,
    content            VARBINARY(MAX) NULL,
    thumbnail_content  VARBINARY(MAX) NULL,
    is_approved        BIT NULL,
    created_by         BIGINT NULL,
    created_at         DATETIME2 NOT NULL CONSTRAINT DF_hwy_member_files_created_at DEFAULT SYSUTCDATETIME(),
    updated_by         BIGINT NULL,
    updated_at         DATETIME2 NOT NULL CONSTRAINT DF_hwy_member_files_updated_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_hwy_member_files_member_id FOREIGN KEY (member_id) REFERENCES dbo.hwy_members(id) ON DELETE CASCADE,
    CONSTRAINT FK_hwy_member_files_file_kind_code FOREIGN KEY (file_kind_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_member_files_created_by FOREIGN KEY (created_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_hwy_member_files_updated_by FOREIGN KEY (updated_by) REFERENCES dbo.base_users(id)
  );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_hwy_member_files_member' AND object_id = OBJECT_ID(N'dbo.hwy_member_files'))
  CREATE INDEX idx_hwy_member_files_member ON dbo.hwy_member_files (member_id);
GO

IF OBJECT_ID(N'dbo.hwy_member_notes', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_member_notes (
    id           BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    member_id    BIGINT NOT NULL,
    body         NVARCHAR(MAX) NOT NULL,
    subject_code NVARCHAR(1000) NULL,
    created_by   BIGINT NULL,
    created_at   DATETIME2 NOT NULL CONSTRAINT DF_hwy_member_notes_created_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_hwy_member_notes_member_id FOREIGN KEY (member_id) REFERENCES dbo.hwy_members(id) ON DELETE CASCADE,
    CONSTRAINT FK_hwy_member_notes_subject_code FOREIGN KEY (subject_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_member_notes_created_by FOREIGN KEY (created_by) REFERENCES dbo.base_users(id)
  );
END;
GO

IF OBJECT_ID(N'dbo.hwy_member_targhin_requests', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_member_targhin_requests (
    id                   BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    member_id            BIGINT NOT NULL,
    request_reason_code  NVARCHAR(1000) NULL,
    request_note         NVARCHAR(1024) NULL,
    status_code          NVARCHAR(64) NOT NULL CONSTRAINT DF_hwy_member_targhin_requests_status DEFAULT N'pending',
    created_by   BIGINT NULL,
    created_at   DATETIME2 NOT NULL CONSTRAINT DF_hwy_member_targhin_requests_created_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_hwy_member_targhin_requests_member_id FOREIGN KEY (member_id) REFERENCES dbo.hwy_members(id) ON DELETE CASCADE,
    CONSTRAINT FK_hwy_member_targhin_requests_created_by FOREIGN KEY (created_by) REFERENCES dbo.base_users(id)
  );
  CREATE INDEX IX_hwy_member_targhin_requests_member ON dbo.hwy_member_targhin_requests (member_id, created_at DESC);
END;
GO

IF COL_LENGTH(N'dbo.hwy_member_targhin_requests', N'request_reason_code') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_member_targhin_requests ADD request_reason_code NVARCHAR(1000) NULL;
END;
GO

IF COL_LENGTH(N'dbo.hwy_member_targhin_requests', N'request_reason_code') IS NOT NULL
BEGIN
  ALTER TABLE dbo.hwy_member_targhin_requests ALTER COLUMN request_reason_code NVARCHAR(1000) NULL;
END;
GO

IF NOT EXISTS (
  SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_hwy_member_targhin_requests_reason_code'
)
BEGIN
  ALTER TABLE dbo.hwy_member_targhin_requests WITH NOCHECK
    ADD CONSTRAINT FK_hwy_member_targhin_requests_reason_code
    FOREIGN KEY (request_reason_code) REFERENCES dbo.base_info(id);
END;
GO

IF COL_LENGTH(N'dbo.hwy_member_targhin_requests', N'legacy_targhin_history_id') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_member_targhin_requests ADD legacy_targhin_history_id UNIQUEIDENTIFIER NULL;
END

IF COL_LENGTH(N'dbo.hwy_member_targhin_requests', N'request_by_legacy') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_member_targhin_requests ADD request_by_legacy NVARCHAR(256) NULL;
END;
GO

IF COL_LENGTH(N'dbo.hwy_member_targhin_requests', N'final_reason_code') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_member_targhin_requests ADD final_reason_code NVARCHAR(64) NULL;
END;
GO

IF COL_LENGTH(N'dbo.hwy_member_targhin_requests', N'final_note') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_member_targhin_requests ADD final_note NVARCHAR(1024) NULL;
END;
GO

IF COL_LENGTH(N'dbo.hwy_member_targhin_requests', N'final_by') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_member_targhin_requests ADD final_by BIGINT NULL;
END;
GO

IF COL_LENGTH(N'dbo.hwy_member_targhin_requests', N'final_at') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_member_targhin_requests ADD final_at DATETIME2 NULL;
END;
GO

IF NOT EXISTS (
  SELECT 1 FROM sys.indexes
  WHERE name = N'UX_hwy_member_targhin_requests_legacy_history_id'
    AND object_id = OBJECT_ID(N'dbo.hwy_member_targhin_requests')
)
BEGIN
  CREATE UNIQUE INDEX UX_hwy_member_targhin_requests_legacy_history_id
    ON dbo.hwy_member_targhin_requests (legacy_targhin_history_id)
    WHERE legacy_targhin_history_id IS NOT NULL;
END;
GO

IF OBJECT_ID(N'dbo.hwy_member_security_profile', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_member_security_profile (
    id                          BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    member_id                   BIGINT NOT NULL,
    can_get_identity_card_code  NVARCHAR(1000) NULL,
    can_get_identity_card_note  NVARCHAR(MAX) NULL,
    can_get_responsibility_code NVARCHAR(1000) NULL,
    can_get_responsibility_note NVARCHAR(MAX) NULL,
    can_join_general_body_code  NVARCHAR(1000) NULL,
    can_join_general_body_note  NVARCHAR(MAX) NULL,
    allows_responsibility_code  NVARCHAR(1000) NULL,
    allows_responsibility_note  NVARCHAR(MAX) NULL,
    created_by                  BIGINT NULL,
    created_at                  DATETIME2 NOT NULL CONSTRAINT DF_hwy_member_security_profile_created_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_hwy_member_security_profile_member_id FOREIGN KEY (member_id) REFERENCES dbo.hwy_members(id) ON DELETE CASCADE,
    CONSTRAINT FK_hwy_member_security_profile_can_get_identity_card_code FOREIGN KEY (can_get_identity_card_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_member_security_profile_can_get_responsibility_code FOREIGN KEY (can_get_responsibility_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_member_security_profile_can_join_general_body_code FOREIGN KEY (can_join_general_body_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_member_security_profile_allows_responsibility_code FOREIGN KEY (allows_responsibility_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_member_security_profile_created_by FOREIGN KEY (created_by) REFERENCES dbo.base_users(id)
  );
END;
GO

IF OBJECT_ID(N'dbo.hwy_member_list_defs', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_member_list_defs (
    id              BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    code            NVARCHAR(4000) NOT NULL,
    title_ar        NVARCHAR(MAX) NOT NULL,
    list_logic_code NVARCHAR(1000) NOT NULL,
    institute_id    INT NULL,
    predicate_ref   NVARCHAR(4000) NULL,
    is_active       BIT NOT NULL CONSTRAINT DF_hwy_member_list_defs_is_active DEFAULT 1,
    sort_order      INT NOT NULL CONSTRAINT DF_hwy_member_list_defs_sort_order DEFAULT 0,
    note            NVARCHAR(MAX) NULL,
    created_by      BIGINT NULL,
    created_at      DATETIME2 NOT NULL CONSTRAINT DF_hwy_member_list_defs_created_at DEFAULT SYSUTCDATETIME(),
    updated_by      BIGINT NULL,
    updated_at      DATETIME2 NOT NULL CONSTRAINT DF_hwy_member_list_defs_updated_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT UQ_hwy_member_list_defs_code UNIQUE (code),
    CONSTRAINT FK_hwy_member_list_defs_list_logic_code FOREIGN KEY (list_logic_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_hwy_member_list_defs_institute_id FOREIGN KEY (institute_id) REFERENCES dbo.hwy_institutes(id) ON DELETE SET NULL,
    CONSTRAINT FK_hwy_member_list_defs_created_by FOREIGN KEY (created_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_hwy_member_list_defs_updated_by FOREIGN KEY (updated_by) REFERENCES dbo.base_users(id)
  );
END;
GO

IF OBJECT_ID(N'dbo.hwy_username_repo', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_username_repo (
    id          BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    username    NVARCHAR(4000) NOT NULL,
    member_id   BIGINT NULL,
    reserved_at DATETIME2 NOT NULL CONSTRAINT DF_hwy_username_repo_reserved_at DEFAULT SYSUTCDATETIME(),
    released_at DATETIME2 NULL,
    CONSTRAINT UQ_hwy_username_repo_username UNIQUE (username),
    CONSTRAINT FK_hwy_username_repo_member_id FOREIGN KEY (member_id) REFERENCES dbo.hwy_members(id) ON DELETE SET NULL
  );
END;
GO

IF OBJECT_ID(N'dbo.hwy_geo_responsibility_requests', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_geo_responsibility_requests (
    id                 UNIQUEIDENTIFIER NOT NULL CONSTRAINT DF_hwy_geo_resp_req_id DEFAULT NEWID() PRIMARY KEY,
    member_id          BIGINT NOT NULL,
    user_id            BIGINT NULL,
    geo_level          NVARCHAR(16) NOT NULL,
    geo_base_info_id   NVARCHAR(128) NOT NULL,
    legacy_geo_id      INT NULL,
    role_name          NVARCHAR(128) NOT NULL,
    request_kind       NVARCHAR(32) NOT NULL CONSTRAINT DF_hwy_geo_resp_req_kind DEFAULT N'nomination',
    status             NVARCHAR(32) NOT NULL,
    nominated_by       BIGINT NOT NULL,
    nominated_at       DATETIME2 NOT NULL CONSTRAINT DF_hwy_geo_resp_req_nom_at DEFAULT SYSUTCDATETIME(),
    decided_by         BIGINT NULL,
    decided_at         DATETIME2 NULL,
    decision_note      NVARCHAR(512) NULL,
    revoked_at         DATETIME2 NULL,
    revoked_by         BIGINT NULL,
    CONSTRAINT FK_hwy_geo_resp_req_member FOREIGN KEY (member_id) REFERENCES dbo.hwy_members(id),
    CONSTRAINT FK_hwy_geo_resp_req_user FOREIGN KEY (user_id) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_hwy_geo_resp_req_nom_by FOREIGN KEY (nominated_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_hwy_geo_resp_req_dec_by FOREIGN KEY (decided_by) REFERENCES dbo.base_users(id),
    CONSTRAINT CK_hwy_geo_resp_req_kind CHECK (request_kind IN (N'nomination', N'official_removal'))
  );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_hwy_geo_resp_req_status' AND object_id = OBJECT_ID(N'dbo.hwy_geo_responsibility_requests'))
  CREATE INDEX idx_hwy_geo_resp_req_status ON dbo.hwy_geo_responsibility_requests (status, geo_level, nominated_at DESC);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_hwy_geo_resp_req_geo' AND object_id = OBJECT_ID(N'dbo.hwy_geo_responsibility_requests'))
  CREATE INDEX idx_hwy_geo_resp_req_geo ON dbo.hwy_geo_responsibility_requests (geo_base_info_id, status);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_hwy_geo_resp_req_active_official' AND object_id = OBJECT_ID(N'dbo.hwy_geo_responsibility_requests'))
  CREATE INDEX idx_hwy_geo_resp_req_active_official
    ON dbo.hwy_geo_responsibility_requests (geo_base_info_id, role_name, geo_level, status, revoked_at);
GO

IF COL_LENGTH(N'dbo.hwy_geo_responsibility_requests', N'legacy_area_limits_id') IS NULL
  ALTER TABLE dbo.hwy_geo_responsibility_requests ADD legacy_area_limits_id UNIQUEIDENTIFIER NULL;
GO

IF NOT EXISTS (
  SELECT 1 FROM sys.indexes
  WHERE name = N'idx_hwy_geo_resp_req_legacy_area_limits'
    AND object_id = OBJECT_ID(N'dbo.hwy_geo_responsibility_requests')
)
  CREATE UNIQUE INDEX idx_hwy_geo_resp_req_legacy_area_limits
    ON dbo.hwy_geo_responsibility_requests (legacy_area_limits_id)
    WHERE legacy_area_limits_id IS NOT NULL;
GO
