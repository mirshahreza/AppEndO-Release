-- Denormalized member stats on dbo.hwy_members (AppEndO edge schema — snake_case).

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NULL
BEGIN
  PRINT 'hwy_member_stat_columns skipped — dbo.hwy_members not present';
END
ELSE
BEGIN
  IF COL_LENGTH(N'dbo.hwy_members', N'stat_fields_completed') IS NULL
    ALTER TABLE dbo.hwy_members ADD stat_fields_completed INT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'stat_days') IS NULL
    ALTER TABLE dbo.hwy_members ADD stat_days INT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'stat_dorat_count') IS NULL
    ALTER TABLE dbo.hwy_members ADD stat_dorat_count INT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'stat_kasb_count') IS NULL
    ALTER TABLE dbo.hwy_members ADD stat_kasb_count INT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'stat_nashatat_count') IS NULL
    ALTER TABLE dbo.hwy_members ADD stat_nashatat_count INT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'stat_moassesat_count') IS NULL
    ALTER TABLE dbo.hwy_members ADD stat_moassesat_count INT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'stat_interviews_2022_count') IS NULL
    ALTER TABLE dbo.hwy_members ADD stat_interviews_2022_count INT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'stat_cards_count') IS NULL
    ALTER TABLE dbo.hwy_members ADD stat_cards_count INT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'stat_has_passed_all') IS NULL
    ALTER TABLE dbo.hwy_members ADD stat_has_passed_all BIT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'stat_has_not_tosigh_older_than_x_days') IS NULL
    ALTER TABLE dbo.hwy_members ADD stat_has_not_tosigh_older_than_x_days BIT NULL;

  IF COL_LENGTH(N'dbo.hwy_members', N'stat2_has_passed_all') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'stat_has_passed_all') IS NOT NULL
  BEGIN
    EXEC(N'
      UPDATE dbo.hwy_members
      SET stat_has_passed_all = COALESCE(stat_has_passed_all, stat2_has_passed_all)
      WHERE stat2_has_passed_all IS NOT NULL;
    ');
  END;
  IF COL_LENGTH(N'dbo.hwy_members', N'stat2_has_not_tosigh_older_than_x_days') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'stat_has_not_tosigh_older_than_x_days') IS NOT NULL
  BEGIN
    EXEC(N'
      UPDATE dbo.hwy_members
      SET stat_has_not_tosigh_older_than_x_days = COALESCE(
        stat_has_not_tosigh_older_than_x_days,
        stat2_has_not_tosigh_older_than_x_days
      )
      WHERE stat2_has_not_tosigh_older_than_x_days IS NOT NULL;
    ');
  END;
  IF COL_LENGTH(N'dbo.hwy_members', N'stat2_has_passed_all') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'stat_has_passed_all') IS NULL
    EXEC sys.sp_rename N'dbo.hwy_members.stat2_has_passed_all', N'stat_has_passed_all', N'COLUMN';
  IF COL_LENGTH(N'dbo.hwy_members', N'stat2_has_not_tosigh_older_than_x_days') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'stat_has_not_tosigh_older_than_x_days') IS NULL
    EXEC sys.sp_rename N'dbo.hwy_members.stat2_has_not_tosigh_older_than_x_days', N'stat_has_not_tosigh_older_than_x_days', N'COLUMN';
  IF COL_LENGTH(N'dbo.hwy_members', N'stat_has_passed_all') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'stat2_has_passed_all') IS NOT NULL
    ALTER TABLE dbo.hwy_members DROP COLUMN stat2_has_passed_all;
  IF COL_LENGTH(N'dbo.hwy_members', N'stat_has_not_tosigh_older_than_x_days') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'stat2_has_not_tosigh_older_than_x_days') IS NOT NULL
    ALTER TABLE dbo.hwy_members DROP COLUMN stat2_has_not_tosigh_older_than_x_days;
  IF COL_LENGTH(N'dbo.hwy_members', N'stat_vasaegh_count') IS NULL
    ALTER TABLE dbo.hwy_members ADD stat_vasaegh_count INT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'stat_is_employee') IS NULL
    ALTER TABLE dbo.hwy_members ADD stat_is_employee BIT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'stat_adam_tatbigh_count') IS NULL
    ALTER TABLE dbo.hwy_members ADD stat_adam_tatbigh_count INT NULL;
  IF COL_LENGTH(N'dbo.hwy_members', N'stat_points') IS NULL
    ALTER TABLE dbo.hwy_members ADD stat_points INT NULL;

  PRINT 'hwy member stat columns (snake_case) ensured';
END
GO

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NULL
BEGIN
  PRINT 'hwy_member_stat_columns legacy rename skipped — dbo.hwy_members not present';
END
ELSE
BEGIN
  DECLARE @legacy SYSNAME;
  DECLARE @target SYSNAME;
  DECLARE @rename_sql NVARCHAR(400);
  DECLARE @member_object_id INT = OBJECT_ID(N'dbo.hwy_members');

  DECLARE legacy_cursor CURSOR LOCAL FAST_FORWARD FOR
    SELECT legacy_name, target_name
    FROM (VALUES
      (N'Stat_FieldsCompleted', N'stat_fields_completed'),
      (N'Stat_Days', N'stat_days'),
      (N'Stat_DoratCount', N'stat_dorat_count'),
      (N'Stat_KasbCount', N'stat_kasb_count'),
      (N'Stat_NashatatCount', N'stat_nashatat_count'),
      (N'Stat_Moassesat_Count', N'stat_moassesat_count'),
      (N'Stat_Moghabelat_2022_Count', N'stat_interviews_2022_count'),
      (N'Stat_CardsCount', N'stat_cards_count'),
      (N'Stat2_HasPassedAll', N'stat_has_passed_all'),
      (N'Stat2_HasNotTosighOlderThanXDays', N'stat_has_not_tosigh_older_than_x_days'),
      (N'Stat_Vasaegh_Count', N'stat_vasaegh_count'),
      (N'Stat_IsEmployee', N'stat_is_employee'),
      (N'Stat_AdamTatbighCount', N'stat_adam_tatbigh_count'),
      (N'Stat_Points', N'stat_points')
    ) AS map(legacy_name, target_name);

  OPEN legacy_cursor;
  FETCH NEXT FROM legacy_cursor INTO @legacy, @target;
  WHILE @@FETCH_STATUS = 0
  BEGIN
    IF EXISTS (
      SELECT 1
      FROM sys.columns c
      WHERE c.object_id = @member_object_id
        AND c.name = @legacy COLLATE Latin1_General_CS_AS
    )
    AND NOT EXISTS (
      SELECT 1
      FROM sys.columns c
      WHERE c.object_id = @member_object_id
        AND c.name = @target COLLATE Latin1_General_CS_AS
    )
    BEGIN
      SET @rename_sql = N'EXEC sys.sp_rename @objname = N''dbo.hwy_members.' + REPLACE(@legacy, N'''', N'''''') + N''', @newname = @target, @objtype = N''COLUMN'';';
      EXEC sp_executesql @rename_sql, N'@target SYSNAME', @target = @target;
    END
    FETCH NEXT FROM legacy_cursor INTO @legacy, @target;
  END
  CLOSE legacy_cursor;
  DEALLOCATE legacy_cursor;

  PRINT 'hwy member stat legacy columns migrated';
END
GO
