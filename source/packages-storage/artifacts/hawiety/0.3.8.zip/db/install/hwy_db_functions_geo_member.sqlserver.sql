SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER FUNCTION dbo.hwy_geo_member_is_male(@gender_code NVARCHAR(128))
RETURNS BIT
AS
BEGIN
  IF @gender_code IS NULL RETURN 0;
  IF @gender_code = N'100.1.1' RETURN 1;
  IF @gender_code LIKE N'%10011%' RETURN 1;
  IF LOWER(@gender_code) LIKE N'%male%' RETURN 1;
  IF @gender_code LIKE N'%ذكر%' RETURN 1;
  RETURN 0;
END;
GO

CREATE OR ALTER FUNCTION dbo.hwy_geo_member_is_female(@gender_code NVARCHAR(128))
RETURNS BIT
AS
BEGIN
  IF @gender_code IS NULL RETURN 0;
  IF @gender_code = N'100.1.2' RETURN 1;
  IF @gender_code LIKE N'%10012%' RETURN 1;
  IF LOWER(@gender_code) LIKE N'%female%' RETURN 1;
  IF @gender_code LIKE N'%انث%' RETURN 1;
  IF @gender_code LIKE N'%أنث%' RETURN 1;
  RETURN 0;
END;
GO

CREATE OR ALTER FUNCTION dbo.hwy_geo_members_same_gender_partition(
  @left_gender NVARCHAR(128),
  @right_gender NVARCHAR(128)
)
RETURNS BIT
AS
BEGIN
  IF dbo.hwy_geo_member_is_male(@left_gender) = 1 AND dbo.hwy_geo_member_is_male(@right_gender) = 1 RETURN 1;
  IF dbo.hwy_geo_member_is_female(@left_gender) = 1 AND dbo.hwy_geo_member_is_female(@right_gender) = 1 RETURN 1;
  RETURN 0;
END;
GO
