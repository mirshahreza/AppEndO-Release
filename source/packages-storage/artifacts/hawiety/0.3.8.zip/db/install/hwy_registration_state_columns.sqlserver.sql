SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF COL_LENGTH(N'dbo.hwy_members', N'nakhebin_join_tasjil_state_code') IS NULL
  ALTER TABLE dbo.hwy_members ADD nakhebin_join_tasjil_state_code NVARCHAR(1000) NULL;
GO

IF COL_LENGTH(N'dbo.hwy_members', N'registration_channel_code') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_members ADD registration_channel_code NVARCHAR(1000) NULL;
  IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_hwy_members_registration_channel_code'
  )
    ALTER TABLE dbo.hwy_members ADD CONSTRAINT FK_hwy_members_registration_channel_code
      FOREIGN KEY (registration_channel_code) REFERENCES dbo.base_info(id);
END
GO

IF COL_LENGTH(N'dbo.hwy_nakhebin', N'registered_case_code') IS NULL
  ALTER TABLE dbo.hwy_nakhebin ADD registered_case_code NVARCHAR(1000) NULL;
GO

PRINT 'hwy registration state columns ready';
