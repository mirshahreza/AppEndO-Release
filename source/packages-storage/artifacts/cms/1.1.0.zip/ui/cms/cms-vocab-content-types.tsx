import React from 'react';
import { buildAppTableGridColumns } from '@/domain/component-designer/DesignerRuntimeAppTableGrid';
import { applyClientGridQuery, EMPTY_GRID_QUERY, type GridQueryState } from '@/shared/lib/appTableGridQuery';
import { resolveDataGridTotalCount, sliceDataGridRowsForDisplay, buildDataGridPageNumbers } from '@/domain/component-designer/designerDataGridRuntime';
import { applyDesignerGridToolbarClientFilters } from '@/domain/component-designer/designerGridToolbarConfig';
import { createDefaultColumnLayout } from '@/shared/lib/appTableGridColumnLayout';
import { validateDesignerFieldNode } from '@/domain/component-designer/previewFieldValidation';
import { AppTableGrid, GridPagingFooter } from '@/shared/ui';
import { UiInput } from '@/shared/ui/HeroFieldControls';
import { Button, Modal, Switch, Toast, toast } from '@heroui/react';

const parseApiErrorMessage = async (response: Response): Promise<string> => {
  try {
    const payload = await response.json();
    if (payload && typeof payload === "object") {
      const record = payload as Record<string, unknown>;
      const message = record.message ?? record.error ?? record.detail;
      if (typeof message === "string" && message.trim().length > 0) {
        return message.trim();
      }
    }
  } catch {
    // fall through to status text
  }
  return response.statusText || `Request failed (${response.status})`;
};

const readBindingParamValue = (
  context: Record<string, unknown> | null | undefined,
  dataPath: string,
): unknown => {
  const segments = dataPath.split(".").map((segment) => segment.trim()).filter(Boolean);
  let cursor: unknown = context;
  for (const segment of segments) {
    if (cursor && typeof cursor === "object" && segment in (cursor as Record<string, unknown>)) {
      cursor = (cursor as Record<string, unknown>)[segment];
    } else {
      return undefined;
    }
  }
  return cursor;
};

const resolveBindingTemplateValue = (
  template: string,
  context: Record<string, unknown> | null | undefined,
  paramPaths: Record<string, string>,
): string =>
  template.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, paramName: string) => {
    const dataPath = paramPaths[paramName];
    if (!dataPath) {
      return "";
    }
    const cursor = readBindingParamValue(context, dataPath);
    return cursor === undefined || cursor === null ? "" : String(cursor);
  });

const resolveBindingUrl = (
  endpointTemplate: string,
  context: Record<string, unknown> | null | undefined,
  paramPaths: Record<string, string>,
): string => {
  const usedParamNames = new Set<string>();
  let resolvedPath = endpointTemplate.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, paramName: string) => {
    usedParamNames.add(paramName);
    const dataPath = paramPaths[paramName];
    if (!dataPath) {
      return "";
    }
    const cursor = readBindingParamValue(context, dataPath);
    return cursor === undefined || cursor === null ? "" : String(cursor);
  });
  for (const [paramName, dataPath] of Object.entries(paramPaths)) {
    if (usedParamNames.has(paramName)) {
      continue;
    }
    const colonParamPattern = new RegExp(`:${paramName}(?=/|$)`, "g");
    if (!colonParamPattern.test(resolvedPath)) {
      continue;
    }
    usedParamNames.add(paramName);
    const cursor = readBindingParamValue(context, dataPath);
    const text = cursor === undefined || cursor === null ? "" : String(cursor);
    resolvedPath = resolvedPath.replace(new RegExp(`:${paramName}(?=/|$)`, "g"), text);
  }
  const searchParams = new URLSearchParams();
  for (const [paramName, dataPath] of Object.entries(paramPaths)) {
    if (usedParamNames.has(paramName)) {
      continue;
    }
    const cursor = readBindingParamValue(context, dataPath);
    if (cursor === undefined || cursor === null) {
      continue;
    }
    const text = String(cursor).trim();
    if (text.length === 0) {
      continue;
    }
    searchParams.set(paramName, text);
  }
  const queryString = searchParams.toString();
  if (!queryString) {
    return resolvedPath;
  }
  return resolvedPath.includes("?") ? `${resolvedPath}&${queryString}` : `${resolvedPath}?${queryString}`;
};

const resolveBindingHeaders = (
  context: Record<string, unknown> | null | undefined,
  headerTemplates: Record<string, string>,
  paramPaths: Record<string, string>,
): Record<string, string> =>
  Object.fromEntries(
    Object.entries(headerTemplates).map(([key, template]) => [
      key,
      resolveBindingTemplateValue(template, context, paramPaths),
    ]),
  );

const setNestedPayloadValue = (target: Record<string, unknown>, path: string, value: unknown): void => {
  const segments = path.split(".").map((segment) => segment.trim()).filter(Boolean);
  if (segments.length === 0) {
    return;
  }
  let cursor: Record<string, unknown> = target;
  for (let index = 0; index < segments.length - 1; index += 1) {
    const segment = segments[index];
    const next = cursor[segment];
    if (!next || typeof next !== "object" || Array.isArray(next)) {
      cursor[segment] = {};
    }
    cursor = cursor[segment] as Record<string, unknown>;
  }
  cursor[segments[segments.length - 1]] = value;
};

const mapDesignerListBoxItems = (rawItems: unknown): Array<{ id: string; textValue: string }> => {
  const items = Array.isArray(rawItems) ? rawItems : [];
  return items
    .map((entry) => {
      if (!entry || typeof entry !== "object") {
        return null;
      }
      const record = entry as Record<string, unknown>;
      const id = String(record.id ?? "").trim();
      if (!id || id === "100" || id === "102") {
        return null;
      }
      const textValue = String(record.textValue ?? record.label ?? record.title ?? id).trim();
      return { id, textValue: textValue || id };
    })
    .filter((entry): entry is { id: string; textValue: string } => entry !== null);
};

const mapDesignerLovItems = (
  rawItems: unknown,
  returnColumn: string,
  displayColumn: string,
): Array<{ id: string; textValue: string }> => {
  const items = Array.isArray(rawItems) ? rawItems : [];
  return items
    .map((entry) => {
      if (!entry || typeof entry !== "object") {
        return null;
      }
      const record = entry as Record<string, unknown>;
      const id = String(record[returnColumn] ?? "").trim();
      if (!id) {
        return null;
      }
      const textValue = String(record[displayColumn] ?? id).trim();
      return { id, textValue: textValue || id };
    })
    .filter((entry): entry is { id: string; textValue: string } => entry !== null);
};

const collectRegionFormDataFromContainer = (
  container: ParentNode,
  formFieldNames: readonly string[],
): FormData => {
  const formData = new FormData();
  for (const formFieldName of formFieldNames) {
    const escapedName = formFieldName.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    const field = container.querySelector(`[name="${escapedName}"]`);
    if (!field) {
      continue;
    }
    if (field instanceof HTMLInputElement) {
      if (field.type === "checkbox" || field.type === "radio") {
        formData.set(formFieldName, field.checked ? "true" : "false");
      } else {
        formData.set(formFieldName, field.value);
      }
      continue;
    }
    if (field instanceof HTMLTextAreaElement || field instanceof HTMLSelectElement) {
      formData.set(formFieldName, field.value);
      continue;
    }
    formData.set(formFieldName, field.getAttribute("value") ?? "");
  }
  return formData;
};

const applyPayloadFieldTransform = (value: FormDataEntryValue | null, transform?: string): unknown => {
  const raw = value === null ? "" : String(value);
  switch (transform) {
    case "number": {
      const parsed = Number(raw);
      return Number.isFinite(parsed) ? parsed : raw;
    }
    case "boolean":
      return raw === "true" || raw === "1" || raw === "on";
    case "commaSeparatedArray":
      return raw.split(",").map((entry) => entry.trim()).filter(Boolean);
    default:
      return raw;
  }
};

// --- AUTH / TOKEN LIFECYCLE INJECTION POINT ---
// Register your application-wide 401 interceptor and token refresh handler here before production.
// Example: const designerFetch = createAuthenticatedFetch({ getAccessToken, refreshTokens, onSessionExpired });
const designerFetch: typeof fetch = fetch;

function useDataFetch<T>(url: string, options: { headers?: Record<string, string> } = {}) {
  const [data, setData] = React.useState<T | null>(null);
  const [isLoading, setIsLoading] = React.useState(Boolean(url));
  const [error, setError] = React.useState<string | null>(null);
  const [refreshNonce, setRefreshNonce] = React.useState(0);
  const headersKey = JSON.stringify(options.headers ?? {});

  const refresh = React.useCallback(async () => {
    setRefreshNonce((previous) => previous + 1);
  }, []);

  React.useEffect(() => {
    if (!url) {
      setData(null);
      setIsLoading(false);
      setError(null);
      return undefined;
    }

    let cancelled = false;
    const load = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const response = await designerFetch(url, {
          method: "GET",
          headers: options.headers,
        });
        if (!response.ok) {
          throw new Error(await parseApiErrorMessage(response));
        }
        const payload = (await response.json()) as T;
        if (!cancelled) {
          setData(payload);
        }
      } catch (loadError) {
        if (!cancelled) {
          setData(null);
          setError(loadError instanceof Error ? loadError.message : "Request failed");
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, [url, headersKey, refreshNonce]);

  return { data, isLoading, error, refresh };
}

const readNestedContextValue = (
  context: Record<string, unknown> | null | undefined,
  path: string,
): unknown => {
  const segments = path.split(".").map((segment) => segment.trim()).filter(Boolean);
  let cursor: unknown = context;
  for (const segment of segments) {
    if (cursor && typeof cursor === "object" && segment in (cursor as Record<string, unknown>)) {
      cursor = (cursor as Record<string, unknown>)[segment];
    } else {
      return undefined;
    }
  }
  return cursor;
};

const applyResponseDataPath = (
  payload: unknown,
  responseMapping?: { dataPath?: string; arrayPath?: string },
): unknown => {
  if (!responseMapping) {
    return payload;
  }
  const arrayPath = responseMapping.arrayPath?.trim();
  if (arrayPath) {
    const arrayValue = readNestedContextValue(
      payload && typeof payload === "object" ? payload as Record<string, unknown> : {},
      arrayPath,
    );
    if (Array.isArray(arrayValue)) {
      return arrayValue;
    }
  }
  const dataPath = responseMapping.dataPath?.trim();
  if (!dataPath || !payload || typeof payload !== "object") {
    return payload;
  }
  return readNestedContextValue(payload as Record<string, unknown>, dataPath);
};

const coerceApiRecordValue = (value: unknown): Record<string, unknown> | undefined => {
  if (value === undefined || value === null) {
    return undefined;
  }
  if (Array.isArray(value)) {
    return value.find(
      (entry): entry is Record<string, unknown> =>
        typeof entry === "object" && entry !== null && !Array.isArray(entry),
    );
  }
  if (typeof value === "object") {
    return value as Record<string, unknown>;
  }
  return undefined;
};

const transformApiRowsToChartData = (
  rows: Array<Record<string, unknown>>,
  mapping: { categoryField: string; categoryAs?: string; series: Array<{ apiField: string; seriesKey: string; aggregation?: string }> },
): Array<Record<string, string | number>> => {
  const categoryKey = mapping.categoryAs?.trim() || "label";
  const parseNum = (raw: unknown): number => {
    if (typeof raw === "number" && Number.isFinite(raw)) return raw;
    if (typeof raw === "string") { const p = Number(raw); return Number.isFinite(p) ? p : 0; }
    return 0;
  };
  const aggregate = (values: number[], agg: string): number => {
    if (values.length === 0) return 0;
    if (agg === "count") return values.length;
    if (agg === "avg") return values.reduce((s, v) => s + v, 0) / values.length;
    if (agg === "min") return Math.min(...values);
    if (agg === "max") return Math.max(...values);
    if (agg === "sum") return values.reduce((s, v) => s + v, 0);
    return values[0] ?? 0;
  };
  const needsGrouping = mapping.series.some((s) => s.aggregation && s.aggregation !== "none");
  if (!needsGrouping) {
    return rows.map((row) => {
      const chartRow: Record<string, string | number> = { [categoryKey]: String(row[mapping.categoryField] ?? "") };
      for (const series of mapping.series) { chartRow[series.seriesKey] = parseNum(row[series.apiField]); }
      return chartRow;
    });
  }
  const grouped = new Map<string, Array<Record<string, unknown>>>();
  for (const row of rows) {
    const cat = String(row[mapping.categoryField] ?? "");
    const bucket = grouped.get(cat);
    if (bucket) bucket.push(row); else grouped.set(cat, [row]);
  }
  return Array.from(grouped.entries()).map(([category, groupRows]) => {
    const chartRow: Record<string, string | number> = { [categoryKey]: category };
    for (const series of mapping.series) {
      const values = groupRows.map((r) => parseNum(r[series.apiField]));
      chartRow[series.seriesKey] = aggregate(values, series.aggregation ?? "sum");
    }
    return chartRow;
  });
};

const readVizStringField = (row: Record<string, unknown>, field: string, fallback = ""): string => {
  const value = row[field];
  if (value === undefined || value === null) return fallback;
  return String(value);
};

const transformApiRowsToTreeNodes = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "tree"; idField: string; labelField: string; parentIdField?: string },
): Array<{ id: string; label: string; children?: unknown[] }> => {
  const parentField = mapping.parentIdField?.trim();
  if (!parentField) {
    return rows.map((row, index) => ({
      id: readVizStringField(row, mapping.idField, `node-${index + 1}`),
      label: readVizStringField(row, mapping.labelField, `Item ${index + 1}`),
    }));
  }
  const nodeMap = new Map<string, { id: string; label: string; children: unknown[] }>();
  rows.forEach((row) => {
    const id = readVizStringField(row, mapping.idField);
    if (!id) return;
    nodeMap.set(id, { id, label: readVizStringField(row, mapping.labelField, id), children: [] });
  });
  const roots: Array<{ id: string; label: string; children?: unknown[] }> = [];
  rows.forEach((row) => {
    const id = readVizStringField(row, mapping.idField);
    if (!id) return;
    const node = nodeMap.get(id);
    if (!node) return;
    const parentId = readVizStringField(row, parentField);
    if (parentId && nodeMap.has(parentId)) {
      nodeMap.get(parentId)!.children.push(node);
    } else {
      roots.push(node);
    }
  });
  return roots;
};

const readVizNumberField = (row: Record<string, unknown>, field: string): number | undefined => {
  const value = row[field];
  const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(parsed) ? parsed : undefined;
};

const transformApiRowsToTimelineEvents = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "timeline" | "gantt"; idField?: string; titleField: string; startField: string; endField?: string; descriptionField?: string; progressField?: string },
): Array<{ id?: string; title: string; start: string; end?: string; description?: string; progress?: number }> =>
  rows.map((row, index) => {
    const progress = mapping.progressField ? readVizNumberField(row, mapping.progressField) : undefined;
    return {
      id: mapping.idField ? readVizStringField(row, mapping.idField, `evt-${index + 1}`) : `evt-${index + 1}`,
      title: readVizStringField(row, mapping.titleField, `Event ${index + 1}`),
      start: readVizStringField(row, mapping.startField),
      ...(mapping.endField ? { end: readVizStringField(row, mapping.endField) } : {}),
      ...(mapping.descriptionField ? { description: readVizStringField(row, mapping.descriptionField) } : {}),
      ...(progress !== undefined ? { progress } : {}),
    };
  });

const transformApiRowsToKanbanBoard = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "kanban"; cardIdField: string; cardTitleField: string; cardDescriptionField?: string; cardColumnField: string; columnOrder?: Array<{ id: string; title: string }> },
): { columns: Array<{ id: string; title: string; cards: Array<{ id: string; title: string; description?: string }> }> } => {
  const cardsByColumn = new Map<string, Array<{ id: string; title: string; description?: string }>>();
  rows.forEach((row, index) => {
    const columnKey = readVizStringField(row, mapping.cardColumnField, "default");
    const card = {
      id: readVizStringField(row, mapping.cardIdField, `card-${index + 1}`),
      title: readVizStringField(row, mapping.cardTitleField, `Card ${index + 1}`),
      ...(mapping.cardDescriptionField ? { description: readVizStringField(row, mapping.cardDescriptionField) } : {}),
    };
    cardsByColumn.set(columnKey, [...(cardsByColumn.get(columnKey) ?? []), card]);
  });
  const columnOrder = mapping.columnOrder && mapping.columnOrder.length > 0
    ? mapping.columnOrder
    : Array.from(cardsByColumn.keys()).map((key) => ({ id: key, title: key }));
  const columns = columnOrder.map((columnDef) => ({
    id: columnDef.id,
    title: columnDef.title,
    cards: cardsByColumn.get(columnDef.id) ?? cardsByColumn.get(columnDef.title) ?? [],
  }));
  cardsByColumn.forEach((cards, columnKey) => {
    if (!columns.some((column) => column.id === columnKey || column.title === columnKey)) {
      columns.push({ id: columnKey, title: columnKey, cards });
    }
  });
  return { columns };
};

const transformApiRowsToSheetData = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "sheet"; columns: Array<{ header: string; field: string }> },
): { columns: string[]; rows: string[][] } => ({
  columns: mapping.columns.map((column) => column.header),
  rows: rows.map((row) => mapping.columns.map((column) => readVizStringField(row, column.field))),
});

type EntityPickerOption = { id: string; textValue: string };
type EntityPickerFieldMapping = { returnField: string; displayField: string };

function normalizeEntityPickerItems(payload: unknown, mapping?: EntityPickerFieldMapping): EntityPickerOption[] {
  const returnField = mapping?.returnField?.trim() || "id";
  const displayField = mapping?.displayField?.trim() || "label";
  if (Array.isArray(payload)) {
    return payload
      .map((entry) => {
        if (!entry || typeof entry !== "object") {
          return null;
        }
        const record = entry as Record<string, unknown>;
        const mappedId = record[returnField];
        const id = typeof mappedId === "string" && mappedId.trim()
          ? mappedId.trim()
          : typeof record.id === "string" && record.id.trim()
            ? record.id.trim()
            : typeof record.value === "string" && record.value.trim()
              ? record.value.trim()
              : "";
        const mappedLabel = record[displayField];
        const textValue = typeof mappedLabel === "string" && mappedLabel.trim()
          ? mappedLabel.trim()
          : typeof record.textValue === "string" && record.textValue.trim()
            ? record.textValue.trim()
            : typeof record.label === "string" && record.label.trim()
              ? record.label.trim()
              : typeof record.name === "string" && record.name.trim()
                ? record.name.trim()
                : id;
        if (!id || !textValue) {
          return null;
        }
        return { id, textValue };
      })
      .filter((entry): entry is EntityPickerOption => entry !== null);
  }

  if (payload && typeof payload === "object") {
    const record = payload as Record<string, unknown>;
    const items = record.items ?? record.results ?? record.data;
    return normalizeEntityPickerItems(items, mapping);
  }

  return [];
}

function useEntityPickerOptions(entityRef: string, searchParam: string, mapping?: EntityPickerFieldMapping) {
  const [items, setItems] = React.useState<EntityPickerOption[]>([]);
  const [isLoading, setIsLoading] = React.useState(false);

  const loadOptions = React.useCallback(async (query: string) => {
    if (!entityRef) {
      setItems([]);
      return;
    }

    setIsLoading(true);
    try {
      const url = entityRef.startsWith("http")
        ? new URL(entityRef)
        : new URL(entityRef, window.location.origin);
      // Option A (parity audit items 31/32): Autocomplete is Select-based — no live typing.
      // Still honour an explicit non-empty query if a caller passes one, but initial load uses "".
      if (query.trim()) {
        url.searchParams.set(searchParam, query);
      }
      const response = await fetch(url.toString());
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      const payload = await response.json();
      setItems(normalizeEntityPickerItems(payload, mapping));
    } catch {
      setItems([]);
    } finally {
      setIsLoading(false);
    }
  }, [entityRef, searchParam, mapping?.returnField, mapping?.displayField]);

  React.useEffect(() => {
    void loadOptions("");
  }, [loadOptions]);

  return { items, isLoading, loadOptions };
}
function useDesignerStore<T extends Record<string, unknown>>(initial: T) {
  const [store, setStore] = React.useState<T>(initial);
  const patch = React.useCallback((path: string, value: unknown) => {
    setStore((previous) => {
      const next = { ...previous };
      setNestedPayloadValue(next, path, value);
      return next as T;
    });
  }, []);
  return { store, patch };
}
function evaluateDesignerCondition(
  designerStore: Record<string, unknown>,
  dataContext: Record<string, unknown> | null,
  scope: { item?: unknown; index?: number },
  condition: string,
): boolean {
  const trimmed = condition.trim();
  if (!trimmed) {
    return true;
  }
  try {
    const formatPathChain = (root: string, path: string): string => {
      const chain = path
        .split('.')
        .filter(Boolean)
        .map((segment) => {
          if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(segment)) {
            return `?.${segment}`;
          }
          return `?.[${JSON.stringify(segment)}]`;
        })
        .join('');
      return `(${root}${chain})`;
    };
    let compiled = trimmed
      .replace(/\bstore\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('designerStore', path))
      .replace(/\bdata\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('dataContext', path))
      .replace(/\bdataContext\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('dataContext', path));
    const evaluator = new Function('designerStore', 'dataContext', 'item', 'index', `return Boolean(${compiled});`);
    return Boolean(evaluator(designerStore, dataContext, scope.item, scope.index));
  } catch {
    return false;
  }
}

export const GeneratedComponent: React.FC = () => {
  const { store: designerStore, patch: patchDesignerStore } = useDesignerStore<Record<string, unknown>>({"selection":{"id":null}});
  const { data: raw_regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d, isLoading: isLoading_regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d, error: error_regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d, refresh: refresh_regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d } = useDataFetch<unknown>("/api/base-info", {});
  const regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d, {"dataPath":"items","arrayPath":"items","totalPath":"count"})), [raw_regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d]);
  const { data: raw_regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6, isLoading: isLoading_regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6, error: error_regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6, refresh: refresh_regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6 } = useDataFetch<unknown>(resolveBindingUrl("/api/base-info", designerStore, { "id": "selection.id" }), {});
  const regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6 = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6, {"dataPath":"items","arrayPath":"items","totalPath":"count"})), [raw_regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6]);
  const handleGridRowAction_heroui_app_table_grid_1785520942714_3omfy = React.useCallback((row: Record<string, unknown>, actionId: string) => {
    switch (actionId) {
      case "edit": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-6f104feb-eb0f-4905-b7f5-3b0e8a4d8bc0", true);
        return;
      }
      case "delete": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-f0a885e5-37a8-435e-8c22-42bfb91d8506", true);
        return;
      }
      default:
        return;
    }
  }, [patchDesignerStore]);
  const { data: raw_gridData_heroui_app_table_grid_1785520942714_3omfy, isLoading: isLoading_gridData_heroui_app_table_grid_1785520942714_3omfy, error: error_gridData_heroui_app_table_grid_1785520942714_3omfy, refresh: refresh_gridData_heroui_app_table_grid_1785520942714_3omfy } = useDataFetch<unknown>(resolveBindingUrl("/api/base-info/children?parentId=101.001&includeInactive=true", designerStore, { "search": "gridToolbar.search", "sortBy": "gridQuery.sortBy", "sortDir": "gridQuery.sortDir", "page": "gridQuery.page", "pageSize": "gridQuery.pageSize", "title": "gridQuery.filters.title" }), {});
  const gridData_heroui_app_table_grid_1785520942714_3omfy = React.useMemo(() => applyResponseDataPath(raw_gridData_heroui_app_table_grid_1785520942714_3omfy, {"dataPath":"items","arrayPath":"items","totalPath":"count"}), [raw_gridData_heroui_app_table_grid_1785520942714_3omfy]);
  const gridColumns_heroui_app_table_grid_1785520942714_3omfy = React.useMemo(() => buildAppTableGridColumns([{"key":"title","label":"Title","sort":true,"filter":true,"filterType":"text","cardRole":"title"},{"key":"actions","label":"","kind":"action-group","actions":[{"actionId":"edit","icon":"Pencil","intent":"edit","tooltip":"Edit","behavior":{"kind":"open-modal","modalNodeId":"node-6f104feb-eb0f-4905-b7f5-3b0e8a4d8bc0","primaryKeyField":"id","selectionStorePath":"selection.id"}},{"actionId":"delete","icon":"Trash2","intent":"delete","tooltip":"Delete","behavior":{"kind":"open-modal","modalNodeId":"node-f0a885e5-37a8-435e-8c22-42bfb91d8506","primaryKeyField":"id","selectionStorePath":"selection.id"}}],"cardRole":"actions","layoutHideable":false,"layoutResizable":false,"layoutReorderable":false,"width":"140px"}], "server", {
    mode: 'runtime',
    detailFlowRef: { current: null },
    rowActionHandlerRef: { current: handleGridRowAction_heroui_app_table_grid_1785520942714_3omfy },
    cellClickHandlerRef: { current: undefined },
    designerStoreRef: { current: designerStore },
  }), [designerStore, handleGridRowAction_heroui_app_table_grid_1785520942714_3omfy]);
  const [gridQuery_heroui_app_table_grid_1785520942714_3omfy, setGridQuery_heroui_app_table_grid_1785520942714_3omfy] = React.useState<GridQueryState>(() => ({ ...EMPTY_GRID_QUERY, sort: { columnId: "viewOrder", direction: 'asc' } }));
  const [gridPage_heroui_app_table_grid_1785520942714_3omfy, setGridPage_heroui_app_table_grid_1785520942714_3omfy] = React.useState(1);
  const [gridPageSize_heroui_app_table_grid_1785520942714_3omfy, setGridPageSize_heroui_app_table_grid_1785520942714_3omfy] = React.useState(50);
  const [gridListMode_heroui_app_table_grid_1785520942714_3omfy, setGridListMode_heroui_app_table_grid_1785520942714_3omfy] = React.useState<'paging' | 'infinite'>("paging");
  const [gridColumnLayout_heroui_app_table_grid_1785520942714_3omfy, setGridColumnLayout_heroui_app_table_grid_1785520942714_3omfy] = React.useState(() => createDefaultColumnLayout(gridColumns_heroui_app_table_grid_1785520942714_3omfy));
  const [gridSearchInput_heroui_app_table_grid_1785520942714_3omfy, setGridSearchInput_heroui_app_table_grid_1785520942714_3omfy] = React.useState('');
  const [gridDebouncedSearch_heroui_app_table_grid_1785520942714_3omfy, setGridDebouncedSearch_heroui_app_table_grid_1785520942714_3omfy] = React.useState('');
  const [gridRoleFilters_heroui_app_table_grid_1785520942714_3omfy, setGridRoleFilters_heroui_app_table_grid_1785520942714_3omfy] = React.useState<Record<string, boolean>>({});
  const gridFilteredRows_heroui_app_table_grid_1785520942714_3omfy = React.useMemo(() => applyClientGridQuery(((Array.isArray(gridData_heroui_app_table_grid_1785520942714_3omfy?.items) ? gridData_heroui_app_table_grid_1785520942714_3omfy?.items : []) ?? []), gridQuery_heroui_app_table_grid_1785520942714_3omfy, gridColumns_heroui_app_table_grid_1785520942714_3omfy, "server"), [gridQuery_heroui_app_table_grid_1785520942714_3omfy, gridColumns_heroui_app_table_grid_1785520942714_3omfy]);
  const gridApiTotal_heroui_app_table_grid_1785520942714_3omfy = React.useMemo(() => {
    const raw = raw_gridData_heroui_app_table_grid_1785520942714_3omfy;
    const value = readNestedContextValue((raw && typeof raw === 'object' ? raw as Record<string, unknown> : {}), "count");
    const parsed = typeof value === 'number' ? value : Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : 0;
  }, [raw_gridData_heroui_app_table_grid_1785520942714_3omfy]);
  const gridTotalCount_heroui_app_table_grid_1785520942714_3omfy = resolveDataGridTotalCount({ page: gridPage_heroui_app_table_grid_1785520942714_3omfy, pageSize: gridPageSize_heroui_app_table_grid_1785520942714_3omfy, total: gridApiTotal_heroui_app_table_grid_1785520942714_3omfy, gridQueryMode: "server" }, gridFilteredRows_heroui_app_table_grid_1785520942714_3omfy.length);
  const gridPaging_heroui_app_table_grid_1785520942714_3omfy = sliceDataGridRowsForDisplay(gridFilteredRows_heroui_app_table_grid_1785520942714_3omfy, gridPage_heroui_app_table_grid_1785520942714_3omfy, gridPageSize_heroui_app_table_grid_1785520942714_3omfy, gridTotalCount_heroui_app_table_grid_1785520942714_3omfy, "server");
  const handleGridQueryChange_heroui_app_table_grid_1785520942714_3omfy = React.useCallback((nextQuery: GridQueryState) => {
    setGridQuery_heroui_app_table_grid_1785520942714_3omfy(nextQuery);
    setGridPage_heroui_app_table_grid_1785520942714_3omfy(1);
    patchDesignerStore("gridQuery.sortBy", nextQuery.sort?.columnId ?? '');
    patchDesignerStore("gridQuery.sortDir", nextQuery.sort?.direction ?? '');
  }, [patchDesignerStore]);
  const handleGridPageChange_heroui_app_table_grid_1785520942714_3omfy = React.useCallback((nextPage: number) => {
    setGridPage_heroui_app_table_grid_1785520942714_3omfy(nextPage);
    patchDesignerStore("gridQuery.page", nextPage);
  }, [patchDesignerStore]);
  const handleGridPageSizeChange_heroui_app_table_grid_1785520942714_3omfy = React.useCallback((nextSize: number) => {
    setGridPageSize_heroui_app_table_grid_1785520942714_3omfy(nextSize);
    setGridPage_heroui_app_table_grid_1785520942714_3omfy(1);
    patchDesignerStore("gridQuery.pageSize", nextSize);
  }, [patchDesignerStore]);
  const handleGridSortByChange_heroui_app_table_grid_1785520942714_3omfy = React.useCallback((nextSortBy: string) => {
    setGridQuery_heroui_app_table_grid_1785520942714_3omfy((current: GridQueryState) => ({ ...current, sort: nextSortBy ? { columnId: nextSortBy, direction: current.sort?.direction ?? 'asc' } : null }));
  }, []);
  const handleGridToggleSortDirection_heroui_app_table_grid_1785520942714_3omfy = React.useCallback(() => {
    setGridQuery_heroui_app_table_grid_1785520942714_3omfy((current: GridQueryState) => (current.sort ? { ...current, sort: { ...current.sort, direction: current.sort.direction === 'asc' ? 'desc' : 'asc' } } : current));
  }, []);
  const searchDebounceTimer_heroui_app_table_grid_1785520942714_3omfy = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const handleGridSearchChange_heroui_app_table_grid_1785520942714_3omfy = React.useCallback((nextValue: string) => {
    setGridSearchInput_heroui_app_table_grid_1785520942714_3omfy(nextValue);
    if (searchDebounceTimer_heroui_app_table_grid_1785520942714_3omfy.current) {
      clearTimeout(searchDebounceTimer_heroui_app_table_grid_1785520942714_3omfy.current);
    }
    searchDebounceTimer_heroui_app_table_grid_1785520942714_3omfy.current = setTimeout(() => {
      setGridDebouncedSearch_heroui_app_table_grid_1785520942714_3omfy(nextValue);
      setGridPage_heroui_app_table_grid_1785520942714_3omfy(1);
      patchDesignerStore("gridToolbar.search", nextValue);
    }, 300);
  }, [patchDesignerStore]);

  const dataContext: Record<string, unknown> | null = regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d ?? null;
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [mutationError, setMutationError] = React.useState<string | null>(null);
  const handleonClick_node_12af0060_c9bb_41b4_8d4e_dfeb7dc4f191 = React.useCallback(async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    let formData: FormData;
    const form = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : event.currentTarget.closest('form');
    if (form) {
      formData = new FormData(form);
    } else {
      const regionRoot = document.querySelector("[data-designer-node-id=\"node-a5197bac-508f-4bfc-a629-4dd40cbf5a3d\"]");
      if (!regionRoot) {
        return;
      }
      formData = collectRegionFormDataFromContainer(regionRoot, ["node-14e7e576-505a-47b6-8765-ef432faf7b55","node-0c7424eb-3faa-4516-97b4-b3f3d1e65f6d","node-ad9ebfff-fcf5-45fb-8364-a2619e38b07b","node-9ed9e87e-599d-4dc4-82a7-b9f8c330f5a6","node-4401ff50-d824-4587-9a0b-4b08d19c922b"]);
    }
    const fieldValidationEntries = [{"nodeId":"node-14e7e576-505a-47b6-8765-ef432faf7b55","formFieldName":"node-14e7e576-505a-47b6-8765-ef432faf7b55","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-0c7424eb-3faa-4516-97b4-b3f3d1e65f6d","formFieldName":"node-0c7424eb-3faa-4516-97b4-b3f3d1e65f6d","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-4401ff50-d824-4587-9a0b-4b08d19c922b","formFieldName":"node-4401ff50-d824-4587-9a0b-4b08d19c922b","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}}] as Array<{ nodeId: string; formFieldName: string; props: Record<string, unknown> }>;
    const fieldValidationErrors: Record<string, string> = {};
    for (const entry of fieldValidationEntries) {
      const rawValue = formData.get(entry.formFieldName);
      const validationMessage = validateDesignerFieldNode(entry.props, typeof rawValue === 'string' ? rawValue : '');
      if (validationMessage) {
        fieldValidationErrors[entry.nodeId] = validationMessage;
      }
    }
    if (Object.keys(fieldValidationErrors).length > 0) {
      setMutationError(Object.values(fieldValidationErrors).join(' '));
      return;
    }
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      payload["title"] = formData.get("node-14e7e576-505a-47b6-8765-ef432faf7b55") ?? '';
      payload["shortName"] = formData.get("node-0c7424eb-3faa-4516-97b4-b3f3d1e65f6d") ?? '';
      payload["viewOrder"] = applyPayloadFieldTransform(formData.get("node-ad9ebfff-fcf5-45fb-8364-a2619e38b07b"), "number");
      payload["isActive"] = applyPayloadFieldTransform(formData.get("node-9ed9e87e-599d-4dc4-82a7-b9f8c330f5a6"), "boolean");
      payload["parentId"] = formData.get("node-4401ff50-d824-4587-9a0b-4b08d19c922b") ?? '';
      const method = regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d?.id != null && String(regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d?.id).length > 0 ? 'PUT' : 'POST';
      const url = (regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d?.id != null && String(regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d?.id).length > 0 ? (regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d?.id != null && String(regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d?.id).length > 0 ? "/api/base-info" + '/' + encodeURIComponent(String(regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d?.id)) : "/api/base-info") : "/api/base-info");
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      patchDesignerStore("ui.visibility.node-68868dba-d561-4e0b-bd88-89d27c0ccede", false);
      toast("Saved successfully", { variant: "success", timeout: 4000 });
      await refresh_gridData_heroui_app_table_grid_1785520942714_3omfy();
      (document.querySelector("[data-designer-node-id=\"node-a5197bac-508f-4bfc-a629-4dd40cbf5a3d\"]") as HTMLFormElement | null)?.reset?.();
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, [regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d]);
  const handleonClick_node_3ab74281_0e4e_49c2_b195_6c2e03c5a6e1 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-68868dba-d561-4e0b-bd88-89d27c0ccede", false);
  }, [patchDesignerStore]);
  const handleonClick_node_a034e485_c654_4207_b8d4_17e3286595b2 = React.useCallback(async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    let formData: FormData;
    const form = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : event.currentTarget.closest('form');
    if (form) {
      formData = new FormData(form);
    } else {
      const regionRoot = document.querySelector("[data-designer-node-id=\"node-bfd723c6-3cd9-4192-aaec-45ad452facf6\"]");
      if (!regionRoot) {
        return;
      }
      formData = collectRegionFormDataFromContainer(regionRoot, ["node-f2f26e26-1486-42b9-97a3-de750d833314","node-f36c44db-2b8a-489b-8067-72eb03d2efe6","node-ca06f9a6-78e7-4bdf-bc7a-af3526ba095d","node-729c3378-6584-4a40-8f07-4929fd1cbd9c","node-fc1d780b-19be-4332-a0d4-a94276c6eca7"]);
    }
    const fieldValidationEntries = [{"nodeId":"node-f2f26e26-1486-42b9-97a3-de750d833314","formFieldName":"node-f2f26e26-1486-42b9-97a3-de750d833314","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-f36c44db-2b8a-489b-8067-72eb03d2efe6","formFieldName":"node-f36c44db-2b8a-489b-8067-72eb03d2efe6","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-fc1d780b-19be-4332-a0d4-a94276c6eca7","formFieldName":"node-fc1d780b-19be-4332-a0d4-a94276c6eca7","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}}] as Array<{ nodeId: string; formFieldName: string; props: Record<string, unknown> }>;
    const fieldValidationErrors: Record<string, string> = {};
    for (const entry of fieldValidationEntries) {
      const rawValue = formData.get(entry.formFieldName);
      const validationMessage = validateDesignerFieldNode(entry.props, typeof rawValue === 'string' ? rawValue : '');
      if (validationMessage) {
        fieldValidationErrors[entry.nodeId] = validationMessage;
      }
    }
    if (Object.keys(fieldValidationErrors).length > 0) {
      setMutationError(Object.values(fieldValidationErrors).join(' '));
      return;
    }
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      payload["title"] = formData.get("node-f2f26e26-1486-42b9-97a3-de750d833314") ?? '';
      payload["shortName"] = formData.get("node-f36c44db-2b8a-489b-8067-72eb03d2efe6") ?? '';
      payload["viewOrder"] = applyPayloadFieldTransform(formData.get("node-ca06f9a6-78e7-4bdf-bc7a-af3526ba095d"), "number");
      payload["isActive"] = applyPayloadFieldTransform(formData.get("node-729c3378-6584-4a40-8f07-4929fd1cbd9c"), "boolean");
      payload["parentId"] = formData.get("node-fc1d780b-19be-4332-a0d4-a94276c6eca7") ?? '';
      const method = regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6?.id != null && String(regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6?.id).length > 0 ? 'PUT' : 'POST';
      const url = (regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6?.id != null && String(regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6?.id).length > 0 ? (regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6?.id != null && String(regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6?.id).length > 0 ? "/api/base-info" + '/' + encodeURIComponent(String(regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6?.id)) : "/api/base-info") : "/api/base-info");
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      patchDesignerStore("ui.visibility.node-6f104feb-eb0f-4905-b7f5-3b0e8a4d8bc0", false);
      toast("Saved successfully", { variant: "success", timeout: 4000 });
      await refresh_gridData_heroui_app_table_grid_1785520942714_3omfy();
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, [regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6]);
  const handleonClick_node_541e9bf8_b323_42aa_a6b8_c9bf23baa617 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-6f104feb-eb0f-4905-b7f5-3b0e8a4d8bc0", false);
  }, [patchDesignerStore]);
  const handleonClick_node_a035318b_dda0_4b85_9a9d_4fcbaa8fa52f = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-f0a885e5-37a8-435e-8c22-42bfb91d8506", false);
  }, [patchDesignerStore]);
  const handleonClick_node_048eacfd_4bff_423d_8d27_1d4243ae7e39 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_ms992gsd_rl2to = true;
      try {
        const response = await designerFetch(("/api/base-info/" + encodeURIComponent(String(designerStore?.selection?.id)) + ""), {
          method: "DELETE",
          headers: { 'Content-Type': 'application/json' },
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_ms992gsd_rl2to = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_ms992gsd_rl2to = false;
      }
      if (mutationOk_da_ms992gsd_rl2to) {
        patchDesignerStore("ui.visibility.node-f0a885e5-37a8-435e-8c22-42bfb91d8506", false);
        toast("Deleted", { variant: "success", timeout: 4000 });
        await refresh_gridData_heroui_app_table_grid_1785520942714_3omfy();
      }
    })();
  }, [patchDesignerStore, refresh_gridData_heroui_app_table_grid_1785520942714_3omfy]);
  return (
    <>
      <Toast.Provider />
      <div className="space-y-3">
        {mutationError ? (
          <div className="rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700">
            {mutationError}
          </div>
        ) : null}
        <div className="flex w-full flex-col gap-2"><div className="flex items-center justify-between gap-2 border-b border-slate-200 bg-white px-2 py-1.5"><div className="flex items-center gap-2"><input type="text" value={gridSearchInput_heroui_app_table_grid_1785520942714_3omfy} onChange={(event) => handleGridSearchChange_heroui_app_table_grid_1785520942714_3omfy(event.target.value)} placeholder={"Search content types…"} className="h-8 rounded-md border border-slate-200 px-2 text-sm" /></div><div className="flex items-center gap-2"><button type="button" onClick={() => { patchDesignerStore("selection.id", null); patchDesignerStore("ui.visibility.node-68868dba-d561-4e0b-bd88-89d27c0ccede", true); }} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700">Create content type</button><button type="button" onClick={() => { void refresh_gridData_heroui_app_table_grid_1785520942714_3omfy(); }} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 px-3 text-xs font-medium text-slate-700 hover:bg-slate-50">Refresh</button></div></div><AppTableGrid className="flex h-full min-h-0 w-full flex-1 flex-col" presentation="cards" cardBelow="phone" cardVariant="compact" columns={gridColumns_heroui_app_table_grid_1785520942714_3omfy} rows={gridPaging_heroui_app_table_grid_1785520942714_3omfy.displayRows} getRowKey={(row) => String((row as Record<string, unknown>)["id"] ?? '')} enableColumnLayout={false} columnLayout={gridColumnLayout_heroui_app_table_grid_1785520942714_3omfy} onColumnLayoutChange={setGridColumnLayout_heroui_app_table_grid_1785520942714_3omfy} isLoading={false} loadingMessage={"Loading content types…"} emptyMessage={"No content types found."} isEmpty={gridFilteredRows_heroui_app_table_grid_1785520942714_3omfy.length === 0} errorContent={gridFilteredRows_heroui_app_table_grid_1785520942714_3omfy.length === 0 ? undefined : "Could not load content types."} gridQueryMode={"server"} query={gridQuery_heroui_app_table_grid_1785520942714_3omfy} onQueryChange={handleGridQueryChange_heroui_app_table_grid_1785520942714_3omfy} onGridRowAction={handleGridRowAction_heroui_app_table_grid_1785520942714_3omfy} footer={<GridPagingFooter totalCount={gridTotalCount_heroui_app_table_grid_1785520942714_3omfy} safePage={gridPaging_heroui_app_table_grid_1785520942714_3omfy.safePage} pageSize={gridPageSize_heroui_app_table_grid_1785520942714_3omfy} onPageSizeChange={handleGridPageSizeChange_heroui_app_table_grid_1785520942714_3omfy} sortBy={gridQuery_heroui_app_table_grid_1785520942714_3omfy.sort?.columnId ?? ''} sortOptions={[{"value":"title","label":"Title"}]} onSortByChange={handleGridSortByChange_heroui_app_table_grid_1785520942714_3omfy} sortDirection={gridQuery_heroui_app_table_grid_1785520942714_3omfy.sort?.direction ?? 'asc'} onToggleSortDirection={handleGridToggleSortDirection_heroui_app_table_grid_1785520942714_3omfy} showSortControls={false} totalPages={gridPaging_heroui_app_table_grid_1785520942714_3omfy.totalPages} pageNumbers={buildDataGridPageNumbers(gridPaging_heroui_app_table_grid_1785520942714_3omfy.safePage, gridPaging_heroui_app_table_grid_1785520942714_3omfy.totalPages)} onPageChange={handleGridPageChange_heroui_app_table_grid_1785520942714_3omfy} visibleInfiniteCount={gridListMode_heroui_app_table_grid_1785520942714_3omfy === 'infinite' ? gridPaging_heroui_app_table_grid_1785520942714_3omfy.displayRows.length : undefined} />} /></div>
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-68868dba-d561-4e0b-bd88-89d27c0ccede === true) && (store.ui.visibility.node-68868dba-d561-4e0b-bd88-89d27c0ccede !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-68868dba-d561-4e0b-bd88-89d27c0ccede"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-68868dba-d561-4e0b-bd88-89d27c0ccede", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Create Content Type</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-68868dba-d561-4e0b-bd88-89d27c0ccede", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <form className="flex min-h-0 flex-col gap-0 overflow-hidden bg-white" method="post" data-designer-node-id="node-a5197bac-508f-4bfc-a629-4dd40cbf5a3d">
            <div className="flex flex-col gap-2 bg-white p-[15px]">
              <UiInput isRequired type="text" placeholder="Title" label="Title" size="sm" value={regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d?.title} name="node-14e7e576-505a-47b6-8765-ef432faf7b55" />
              <UiInput isRequired type="text" placeholder="Short Name" label="Short Name" size="sm" value={regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d?.shortName} name="node-0c7424eb-3faa-4516-97b4-b3f3d1e65f6d" />
              <UiInput type="number" placeholder="View Order" label="View Order" step={1} size="sm" value={regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d?.viewOrder} name="node-ad9ebfff-fcf5-45fb-8364-a2619e38b07b" />
              <Switch label="Is Active" aria-label="Is Active" size="md" isSelected={regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d?.isActive} name="node-9ed9e87e-599d-4dc4-82a7-b9f8c330f5a6"><Switch.Control><Switch.Thumb /></Switch.Control></Switch>
              <UiInput isRequired className="hidden" readOnly type="text" placeholder="Parent Id" label="Parent Id" defaultValue={101.001} size="sm" value={regionData_vocabItems_node_a5197bac_508f_4bfc_a629_4dd40cbf5a3d?.parentId} name="node-4401ff50-d824-4587-9a0b-4b08d19c922b" />
            </div>
            <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" onClick={handleonClick_node_3ab74281_0e4e_49c2_b195_6c2e03c5a6e1}>Cancel</Button>
              <Button type="submit" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" icon="Plus" variant="primary" size="md" href="#" target="_self" isDisabled={isSubmitting} onClick={handleonClick_node_12af0060_c9bb_41b4_8d4e_dfeb7dc4f191}>Create Content Type</Button>
            </div>
          </form>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-6f104feb-eb0f-4905-b7f5-3b0e8a4d8bc0 === true) && (store.ui.visibility.node-6f104feb-eb0f-4905-b7f5-3b0e8a4d8bc0 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-6f104feb-eb0f-4905-b7f5-3b0e8a4d8bc0"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-6f104feb-eb0f-4905-b7f5-3b0e8a4d8bc0", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Edit Content Type</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-6f104feb-eb0f-4905-b7f5-3b0e8a4d8bc0", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <form className="flex min-h-0 flex-col gap-0 overflow-hidden bg-white" method="post" data-designer-node-id="node-bfd723c6-3cd9-4192-aaec-45ad452facf6">
            <div className="flex flex-col gap-2 bg-white p-[15px]">
              <UiInput isRequired type="text" placeholder="Title" label="Title" size="sm" value={regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6?.title} name="node-f2f26e26-1486-42b9-97a3-de750d833314" />
              <UiInput isRequired type="text" placeholder="Short Name" label="Short Name" size="sm" value={regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6?.shortName} name="node-f36c44db-2b8a-489b-8067-72eb03d2efe6" />
              <UiInput type="number" placeholder="View Order" label="View Order" step={1} size="sm" value={regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6?.viewOrder} name="node-ca06f9a6-78e7-4bdf-bc7a-af3526ba095d" />
              <Switch label="Is Active" aria-label="Is Active" size="md" isSelected={regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6?.isActive} name="node-729c3378-6584-4a40-8f07-4929fd1cbd9c"><Switch.Control><Switch.Thumb /></Switch.Control></Switch>
              <UiInput isRequired type="text" placeholder="Parent Id" label="Parent Id" size="sm" value={regionData_vocabItems_node_bfd723c6_3cd9_4192_aaec_45ad452facf6?.parentId} name="node-fc1d780b-19be-4332-a0d4-a94276c6eca7" />
            </div>
            <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" onClick={handleonClick_node_541e9bf8_b323_42aa_a6b8_c9bf23baa617}>Cancel</Button>
              <Button type="submit" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" icon="Save" variant="primary" size="md" href="#" target="_self" isDisabled={isSubmitting} onClick={handleonClick_node_a034e485_c654_4207_b8d4_17e3286595b2}>Save</Button>
            </div>
          </form>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-f0a885e5-37a8-435e-8c22-42bfb91d8506 === true) && (store.ui.visibility.node-f0a885e5-37a8-435e-8c22-42bfb91d8506 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-f0a885e5-37a8-435e-8c22-42bfb91d8506"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-f0a885e5-37a8-435e-8c22-42bfb91d8506", false); } }} variant="blur"><Modal.Container><Modal.Dialog role="alertdialog" className="w-full max-w-md overflow-hidden rounded-xl border border-rose-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-rose-200 bg-rose-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-rose-800">Delete Content Type?</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-f0a885e5-37a8-435e-8c22-42bfb91d8506", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <p className="block bg-white p-[15px] text-sm text-slate-700">Delete this content type? This cannot be undone.</p>
          <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
            <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_node_a035318b_dda0_4b85_9a9d_4fcbaa8fa52f}>Cancel</Button>
            <Button icon="Trash2" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-rose-600 px-3 text-xs font-semibold text-white hover:bg-rose-700" variant="primary" size="md" href="#" target="_self" onClick={handleonClick_node_048eacfd_4bff_423d_8d27_1d4243ae7e39}>Delete</Button>
          </div>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
      </div>
    </>
  );
};
export default GeneratedComponent;
