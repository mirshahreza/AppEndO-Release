-- Read model: exactly one row per dbo.hwy_members.id (lists / queues never include base_users-only rows).
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER VIEW dbo.vw_hwy_members
AS
SELECT
  m.id,
  m.user_id,
  NULLIF(
    LTRIM(RTRIM(COALESCE(
      CASE
        WHEN NULLIF(LTRIM(RTRIM(m.username)), N'') IS NOT NULL
          AND LTRIM(RTRIM(m.username)) <> CAST(m.id AS NVARCHAR(32))
          AND LOWER(LTRIM(RTRIM(m.username))) <> N'm' + CAST(m.id AS NVARCHAR(32))
          AND LOWER(LTRIM(RTRIM(m.username))) <> N'hwy-m-' + CAST(m.id AS NVARCHAR(32))
          AND LEN(LTRIM(RTRIM(m.username))) = 6
          AND LTRIM(RTRIM(m.username)) NOT LIKE N'%[^0-9]%'
        THEN NULLIF(LTRIM(RTRIM(m.username)), N'')
        ELSE NULL
      END,
      CASE
        WHEN NULLIF(LTRIM(RTRIM(u.username)), N'') IS NOT NULL
          AND LTRIM(RTRIM(u.username)) <> CAST(m.id AS NVARCHAR(32))
          AND LOWER(LTRIM(RTRIM(u.username))) <> N'm' + CAST(m.id AS NVARCHAR(32))
          AND LOWER(LTRIM(RTRIM(u.username))) <> N'hwy-m-' + CAST(m.id AS NVARCHAR(32))
          AND LEN(LTRIM(RTRIM(u.username))) = 6
          AND LTRIM(RTRIM(u.username)) NOT LIKE N'%[^0-9]%'
        THEN NULLIF(LTRIM(RTRIM(u.username)), N'')
        ELSE NULL
      END
    ))),
    N''
  ) AS username,
  COALESCE(u.email, m.email) AS email,
  u.mobile AS user_mobile,
  u.locked AS user_locked,
  u.last_login_at,
  COALESCE(p.firstname, m.first_name) AS firstname,
  COALESCE(p.lastname, m.family_name) AS lastname,
  COALESCE(p.fathername, m.father_name) AS fathername,
  COALESCE(p.grandfathername, m.grandfather_name) AS grandfathername,
  COALESCE(p.nickname, m.nickname) AS nickname,
  COALESCE(p.national_code, m.national_id) AS national_code,
  COALESCE(p.birth_year, m.birth_year) AS birth_year,
  COALESCE(p.birth_month, m.birth_month) AS birth_month,
  COALESCE(p.birth_day, m.birth_day) AS birth_day,
  COALESCE(p.gender_code, m.gender_code) AS gender_code,
  COALESCE(p.person_type_code, N'100.2.1') AS person_type_code,
  CONCAT_WS(
    N' ',
    NULLIF(LTRIM(RTRIM(COALESCE(p.firstname, m.first_name))), N''),
    NULLIF(LTRIM(RTRIM(COALESCE(p.fathername, m.father_name))), N''),
    NULLIF(LTRIM(RTRIM(COALESCE(p.grandfathername, m.grandfather_name))), N''),
    NULLIF(LTRIM(RTRIM(COALESCE(p.lastname, m.family_name))), N'')
  ) AS display_full_name,
  COALESCE(p.phone, m.phone1) AS phone1,
  m.phone2,
  CASE WHEN p.profile_image_body IS NULL THEN CAST(0 AS bit) ELSE CAST(1 AS bit) END AS has_profile_image,
  CASE
    WHEN p.profile_image_body IS NOT NULL AND m.user_id IS NOT NULL
      THEN CONCAT(N'/api/users/', CAST(m.user_id AS VARCHAR(20)), N'/avatar-xs')
    ELSE NULL
  END AS avatar_url,
  p.profile_image_mime,
  p.profile_image_size,
  m.facebook_id,
  m.twitter_id,
  m.tiktok_id,
  m.great_grandfather_name,
  m.mother_first_name,
  m.mother_father_name,
  m.mother_grandfather_name,
  m.addr_province_id,
  m.addr_district_id,
  m.addr_subdistrict_id,
  m.addr_quarter_name,
  m.addr_quarter_no,
  m.addr_alley_no,
  m.addr_house_no,
  m.addr_nearest_landmark,
  m.addr_most_important_place,
  m.addr_maktab_id,
  m.addr_region_id,
  m.addr_circle_id,
  m.nakhebin_id,
  n.family_code AS nakhebin_family_code,
  m.nakhebin_link_type_code,
  m.nakhebin_link_problem_reason_id,
  m.nakhebin_link_problem_note,
  m.nakhebin_link_region_id,
  m.family_code,
  COALESCE(
    NULLIF(LTRIM(RTRIM(m.voted_on_2021)), N''),
    NULLIF(LTRIM(RTRIM(n.voted_on_2021)), N''),
    NULLIF(LTRIM(RTRIM(nb_member.voted_on_2021)), N'')
  ) AS voted_on_2021,
  COALESCE(
    NULLIF(LTRIM(RTRIM(m.voted_on_2023)), N''),
    NULLIF(LTRIM(RTRIM(n.voted_on_2023)), N''),
    NULLIF(LTRIM(RTRIM(nb_member.voted_on_2023)), N'')
  ) AS voted_on_2023,
  COALESCE(
    NULLIF(LTRIM(RTRIM(m.voted_on_2025)), N''),
    NULLIF(LTRIM(RTRIM(n.voted_on_2025)), N''),
    NULLIF(LTRIM(RTRIM(nb_member.voted_on_2025)), N'')
  ) AS voted_on_2025,
  m.membership_status_code,
  m.membership_status_updated_on,
  m.membership_status_updated_by,
  m.membership_on,
  m.referrer_username,
  m.referrer_relation_id,
  m.referrer_institute_id,
  m.second_referrer_username,
  m.second_referrer_relation_id,
  m.education_level_code,
  m.education_level_in_code,
  m.education_entry_year,
  m.education_branch,
  m.education_school,
  m.education_end_year,
  m.education_university_code,
  m.education_university_faculty_code,
  m.job_type_code,
  m.job_place,
  m.mehani_union_code,
  m.mehani_union_degree_code,
  m.mehani_membership_expires_on,
  m.note,
  n.region_id AS nakhebin_region_id,
  n.maktab_id AS nakhebin_maktab_id,
  dbo.hwy_region_electoral_title_path(CAST(n.region_id AS NVARCHAR(32))) AS electoral_division_path,
  CAST(m.id AS NVARCHAR(32)) AS tracking_code,
  m.registration_channel_code,
  m.nakhebin_join_tasjil_state_code,
  m.created_by,
  m.created_at,
  m.updated_by,
  m.updated_at
FROM dbo.hwy_members m
LEFT JOIN dbo.base_users u ON u.id = m.user_id
LEFT JOIN dbo.base_user_profiles p ON p.user_id = m.user_id
LEFT JOIN dbo.hwy_nakhebin n ON n.id = m.nakhebin_id
OUTER APPLY (
  SELECT TOP (1) voted_on_2021, voted_on_2023, voted_on_2025
  FROM dbo.hwy_nakhebin nb
  WHERE nb.member_id = m.id
  ORDER BY nb.id DESC
) nb_member;
GO

PRINT 'vw_hwy_members ready';
