import React from 'react';
import { buildAppTableGridColumns } from '@/domain/component-designer/DesignerRuntimeAppTableGrid';
import { applyClientGridQuery, EMPTY_GRID_QUERY, type GridQueryState } from '@/shared/lib/appTableGridQuery';
import { resolveDataGridTotalCount, sliceDataGridRowsForDisplay, buildDataGridPageNumbers } from '@/domain/component-designer/designerDataGridRuntime';
import { applyDesignerGridToolbarClientFilters } from '@/domain/component-designer/designerGridToolbarConfig';
import { createDefaultColumnLayout } from '@/shared/lib/appTableGridColumnLayout';
import { validateDesignerFieldNode } from '@/domain/component-designer/previewFieldValidation';
import { AppTableGrid, GridPagingFooter } from '@/shared/ui';
import { DesignerCodeEditorField, DesignerHtmlEditorField } from '@/shared/ui/DesignerFormFields';
import { UiInput, UiSelect, UiTextarea } from '@/shared/ui/HeroFieldControls';
import { Button, Modal, Switch, Toast, toast } from '@heroui/react';

const parseApiErrorMessage = async (response: Response): Promise<string> => {
  try {
    const payload = await response.json();
    if (payload && typeof payload === "object") {
      const record = payload as Record<string, unknown>;
      const message = record.message ?? record.error ?? record.detail;
      if (typeof message === "string" && message.trim().length > 0) {
        return message.trim();
      }
    }
  } catch {
    // fall through to status text
  }
  return response.statusText || `Request failed (${response.status})`;
};

const readBindingParamValue = (
  context: Record<string, unknown> | null | undefined,
  dataPath: string,
): unknown => {
  const segments = dataPath.split(".").map((segment) => segment.trim()).filter(Boolean);
  let cursor: unknown = context;
  for (const segment of segments) {
    if (cursor && typeof cursor === "object" && segment in (cursor as Record<string, unknown>)) {
      cursor = (cursor as Record<string, unknown>)[segment];
    } else {
      return undefined;
    }
  }
  return cursor;
};

const resolveBindingTemplateValue = (
  template: string,
  context: Record<string, unknown> | null | undefined,
  paramPaths: Record<string, string>,
): string =>
  template.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, paramName: string) => {
    const dataPath = paramPaths[paramName];
    if (!dataPath) {
      return "";
    }
    const cursor = readBindingParamValue(context, dataPath);
    return cursor === undefined || cursor === null ? "" : String(cursor);
  });

const resolveBindingUrl = (
  endpointTemplate: string,
  context: Record<string, unknown> | null | undefined,
  paramPaths: Record<string, string>,
): string => {
  const usedParamNames = new Set<string>();
  let resolvedPath = endpointTemplate.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, paramName: string) => {
    usedParamNames.add(paramName);
    const dataPath = paramPaths[paramName];
    if (!dataPath) {
      return "";
    }
    const cursor = readBindingParamValue(context, dataPath);
    return cursor === undefined || cursor === null ? "" : String(cursor);
  });
  for (const [paramName, dataPath] of Object.entries(paramPaths)) {
    if (usedParamNames.has(paramName)) {
      continue;
    }
    const colonParamPattern = new RegExp(`:${paramName}(?=/|$)`, "g");
    if (!colonParamPattern.test(resolvedPath)) {
      continue;
    }
    usedParamNames.add(paramName);
    const cursor = readBindingParamValue(context, dataPath);
    const text = cursor === undefined || cursor === null ? "" : String(cursor);
    resolvedPath = resolvedPath.replace(new RegExp(`:${paramName}(?=/|$)`, "g"), text);
  }
  const searchParams = new URLSearchParams();
  for (const [paramName, dataPath] of Object.entries(paramPaths)) {
    if (usedParamNames.has(paramName)) {
      continue;
    }
    const cursor = readBindingParamValue(context, dataPath);
    if (cursor === undefined || cursor === null) {
      continue;
    }
    const text = String(cursor).trim();
    if (text.length === 0) {
      continue;
    }
    searchParams.set(paramName, text);
  }
  const queryString = searchParams.toString();
  if (!queryString) {
    return resolvedPath;
  }
  return resolvedPath.includes("?") ? `${resolvedPath}&${queryString}` : `${resolvedPath}?${queryString}`;
};

const resolveBindingHeaders = (
  context: Record<string, unknown> | null | undefined,
  headerTemplates: Record<string, string>,
  paramPaths: Record<string, string>,
): Record<string, string> =>
  Object.fromEntries(
    Object.entries(headerTemplates).map(([key, template]) => [
      key,
      resolveBindingTemplateValue(template, context, paramPaths),
    ]),
  );

const setNestedPayloadValue = (target: Record<string, unknown>, path: string, value: unknown): void => {
  const segments = path.split(".").map((segment) => segment.trim()).filter(Boolean);
  if (segments.length === 0) {
    return;
  }
  let cursor: Record<string, unknown> = target;
  for (let index = 0; index < segments.length - 1; index += 1) {
    const segment = segments[index];
    const next = cursor[segment];
    if (!next || typeof next !== "object" || Array.isArray(next)) {
      cursor[segment] = {};
    }
    cursor = cursor[segment] as Record<string, unknown>;
  }
  cursor[segments[segments.length - 1]] = value;
};

const mapDesignerListBoxItems = (rawItems: unknown): Array<{ id: string; textValue: string }> => {
  const items = Array.isArray(rawItems) ? rawItems : [];
  return items
    .map((entry) => {
      if (!entry || typeof entry !== "object") {
        return null;
      }
      const record = entry as Record<string, unknown>;
      const id = String(record.id ?? "").trim();
      if (!id || id === "100" || id === "102") {
        return null;
      }
      const textValue = String(record.textValue ?? record.label ?? record.title ?? id).trim();
      return { id, textValue: textValue || id };
    })
    .filter((entry): entry is { id: string; textValue: string } => entry !== null);
};

const mapDesignerLovItems = (
  rawItems: unknown,
  returnColumn: string,
  displayColumn: string,
): Array<{ id: string; textValue: string }> => {
  const items = Array.isArray(rawItems) ? rawItems : [];
  return items
    .map((entry) => {
      if (!entry || typeof entry !== "object") {
        return null;
      }
      const record = entry as Record<string, unknown>;
      const id = String(record[returnColumn] ?? "").trim();
      if (!id) {
        return null;
      }
      const textValue = String(record[displayColumn] ?? id).trim();
      return { id, textValue: textValue || id };
    })
    .filter((entry): entry is { id: string; textValue: string } => entry !== null);
};

const collectRegionFormDataFromContainer = (
  container: ParentNode,
  formFieldNames: readonly string[],
): FormData => {
  const formData = new FormData();
  for (const formFieldName of formFieldNames) {
    const escapedName = formFieldName.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    const field = container.querySelector(`[name="${escapedName}"]`);
    if (!field) {
      continue;
    }
    if (field instanceof HTMLInputElement) {
      if (field.type === "checkbox" || field.type === "radio") {
        formData.set(formFieldName, field.checked ? "true" : "false");
      } else {
        formData.set(formFieldName, field.value);
      }
      continue;
    }
    if (field instanceof HTMLTextAreaElement || field instanceof HTMLSelectElement) {
      formData.set(formFieldName, field.value);
      continue;
    }
    formData.set(formFieldName, field.getAttribute("value") ?? "");
  }
  return formData;
};

const applyPayloadFieldTransform = (value: FormDataEntryValue | null, transform?: string): unknown => {
  const raw = value === null ? "" : String(value);
  switch (transform) {
    case "number": {
      const parsed = Number(raw);
      return Number.isFinite(parsed) ? parsed : raw;
    }
    case "boolean":
      return raw === "true" || raw === "1" || raw === "on";
    case "commaSeparatedArray":
      return raw.split(",").map((entry) => entry.trim()).filter(Boolean);
    default:
      return raw;
  }
};

// --- AUTH / TOKEN LIFECYCLE INJECTION POINT ---
// Register your application-wide 401 interceptor and token refresh handler here before production.
// Example: const designerFetch = createAuthenticatedFetch({ getAccessToken, refreshTokens, onSessionExpired });
const designerFetch: typeof fetch = fetch;

function useDataFetch<T>(url: string, options: { headers?: Record<string, string> } = {}) {
  const [data, setData] = React.useState<T | null>(null);
  const [isLoading, setIsLoading] = React.useState(Boolean(url));
  const [error, setError] = React.useState<string | null>(null);
  const [refreshNonce, setRefreshNonce] = React.useState(0);
  const headersKey = JSON.stringify(options.headers ?? {});

  const refresh = React.useCallback(async () => {
    setRefreshNonce((previous) => previous + 1);
  }, []);

  React.useEffect(() => {
    if (!url) {
      setData(null);
      setIsLoading(false);
      setError(null);
      return undefined;
    }

    let cancelled = false;
    const load = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const response = await designerFetch(url, {
          method: "GET",
          headers: options.headers,
        });
        if (!response.ok) {
          throw new Error(await parseApiErrorMessage(response));
        }
        const payload = (await response.json()) as T;
        if (!cancelled) {
          setData(payload);
        }
      } catch (loadError) {
        if (!cancelled) {
          setData(null);
          setError(loadError instanceof Error ? loadError.message : "Request failed");
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, [url, headersKey, refreshNonce]);

  return { data, isLoading, error, refresh };
}

const readNestedContextValue = (
  context: Record<string, unknown> | null | undefined,
  path: string,
): unknown => {
  const segments = path.split(".").map((segment) => segment.trim()).filter(Boolean);
  let cursor: unknown = context;
  for (const segment of segments) {
    if (cursor && typeof cursor === "object" && segment in (cursor as Record<string, unknown>)) {
      cursor = (cursor as Record<string, unknown>)[segment];
    } else {
      return undefined;
    }
  }
  return cursor;
};

const applyResponseDataPath = (
  payload: unknown,
  responseMapping?: { dataPath?: string; arrayPath?: string },
): unknown => {
  if (!responseMapping) {
    return payload;
  }
  const arrayPath = responseMapping.arrayPath?.trim();
  if (arrayPath) {
    const arrayValue = readNestedContextValue(
      payload && typeof payload === "object" ? payload as Record<string, unknown> : {},
      arrayPath,
    );
    if (Array.isArray(arrayValue)) {
      return arrayValue;
    }
  }
  const dataPath = responseMapping.dataPath?.trim();
  if (!dataPath || !payload || typeof payload !== "object") {
    return payload;
  }
  return readNestedContextValue(payload as Record<string, unknown>, dataPath);
};

const coerceApiRecordValue = (value: unknown): Record<string, unknown> | undefined => {
  if (value === undefined || value === null) {
    return undefined;
  }
  if (Array.isArray(value)) {
    return value.find(
      (entry): entry is Record<string, unknown> =>
        typeof entry === "object" && entry !== null && !Array.isArray(entry),
    );
  }
  if (typeof value === "object") {
    return value as Record<string, unknown>;
  }
  return undefined;
};

const transformApiRowsToChartData = (
  rows: Array<Record<string, unknown>>,
  mapping: { categoryField: string; categoryAs?: string; series: Array<{ apiField: string; seriesKey: string; aggregation?: string }> },
): Array<Record<string, string | number>> => {
  const categoryKey = mapping.categoryAs?.trim() || "label";
  const parseNum = (raw: unknown): number => {
    if (typeof raw === "number" && Number.isFinite(raw)) return raw;
    if (typeof raw === "string") { const p = Number(raw); return Number.isFinite(p) ? p : 0; }
    return 0;
  };
  const aggregate = (values: number[], agg: string): number => {
    if (values.length === 0) return 0;
    if (agg === "count") return values.length;
    if (agg === "avg") return values.reduce((s, v) => s + v, 0) / values.length;
    if (agg === "min") return Math.min(...values);
    if (agg === "max") return Math.max(...values);
    if (agg === "sum") return values.reduce((s, v) => s + v, 0);
    return values[0] ?? 0;
  };
  const needsGrouping = mapping.series.some((s) => s.aggregation && s.aggregation !== "none");
  if (!needsGrouping) {
    return rows.map((row) => {
      const chartRow: Record<string, string | number> = { [categoryKey]: String(row[mapping.categoryField] ?? "") };
      for (const series of mapping.series) { chartRow[series.seriesKey] = parseNum(row[series.apiField]); }
      return chartRow;
    });
  }
  const grouped = new Map<string, Array<Record<string, unknown>>>();
  for (const row of rows) {
    const cat = String(row[mapping.categoryField] ?? "");
    const bucket = grouped.get(cat);
    if (bucket) bucket.push(row); else grouped.set(cat, [row]);
  }
  return Array.from(grouped.entries()).map(([category, groupRows]) => {
    const chartRow: Record<string, string | number> = { [categoryKey]: category };
    for (const series of mapping.series) {
      const values = groupRows.map((r) => parseNum(r[series.apiField]));
      chartRow[series.seriesKey] = aggregate(values, series.aggregation ?? "sum");
    }
    return chartRow;
  });
};

const readVizStringField = (row: Record<string, unknown>, field: string, fallback = ""): string => {
  const value = row[field];
  if (value === undefined || value === null) return fallback;
  return String(value);
};

const transformApiRowsToTreeNodes = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "tree"; idField: string; labelField: string; parentIdField?: string },
): Array<{ id: string; label: string; children?: unknown[] }> => {
  const parentField = mapping.parentIdField?.trim();
  if (!parentField) {
    return rows.map((row, index) => ({
      id: readVizStringField(row, mapping.idField, `node-${index + 1}`),
      label: readVizStringField(row, mapping.labelField, `Item ${index + 1}`),
    }));
  }
  const nodeMap = new Map<string, { id: string; label: string; children: unknown[] }>();
  rows.forEach((row) => {
    const id = readVizStringField(row, mapping.idField);
    if (!id) return;
    nodeMap.set(id, { id, label: readVizStringField(row, mapping.labelField, id), children: [] });
  });
  const roots: Array<{ id: string; label: string; children?: unknown[] }> = [];
  rows.forEach((row) => {
    const id = readVizStringField(row, mapping.idField);
    if (!id) return;
    const node = nodeMap.get(id);
    if (!node) return;
    const parentId = readVizStringField(row, parentField);
    if (parentId && nodeMap.has(parentId)) {
      nodeMap.get(parentId)!.children.push(node);
    } else {
      roots.push(node);
    }
  });
  return roots;
};

const readVizNumberField = (row: Record<string, unknown>, field: string): number | undefined => {
  const value = row[field];
  const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(parsed) ? parsed : undefined;
};

const transformApiRowsToTimelineEvents = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "timeline" | "gantt"; idField?: string; titleField: string; startField: string; endField?: string; descriptionField?: string; progressField?: string },
): Array<{ id?: string; title: string; start: string; end?: string; description?: string; progress?: number }> =>
  rows.map((row, index) => {
    const progress = mapping.progressField ? readVizNumberField(row, mapping.progressField) : undefined;
    return {
      id: mapping.idField ? readVizStringField(row, mapping.idField, `evt-${index + 1}`) : `evt-${index + 1}`,
      title: readVizStringField(row, mapping.titleField, `Event ${index + 1}`),
      start: readVizStringField(row, mapping.startField),
      ...(mapping.endField ? { end: readVizStringField(row, mapping.endField) } : {}),
      ...(mapping.descriptionField ? { description: readVizStringField(row, mapping.descriptionField) } : {}),
      ...(progress !== undefined ? { progress } : {}),
    };
  });

const transformApiRowsToKanbanBoard = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "kanban"; cardIdField: string; cardTitleField: string; cardDescriptionField?: string; cardColumnField: string; columnOrder?: Array<{ id: string; title: string }> },
): { columns: Array<{ id: string; title: string; cards: Array<{ id: string; title: string; description?: string }> }> } => {
  const cardsByColumn = new Map<string, Array<{ id: string; title: string; description?: string }>>();
  rows.forEach((row, index) => {
    const columnKey = readVizStringField(row, mapping.cardColumnField, "default");
    const card = {
      id: readVizStringField(row, mapping.cardIdField, `card-${index + 1}`),
      title: readVizStringField(row, mapping.cardTitleField, `Card ${index + 1}`),
      ...(mapping.cardDescriptionField ? { description: readVizStringField(row, mapping.cardDescriptionField) } : {}),
    };
    cardsByColumn.set(columnKey, [...(cardsByColumn.get(columnKey) ?? []), card]);
  });
  const columnOrder = mapping.columnOrder && mapping.columnOrder.length > 0
    ? mapping.columnOrder
    : Array.from(cardsByColumn.keys()).map((key) => ({ id: key, title: key }));
  const columns = columnOrder.map((columnDef) => ({
    id: columnDef.id,
    title: columnDef.title,
    cards: cardsByColumn.get(columnDef.id) ?? cardsByColumn.get(columnDef.title) ?? [],
  }));
  cardsByColumn.forEach((cards, columnKey) => {
    if (!columns.some((column) => column.id === columnKey || column.title === columnKey)) {
      columns.push({ id: columnKey, title: columnKey, cards });
    }
  });
  return { columns };
};

const transformApiRowsToSheetData = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "sheet"; columns: Array<{ header: string; field: string }> },
): { columns: string[]; rows: string[][] } => ({
  columns: mapping.columns.map((column) => column.header),
  rows: rows.map((row) => mapping.columns.map((column) => readVizStringField(row, column.field))),
});

type EntityPickerOption = { id: string; textValue: string };
type EntityPickerFieldMapping = { returnField: string; displayField: string };

function normalizeEntityPickerItems(payload: unknown, mapping?: EntityPickerFieldMapping): EntityPickerOption[] {
  const returnField = mapping?.returnField?.trim() || "id";
  const displayField = mapping?.displayField?.trim() || "label";
  if (Array.isArray(payload)) {
    return payload
      .map((entry) => {
        if (!entry || typeof entry !== "object") {
          return null;
        }
        const record = entry as Record<string, unknown>;
        const mappedId = record[returnField];
        const id = typeof mappedId === "string" && mappedId.trim()
          ? mappedId.trim()
          : typeof record.id === "string" && record.id.trim()
            ? record.id.trim()
            : typeof record.value === "string" && record.value.trim()
              ? record.value.trim()
              : "";
        const mappedLabel = record[displayField];
        const textValue = typeof mappedLabel === "string" && mappedLabel.trim()
          ? mappedLabel.trim()
          : typeof record.textValue === "string" && record.textValue.trim()
            ? record.textValue.trim()
            : typeof record.label === "string" && record.label.trim()
              ? record.label.trim()
              : typeof record.name === "string" && record.name.trim()
                ? record.name.trim()
                : id;
        if (!id || !textValue) {
          return null;
        }
        return { id, textValue };
      })
      .filter((entry): entry is EntityPickerOption => entry !== null);
  }

  if (payload && typeof payload === "object") {
    const record = payload as Record<string, unknown>;
    const items = record.items ?? record.results ?? record.data;
    return normalizeEntityPickerItems(items, mapping);
  }

  return [];
}

function useEntityPickerOptions(entityRef: string, searchParam: string, mapping?: EntityPickerFieldMapping) {
  const [items, setItems] = React.useState<EntityPickerOption[]>([]);
  const [isLoading, setIsLoading] = React.useState(false);

  const loadOptions = React.useCallback(async (query: string) => {
    if (!entityRef) {
      setItems([]);
      return;
    }

    setIsLoading(true);
    try {
      const url = entityRef.startsWith("http")
        ? new URL(entityRef)
        : new URL(entityRef, window.location.origin);
      // Option A (parity audit items 31/32): Autocomplete is Select-based — no live typing.
      // Still honour an explicit non-empty query if a caller passes one, but initial load uses "".
      if (query.trim()) {
        url.searchParams.set(searchParam, query);
      }
      const response = await fetch(url.toString());
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      const payload = await response.json();
      setItems(normalizeEntityPickerItems(payload, mapping));
    } catch {
      setItems([]);
    } finally {
      setIsLoading(false);
    }
  }, [entityRef, searchParam, mapping?.returnField, mapping?.displayField]);

  React.useEffect(() => {
    void loadOptions("");
  }, [loadOptions]);

  return { items, isLoading, loadOptions };
}
function useDesignerStore<T extends Record<string, unknown>>(initial: T) {
  const [store, setStore] = React.useState<T>(initial);
  const patch = React.useCallback((path: string, value: unknown) => {
    setStore((previous) => {
      const next = { ...previous };
      setNestedPayloadValue(next, path, value);
      return next as T;
    });
  }, []);
  return { store, patch };
}
function evaluateDesignerCondition(
  designerStore: Record<string, unknown>,
  dataContext: Record<string, unknown> | null,
  scope: { item?: unknown; index?: number },
  condition: string,
): boolean {
  const trimmed = condition.trim();
  if (!trimmed) {
    return true;
  }
  try {
    const formatPathChain = (root: string, path: string): string => {
      const chain = path
        .split('.')
        .filter(Boolean)
        .map((segment) => {
          if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(segment)) {
            return `?.${segment}`;
          }
          return `?.[${JSON.stringify(segment)}]`;
        })
        .join('');
      return `(${root}${chain})`;
    };
    let compiled = trimmed
      .replace(/\bstore\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('designerStore', path))
      .replace(/\bdata\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('dataContext', path))
      .replace(/\bdataContext\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('dataContext', path));
    const evaluator = new Function('designerStore', 'dataContext', 'item', 'index', `return Boolean(${compiled});`);
    return Boolean(evaluator(designerStore, dataContext, scope.item, scope.index));
  } catch {
    return false;
  }
}

export const GeneratedComponent: React.FC = () => {
  const { store: designerStore, patch: patchDesignerStore } = useDesignerStore<Record<string, unknown>>({"selection":{"id":null}});
  const { data: raw_regionData_cmsContents_html_form_1785520939875_gp3s4, isLoading: isLoading_regionData_cmsContents_html_form_1785520939875_gp3s4, error: error_regionData_cmsContents_html_form_1785520939875_gp3s4, refresh: refresh_regionData_cmsContents_html_form_1785520939875_gp3s4 } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/contents/:id", designerStore, { "id": "routeParams.id" }), {});
  const regionData_cmsContents_html_form_1785520939875_gp3s4 = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContents_html_form_1785520939875_gp3s4, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContents_html_form_1785520939875_gp3s4]);
  const { data: raw_regionData_cmsContents_html_form_1785520939911_fu8nt, isLoading: isLoading_regionData_cmsContents_html_form_1785520939911_fu8nt, error: error_regionData_cmsContents_html_form_1785520939911_fu8nt, refresh: refresh_regionData_cmsContents_html_form_1785520939911_fu8nt } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/contents/:id", designerStore, { "id": "routeParams.id" }), {});
  const regionData_cmsContents_html_form_1785520939911_fu8nt = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContents_html_form_1785520939911_fu8nt, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContents_html_form_1785520939911_fu8nt]);
  const { data: raw_regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69, isLoading: isLoading_regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69, error: error_regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69, refresh: refresh_regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69 } = useDataFetch<unknown>("/api/cms/assets", {});
  const regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69 = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69]);
  const { data: raw_regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d, isLoading: isLoading_regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d, error: error_regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d, refresh: refresh_regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/assets", designerStore, { "id": "selection.id" }), {});
  const regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d]);
  const { data: raw_regionData_cmsContents_html_form_1785520940013_m2o3f, isLoading: isLoading_regionData_cmsContents_html_form_1785520940013_m2o3f, error: error_regionData_cmsContents_html_form_1785520940013_m2o3f, refresh: refresh_regionData_cmsContents_html_form_1785520940013_m2o3f } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/contents/:id", designerStore, { "id": "routeParams.id" }), {});
  const regionData_cmsContents_html_form_1785520940013_m2o3f = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContents_html_form_1785520940013_m2o3f, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContents_html_form_1785520940013_m2o3f]);
  const { data: raw_regionData_cmsContents_html_form_1785520940198_yar9f, isLoading: isLoading_regionData_cmsContents_html_form_1785520940198_yar9f, error: error_regionData_cmsContents_html_form_1785520940198_yar9f, refresh: refresh_regionData_cmsContents_html_form_1785520940198_yar9f } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/contents/:id", designerStore, { "id": "routeParams.id" }), {});
  const regionData_cmsContents_html_form_1785520940198_yar9f = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContents_html_form_1785520940198_yar9f, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContents_html_form_1785520940198_yar9f]);
  const { data: raw_regionData_cmsContents_html_form_1785520940295_4yqrv, isLoading: isLoading_regionData_cmsContents_html_form_1785520940295_4yqrv, error: error_regionData_cmsContents_html_form_1785520940295_4yqrv, refresh: refresh_regionData_cmsContents_html_form_1785520940295_4yqrv } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/contents/:id", designerStore, { "id": "routeParams.id" }), {});
  const regionData_cmsContents_html_form_1785520940295_4yqrv = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContents_html_form_1785520940295_4yqrv, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContents_html_form_1785520940295_4yqrv]);
  const { data: raw_regionData_cmsContents_html_form_1785520940444_hesui, isLoading: isLoading_regionData_cmsContents_html_form_1785520940444_hesui, error: error_regionData_cmsContents_html_form_1785520940444_hesui, refresh: refresh_regionData_cmsContents_html_form_1785520940444_hesui } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/contents/:id", designerStore, { "id": "routeParams.id" }), {});
  const regionData_cmsContents_html_form_1785520940444_hesui = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContents_html_form_1785520940444_hesui, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContents_html_form_1785520940444_hesui]);
  const { data: raw_regionData_cmsContents_html_form_1785520940525_stvys, isLoading: isLoading_regionData_cmsContents_html_form_1785520940525_stvys, error: error_regionData_cmsContents_html_form_1785520940525_stvys, refresh: refresh_regionData_cmsContents_html_form_1785520940525_stvys } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/contents/:id", designerStore, { "id": "routeParams.id" }), {});
  const regionData_cmsContents_html_form_1785520940525_stvys = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContents_html_form_1785520940525_stvys, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContents_html_form_1785520940525_stvys]);
  const { data: raw_regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133, isLoading: isLoading_regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133, error: error_regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133, refresh: refresh_regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133 } = useDataFetch<unknown>("/api/cms/relations", {});
  const regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133 = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133]);
  const { data: raw_regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47, isLoading: isLoading_regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47, error: error_regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47, refresh: refresh_regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47 } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/relations", designerStore, { "id": "selection.id" }), {});
  const regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47 = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47]);
  const { data: raw_regionData_cmsContents_html_form_1785520940781_42isk, isLoading: isLoading_regionData_cmsContents_html_form_1785520940781_42isk, error: error_regionData_cmsContents_html_form_1785520940781_42isk, refresh: refresh_regionData_cmsContents_html_form_1785520940781_42isk } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/contents/:id", designerStore, { "id": "routeParams.id" }), {});
  const regionData_cmsContents_html_form_1785520940781_42isk = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContents_html_form_1785520940781_42isk, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContents_html_form_1785520940781_42isk]);
  const { data: raw_regionData_cmsContents_html_form_1785520940891_47lmx, isLoading: isLoading_regionData_cmsContents_html_form_1785520940891_47lmx, error: error_regionData_cmsContents_html_form_1785520940891_47lmx, refresh: refresh_regionData_cmsContents_html_form_1785520940891_47lmx } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/contents/:id", designerStore, { "id": "routeParams.id" }), {});
  const regionData_cmsContents_html_form_1785520940891_47lmx = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContents_html_form_1785520940891_47lmx, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContents_html_form_1785520940891_47lmx]);
  const { data: raw_regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe, isLoading: isLoading_regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe, error: error_regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe, refresh: refresh_regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/contents/:id", designerStore, { "id": "routeParams.id" }), {});
  const regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe]);
  const { data: raw_regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad, isLoading: isLoading_regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad, error: error_regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad, refresh: refresh_regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/contents/:id", designerStore, { "id": "routeParams.id" }), {});
  const regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad]);
  const { data: raw_regionData_cmsContents_node_80938477_50e9_441d_80da_62a7fc2f6634, isLoading: isLoading_regionData_cmsContents_node_80938477_50e9_441d_80da_62a7fc2f6634, error: error_regionData_cmsContents_node_80938477_50e9_441d_80da_62a7fc2f6634, refresh: refresh_regionData_cmsContents_node_80938477_50e9_441d_80da_62a7fc2f6634 } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/contents/:id", designerStore, { "id": "routeParams.id" }), {});
  const regionData_cmsContents_node_80938477_50e9_441d_80da_62a7fc2f6634 = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContents_node_80938477_50e9_441d_80da_62a7fc2f6634, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContents_node_80938477_50e9_441d_80da_62a7fc2f6634]);
  const { data: raw_regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd, isLoading: isLoading_regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd, error: error_regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd, refresh: refresh_regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/contents/:id", designerStore, { "id": "routeParams.id" }), {});
  const regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd]);
  const { data: raw_regionData_cmsContents_node_d47908af_aca4_4737_91b3_b6d5d40d8cd7, isLoading: isLoading_regionData_cmsContents_node_d47908af_aca4_4737_91b3_b6d5d40d8cd7, error: error_regionData_cmsContents_node_d47908af_aca4_4737_91b3_b6d5d40d8cd7, refresh: refresh_regionData_cmsContents_node_d47908af_aca4_4737_91b3_b6d5d40d8cd7 } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/contents/:id", designerStore, { "id": "routeParams.id" }), {});
  const regionData_cmsContents_node_d47908af_aca4_4737_91b3_b6d5d40d8cd7 = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContents_node_d47908af_aca4_4737_91b3_b6d5d40d8cd7, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContents_node_d47908af_aca4_4737_91b3_b6d5d40d8cd7]);
  const { data: raw_regionData_cmsContents_html_form_1785520941308_fssdj, isLoading: isLoading_regionData_cmsContents_html_form_1785520941308_fssdj, error: error_regionData_cmsContents_html_form_1785520941308_fssdj, refresh: refresh_regionData_cmsContents_html_form_1785520941308_fssdj } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/contents/:id", designerStore, { "id": "routeParams.id" }), {});
  const regionData_cmsContents_html_form_1785520941308_fssdj = React.useMemo(() => coerceApiRecordValue(applyResponseDataPath(raw_regionData_cmsContents_html_form_1785520941308_fssdj, {"dataPath":"data","arrayPath":"data","totalPath":"count"})), [raw_regionData_cmsContents_html_form_1785520941308_fssdj]);
  const handleGridRowAction_heroui_app_table_grid_1785520939947_dfuyc = React.useCallback((row: Record<string, unknown>, actionId: string) => {
    switch (actionId) {
      case "edit": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-41a85cab-7382-4ad6-b26f-b0a7a9b21aa9", true);
        return;
      }
      case "delete": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-3f533133-b07b-429c-a396-8a3e7748ebda", true);
        return;
      }
      default:
        return;
    }
  }, [patchDesignerStore]);
  const handleGridRowAction_heroui_app_table_grid_1785520940673_flr3i = React.useCallback((row: Record<string, unknown>, actionId: string) => {
    switch (actionId) {
      case "edit": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-132a0a55-4dab-49d3-897e-c1fac1254a15", true);
        return;
      }
      case "delete": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-5e28a7e2-a612-4531-9fb2-67244e8a4f43", true);
        return;
      }
      default:
        return;
    }
  }, [patchDesignerStore]);
  const { data: raw_gridData_heroui_app_table_grid_1785520939947_dfuyc, isLoading: isLoading_gridData_heroui_app_table_grid_1785520939947_dfuyc, error: error_gridData_heroui_app_table_grid_1785520939947_dfuyc, refresh: refresh_gridData_heroui_app_table_grid_1785520939947_dfuyc } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/assets", designerStore, { "search": "gridToolbar.search", "sortBy": "gridQuery.sortBy", "sortDir": "gridQuery.sortDir", "page": "gridQuery.page", "pageSize": "gridQuery.pageSize", "fileName": "gridQuery.filters.fileName" }), {});
  const gridData_heroui_app_table_grid_1785520939947_dfuyc = React.useMemo(() => applyResponseDataPath(raw_gridData_heroui_app_table_grid_1785520939947_dfuyc, {"dataPath":"data","arrayPath":"data","totalPath":"count"}), [raw_gridData_heroui_app_table_grid_1785520939947_dfuyc]);
  const { data: raw_gridData_heroui_app_table_grid_1785520940673_flr3i, isLoading: isLoading_gridData_heroui_app_table_grid_1785520940673_flr3i, error: error_gridData_heroui_app_table_grid_1785520940673_flr3i, refresh: refresh_gridData_heroui_app_table_grid_1785520940673_flr3i } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/relations", designerStore, { "search": "gridToolbar.search", "sortBy": "gridQuery.sortBy", "sortDir": "gridQuery.sortDir", "page": "gridQuery.page", "pageSize": "gridQuery.pageSize", "filter[contentIdA]": "routeParams.id" }), {});
  const gridData_heroui_app_table_grid_1785520940673_flr3i = React.useMemo(() => applyResponseDataPath(raw_gridData_heroui_app_table_grid_1785520940673_flr3i, {"dataPath":"data","arrayPath":"data","totalPath":"count"}), [raw_gridData_heroui_app_table_grid_1785520940673_flr3i]);
  const { data: raw_gridData_heroui_app_table_grid_1785520940709_3evjs, isLoading: isLoading_gridData_heroui_app_table_grid_1785520940709_3evjs, error: error_gridData_heroui_app_table_grid_1785520940709_3evjs, refresh: refresh_gridData_heroui_app_table_grid_1785520940709_3evjs } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/relations", designerStore, { "search": "gridToolbar.search", "sortBy": "gridQuery.sortBy", "sortDir": "gridQuery.sortDir", "page": "gridQuery.page", "pageSize": "gridQuery.pageSize", "filter[contentIdB]": "routeParams.id" }), {});
  const gridData_heroui_app_table_grid_1785520940709_3evjs = React.useMemo(() => applyResponseDataPath(raw_gridData_heroui_app_table_grid_1785520940709_3evjs, {"dataPath":"data","arrayPath":"data","totalPath":"count"}), [raw_gridData_heroui_app_table_grid_1785520940709_3evjs]);
  const { data: raw_gridData_heroui_app_table_grid_1785520941117_h6zx4, isLoading: isLoading_gridData_heroui_app_table_grid_1785520941117_h6zx4, error: error_gridData_heroui_app_table_grid_1785520941117_h6zx4, refresh: refresh_gridData_heroui_app_table_grid_1785520941117_h6zx4 } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/revisions", designerStore, { "filter[contentId]": "routeParams.id" }), {});
  const gridData_heroui_app_table_grid_1785520941117_h6zx4 = React.useMemo(() => applyResponseDataPath(raw_gridData_heroui_app_table_grid_1785520941117_h6zx4, {"dataPath":"data","arrayPath":"data","totalPath":"count"}), [raw_gridData_heroui_app_table_grid_1785520941117_h6zx4]);
  const { data: raw_gridData_heroui_app_table_grid_1785520941205_diay5, isLoading: isLoading_gridData_heroui_app_table_grid_1785520941205_diay5, error: error_gridData_heroui_app_table_grid_1785520941205_diay5, refresh: refresh_gridData_heroui_app_table_grid_1785520941205_diay5 } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/comments", designerStore, { "filter[contentId]": "routeParams.id" }), {});
  const gridData_heroui_app_table_grid_1785520941205_diay5 = React.useMemo(() => applyResponseDataPath(raw_gridData_heroui_app_table_grid_1785520941205_diay5, {"dataPath":"data","arrayPath":"data","totalPath":"count"}), [raw_gridData_heroui_app_table_grid_1785520941205_diay5]);
  const gridColumns_heroui_app_table_grid_1785520939947_dfuyc = React.useMemo(() => buildAppTableGridColumns([{"key":"fileName","label":"File name","sort":true,"filter":true,"filterType":"text","cardRole":"title"},{"key":"fileMime","label":"MIME","sort":true,"cardRole":"field"},{"key":"fileSize","label":"Size","sort":true,"cardRole":"meta"},{"key":"sortOrder","label":"Order","sort":true,"cardRole":"meta"},{"key":"updatedAt","label":"Updated","sort":true,"cellKind":"date","cardRole":"meta","hideBelow":"lg"},{"key":"actions","label":"","kind":"action-group","actions":[{"actionId":"edit","icon":"Pencil","intent":"edit","tooltip":"Edit","behavior":{"kind":"open-modal","modalNodeId":"node-41a85cab-7382-4ad6-b26f-b0a7a9b21aa9","primaryKeyField":"id","selectionStorePath":"selection.id"}},{"actionId":"delete","icon":"Trash2","intent":"delete","tooltip":"Delete","behavior":{"kind":"open-modal","modalNodeId":"node-3f533133-b07b-429c-a396-8a3e7748ebda","primaryKeyField":"id","selectionStorePath":"selection.id"}}],"cardRole":"actions","layoutHideable":false,"layoutResizable":false,"layoutReorderable":false,"width":"140px"}], "server", {
    mode: 'runtime',
    detailFlowRef: { current: null },
    rowActionHandlerRef: { current: handleGridRowAction_heroui_app_table_grid_1785520939947_dfuyc },
    cellClickHandlerRef: { current: undefined },
    designerStoreRef: { current: designerStore },
  }), [designerStore, handleGridRowAction_heroui_app_table_grid_1785520939947_dfuyc]);
  const [gridQuery_heroui_app_table_grid_1785520939947_dfuyc, setGridQuery_heroui_app_table_grid_1785520939947_dfuyc] = React.useState<GridQueryState>(() => ({ ...EMPTY_GRID_QUERY, sort: { columnId: "sortOrder", direction: 'asc' } }));
  const [gridPage_heroui_app_table_grid_1785520939947_dfuyc, setGridPage_heroui_app_table_grid_1785520939947_dfuyc] = React.useState(1);
  const [gridPageSize_heroui_app_table_grid_1785520939947_dfuyc, setGridPageSize_heroui_app_table_grid_1785520939947_dfuyc] = React.useState(50);
  const [gridListMode_heroui_app_table_grid_1785520939947_dfuyc, setGridListMode_heroui_app_table_grid_1785520939947_dfuyc] = React.useState<'paging' | 'infinite'>("paging");
  const [gridColumnLayout_heroui_app_table_grid_1785520939947_dfuyc, setGridColumnLayout_heroui_app_table_grid_1785520939947_dfuyc] = React.useState(() => createDefaultColumnLayout(gridColumns_heroui_app_table_grid_1785520939947_dfuyc));
  const [gridSearchInput_heroui_app_table_grid_1785520939947_dfuyc, setGridSearchInput_heroui_app_table_grid_1785520939947_dfuyc] = React.useState('');
  const [gridDebouncedSearch_heroui_app_table_grid_1785520939947_dfuyc, setGridDebouncedSearch_heroui_app_table_grid_1785520939947_dfuyc] = React.useState('');
  const [gridRoleFilters_heroui_app_table_grid_1785520939947_dfuyc, setGridRoleFilters_heroui_app_table_grid_1785520939947_dfuyc] = React.useState<Record<string, boolean>>({});
  const gridFilteredRows_heroui_app_table_grid_1785520939947_dfuyc = React.useMemo(() => applyClientGridQuery(((Array.isArray(gridData_heroui_app_table_grid_1785520939947_dfuyc?.data) ? gridData_heroui_app_table_grid_1785520939947_dfuyc?.data : []) ?? []), gridQuery_heroui_app_table_grid_1785520939947_dfuyc, gridColumns_heroui_app_table_grid_1785520939947_dfuyc, "server"), [gridQuery_heroui_app_table_grid_1785520939947_dfuyc, gridColumns_heroui_app_table_grid_1785520939947_dfuyc]);
  const gridApiTotal_heroui_app_table_grid_1785520939947_dfuyc = React.useMemo(() => {
    const raw = raw_gridData_heroui_app_table_grid_1785520939947_dfuyc;
    const value = readNestedContextValue((raw && typeof raw === 'object' ? raw as Record<string, unknown> : {}), "count");
    const parsed = typeof value === 'number' ? value : Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : 0;
  }, [raw_gridData_heroui_app_table_grid_1785520939947_dfuyc]);
  const gridTotalCount_heroui_app_table_grid_1785520939947_dfuyc = resolveDataGridTotalCount({ page: gridPage_heroui_app_table_grid_1785520939947_dfuyc, pageSize: gridPageSize_heroui_app_table_grid_1785520939947_dfuyc, total: gridApiTotal_heroui_app_table_grid_1785520939947_dfuyc, gridQueryMode: "server" }, gridFilteredRows_heroui_app_table_grid_1785520939947_dfuyc.length);
  const gridPaging_heroui_app_table_grid_1785520939947_dfuyc = sliceDataGridRowsForDisplay(gridFilteredRows_heroui_app_table_grid_1785520939947_dfuyc, gridPage_heroui_app_table_grid_1785520939947_dfuyc, gridPageSize_heroui_app_table_grid_1785520939947_dfuyc, gridTotalCount_heroui_app_table_grid_1785520939947_dfuyc, "server");
  const handleGridQueryChange_heroui_app_table_grid_1785520939947_dfuyc = React.useCallback((nextQuery: GridQueryState) => {
    setGridQuery_heroui_app_table_grid_1785520939947_dfuyc(nextQuery);
    setGridPage_heroui_app_table_grid_1785520939947_dfuyc(1);
    patchDesignerStore("gridQuery.sortBy", nextQuery.sort?.columnId ?? '');
    patchDesignerStore("gridQuery.sortDir", nextQuery.sort?.direction ?? '');
  }, [patchDesignerStore]);
  const handleGridPageChange_heroui_app_table_grid_1785520939947_dfuyc = React.useCallback((nextPage: number) => {
    setGridPage_heroui_app_table_grid_1785520939947_dfuyc(nextPage);
    patchDesignerStore("gridQuery.page", nextPage);
  }, [patchDesignerStore]);
  const handleGridPageSizeChange_heroui_app_table_grid_1785520939947_dfuyc = React.useCallback((nextSize: number) => {
    setGridPageSize_heroui_app_table_grid_1785520939947_dfuyc(nextSize);
    setGridPage_heroui_app_table_grid_1785520939947_dfuyc(1);
    patchDesignerStore("gridQuery.pageSize", nextSize);
  }, [patchDesignerStore]);
  const handleGridSortByChange_heroui_app_table_grid_1785520939947_dfuyc = React.useCallback((nextSortBy: string) => {
    setGridQuery_heroui_app_table_grid_1785520939947_dfuyc((current: GridQueryState) => ({ ...current, sort: nextSortBy ? { columnId: nextSortBy, direction: current.sort?.direction ?? 'asc' } : null }));
  }, []);
  const handleGridToggleSortDirection_heroui_app_table_grid_1785520939947_dfuyc = React.useCallback(() => {
    setGridQuery_heroui_app_table_grid_1785520939947_dfuyc((current: GridQueryState) => (current.sort ? { ...current, sort: { ...current.sort, direction: current.sort.direction === 'asc' ? 'desc' : 'asc' } } : current));
  }, []);
  const searchDebounceTimer_heroui_app_table_grid_1785520939947_dfuyc = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const handleGridSearchChange_heroui_app_table_grid_1785520939947_dfuyc = React.useCallback((nextValue: string) => {
    setGridSearchInput_heroui_app_table_grid_1785520939947_dfuyc(nextValue);
    if (searchDebounceTimer_heroui_app_table_grid_1785520939947_dfuyc.current) {
      clearTimeout(searchDebounceTimer_heroui_app_table_grid_1785520939947_dfuyc.current);
    }
    searchDebounceTimer_heroui_app_table_grid_1785520939947_dfuyc.current = setTimeout(() => {
      setGridDebouncedSearch_heroui_app_table_grid_1785520939947_dfuyc(nextValue);
      setGridPage_heroui_app_table_grid_1785520939947_dfuyc(1);
      patchDesignerStore("gridToolbar.search", nextValue);
    }, 300);
  }, [patchDesignerStore]);

  const gridColumns_heroui_app_table_grid_1785520940673_flr3i = React.useMemo(() => buildAppTableGridColumns([{"key":"contentIdBTitle","label":"Related content","sort":true,"cellKind":"link","cellFields":{"labelField":"contentIdBTitle","labelFallbackField":"contentIdB","hrefTemplate":"/studio/cms/contents/edit/{contentIdB}"},"cardRole":"title"},{"key":"contentIdBSlug","label":"Slug","cardRole":"field"},{"key":"note","label":"Note","cardRole":"meta"},{"key":"actions","label":"","kind":"action-group","actions":[{"actionId":"edit","icon":"Pencil","intent":"edit","tooltip":"Edit","behavior":{"kind":"open-modal","modalNodeId":"node-132a0a55-4dab-49d3-897e-c1fac1254a15","primaryKeyField":"id","selectionStorePath":"selection.id"}},{"actionId":"delete","icon":"Trash2","intent":"delete","tooltip":"Delete","behavior":{"kind":"open-modal","modalNodeId":"node-5e28a7e2-a612-4531-9fb2-67244e8a4f43","primaryKeyField":"id","selectionStorePath":"selection.id"}}],"cardRole":"actions","layoutHideable":false,"layoutResizable":false,"layoutReorderable":false,"width":"140px"}], "server", {
    mode: 'runtime',
    detailFlowRef: { current: null },
    rowActionHandlerRef: { current: handleGridRowAction_heroui_app_table_grid_1785520940673_flr3i },
    cellClickHandlerRef: { current: undefined },
    designerStoreRef: { current: designerStore },
  }), [designerStore, handleGridRowAction_heroui_app_table_grid_1785520940673_flr3i]);
  const [gridQuery_heroui_app_table_grid_1785520940673_flr3i, setGridQuery_heroui_app_table_grid_1785520940673_flr3i] = React.useState<GridQueryState>(() => ({ ...EMPTY_GRID_QUERY, sort: { columnId: "id", direction: 'asc' } }));
  const [gridPage_heroui_app_table_grid_1785520940673_flr3i, setGridPage_heroui_app_table_grid_1785520940673_flr3i] = React.useState(1);
  const [gridPageSize_heroui_app_table_grid_1785520940673_flr3i, setGridPageSize_heroui_app_table_grid_1785520940673_flr3i] = React.useState(50);
  const [gridListMode_heroui_app_table_grid_1785520940673_flr3i, setGridListMode_heroui_app_table_grid_1785520940673_flr3i] = React.useState<'paging' | 'infinite'>("paging");
  const [gridColumnLayout_heroui_app_table_grid_1785520940673_flr3i, setGridColumnLayout_heroui_app_table_grid_1785520940673_flr3i] = React.useState(() => createDefaultColumnLayout(gridColumns_heroui_app_table_grid_1785520940673_flr3i));
  const [gridSearchInput_heroui_app_table_grid_1785520940673_flr3i, setGridSearchInput_heroui_app_table_grid_1785520940673_flr3i] = React.useState('');
  const [gridDebouncedSearch_heroui_app_table_grid_1785520940673_flr3i, setGridDebouncedSearch_heroui_app_table_grid_1785520940673_flr3i] = React.useState('');
  const [gridRoleFilters_heroui_app_table_grid_1785520940673_flr3i, setGridRoleFilters_heroui_app_table_grid_1785520940673_flr3i] = React.useState<Record<string, boolean>>({});
  const gridFilteredRows_heroui_app_table_grid_1785520940673_flr3i = React.useMemo(() => applyClientGridQuery(((Array.isArray(gridData_heroui_app_table_grid_1785520940673_flr3i?.data) ? gridData_heroui_app_table_grid_1785520940673_flr3i?.data : []) ?? []), gridQuery_heroui_app_table_grid_1785520940673_flr3i, gridColumns_heroui_app_table_grid_1785520940673_flr3i, "server"), [gridQuery_heroui_app_table_grid_1785520940673_flr3i, gridColumns_heroui_app_table_grid_1785520940673_flr3i]);
  const gridApiTotal_heroui_app_table_grid_1785520940673_flr3i = React.useMemo(() => {
    const raw = raw_gridData_heroui_app_table_grid_1785520940673_flr3i;
    const value = readNestedContextValue((raw && typeof raw === 'object' ? raw as Record<string, unknown> : {}), "count");
    const parsed = typeof value === 'number' ? value : Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : 0;
  }, [raw_gridData_heroui_app_table_grid_1785520940673_flr3i]);
  const gridTotalCount_heroui_app_table_grid_1785520940673_flr3i = resolveDataGridTotalCount({ page: gridPage_heroui_app_table_grid_1785520940673_flr3i, pageSize: gridPageSize_heroui_app_table_grid_1785520940673_flr3i, total: gridApiTotal_heroui_app_table_grid_1785520940673_flr3i, gridQueryMode: "server" }, gridFilteredRows_heroui_app_table_grid_1785520940673_flr3i.length);
  const gridPaging_heroui_app_table_grid_1785520940673_flr3i = sliceDataGridRowsForDisplay(gridFilteredRows_heroui_app_table_grid_1785520940673_flr3i, gridPage_heroui_app_table_grid_1785520940673_flr3i, gridPageSize_heroui_app_table_grid_1785520940673_flr3i, gridTotalCount_heroui_app_table_grid_1785520940673_flr3i, "server");
  const handleGridQueryChange_heroui_app_table_grid_1785520940673_flr3i = React.useCallback((nextQuery: GridQueryState) => {
    setGridQuery_heroui_app_table_grid_1785520940673_flr3i(nextQuery);
    setGridPage_heroui_app_table_grid_1785520940673_flr3i(1);
    patchDesignerStore("gridQuery.sortBy", nextQuery.sort?.columnId ?? '');
    patchDesignerStore("gridQuery.sortDir", nextQuery.sort?.direction ?? '');
  }, [patchDesignerStore]);
  const handleGridPageChange_heroui_app_table_grid_1785520940673_flr3i = React.useCallback((nextPage: number) => {
    setGridPage_heroui_app_table_grid_1785520940673_flr3i(nextPage);
    patchDesignerStore("gridQuery.page", nextPage);
  }, [patchDesignerStore]);
  const handleGridPageSizeChange_heroui_app_table_grid_1785520940673_flr3i = React.useCallback((nextSize: number) => {
    setGridPageSize_heroui_app_table_grid_1785520940673_flr3i(nextSize);
    setGridPage_heroui_app_table_grid_1785520940673_flr3i(1);
    patchDesignerStore("gridQuery.pageSize", nextSize);
  }, [patchDesignerStore]);
  const handleGridSortByChange_heroui_app_table_grid_1785520940673_flr3i = React.useCallback((nextSortBy: string) => {
    setGridQuery_heroui_app_table_grid_1785520940673_flr3i((current: GridQueryState) => ({ ...current, sort: nextSortBy ? { columnId: nextSortBy, direction: current.sort?.direction ?? 'asc' } : null }));
  }, []);
  const handleGridToggleSortDirection_heroui_app_table_grid_1785520940673_flr3i = React.useCallback(() => {
    setGridQuery_heroui_app_table_grid_1785520940673_flr3i((current: GridQueryState) => (current.sort ? { ...current, sort: { ...current.sort, direction: current.sort.direction === 'asc' ? 'desc' : 'asc' } } : current));
  }, []);
  const searchDebounceTimer_heroui_app_table_grid_1785520940673_flr3i = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const handleGridSearchChange_heroui_app_table_grid_1785520940673_flr3i = React.useCallback((nextValue: string) => {
    setGridSearchInput_heroui_app_table_grid_1785520940673_flr3i(nextValue);
    if (searchDebounceTimer_heroui_app_table_grid_1785520940673_flr3i.current) {
      clearTimeout(searchDebounceTimer_heroui_app_table_grid_1785520940673_flr3i.current);
    }
    searchDebounceTimer_heroui_app_table_grid_1785520940673_flr3i.current = setTimeout(() => {
      setGridDebouncedSearch_heroui_app_table_grid_1785520940673_flr3i(nextValue);
      setGridPage_heroui_app_table_grid_1785520940673_flr3i(1);
      patchDesignerStore("gridToolbar.search", nextValue);
    }, 300);
  }, [patchDesignerStore]);

  const gridColumns_heroui_app_table_grid_1785520940709_3evjs = React.useMemo(() => buildAppTableGridColumns([{"key":"contentIdATitle","label":"Related content","sort":true,"cellKind":"link","cellFields":{"labelField":"contentIdATitle","labelFallbackField":"contentIdA","hrefTemplate":"/studio/cms/contents/edit/{contentIdA}"},"cardRole":"title"},{"key":"contentIdASlug","label":"Slug","cardRole":"field"},{"key":"note","label":"Note","cardRole":"meta"}], "server", {
    mode: 'runtime',
    detailFlowRef: { current: null },
    rowActionHandlerRef: { current: undefined },
    cellClickHandlerRef: { current: undefined },
    designerStoreRef: { current: designerStore },
  }), [designerStore]);
  const [gridQuery_heroui_app_table_grid_1785520940709_3evjs, setGridQuery_heroui_app_table_grid_1785520940709_3evjs] = React.useState<GridQueryState>(() => ({ ...EMPTY_GRID_QUERY, sort: { columnId: "id", direction: 'asc' } }));
  const [gridPage_heroui_app_table_grid_1785520940709_3evjs, setGridPage_heroui_app_table_grid_1785520940709_3evjs] = React.useState(1);
  const [gridPageSize_heroui_app_table_grid_1785520940709_3evjs, setGridPageSize_heroui_app_table_grid_1785520940709_3evjs] = React.useState(50);
  const [gridListMode_heroui_app_table_grid_1785520940709_3evjs, setGridListMode_heroui_app_table_grid_1785520940709_3evjs] = React.useState<'paging' | 'infinite'>("paging");
  const [gridColumnLayout_heroui_app_table_grid_1785520940709_3evjs, setGridColumnLayout_heroui_app_table_grid_1785520940709_3evjs] = React.useState(() => createDefaultColumnLayout(gridColumns_heroui_app_table_grid_1785520940709_3evjs));
  const [gridSearchInput_heroui_app_table_grid_1785520940709_3evjs, setGridSearchInput_heroui_app_table_grid_1785520940709_3evjs] = React.useState('');
  const [gridDebouncedSearch_heroui_app_table_grid_1785520940709_3evjs, setGridDebouncedSearch_heroui_app_table_grid_1785520940709_3evjs] = React.useState('');
  const [gridRoleFilters_heroui_app_table_grid_1785520940709_3evjs, setGridRoleFilters_heroui_app_table_grid_1785520940709_3evjs] = React.useState<Record<string, boolean>>({});
  const gridFilteredRows_heroui_app_table_grid_1785520940709_3evjs = React.useMemo(() => applyClientGridQuery(((Array.isArray(gridData_heroui_app_table_grid_1785520940709_3evjs?.data) ? gridData_heroui_app_table_grid_1785520940709_3evjs?.data : []) ?? []), gridQuery_heroui_app_table_grid_1785520940709_3evjs, gridColumns_heroui_app_table_grid_1785520940709_3evjs, "server"), [gridQuery_heroui_app_table_grid_1785520940709_3evjs, gridColumns_heroui_app_table_grid_1785520940709_3evjs]);
  const gridApiTotal_heroui_app_table_grid_1785520940709_3evjs = React.useMemo(() => {
    const raw = raw_gridData_heroui_app_table_grid_1785520940709_3evjs;
    const value = readNestedContextValue((raw && typeof raw === 'object' ? raw as Record<string, unknown> : {}), "count");
    const parsed = typeof value === 'number' ? value : Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : 0;
  }, [raw_gridData_heroui_app_table_grid_1785520940709_3evjs]);
  const gridTotalCount_heroui_app_table_grid_1785520940709_3evjs = resolveDataGridTotalCount({ page: gridPage_heroui_app_table_grid_1785520940709_3evjs, pageSize: gridPageSize_heroui_app_table_grid_1785520940709_3evjs, total: gridApiTotal_heroui_app_table_grid_1785520940709_3evjs, gridQueryMode: "server" }, gridFilteredRows_heroui_app_table_grid_1785520940709_3evjs.length);
  const gridPaging_heroui_app_table_grid_1785520940709_3evjs = sliceDataGridRowsForDisplay(gridFilteredRows_heroui_app_table_grid_1785520940709_3evjs, gridPage_heroui_app_table_grid_1785520940709_3evjs, gridPageSize_heroui_app_table_grid_1785520940709_3evjs, gridTotalCount_heroui_app_table_grid_1785520940709_3evjs, "server");
  const handleGridQueryChange_heroui_app_table_grid_1785520940709_3evjs = React.useCallback((nextQuery: GridQueryState) => {
    setGridQuery_heroui_app_table_grid_1785520940709_3evjs(nextQuery);
    setGridPage_heroui_app_table_grid_1785520940709_3evjs(1);
    patchDesignerStore("gridQuery.sortBy", nextQuery.sort?.columnId ?? '');
    patchDesignerStore("gridQuery.sortDir", nextQuery.sort?.direction ?? '');
  }, [patchDesignerStore]);
  const handleGridPageChange_heroui_app_table_grid_1785520940709_3evjs = React.useCallback((nextPage: number) => {
    setGridPage_heroui_app_table_grid_1785520940709_3evjs(nextPage);
    patchDesignerStore("gridQuery.page", nextPage);
  }, [patchDesignerStore]);
  const handleGridPageSizeChange_heroui_app_table_grid_1785520940709_3evjs = React.useCallback((nextSize: number) => {
    setGridPageSize_heroui_app_table_grid_1785520940709_3evjs(nextSize);
    setGridPage_heroui_app_table_grid_1785520940709_3evjs(1);
    patchDesignerStore("gridQuery.pageSize", nextSize);
  }, [patchDesignerStore]);
  const handleGridSortByChange_heroui_app_table_grid_1785520940709_3evjs = React.useCallback((nextSortBy: string) => {
    setGridQuery_heroui_app_table_grid_1785520940709_3evjs((current: GridQueryState) => ({ ...current, sort: nextSortBy ? { columnId: nextSortBy, direction: current.sort?.direction ?? 'asc' } : null }));
  }, []);
  const handleGridToggleSortDirection_heroui_app_table_grid_1785520940709_3evjs = React.useCallback(() => {
    setGridQuery_heroui_app_table_grid_1785520940709_3evjs((current: GridQueryState) => (current.sort ? { ...current, sort: { ...current.sort, direction: current.sort.direction === 'asc' ? 'desc' : 'asc' } } : current));
  }, []);
  const searchDebounceTimer_heroui_app_table_grid_1785520940709_3evjs = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const handleGridSearchChange_heroui_app_table_grid_1785520940709_3evjs = React.useCallback((nextValue: string) => {
    setGridSearchInput_heroui_app_table_grid_1785520940709_3evjs(nextValue);
    if (searchDebounceTimer_heroui_app_table_grid_1785520940709_3evjs.current) {
      clearTimeout(searchDebounceTimer_heroui_app_table_grid_1785520940709_3evjs.current);
    }
    searchDebounceTimer_heroui_app_table_grid_1785520940709_3evjs.current = setTimeout(() => {
      setGridDebouncedSearch_heroui_app_table_grid_1785520940709_3evjs(nextValue);
      setGridPage_heroui_app_table_grid_1785520940709_3evjs(1);
      patchDesignerStore("gridToolbar.search", nextValue);
    }, 300);
  }, [patchDesignerStore]);

  const gridColumns_heroui_app_table_grid_1785520941117_h6zx4 = React.useMemo(() => buildAppTableGridColumns([{"key":"revisionNo","label":"#","sort":true},{"key":"title","label":"Title"},{"key":"summary","label":"Summary"},{"key":"body","label":"Body"}], "client", {
    mode: 'runtime',
    detailFlowRef: { current: null },
    rowActionHandlerRef: { current: undefined },
    cellClickHandlerRef: { current: undefined },
    designerStoreRef: { current: designerStore },
  }), [designerStore]);
  const [gridQuery_heroui_app_table_grid_1785520941117_h6zx4, setGridQuery_heroui_app_table_grid_1785520941117_h6zx4] = React.useState<GridQueryState>(() => ({ ...EMPTY_GRID_QUERY, sort: { columnId: "revisionNo", direction: 'asc' } }));
  const [gridPage_heroui_app_table_grid_1785520941117_h6zx4, setGridPage_heroui_app_table_grid_1785520941117_h6zx4] = React.useState(1);
  const [gridPageSize_heroui_app_table_grid_1785520941117_h6zx4, setGridPageSize_heroui_app_table_grid_1785520941117_h6zx4] = React.useState(50);
  const [gridListMode_heroui_app_table_grid_1785520941117_h6zx4, setGridListMode_heroui_app_table_grid_1785520941117_h6zx4] = React.useState<'paging' | 'infinite'>("paging");
  const [gridColumnLayout_heroui_app_table_grid_1785520941117_h6zx4, setGridColumnLayout_heroui_app_table_grid_1785520941117_h6zx4] = React.useState(() => createDefaultColumnLayout(gridColumns_heroui_app_table_grid_1785520941117_h6zx4));
  const gridFilteredRows_heroui_app_table_grid_1785520941117_h6zx4 = React.useMemo(() => applyClientGridQuery(((Array.isArray(gridData_heroui_app_table_grid_1785520941117_h6zx4?.data) ? gridData_heroui_app_table_grid_1785520941117_h6zx4?.data : []) ?? []), gridQuery_heroui_app_table_grid_1785520941117_h6zx4, gridColumns_heroui_app_table_grid_1785520941117_h6zx4, "client"), [gridQuery_heroui_app_table_grid_1785520941117_h6zx4, gridColumns_heroui_app_table_grid_1785520941117_h6zx4]);
  const gridApiTotal_heroui_app_table_grid_1785520941117_h6zx4 = React.useMemo(() => {
    const raw = raw_gridData_heroui_app_table_grid_1785520941117_h6zx4;
    const value = readNestedContextValue((raw && typeof raw === 'object' ? raw as Record<string, unknown> : {}), "count");
    const parsed = typeof value === 'number' ? value : Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : 0;
  }, [raw_gridData_heroui_app_table_grid_1785520941117_h6zx4]);
  const gridTotalCount_heroui_app_table_grid_1785520941117_h6zx4 = resolveDataGridTotalCount({ page: gridPage_heroui_app_table_grid_1785520941117_h6zx4, pageSize: gridPageSize_heroui_app_table_grid_1785520941117_h6zx4, total: gridApiTotal_heroui_app_table_grid_1785520941117_h6zx4, gridQueryMode: "client" }, gridFilteredRows_heroui_app_table_grid_1785520941117_h6zx4.length);
  const gridPaging_heroui_app_table_grid_1785520941117_h6zx4 = sliceDataGridRowsForDisplay(gridFilteredRows_heroui_app_table_grid_1785520941117_h6zx4, gridPage_heroui_app_table_grid_1785520941117_h6zx4, gridPageSize_heroui_app_table_grid_1785520941117_h6zx4, gridTotalCount_heroui_app_table_grid_1785520941117_h6zx4, "client");
  const handleGridQueryChange_heroui_app_table_grid_1785520941117_h6zx4 = React.useCallback((nextQuery: GridQueryState) => {
    setGridQuery_heroui_app_table_grid_1785520941117_h6zx4(nextQuery);
    setGridPage_heroui_app_table_grid_1785520941117_h6zx4(1);
  }, [patchDesignerStore]);
  const handleGridPageChange_heroui_app_table_grid_1785520941117_h6zx4 = React.useCallback((nextPage: number) => {
    setGridPage_heroui_app_table_grid_1785520941117_h6zx4(nextPage);
  }, [patchDesignerStore]);
  const handleGridPageSizeChange_heroui_app_table_grid_1785520941117_h6zx4 = React.useCallback((nextSize: number) => {
    setGridPageSize_heroui_app_table_grid_1785520941117_h6zx4(nextSize);
    setGridPage_heroui_app_table_grid_1785520941117_h6zx4(1);
  }, [patchDesignerStore]);
  const handleGridSortByChange_heroui_app_table_grid_1785520941117_h6zx4 = React.useCallback((nextSortBy: string) => {
    setGridQuery_heroui_app_table_grid_1785520941117_h6zx4((current: GridQueryState) => ({ ...current, sort: nextSortBy ? { columnId: nextSortBy, direction: current.sort?.direction ?? 'asc' } : null }));
  }, []);
  const handleGridToggleSortDirection_heroui_app_table_grid_1785520941117_h6zx4 = React.useCallback(() => {
    setGridQuery_heroui_app_table_grid_1785520941117_h6zx4((current: GridQueryState) => (current.sort ? { ...current, sort: { ...current.sort, direction: current.sort.direction === 'asc' ? 'desc' : 'asc' } } : current));
  }, []);

  const gridColumns_heroui_app_table_grid_1785520941205_diay5 = React.useMemo(() => buildAppTableGridColumns([{"key":"authorDisplayName","label":"Author","sort":true},{"key":"body","label":"Comment"},{"key":"statusCode","label":"Status","cellKind":"status-badge","cellFields":{"labelField":"statusCodeTitle","labelFallbackField":"statusCode","htmlField":"statusCodeUiHtml"}},{"key":"createdAt","label":"Submitted","sort":true,"cellKind":"date"}], "client", {
    mode: 'runtime',
    detailFlowRef: { current: null },
    rowActionHandlerRef: { current: undefined },
    cellClickHandlerRef: { current: undefined },
    designerStoreRef: { current: designerStore },
  }), [designerStore]);
  const [gridQuery_heroui_app_table_grid_1785520941205_diay5, setGridQuery_heroui_app_table_grid_1785520941205_diay5] = React.useState<GridQueryState>(() => ({ ...EMPTY_GRID_QUERY, sort: { columnId: "createdAt", direction: 'asc' } }));
  const [gridPage_heroui_app_table_grid_1785520941205_diay5, setGridPage_heroui_app_table_grid_1785520941205_diay5] = React.useState(1);
  const [gridPageSize_heroui_app_table_grid_1785520941205_diay5, setGridPageSize_heroui_app_table_grid_1785520941205_diay5] = React.useState(50);
  const [gridListMode_heroui_app_table_grid_1785520941205_diay5, setGridListMode_heroui_app_table_grid_1785520941205_diay5] = React.useState<'paging' | 'infinite'>("paging");
  const [gridColumnLayout_heroui_app_table_grid_1785520941205_diay5, setGridColumnLayout_heroui_app_table_grid_1785520941205_diay5] = React.useState(() => createDefaultColumnLayout(gridColumns_heroui_app_table_grid_1785520941205_diay5));
  const gridFilteredRows_heroui_app_table_grid_1785520941205_diay5 = React.useMemo(() => applyClientGridQuery(((Array.isArray(gridData_heroui_app_table_grid_1785520941205_diay5?.data) ? gridData_heroui_app_table_grid_1785520941205_diay5?.data : []) ?? []), gridQuery_heroui_app_table_grid_1785520941205_diay5, gridColumns_heroui_app_table_grid_1785520941205_diay5, "client"), [gridQuery_heroui_app_table_grid_1785520941205_diay5, gridColumns_heroui_app_table_grid_1785520941205_diay5]);
  const gridApiTotal_heroui_app_table_grid_1785520941205_diay5 = React.useMemo(() => {
    const raw = raw_gridData_heroui_app_table_grid_1785520941205_diay5;
    const value = readNestedContextValue((raw && typeof raw === 'object' ? raw as Record<string, unknown> : {}), "count");
    const parsed = typeof value === 'number' ? value : Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : 0;
  }, [raw_gridData_heroui_app_table_grid_1785520941205_diay5]);
  const gridTotalCount_heroui_app_table_grid_1785520941205_diay5 = resolveDataGridTotalCount({ page: gridPage_heroui_app_table_grid_1785520941205_diay5, pageSize: gridPageSize_heroui_app_table_grid_1785520941205_diay5, total: gridApiTotal_heroui_app_table_grid_1785520941205_diay5, gridQueryMode: "client" }, gridFilteredRows_heroui_app_table_grid_1785520941205_diay5.length);
  const gridPaging_heroui_app_table_grid_1785520941205_diay5 = sliceDataGridRowsForDisplay(gridFilteredRows_heroui_app_table_grid_1785520941205_diay5, gridPage_heroui_app_table_grid_1785520941205_diay5, gridPageSize_heroui_app_table_grid_1785520941205_diay5, gridTotalCount_heroui_app_table_grid_1785520941205_diay5, "client");
  const handleGridQueryChange_heroui_app_table_grid_1785520941205_diay5 = React.useCallback((nextQuery: GridQueryState) => {
    setGridQuery_heroui_app_table_grid_1785520941205_diay5(nextQuery);
    setGridPage_heroui_app_table_grid_1785520941205_diay5(1);
  }, [patchDesignerStore]);
  const handleGridPageChange_heroui_app_table_grid_1785520941205_diay5 = React.useCallback((nextPage: number) => {
    setGridPage_heroui_app_table_grid_1785520941205_diay5(nextPage);
  }, [patchDesignerStore]);
  const handleGridPageSizeChange_heroui_app_table_grid_1785520941205_diay5 = React.useCallback((nextSize: number) => {
    setGridPageSize_heroui_app_table_grid_1785520941205_diay5(nextSize);
    setGridPage_heroui_app_table_grid_1785520941205_diay5(1);
  }, [patchDesignerStore]);
  const handleGridSortByChange_heroui_app_table_grid_1785520941205_diay5 = React.useCallback((nextSortBy: string) => {
    setGridQuery_heroui_app_table_grid_1785520941205_diay5((current: GridQueryState) => ({ ...current, sort: nextSortBy ? { columnId: nextSortBy, direction: current.sort?.direction ?? 'asc' } : null }));
  }, []);
  const handleGridToggleSortDirection_heroui_app_table_grid_1785520941205_diay5 = React.useCallback(() => {
    setGridQuery_heroui_app_table_grid_1785520941205_diay5((current: GridQueryState) => (current.sort ? { ...current, sort: { ...current.sort, direction: current.sort.direction === 'asc' ? 'desc' : 'asc' } } : current));
  }, []);

  const dataContext: Record<string, unknown> | null = regionData_cmsContents_html_form_1785520939875_gp3s4 ?? null;
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [mutationError, setMutationError] = React.useState<string | null>(null);
  const handleonSubmit_html_form_1785520939875_gp3s4 = React.useCallback(async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      payload["title"] = formData.get("heroui-input-text-1785520939886-bppz8") ?? '';
      payload["summary"] = formData.get("heroui-textarea-1785520939888-ov64f") ?? '';
      payload["body"] = formData.get("heroui-textarea-1785520939890-ozkz7") ?? '';
      payload["body"] = formData.get("form-code-editor-1785520939892-o9xoz") ?? '';
      payload["body"] = formData.get("form-html-editor-1785520939898-a2r2i") ?? '';
      const method = regionData_cmsContents_html_form_1785520939875_gp3s4?.id != null && String(regionData_cmsContents_html_form_1785520939875_gp3s4?.id).length > 0 ? 'PUT' : 'POST';
      const url = (regionData_cmsContents_html_form_1785520939875_gp3s4?.id != null && String(regionData_cmsContents_html_form_1785520939875_gp3s4?.id).length > 0 ? (regionData_cmsContents_html_form_1785520939875_gp3s4?.id != null && String(regionData_cmsContents_html_form_1785520939875_gp3s4?.id).length > 0 ? "/api/cms/contents" + '/' + encodeURIComponent(String(regionData_cmsContents_html_form_1785520939875_gp3s4?.id)) : "/api/cms/contents") : "/api/cms/contents");
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, [regionData_cmsContents_html_form_1785520939875_gp3s4]);
  const handleonClick_node_e7486e00_cae0_4490_a687_36cf2241fb81 = React.useCallback(async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    let formData: FormData;
    const form = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : event.currentTarget.closest('form');
    if (form) {
      formData = new FormData(form);
    } else {
      const regionRoot = document.querySelector("[data-designer-node-id=\"node-8361b410-cbbf-43ad-852b-0f5ac1e69c69\"]");
      if (!regionRoot) {
        return;
      }
      formData = collectRegionFormDataFromContainer(regionRoot, ["node-29441cd9-03df-4685-98b9-2f6d087258e0","node-c2031f05-c4b5-4561-a292-824d713ab953","node-250c311f-d07a-446b-8f9d-8ae43ce0486d","node-41b3f7f5-d1a3-47ad-bafd-49a37ef89735","node-47d2dd33-f694-4081-aa3c-1ff7b0e37763","node-a301f4cf-416f-4b8d-a3cb-ebd1cdcc19e0","node-46691bc1-efe1-4efc-bf2a-ac29779f9c24"]);
    }
    const fieldValidationEntries = [{"nodeId":"node-29441cd9-03df-4685-98b9-2f6d087258e0","formFieldName":"node-29441cd9-03df-4685-98b9-2f6d087258e0","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-c2031f05-c4b5-4561-a292-824d713ab953","formFieldName":"node-c2031f05-c4b5-4561-a292-824d713ab953","props":{"_designerPaletteItemId":"html.file-upload","isRequired":true}},{"nodeId":"node-250c311f-d07a-446b-8f9d-8ae43ce0486d","formFieldName":"node-250c311f-d07a-446b-8f9d-8ae43ce0486d","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-41b3f7f5-d1a3-47ad-bafd-49a37ef89735","formFieldName":"node-41b3f7f5-d1a3-47ad-bafd-49a37ef89735","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-47d2dd33-f694-4081-aa3c-1ff7b0e37763","formFieldName":"node-47d2dd33-f694-4081-aa3c-1ff7b0e37763","props":{"_designerPaletteItemId":"heroui.number-input","isRequired":true}},{"nodeId":"node-a301f4cf-416f-4b8d-a3cb-ebd1cdcc19e0","formFieldName":"node-a301f4cf-416f-4b8d-a3cb-ebd1cdcc19e0","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-46691bc1-efe1-4efc-bf2a-ac29779f9c24","formFieldName":"node-46691bc1-efe1-4efc-bf2a-ac29779f9c24","props":{"_designerPaletteItemId":"heroui.number-input","isRequired":true}}] as Array<{ nodeId: string; formFieldName: string; props: Record<string, unknown> }>;
    const fieldValidationErrors: Record<string, string> = {};
    for (const entry of fieldValidationEntries) {
      const rawValue = formData.get(entry.formFieldName);
      const validationMessage = validateDesignerFieldNode(entry.props, typeof rawValue === 'string' ? rawValue : '');
      if (validationMessage) {
        fieldValidationErrors[entry.nodeId] = validationMessage;
      }
    }
    if (Object.keys(fieldValidationErrors).length > 0) {
      setMutationError(Object.values(fieldValidationErrors).join(' '));
      return;
    }
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      payload["contentId"] = formData.get("node-29441cd9-03df-4685-98b9-2f6d087258e0") ?? '';
      payload["file"] = formData.get("node-c2031f05-c4b5-4561-a292-824d713ab953") ?? '';
      payload["fileName"] = formData.get("node-250c311f-d07a-446b-8f9d-8ae43ce0486d") ?? '';
      payload["fileMime"] = formData.get("node-41b3f7f5-d1a3-47ad-bafd-49a37ef89735") ?? '';
      payload["fileSize"] = applyPayloadFieldTransform(formData.get("node-47d2dd33-f694-4081-aa3c-1ff7b0e37763"), "number");
      payload["sha256"] = formData.get("node-a301f4cf-416f-4b8d-a3cb-ebd1cdcc19e0") ?? '';
      payload["sortOrder"] = applyPayloadFieldTransform(formData.get("node-46691bc1-efe1-4efc-bf2a-ac29779f9c24"), "number");
      const method = regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69?.id != null && String(regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69?.id).length > 0 ? 'PUT' : 'POST';
      const url = (regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69?.id != null && String(regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69?.id).length > 0 ? (regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69?.id != null && String(regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69?.id).length > 0 ? "/api/cms/assets" + '/' + encodeURIComponent(String(regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69?.id)) : "/api/cms/assets") : "/api/cms/assets");
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      patchDesignerStore("ui.visibility.node-ece35d40-ae8a-44e5-9540-05cabf267f89", false);
      toast("Saved successfully", { variant: "success", timeout: 4000 });
      await refresh_gridData_heroui_app_table_grid_1785520939947_dfuyc();
      (document.querySelector("[data-designer-node-id=\"node-8361b410-cbbf-43ad-852b-0f5ac1e69c69\"]") as HTMLFormElement | null)?.reset?.();
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, [regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69]);
  const handleonClick_node_8b27e93b_f5f9_4400_884b_bc22c2820974 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-ece35d40-ae8a-44e5-9540-05cabf267f89", false);
  }, [patchDesignerStore]);
  const handleonClick_node_d64a3dc6_5294_4412_a545_6729671d3d12 = React.useCallback(async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    let formData: FormData;
    const form = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : event.currentTarget.closest('form');
    if (form) {
      formData = new FormData(form);
    } else {
      const regionRoot = document.querySelector("[data-designer-node-id=\"node-96c7a90e-cfc1-41df-80d3-ce140dbdc93d\"]");
      if (!regionRoot) {
        return;
      }
      formData = collectRegionFormDataFromContainer(regionRoot, ["node-5d63a6df-0969-4d30-b319-ca3b5f4f7725","node-e24ab20a-8ac8-462c-a5a3-aed192fda44d","node-808fc709-6952-4553-8e4f-43af1a7f7b1b","node-ba21d796-9868-4391-b156-4079913feefd","node-9521c419-838d-4115-b228-fd52b33df8f5","node-ee011d48-c0ca-4776-8a3f-0a27e58b1086","node-7b76ba08-b087-4a0c-8231-a98ba614380f"]);
    }
    const fieldValidationEntries = [{"nodeId":"node-5d63a6df-0969-4d30-b319-ca3b5f4f7725","formFieldName":"node-5d63a6df-0969-4d30-b319-ca3b5f4f7725","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-e24ab20a-8ac8-462c-a5a3-aed192fda44d","formFieldName":"node-e24ab20a-8ac8-462c-a5a3-aed192fda44d","props":{"_designerPaletteItemId":"html.file-upload","isRequired":true}},{"nodeId":"node-808fc709-6952-4553-8e4f-43af1a7f7b1b","formFieldName":"node-808fc709-6952-4553-8e4f-43af1a7f7b1b","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-ba21d796-9868-4391-b156-4079913feefd","formFieldName":"node-ba21d796-9868-4391-b156-4079913feefd","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-9521c419-838d-4115-b228-fd52b33df8f5","formFieldName":"node-9521c419-838d-4115-b228-fd52b33df8f5","props":{"_designerPaletteItemId":"heroui.number-input","isRequired":true}},{"nodeId":"node-ee011d48-c0ca-4776-8a3f-0a27e58b1086","formFieldName":"node-ee011d48-c0ca-4776-8a3f-0a27e58b1086","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-7b76ba08-b087-4a0c-8231-a98ba614380f","formFieldName":"node-7b76ba08-b087-4a0c-8231-a98ba614380f","props":{"_designerPaletteItemId":"heroui.number-input","isRequired":true}}] as Array<{ nodeId: string; formFieldName: string; props: Record<string, unknown> }>;
    const fieldValidationErrors: Record<string, string> = {};
    for (const entry of fieldValidationEntries) {
      const rawValue = formData.get(entry.formFieldName);
      const validationMessage = validateDesignerFieldNode(entry.props, typeof rawValue === 'string' ? rawValue : '');
      if (validationMessage) {
        fieldValidationErrors[entry.nodeId] = validationMessage;
      }
    }
    if (Object.keys(fieldValidationErrors).length > 0) {
      setMutationError(Object.values(fieldValidationErrors).join(' '));
      return;
    }
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      payload["contentId"] = formData.get("node-5d63a6df-0969-4d30-b319-ca3b5f4f7725") ?? '';
      payload["file"] = formData.get("node-e24ab20a-8ac8-462c-a5a3-aed192fda44d") ?? '';
      payload["fileName"] = formData.get("node-808fc709-6952-4553-8e4f-43af1a7f7b1b") ?? '';
      payload["fileMime"] = formData.get("node-ba21d796-9868-4391-b156-4079913feefd") ?? '';
      payload["fileSize"] = applyPayloadFieldTransform(formData.get("node-9521c419-838d-4115-b228-fd52b33df8f5"), "number");
      payload["sha256"] = formData.get("node-ee011d48-c0ca-4776-8a3f-0a27e58b1086") ?? '';
      payload["sortOrder"] = applyPayloadFieldTransform(formData.get("node-7b76ba08-b087-4a0c-8231-a98ba614380f"), "number");
      const method = regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d?.id != null && String(regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d?.id).length > 0 ? 'PUT' : 'POST';
      const url = (regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d?.id != null && String(regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d?.id).length > 0 ? (regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d?.id != null && String(regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d?.id).length > 0 ? "/api/cms/assets" + '/' + encodeURIComponent(String(regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d?.id)) : "/api/cms/assets") : "/api/cms/assets");
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      patchDesignerStore("ui.visibility.node-41a85cab-7382-4ad6-b26f-b0a7a9b21aa9", false);
      toast("Saved successfully", { variant: "success", timeout: 4000 });
      await refresh_gridData_heroui_app_table_grid_1785520939947_dfuyc();
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, [regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d]);
  const handleonClick_node_4222597e_7768_4eb7_b9d0_6dd6c0d48cfd = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-41a85cab-7382-4ad6-b26f-b0a7a9b21aa9", false);
  }, [patchDesignerStore]);
  const handleonClick_node_0ae9132f_b9eb_4243_8d8a_02fcdfd8f921 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-3f533133-b07b-429c-a396-8a3e7748ebda", false);
  }, [patchDesignerStore]);
  const handleonClick_node_46261deb_59d5_4b74_b53f_957cb845a656 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_ms992eo5_4uusv = true;
      try {
        const response = await designerFetch(("/api/cms/assets/" + encodeURIComponent(String(designerStore?.selection?.id)) + ""), {
          method: "DELETE",
          headers: { 'Content-Type': 'application/json' },
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_ms992eo5_4uusv = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_ms992eo5_4uusv = false;
      }
      if (mutationOk_da_ms992eo5_4uusv) {
        patchDesignerStore("ui.visibility.node-3f533133-b07b-429c-a396-8a3e7748ebda", false);
        toast("Deleted", { variant: "success", timeout: 4000 });
        await refresh_gridData_heroui_app_table_grid_1785520939947_dfuyc();
      }
    })();
  }, [patchDesignerStore, refresh_gridData_heroui_app_table_grid_1785520939947_dfuyc]);
  const handleonClick_heroui_button_outline_1785520939997_v4gf5 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-7027b007-a233-4b5a-b327-e10e3360fdf1", true);
  }, [patchDesignerStore]);
  const handleonClick_heroui_button_outline_1785520940112_4gmqo = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-6fdbf622-b138-4b29-8042-4af78f284e06", true);
  }, [patchDesignerStore]);
  const handleonClick_heroui_button_outline_1785520940418_uhbws = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-1696ccf3-e9cc-4a8b-a4e0-a4e2314c817d", true);
  }, [patchDesignerStore]);
  const handleonClick_heroui_button_outline_1785520940452_43l1v = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-1696ccf3-e9cc-4a8b-a4e0-a4e2314c817d", true);
  }, [patchDesignerStore]);
  const handleonClick_heroui_button_outline_1785520940472_d4diq = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-1696ccf3-e9cc-4a8b-a4e0-a4e2314c817d", true);
  }, [patchDesignerStore]);
  const handleonClick_heroui_button_outline_1785520940509_s4wy1 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-4be6aeda-2057-4e95-a3e9-165b6fe46a54", true);
  }, [patchDesignerStore]);
  const handleonClick_heroui_button_outline_1785520940531_q9eya = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-4be6aeda-2057-4e95-a3e9-165b6fe46a54", true);
  }, [patchDesignerStore]);
  const handleonClick_heroui_button_outline_1785520940549_qj6f6 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-4be6aeda-2057-4e95-a3e9-165b6fe46a54", true);
  }, [patchDesignerStore]);
  const handleonClick_node_a55901d0_a746_41b9_91fe_61d6edde90e3 = React.useCallback(async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    let formData: FormData;
    const form = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : event.currentTarget.closest('form');
    if (form) {
      formData = new FormData(form);
    } else {
      const regionRoot = document.querySelector("[data-designer-node-id=\"node-fbdb9eb2-fb81-40fd-97f3-bc21913ed133\"]");
      if (!regionRoot) {
        return;
      }
      formData = collectRegionFormDataFromContainer(regionRoot, ["node-a2a92873-585b-4580-80ef-2b1c8f82e36a","node-25100434-2df4-4e56-b35d-5a7687ea340b","node-9d087163-7aa2-44b1-8030-7aa43b6bba3a"]);
    }
    const fieldValidationEntries = [{"nodeId":"node-a2a92873-585b-4580-80ef-2b1c8f82e36a","formFieldName":"node-a2a92873-585b-4580-80ef-2b1c8f82e36a","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-25100434-2df4-4e56-b35d-5a7687ea340b","formFieldName":"node-25100434-2df4-4e56-b35d-5a7687ea340b","props":{"_designerPaletteItemId":"heroui.select","isRequired":true}}] as Array<{ nodeId: string; formFieldName: string; props: Record<string, unknown> }>;
    const fieldValidationErrors: Record<string, string> = {};
    for (const entry of fieldValidationEntries) {
      const rawValue = formData.get(entry.formFieldName);
      const validationMessage = validateDesignerFieldNode(entry.props, typeof rawValue === 'string' ? rawValue : '');
      if (validationMessage) {
        fieldValidationErrors[entry.nodeId] = validationMessage;
      }
    }
    if (Object.keys(fieldValidationErrors).length > 0) {
      setMutationError(Object.values(fieldValidationErrors).join(' '));
      return;
    }
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      payload["contentIdA"] = formData.get("node-a2a92873-585b-4580-80ef-2b1c8f82e36a") ?? '';
      payload["contentIdB"] = formData.get("node-25100434-2df4-4e56-b35d-5a7687ea340b") ?? '';
      payload["note"] = formData.get("node-9d087163-7aa2-44b1-8030-7aa43b6bba3a") ?? '';
      const method = regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133?.id != null && String(regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133?.id).length > 0 ? 'PUT' : 'POST';
      const url = (regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133?.id != null && String(regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133?.id).length > 0 ? (regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133?.id != null && String(regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133?.id).length > 0 ? "/api/cms/relations" + '/' + encodeURIComponent(String(regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133?.id)) : "/api/cms/relations") : "/api/cms/relations");
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      patchDesignerStore("ui.visibility.node-81f75146-ffb7-4e51-ae27-f7802a32d793", false);
      toast("Saved successfully", { variant: "success", timeout: 4000 });
      await refresh_gridData_heroui_app_table_grid_1785520940673_flr3i();
      (document.querySelector("[data-designer-node-id=\"node-fbdb9eb2-fb81-40fd-97f3-bc21913ed133\"]") as HTMLFormElement | null)?.reset?.();
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, [regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133]);
  const handleonClick_node_e17f82f0_33e4_44f5_b5a2_9c1ad0ceff3e = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-81f75146-ffb7-4e51-ae27-f7802a32d793", false);
  }, [patchDesignerStore]);
  const handleonClick_node_3f73d495_3ae7_41af_9bdc_1b6d1a763b74 = React.useCallback(async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    let formData: FormData;
    const form = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : event.currentTarget.closest('form');
    if (form) {
      formData = new FormData(form);
    } else {
      const regionRoot = document.querySelector("[data-designer-node-id=\"node-bb48e4f6-4842-406f-9932-296984139f47\"]");
      if (!regionRoot) {
        return;
      }
      formData = collectRegionFormDataFromContainer(regionRoot, ["node-f492ca21-1d4b-4c8d-928a-fb9146529c75","node-2757002b-b3d6-421a-b348-511546c900c5","node-95b0d72c-d576-4d42-a615-7cf15f042607"]);
    }
    const fieldValidationEntries = [{"nodeId":"node-f492ca21-1d4b-4c8d-928a-fb9146529c75","formFieldName":"node-f492ca21-1d4b-4c8d-928a-fb9146529c75","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}},{"nodeId":"node-2757002b-b3d6-421a-b348-511546c900c5","formFieldName":"node-2757002b-b3d6-421a-b348-511546c900c5","props":{"_designerPaletteItemId":"heroui.select","isRequired":true}}] as Array<{ nodeId: string; formFieldName: string; props: Record<string, unknown> }>;
    const fieldValidationErrors: Record<string, string> = {};
    for (const entry of fieldValidationEntries) {
      const rawValue = formData.get(entry.formFieldName);
      const validationMessage = validateDesignerFieldNode(entry.props, typeof rawValue === 'string' ? rawValue : '');
      if (validationMessage) {
        fieldValidationErrors[entry.nodeId] = validationMessage;
      }
    }
    if (Object.keys(fieldValidationErrors).length > 0) {
      setMutationError(Object.values(fieldValidationErrors).join(' '));
      return;
    }
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      payload["contentIdA"] = formData.get("node-f492ca21-1d4b-4c8d-928a-fb9146529c75") ?? '';
      payload["contentIdB"] = formData.get("node-2757002b-b3d6-421a-b348-511546c900c5") ?? '';
      payload["note"] = formData.get("node-95b0d72c-d576-4d42-a615-7cf15f042607") ?? '';
      const method = regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47?.id != null && String(regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47?.id).length > 0 ? 'PUT' : 'POST';
      const url = (regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47?.id != null && String(regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47?.id).length > 0 ? (regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47?.id != null && String(regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47?.id).length > 0 ? "/api/cms/relations" + '/' + encodeURIComponent(String(regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47?.id)) : "/api/cms/relations") : "/api/cms/relations");
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      patchDesignerStore("ui.visibility.node-132a0a55-4dab-49d3-897e-c1fac1254a15", false);
      toast("Saved successfully", { variant: "success", timeout: 4000 });
      await refresh_gridData_heroui_app_table_grid_1785520940673_flr3i();
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, [regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47]);
  const handleonClick_node_78092672_3b58_40fe_8f1a_7cd0549f6255 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-132a0a55-4dab-49d3-897e-c1fac1254a15", false);
  }, [patchDesignerStore]);
  const handleonClick_node_ab345e7c_74be_4673_9395_31f822efc4fd = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-5e28a7e2-a612-4531-9fb2-67244e8a4f43", false);
  }, [patchDesignerStore]);
  const handleonClick_node_b37f1911_abb6_4051_97ee_038831178be1 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_ms992f9n_12eej = true;
      try {
        const response = await designerFetch(("/api/cms/relations/" + encodeURIComponent(String(designerStore?.selection?.id)) + ""), {
          method: "DELETE",
          headers: { 'Content-Type': 'application/json' },
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_ms992f9n_12eej = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_ms992f9n_12eej = false;
      }
      if (mutationOk_da_ms992f9n_12eej) {
        patchDesignerStore("ui.visibility.node-5e28a7e2-a612-4531-9fb2-67244e8a4f43", false);
        toast("Deleted", { variant: "success", timeout: 4000 });
        await refresh_gridData_heroui_app_table_grid_1785520940673_flr3i();
      }
    })();
  }, [patchDesignerStore, refresh_gridData_heroui_app_table_grid_1785520940673_flr3i]);
  const handleonClick_heroui_button_outline_1785520940826_k9iza = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-d77d1af5-2bc5-4675-9882-3647524e0b9e", true);
  }, [patchDesignerStore]);
  const handleonClick_heroui_button_outline_1785520940925_zls2g = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.heroui-modal-1785520941080-38heo", true);
  }, [patchDesignerStore]);
  const handleonClick_heroui_button_outline_1785520940939_f2lyf = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.heroui-modal-1785520939904-1046r", true);
  }, [patchDesignerStore]);
  const handleonClick_heroui_button_outline_1785520941002_yd12r = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.heroui-modal-1785520940959-vxtiy", true);
  }, [patchDesignerStore]);
  const handleonClick_heroui_button_solid_1785520941023_7ms5y = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_ms992fhp_e8tnq = true;
      try {
        const response = await designerFetch(("/api/cms/contents/" + encodeURIComponent(String(designerStore?.routeParams?.id)) + ""), {
          method: "PUT",
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({"statusCode":"101.002.003"}),
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_ms992fhp_e8tnq = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_ms992fhp_e8tnq = false;
      }
      if (mutationOk_da_ms992fhp_e8tnq) {
        patchDesignerStore("ui.visibility.heroui-modal-1785520940959-vxtiy", false);
        toast("Published", { variant: "success", timeout: 4000 });
        await refresh_regionData_cmsContents_html_form_1785520939875_gp3s4();
      }
    })();
  }, [patchDesignerStore, refresh_regionData_cmsContents_html_form_1785520939875_gp3s4]);
  const handleonClick_heroui_button_outline_1785520941042_o6zu0 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_ms992fib_jvzoy = true;
      try {
        const response = await designerFetch(("/api/cms/contents/" + encodeURIComponent(String(designerStore?.routeParams?.id)) + ""), {
          method: "PUT",
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({"statusCode":"101.002.004","publishedAt":null}),
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_ms992fib_jvzoy = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_ms992fib_jvzoy = false;
      }
      if (mutationOk_da_ms992fib_jvzoy) {
        patchDesignerStore("ui.visibility.heroui-modal-1785520940959-vxtiy", false);
        toast("Archived", { variant: "success", timeout: 4000 });
        await refresh_regionData_cmsContents_html_form_1785520939875_gp3s4();
      }
    })();
  }, [patchDesignerStore, refresh_regionData_cmsContents_html_form_1785520939875_gp3s4]);
  const handleonClick_heroui_button_outline_1785520941062_74sai = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_ms992fis_z0ia9 = true;
      try {
        const response = await designerFetch(("/api/cms/contents/" + encodeURIComponent(String(designerStore?.routeParams?.id)) + ""), {
          method: "PUT",
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({"statusCode":"101.002.001"}),
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_ms992fis_z0ia9 = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_ms992fis_z0ia9 = false;
      }
      if (mutationOk_da_ms992fis_z0ia9) {
        patchDesignerStore("ui.visibility.heroui-modal-1785520940959-vxtiy", false);
        toast("Moved back to draft", { variant: "success", timeout: 4000 });
        await refresh_regionData_cmsContents_html_form_1785520939875_gp3s4();
      }
    })();
  }, [patchDesignerStore, refresh_regionData_cmsContents_html_form_1785520939875_gp3s4]);
  const handleonClick_node_1aa072bb_a65f_4dba_b70a_015aa7c01b9b = React.useCallback(async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    let formData: FormData;
    const form = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : event.currentTarget.closest('form');
    if (form) {
      formData = new FormData(form);
    } else {
      const regionRoot = document.querySelector("[data-designer-node-id=\"node-910583ce-e66a-44e2-a372-1c5144f11ffe\"]");
      if (!regionRoot) {
        return;
      }
      formData = collectRegionFormDataFromContainer(regionRoot, ["node-0c44bd0e-e7c7-4fa7-8c05-535b20654570","node-e8e98b24-39cc-486a-935f-427076bf0971"]);
    }
    const fieldValidationEntries = [{"nodeId":"node-0c44bd0e-e7c7-4fa7-8c05-535b20654570","formFieldName":"node-0c44bd0e-e7c7-4fa7-8c05-535b20654570","props":{"_designerPaletteItemId":"heroui.select","isRequired":true}},{"nodeId":"node-e8e98b24-39cc-486a-935f-427076bf0971","formFieldName":"node-e8e98b24-39cc-486a-935f-427076bf0971","props":{"_designerPaletteItemId":"heroui.select","isRequired":true}}] as Array<{ nodeId: string; formFieldName: string; props: Record<string, unknown> }>;
    const fieldValidationErrors: Record<string, string> = {};
    for (const entry of fieldValidationEntries) {
      const rawValue = formData.get(entry.formFieldName);
      const validationMessage = validateDesignerFieldNode(entry.props, typeof rawValue === 'string' ? rawValue : '');
      if (validationMessage) {
        fieldValidationErrors[entry.nodeId] = validationMessage;
      }
    }
    if (Object.keys(fieldValidationErrors).length > 0) {
      setMutationError(Object.values(fieldValidationErrors).join(' '));
      return;
    }
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      payload["contentTypeCode"] = formData.get("node-0c44bd0e-e7c7-4fa7-8c05-535b20654570") ?? '';
      payload["languageCode"] = formData.get("node-e8e98b24-39cc-486a-935f-427076bf0971") ?? '';
      const method = regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe?.id != null && String(regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe?.id).length > 0 ? 'PUT' : 'POST';
      const url = (regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe?.id != null && String(regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe?.id).length > 0 ? (regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe?.id != null && String(regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe?.id).length > 0 ? "/api/cms/contents" + '/' + encodeURIComponent(String(regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe?.id)) : "/api/cms/contents") : "/api/cms/contents");
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      patchDesignerStore("ui.visibility.node-7027b007-a233-4b5a-b327-e10e3360fdf1", false);
      toast("Saved successfully", { variant: "success", timeout: 4000 });
      await refresh_regionData_cmsContents_html_form_1785520939875_gp3s4();
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, [regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe]);
  const handleonClick_node_97d030cb_3fe2_4b1e_afad_7b16b7926630 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-7027b007-a233-4b5a-b327-e10e3360fdf1", false);
  }, [patchDesignerStore]);
  const handleonClick_node_a1d378e6_2a4e_43d8_a4b5_962c60dc0a10 = React.useCallback(async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    let formData: FormData;
    const form = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : event.currentTarget.closest('form');
    if (form) {
      formData = new FormData(form);
    } else {
      const regionRoot = document.querySelector("[data-designer-node-id=\"node-bf16e7ef-f904-4f3e-ae1c-0f1b6bfd57ad\"]");
      if (!regionRoot) {
        return;
      }
      formData = collectRegionFormDataFromContainer(regionRoot, ["node-efea763c-39c5-477c-8137-52058bf4d991","node-7c888dd7-f3eb-43b8-81b7-227055cff693","node-18a60015-8bdc-4e4a-95d3-97c9fad0a106"]);
    }
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      payload["commentsEnabled"] = applyPayloadFieldTransform(formData.get("node-efea763c-39c5-477c-8137-52058bf4d991"), "boolean");
      payload["commentsPolicyCode"] = formData.get("node-7c888dd7-f3eb-43b8-81b7-227055cff693") ?? '';
      payload["commentsBodyFormatCode"] = formData.get("node-18a60015-8bdc-4e4a-95d3-97c9fad0a106") ?? '';
      const method = regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad?.id != null && String(regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad?.id).length > 0 ? 'PUT' : 'POST';
      const url = (regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad?.id != null && String(regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad?.id).length > 0 ? (regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad?.id != null && String(regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad?.id).length > 0 ? "/api/cms/contents" + '/' + encodeURIComponent(String(regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad?.id)) : "/api/cms/contents") : "/api/cms/contents");
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      patchDesignerStore("ui.visibility.node-d77d1af5-2bc5-4675-9882-3647524e0b9e", false);
      toast("Saved successfully", { variant: "success", timeout: 4000 });
      await refresh_regionData_cmsContents_html_form_1785520939875_gp3s4();
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, [regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad]);
  const handleonClick_node_1709d617_1ccd_4012_8a68_9127a854f8fb = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-d77d1af5-2bc5-4675-9882-3647524e0b9e", false);
  }, [patchDesignerStore]);
  const handleonClick_node_0e47605c_0520_4b14_9c3d_6135d20e1890 = React.useCallback(async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    let formData: FormData;
    const form = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : event.currentTarget.closest('form');
    if (form) {
      formData = new FormData(form);
    } else {
      const regionRoot = document.querySelector("[data-designer-node-id=\"node-80938477-50e9-441d-80da-62a7fc2f6634\"]");
      if (!regionRoot) {
        return;
      }
      formData = collectRegionFormDataFromContainer(regionRoot, ["node-d3b91390-175d-492f-afda-ae9745c39113"]);
    }
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      payload["operatorNote"] = formData.get("node-d3b91390-175d-492f-afda-ae9745c39113") ?? '';
      const method = regionData_cmsContents_node_80938477_50e9_441d_80da_62a7fc2f6634?.id != null && String(regionData_cmsContents_node_80938477_50e9_441d_80da_62a7fc2f6634?.id).length > 0 ? 'PUT' : 'POST';
      const url = (regionData_cmsContents_node_80938477_50e9_441d_80da_62a7fc2f6634?.id != null && String(regionData_cmsContents_node_80938477_50e9_441d_80da_62a7fc2f6634?.id).length > 0 ? (regionData_cmsContents_node_80938477_50e9_441d_80da_62a7fc2f6634?.id != null && String(regionData_cmsContents_node_80938477_50e9_441d_80da_62a7fc2f6634?.id).length > 0 ? "/api/cms/contents" + '/' + encodeURIComponent(String(regionData_cmsContents_node_80938477_50e9_441d_80da_62a7fc2f6634?.id)) : "/api/cms/contents") : "/api/cms/contents");
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      patchDesignerStore("ui.visibility.node-1696ccf3-e9cc-4a8b-a4e0-a4e2314c817d", false);
      toast("Saved successfully", { variant: "success", timeout: 4000 });
      await refresh_regionData_cmsContents_html_form_1785520939875_gp3s4();
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, [regionData_cmsContents_node_80938477_50e9_441d_80da_62a7fc2f6634]);
  const handleonClick_node_95de89ec_f63f_40bf_9248_328e1a5e070d = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-1696ccf3-e9cc-4a8b-a4e0-a4e2314c817d", false);
  }, [patchDesignerStore]);
  const handleonClick_node_4a37d840_0384_4688_ac1f_772c1e54ab6a = React.useCallback(async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    let formData: FormData;
    const form = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : event.currentTarget.closest('form');
    if (form) {
      formData = new FormData(form);
    } else {
      const regionRoot = document.querySelector("[data-designer-node-id=\"node-b9e0e569-9f05-4059-b144-5d9ad3dd99cd\"]");
      if (!regionRoot) {
        return;
      }
      formData = collectRegionFormDataFromContainer(regionRoot, ["node-693aa8b8-8bda-4844-ad8d-29a2a89ec8b4","node-08ef0595-d97b-486f-9952-c95ca41dd464"]);
    }
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      payload["seoTitle"] = formData.get("node-693aa8b8-8bda-4844-ad8d-29a2a89ec8b4") ?? '';
      payload["seoNote"] = formData.get("node-08ef0595-d97b-486f-9952-c95ca41dd464") ?? '';
      const method = regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd?.id != null && String(regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd?.id).length > 0 ? 'PUT' : 'POST';
      const url = (regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd?.id != null && String(regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd?.id).length > 0 ? (regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd?.id != null && String(regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd?.id).length > 0 ? "/api/cms/contents" + '/' + encodeURIComponent(String(regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd?.id)) : "/api/cms/contents") : "/api/cms/contents");
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      patchDesignerStore("ui.visibility.node-4be6aeda-2057-4e95-a3e9-165b6fe46a54", false);
      toast("Saved successfully", { variant: "success", timeout: 4000 });
      await refresh_regionData_cmsContents_html_form_1785520939875_gp3s4();
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, [regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd]);
  const handleonClick_node_1528be36_e1cd_4b16_901d_f215599aee69 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-4be6aeda-2057-4e95-a3e9-165b6fe46a54", false);
  }, [patchDesignerStore]);
  const handleonClick_node_1d352cea_9f68_41e8_8f80_5b0106ae2802 = React.useCallback(async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    let formData: FormData;
    const form = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : event.currentTarget.closest('form');
    if (form) {
      formData = new FormData(form);
    } else {
      const regionRoot = document.querySelector("[data-designer-node-id=\"node-d47908af-aca4-4737-91b3-b6d5d40d8cd7\"]");
      if (!regionRoot) {
        return;
      }
      formData = collectRegionFormDataFromContainer(regionRoot, ["node-bb2393fb-2ca8-42eb-af1c-63a21b78937b"]);
    }
    const fieldValidationEntries = [{"nodeId":"node-bb2393fb-2ca8-42eb-af1c-63a21b78937b","formFieldName":"node-bb2393fb-2ca8-42eb-af1c-63a21b78937b","props":{"_designerPaletteItemId":"heroui.input-text","isRequired":true}}] as Array<{ nodeId: string; formFieldName: string; props: Record<string, unknown> }>;
    const fieldValidationErrors: Record<string, string> = {};
    for (const entry of fieldValidationEntries) {
      const rawValue = formData.get(entry.formFieldName);
      const validationMessage = validateDesignerFieldNode(entry.props, typeof rawValue === 'string' ? rawValue : '');
      if (validationMessage) {
        fieldValidationErrors[entry.nodeId] = validationMessage;
      }
    }
    if (Object.keys(fieldValidationErrors).length > 0) {
      setMutationError(Object.values(fieldValidationErrors).join(' '));
      return;
    }
    setIsSubmitting(true);
    setMutationError(null);
    try {
      const payload: Record<string, unknown> = {};
      payload["slug"] = formData.get("node-bb2393fb-2ca8-42eb-af1c-63a21b78937b") ?? '';
      const method = regionData_cmsContents_node_d47908af_aca4_4737_91b3_b6d5d40d8cd7?.id != null && String(regionData_cmsContents_node_d47908af_aca4_4737_91b3_b6d5d40d8cd7?.id).length > 0 ? 'PUT' : 'POST';
      const url = (regionData_cmsContents_node_d47908af_aca4_4737_91b3_b6d5d40d8cd7?.id != null && String(regionData_cmsContents_node_d47908af_aca4_4737_91b3_b6d5d40d8cd7?.id).length > 0 ? (regionData_cmsContents_node_d47908af_aca4_4737_91b3_b6d5d40d8cd7?.id != null && String(regionData_cmsContents_node_d47908af_aca4_4737_91b3_b6d5d40d8cd7?.id).length > 0 ? "/api/cms/contents" + '/' + encodeURIComponent(String(regionData_cmsContents_node_d47908af_aca4_4737_91b3_b6d5d40d8cd7?.id)) : "/api/cms/contents") : "/api/cms/contents");
      const response = await designerFetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      patchDesignerStore("ui.visibility.node-6fdbf622-b138-4b29-8042-4af78f284e06", false);
      toast("Saved successfully", { variant: "success", timeout: 4000 });
      await refresh_regionData_cmsContents_html_form_1785520939875_gp3s4();
    } catch (mutationFailure) {
      setMutationError(
        mutationFailure instanceof Error ? mutationFailure.message : 'Request failed',
      );
    }
    finally {
      setIsSubmitting(false);
    }
  }, [regionData_cmsContents_node_d47908af_aca4_4737_91b3_b6d5d40d8cd7]);
  const handleonClick_node_5f5956ee_6b83_42ce_8555_11dc431a1ecc = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-6fdbf622-b138-4b29-8042-4af78f284e06", false);
  }, [patchDesignerStore]);
  const handleonClick_heroui_button_outline_1785520941322_3gsov = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.heroui-modal-1785520941166-a4079", true);
  }, [patchDesignerStore]);
  return (
    <>
      <Toast.Provider />
      <div className="space-y-3">
        {mutationError ? (
          <div className="rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700">
            {mutationError}
          </div>
        ) : null}
        <div className="flex h-full min-h-0 w-full flex-1 flex-col overflow-hidden bg-white">
          <div className="flex shrink-0 items-center gap-3 border-b border-slate-200 bg-white px-3 py-2.5 sm:px-5">
            <a href="/studio/cms/contents" target="_self" className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded p-0 text-[0px] text-slate-500 no-underline outline-none transition-colors hover:bg-slate-100 hover:text-slate-700 [&>svg]:h-6 [&>svg]:w-6" icon="ArrowLeft" aria-label="Back to Contents" title="Back to Contents">Back</a>
            <Button className="inline-flex h-8 items-center justify-center gap-1.5 rounded-md border border-cyan-200 bg-white px-2.5 text-xs font-semibold text-cyan-700 hover:bg-cyan-50" icon="Eye" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_heroui_button_outline_1785520940939_f2lyf}>Preview</Button>
            <Button className="inline-flex h-8 items-center justify-center gap-1.5 rounded-md border border-slate-300 bg-white px-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50" icon="RefreshCw" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_heroui_button_outline_1785520941002_yd12r}>Change status</Button>
            <form className="relative shrink-0" data-designer-node-id="html-form-1785520941308-fssdj">
              <Button className="inline-flex h-8 shrink-0 items-center justify-center gap-1.5 rounded-md border border-violet-200 bg-white px-3 text-xs font-semibold text-violet-700 no-underline hover:bg-violet-50" icon="MessagesSquare" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_heroui_button_outline_1785520941322_3gsov}>View comments</Button>
              <p className="pointer-events-none absolute -end-2 -top-2 inline-flex min-w-5 items-center justify-center rounded-full bg-violet-600 px-1.5 text-[10px] font-bold leading-5 text-white" name="html-text-1785520941347-yxuw4">{regionData_cmsContents_html_form_1785520941308_fssdj?.commentCount ?? "Text"}</p>
            </form>
            <Button className="inline-flex h-8 shrink-0 items-center justify-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" icon="Save" type="submit" form="cms-content-editor-form" variant="primary" size="md" href="#" target="_self">Save</Button>
          </div>
          <div className="min-h-0 flex-1 gap-0 overflow-hidden bg-white w-full grid" style={{ gridTemplateColumns: '1fr 320px' }}>
            <div className="min-h-0 min-w-0 overflow-hidden">
              <div className="flex min-w-0 flex-1 flex-col overflow-hidden bg-white">
                <form className="flex h-full min-h-0 min-w-0 flex-col overflow-hidden" id="cms-content-editor-form" onSubmit={handleonSubmit_html_form_1785520939875_gp3s4} data-designer-node-id="html-form-1785520939875-gp3s4">
                  <div className="flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto bg-white px-5 py-4">
                    <div className="flex flex-col space-y-2">
                      <div className="flex min-h-4 items-center gap-0.5 ps-[4px]">
                        <p className="border-s-2 ps-1.5 text-[11px] font-bold uppercase tracking-wider leading-none text-indigo-700 border-indigo-400">Content</p>
                      </div>
                      <div className="flex flex-col gap-2">
                        <UiInput className="rounded-md border border-slate-300 bg-white px-2.5 py-px text-xs text-slate-700" type="text" placeholder="Text input" label="Title" size="sm" value={regionData_cmsContents_html_form_1785520939875_gp3s4?.title} name="heroui-input-text-1785520939886-bppz8" />
                        <UiTextarea className="min-h-24 rounded-md border border-slate-300 bg-white px-2.5 py-2 text-xs text-slate-700" rows={2} placeholder="Text area" label="Summary" size="sm" value={regionData_cmsContents_html_form_1785520939875_gp3s4?.summary} name="heroui-textarea-1785520939888-ov64f" />
                                        {evaluateDesignerCondition(designerStore, dataContext, ({}), "!data.bodyFormatCode || data.bodyFormatCode === '101.003.001'") && (
                                          <UiTextarea className="h-[7.5rem] min-h-[7.5rem] max-h-[7.5rem]" rows={5} placeholder="Text area" label="Body (plain)" size="sm" style={{ height: '7.5rem' }} value={regionData_cmsContents_html_form_1785520939875_gp3s4?.body} name="heroui-textarea-1785520939890-ozkz7" />
                                        )}
                                        {evaluateDesignerCondition(designerStore, dataContext, ({}), "data.bodyFormatCode === '101.003.002'") && (
                                          <DesignerCodeEditorField className="h-[7.5rem] min-h-[7.5rem] max-h-[7.5rem] overflow-auto" style={{ height: '7.5rem' }} value={regionData_cmsContents_html_form_1785520939875_gp3s4?.body} name="form-code-editor-1785520939892-o9xoz" label="Body (markdown)" language="markdown" theme="vs" placeholder="// Enter code…" lineNumbers={false} wordWrap={true} readOnly={false} minimap={false} tabSize={2} fontSize={13} />
                                        )}
                                        {evaluateDesignerCondition(designerStore, dataContext, ({}), "data.bodyFormatCode === '101.003.003'") && (
                                          <DesignerHtmlEditorField className="h-[7.5rem] min-h-[7.5rem] max-h-[7.5rem] overflow-auto" style={{ height: '7.5rem' }} value={regionData_cmsContents_html_form_1785520939875_gp3s4?.body} name="form-html-editor-1785520939898-a2r2i" label="Body (html)" placeholder="Start writing…" editorHeight={160} fontSize={14} showToolbar={true} enableBold={true} enableItalic={true} enableUnderline={true} enableStrike={true} enableInlineCode={true} enableSubscript={true} enableSuperscript={true} enableTextColor={true} enableHighlight={true} enableHeading={true} enableBulletList={true} enableOrderedList={true} enableTaskList={true} enableBlockquote={true} enableCodeBlock={false} enableHorizontalRule={true} enableTextAlign={true} enableTextDirection={false} enableIndent={true} enableLink={true} enableImage={true} enableTable={true} enableClearFormatting={true} enableUndoRedo={true} readOnly={false} />
                                        )}
                      </div>
                    </div>
                    <div className="flex flex-col space-y-2 pt-3">
                      <div className="flex min-h-4 items-center gap-0.5 ps-[4px]">
                        <p className="border-s-2 ps-1.5 text-[11px] font-bold uppercase tracking-wider leading-none text-cyan-700 border-cyan-500">Assets</p>
                      </div>
                      <div className="flex flex-col gap-2">
                        <p className="ps-[4px] text-xs leading-relaxed text-slate-500">Upload assets for this content. Bytes live in the CMS database; the grid below reflects the current attachments.</p>
                        <div className="flex w-full flex-col gap-2"><div className="flex items-center justify-between gap-2 border-b border-slate-200 bg-white px-2 py-1.5"><div className="flex items-center gap-2"><input type="text" value={gridSearchInput_heroui_app_table_grid_1785520939947_dfuyc} onChange={(event) => handleGridSearchChange_heroui_app_table_grid_1785520939947_dfuyc(event.target.value)} placeholder={"Search assets…"} className="h-8 rounded-md border border-slate-200 px-2 text-sm" /></div><div className="flex items-center gap-2"><button type="button" onClick={() => { patchDesignerStore("selection.id", null); patchDesignerStore("ui.visibility.node-ece35d40-ae8a-44e5-9540-05cabf267f89", true); }} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700">Upload asset</button><button type="button" onClick={() => { void refresh_gridData_heroui_app_table_grid_1785520939947_dfuyc(); }} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 px-3 text-xs font-medium text-slate-700 hover:bg-slate-50">Refresh</button></div></div><AppTableGrid className="flex h-full min-h-0 w-full flex-1 flex-col" presentation="cards" cardBelow="phone" cardVariant="list" columns={gridColumns_heroui_app_table_grid_1785520939947_dfuyc} rows={gridPaging_heroui_app_table_grid_1785520939947_dfuyc.displayRows} getRowKey={(row) => String((row as Record<string, unknown>)["id"] ?? '')} enableColumnLayout={false} columnLayout={gridColumnLayout_heroui_app_table_grid_1785520939947_dfuyc} onColumnLayoutChange={setGridColumnLayout_heroui_app_table_grid_1785520939947_dfuyc} isLoading={false} loadingMessage={"Loading assets…"} emptyMessage={"No assets found."} isEmpty={gridFilteredRows_heroui_app_table_grid_1785520939947_dfuyc.length === 0} errorContent={gridFilteredRows_heroui_app_table_grid_1785520939947_dfuyc.length === 0 ? undefined : "Could not load assets."} gridQueryMode={"server"} query={gridQuery_heroui_app_table_grid_1785520939947_dfuyc} onQueryChange={handleGridQueryChange_heroui_app_table_grid_1785520939947_dfuyc} onGridRowAction={handleGridRowAction_heroui_app_table_grid_1785520939947_dfuyc} footer={<GridPagingFooter totalCount={gridTotalCount_heroui_app_table_grid_1785520939947_dfuyc} safePage={gridPaging_heroui_app_table_grid_1785520939947_dfuyc.safePage} pageSize={gridPageSize_heroui_app_table_grid_1785520939947_dfuyc} onPageSizeChange={handleGridPageSizeChange_heroui_app_table_grid_1785520939947_dfuyc} sortBy={gridQuery_heroui_app_table_grid_1785520939947_dfuyc.sort?.columnId ?? ''} sortOptions={[{"value":"fileName","label":"File name"},{"value":"fileMime","label":"MIME"},{"value":"fileSize","label":"Size"},{"value":"sortOrder","label":"Order"},{"value":"updatedAt","label":"Updated"}]} onSortByChange={handleGridSortByChange_heroui_app_table_grid_1785520939947_dfuyc} sortDirection={gridQuery_heroui_app_table_grid_1785520939947_dfuyc.sort?.direction ?? 'asc'} onToggleSortDirection={handleGridToggleSortDirection_heroui_app_table_grid_1785520939947_dfuyc} showSortControls={false} totalPages={gridPaging_heroui_app_table_grid_1785520939947_dfuyc.totalPages} pageNumbers={buildDataGridPageNumbers(gridPaging_heroui_app_table_grid_1785520939947_dfuyc.safePage, gridPaging_heroui_app_table_grid_1785520939947_dfuyc.totalPages)} onPageChange={handleGridPageChange_heroui_app_table_grid_1785520939947_dfuyc} visibleInfiniteCount={gridListMode_heroui_app_table_grid_1785520939947_dfuyc === 'infinite' ? gridPaging_heroui_app_table_grid_1785520939947_dfuyc.displayRows.length : undefined} />} /></div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <div className="min-h-0 min-w-0 overflow-hidden">
              <div className="flex h-full min-h-0 min-w-0 flex-col gap-3 overflow-y-auto border-s border-slate-200 bg-white px-3 py-3">
                <div className="flex flex-col space-y-2">
                  <div className="flex min-h-4 items-center gap-0.5 ps-[4px]">
                    <p className="border-s-2 ps-1.5 text-[11px] font-bold uppercase tracking-wider leading-none text-slate-700 border-slate-400">Identity</p>
                    <Button className="ms-auto inline-flex h-5 w-5 shrink-0 items-center justify-center rounded border-0 bg-transparent p-0 text-[0px] text-slate-400 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700 [&>svg]:h-3.5 [&>svg]:w-3.5" icon="Pencil" type="button" aria-label="Edit identity" title="Edit identity" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_heroui_button_outline_1785520939997_v4gf5}>Edit identity</Button>
                  </div>
                  <div className="flex flex-col gap-2">
                    <form className="flex min-w-0 flex-col gap-2" data-designer-node-id="html-form-1785520940013-m2o3f">
                      <div className="flex min-w-0 items-center justify-between gap-3 overflow-hidden ps-[4px]">
                        <p className="text-[11px] font-normal normal-case tracking-normal text-slate-500">Content ID</p>
                        <p className="min-w-0 overflow-hidden break-words text-sm font-medium text-slate-800 text-end" name="html-text-1785520940035-48e6q">{regionData_cmsContents_html_form_1785520940013_m2o3f?.id ?? "Text"}</p>
                      </div>
                      <div className="flex min-w-0 items-center justify-between gap-3 overflow-hidden ps-[4px]">
                        <p className="text-[11px] font-normal normal-case tracking-normal text-slate-500">Content type</p>
                        <p className="min-w-0 overflow-hidden break-words text-sm font-medium text-slate-800 text-end" name="html-text-1785520940057-54ov5">{regionData_cmsContents_html_form_1785520940013_m2o3f?.contentTypeCodeTitle ?? "Text"}</p>
                      </div>
                      <div className="flex min-w-0 items-center justify-between gap-3 overflow-hidden ps-[4px]">
                        <p className="text-[11px] font-normal normal-case tracking-normal text-slate-500">Language</p>
                        <p className="min-w-0 overflow-hidden break-words text-sm font-medium text-slate-800 text-end" name="html-text-1785520940080-f0z3v">{regionData_cmsContents_html_form_1785520940013_m2o3f?.languageCodeTitle ?? "Text"}</p>
                      </div>
                      <div className="flex min-w-0 items-center justify-between gap-3 overflow-hidden ps-[4px]">
                        <p className="text-[11px] font-normal normal-case tracking-normal text-slate-500">Slug</p>
                        <p className="min-w-0 overflow-hidden break-words text-sm font-medium text-slate-800 text-end font-mono text-[13px]" name="html-text-1785520940098-rdb7j">{regionData_cmsContents_html_form_1785520940013_m2o3f?.slug ?? "Text"}</p>
                      </div>
                      <div className="flex justify-end ps-[4px]">
                        <Button className="h-auto rounded-none border-0 bg-transparent p-0 text-[11px] font-semibold text-sky-700 underline-offset-2 hover:bg-transparent hover:underline" type="button" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_heroui_button_outline_1785520940112_4gmqo}>Edit slug</Button>
                      </div>
                      <div className="flex min-w-0 items-center justify-between gap-3 overflow-hidden ps-[4px]">
                        <p className="text-[11px] font-normal normal-case tracking-normal text-slate-500">Status</p>
                        <p className="min-w-0 overflow-hidden break-words text-sm font-medium rounded-md border border-emerald-200 bg-emerald-50/70 px-2 py-1.5 text-emerald-900 text-end" name="html-text-1785520940136-rk3kh">{regionData_cmsContents_html_form_1785520940013_m2o3f?.statusCodeTitle ?? "Text"}</p>
                      </div>
                      <div className="flex min-w-0 items-center justify-between gap-3 overflow-hidden ps-[4px]">
                        <p className="text-[11px] font-normal normal-case tracking-normal text-slate-500">Body format</p>
                        <p className="min-w-0 overflow-hidden break-words text-sm font-medium text-slate-800 text-end" name="html-text-1785520940160-r8x9y">{regionData_cmsContents_html_form_1785520940013_m2o3f?.bodyFormatCodeTitle ?? "Text"}</p>
                      </div>
                    </form>
                  </div>
                </div>
                <div className="flex flex-col space-y-2 pt-3">
                  <div className="flex min-h-4 items-center gap-0.5 ps-[4px]">
                    <p className="border-s-2 ps-1.5 text-[11px] font-bold uppercase tracking-wider leading-none text-emerald-700 border-emerald-400">Publication</p>
                  </div>
                  <div className="flex flex-col gap-2">
                    <form className="flex min-w-0 flex-col gap-2" data-designer-node-id="html-form-1785520940198-yar9f">
                      <div className="flex min-w-0 items-center justify-between gap-3 overflow-hidden ps-[4px]">
                        <p className="text-[11px] font-normal normal-case tracking-normal text-slate-500">Published at</p>
                        <p className="min-w-0 overflow-hidden break-words text-sm font-medium text-slate-800 text-end" name="html-text-1785520940216-zueou">{regionData_cmsContents_html_form_1785520940198_yar9f?.publishedAt ?? "Text"}</p>
                      </div>
                      <div className="flex min-w-0 items-center justify-between gap-3 overflow-hidden ps-[4px]">
                        <p className="text-[11px] font-normal normal-case tracking-normal text-slate-500">Status updated at</p>
                        <p className="min-w-0 overflow-hidden break-words text-sm font-medium text-slate-800 text-end" name="html-text-1785520940235-ukh1w">{regionData_cmsContents_html_form_1785520940198_yar9f?.statusCodeUpdatedAt ?? "Text"}</p>
                      </div>
                      <div className="flex min-w-0 items-center justify-between gap-3 overflow-hidden ps-[4px]">
                        <p className="text-[11px] font-normal normal-case tracking-normal text-slate-500">Status updated by</p>
                        <p className="min-w-0 overflow-hidden break-words text-sm font-medium text-slate-800 text-end" name="html-text-1785520940261-qfpr5">{regionData_cmsContents_html_form_1785520940198_yar9f?.statusCodeUpdatedBy ?? "Text"}</p>
                      </div>
                    </form>
                  </div>
                </div>
                <div className="flex flex-col space-y-2 pt-3">
                  <div className="flex min-h-4 items-center gap-0.5 ps-[4px]">
                    <p className="border-s-2 ps-1.5 text-[11px] font-bold uppercase tracking-wider leading-none text-amber-700 border-amber-400">Audit trail</p>
                  </div>
                  <div className="flex flex-col gap-2">
                    <form className="flex min-w-0 flex-col gap-2" data-designer-node-id="html-form-1785520940295-4yqrv">
                      <div className="flex min-w-0 items-center justify-between gap-3 overflow-hidden ps-[4px]">
                        <p className="text-[11px] font-normal normal-case tracking-normal text-slate-500">Created at</p>
                        <p className="min-w-0 overflow-hidden break-words text-sm font-medium text-slate-800 text-end" name="html-text-1785520940319-k4hex">{regionData_cmsContents_html_form_1785520940295_4yqrv?.createdAt ?? "Text"}</p>
                      </div>
                      <div className="flex min-w-0 items-center justify-between gap-3 overflow-hidden ps-[4px]">
                        <p className="text-[11px] font-normal normal-case tracking-normal text-slate-500">Created by</p>
                        <p className="min-w-0 overflow-hidden break-words text-sm font-medium text-slate-800 text-end" name="html-text-1785520940338-advux">{regionData_cmsContents_html_form_1785520940295_4yqrv?.createdBy ?? "Text"}</p>
                      </div>
                      <div className="flex min-w-0 items-center justify-between gap-3 overflow-hidden ps-[4px]">
                        <p className="text-[11px] font-normal normal-case tracking-normal text-slate-500">Updated at</p>
                        <p className="min-w-0 overflow-hidden break-words text-sm font-medium text-slate-800 text-end" name="html-text-1785520940361-m8ulu">{regionData_cmsContents_html_form_1785520940295_4yqrv?.updatedAt ?? "Text"}</p>
                      </div>
                      <div className="flex min-w-0 items-center justify-between gap-3 overflow-hidden ps-[4px]">
                        <p className="text-[11px] font-normal normal-case tracking-normal text-slate-500">Updated by</p>
                        <p className="min-w-0 overflow-hidden break-words text-sm font-medium text-slate-800 text-end" name="html-text-1785520940385-gv2w8">{regionData_cmsContents_html_form_1785520940295_4yqrv?.updatedBy ?? "Text"}</p>
                      </div>
                    </form>
                  </div>
                </div>
                <div className="flex flex-col space-y-2 pt-3">
                  <div className="flex min-h-4 items-center gap-0.5 ps-[4px]">
                    <p className="border-s-2 ps-1.5 text-[11px] font-bold uppercase tracking-wider leading-none text-slate-700 border-slate-400">Operator note</p>
                    <Button className="ms-auto inline-flex h-5 w-5 shrink-0 items-center justify-center rounded border-0 bg-transparent p-0 text-[0px] text-slate-400 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700 [&>svg]:h-3.5 [&>svg]:w-3.5" icon="Pencil" type="button" aria-label="Edit operator note" title="Edit operator note" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_heroui_button_outline_1785520940418_uhbws}>Edit operator note</Button>
                  </div>
                  <div className="flex flex-col gap-2">
                    <form className="min-w-0" data-designer-node-id="html-form-1785520940444-hesui">
                                    {evaluateDesignerCondition(designerStore, dataContext, ({}), "!data.operatorNote") && (
                                      <Button className="flex h-auto min-h-9 w-full items-center justify-start gap-1.5 whitespace-normal rounded-md border border-dashed border-slate-200 bg-white px-2.5 py-2 text-start text-[11px] font-medium text-slate-600 outline-none transition-colors hover:border-slate-300 hover:bg-slate-50" icon="StickyNote" type="button" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_heroui_button_outline_1785520940452_43l1v}>No operator note yet — click to add one</Button>
                                    )}
                                    {evaluateDesignerCondition(designerStore, dataContext, ({}), "!!data.operatorNote") && (
                                      <Button className="flex h-auto min-h-9 w-full cursor-pointer items-start justify-start whitespace-pre-wrap rounded-md border border-slate-200 bg-white px-3 py-2 text-start text-xs font-normal leading-relaxed text-slate-700 outline-none transition-colors hover:border-slate-300 hover:bg-slate-50" type="button" variant="outline" size="md" href="#" target="_self" text={regionData_cmsContents_html_form_1785520940444_hesui?.operatorNote} onClick={handleonClick_heroui_button_outline_1785520940472_d4diq} name="heroui-button-outline-1785520940472-d4diq">Secondary</Button>
                                    )}
                    </form>
                  </div>
                </div>
                <div className="flex flex-col space-y-2 pt-3">
                  <div className="flex min-h-4 items-center gap-0.5 ps-[4px]">
                    <p className="border-s-2 ps-1.5 text-[11px] font-bold uppercase tracking-wider leading-none text-cyan-700 border-cyan-500">SEO</p>
                    <Button className="ms-auto inline-flex h-5 w-5 shrink-0 items-center justify-center rounded border-0 bg-transparent p-0 text-[0px] text-slate-400 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700 [&>svg]:h-3.5 [&>svg]:w-3.5" icon="Pencil" type="button" aria-label="Edit SEO" title="Edit SEO" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_heroui_button_outline_1785520940509_s4wy1}>Edit SEO</Button>
                  </div>
                  <div className="flex flex-col gap-2">
                    <form className="flex min-w-0 flex-col gap-1.5" data-designer-node-id="html-form-1785520940525-stvys">
                                    {evaluateDesignerCondition(designerStore, dataContext, ({}), "!data.seoTitle") && (
                                      <Button className="flex h-auto min-h-9 w-full items-center justify-start gap-1.5 whitespace-normal rounded-md border border-dashed border-slate-200 bg-white px-2.5 py-2 text-start text-[11px] font-medium text-slate-600 outline-none transition-colors hover:border-slate-300 hover:bg-slate-50" icon="Search" type="button" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_heroui_button_outline_1785520940531_q9eya}>No SEO metadata yet — click to add</Button>
                                    )}
                                    {evaluateDesignerCondition(designerStore, dataContext, ({}), "!!data.seoTitle") && (
                                      <Button className="flex h-auto min-h-9 w-full cursor-pointer items-start justify-start whitespace-pre-wrap rounded-md border border-slate-200 bg-white px-3 py-2 text-start text-xs font-normal leading-relaxed text-slate-700 outline-none transition-colors hover:border-slate-300 hover:bg-slate-50" type="button" variant="outline" size="md" href="#" target="_self" text={regionData_cmsContents_html_form_1785520940525_stvys?.seoTitle} onClick={handleonClick_heroui_button_outline_1785520940549_qj6f6} name="heroui-button-outline-1785520940549-qj6f6">Secondary</Button>
                                    )}
                      <div className="flex min-w-0 flex-col gap-[2px] overflow-hidden ps-[4px]">
                        <p className="text-[11px] font-normal normal-case tracking-normal text-slate-500">SEO description</p>
                        <p className="min-w-0 overflow-hidden break-words text-sm font-medium text-slate-800" name="html-text-1785520940576-i9rej">{regionData_cmsContents_html_form_1785520940525_stvys?.seoNote ?? "Text"}</p>
                      </div>
                    </form>
                  </div>
                </div>
                <div className="flex flex-col space-y-2 pt-3">
                  <div className="flex min-h-4 items-center gap-0.5 ps-[4px]">
                    <p className="border-s-2 ps-1.5 text-[11px] font-bold uppercase tracking-wider leading-none text-violet-700 border-violet-400">Tags</p>
                  </div>
                  <div className="flex flex-col gap-2">
                    <p className="min-h-10 rounded-md border border-violet-200 bg-violet-50 px-3 py-2 text-sm text-violet-900">—</p>
                    <a href="/studio/cms/vocabulary/content-tags" target="_self" className="inline-flex w-fit items-center gap-1.5 rounded-md border border-violet-200 bg-white px-3 py-1.5 text-xs font-semibold text-violet-700 no-underline hover:bg-violet-50">Manage tags</a>
                  </div>
                </div>
                <div className="flex flex-col space-y-2 pt-3">
                  <div className="flex min-h-4 items-center gap-0.5 ps-[4px]">
                    <p className="border-s-2 ps-1.5 text-[11px] font-bold uppercase tracking-wider leading-none text-emerald-700 border-emerald-400">Related contents</p>
                  </div>
                  <div className="flex flex-col gap-2">
                    <p className="ps-[4px] text-xs leading-relaxed text-slate-500">Undirected edges. Click a related item to open its editor.</p>
                    <div className="flex w-full flex-col gap-2"><div className="flex items-center justify-between gap-2 border-b border-slate-200 bg-white px-2 py-1.5"><div className="flex items-center gap-2"><input type="text" value={gridSearchInput_heroui_app_table_grid_1785520940673_flr3i} onChange={(event) => handleGridSearchChange_heroui_app_table_grid_1785520940673_flr3i(event.target.value)} placeholder={"Search related contents…"} className="h-8 rounded-md border border-slate-200 px-2 text-sm" /></div><div className="flex items-center gap-2"><button type="button" onClick={() => { patchDesignerStore("selection.id", null); patchDesignerStore("ui.visibility.node-81f75146-ffb7-4e51-ae27-f7802a32d793", true); }} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700">Add relation</button><button type="button" onClick={() => { void refresh_gridData_heroui_app_table_grid_1785520940673_flr3i(); }} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 px-3 text-xs font-medium text-slate-700 hover:bg-slate-50">Refresh</button></div></div><AppTableGrid className="flex h-full min-h-0 w-full flex-1 flex-col" presentation="cards" cardBelow="phone" cardVariant="list" columns={gridColumns_heroui_app_table_grid_1785520940673_flr3i} rows={gridPaging_heroui_app_table_grid_1785520940673_flr3i.displayRows} getRowKey={(row) => String((row as Record<string, unknown>)["id"] ?? '')} enableColumnLayout={false} columnLayout={gridColumnLayout_heroui_app_table_grid_1785520940673_flr3i} onColumnLayoutChange={setGridColumnLayout_heroui_app_table_grid_1785520940673_flr3i} isLoading={false} loadingMessage={"Loading relations…"} emptyMessage={"No relations found."} isEmpty={gridFilteredRows_heroui_app_table_grid_1785520940673_flr3i.length === 0} errorContent={gridFilteredRows_heroui_app_table_grid_1785520940673_flr3i.length === 0 ? undefined : "Could not load relations."} gridQueryMode={"server"} query={gridQuery_heroui_app_table_grid_1785520940673_flr3i} onQueryChange={handleGridQueryChange_heroui_app_table_grid_1785520940673_flr3i} onGridRowAction={handleGridRowAction_heroui_app_table_grid_1785520940673_flr3i} footer={<GridPagingFooter totalCount={gridTotalCount_heroui_app_table_grid_1785520940673_flr3i} safePage={gridPaging_heroui_app_table_grid_1785520940673_flr3i.safePage} pageSize={gridPageSize_heroui_app_table_grid_1785520940673_flr3i} onPageSizeChange={handleGridPageSizeChange_heroui_app_table_grid_1785520940673_flr3i} sortBy={gridQuery_heroui_app_table_grid_1785520940673_flr3i.sort?.columnId ?? ''} sortOptions={[{"value":"contentIdBTitle","label":"Related content"}]} onSortByChange={handleGridSortByChange_heroui_app_table_grid_1785520940673_flr3i} sortDirection={gridQuery_heroui_app_table_grid_1785520940673_flr3i.sort?.direction ?? 'asc'} onToggleSortDirection={handleGridToggleSortDirection_heroui_app_table_grid_1785520940673_flr3i} showSortControls={false} totalPages={gridPaging_heroui_app_table_grid_1785520940673_flr3i.totalPages} pageNumbers={buildDataGridPageNumbers(gridPaging_heroui_app_table_grid_1785520940673_flr3i.safePage, gridPaging_heroui_app_table_grid_1785520940673_flr3i.totalPages)} onPageChange={handleGridPageChange_heroui_app_table_grid_1785520940673_flr3i} visibleInfiniteCount={gridListMode_heroui_app_table_grid_1785520940673_flr3i === 'infinite' ? gridPaging_heroui_app_table_grid_1785520940673_flr3i.displayRows.length : undefined} />} /></div>
                    <div className="flex w-full flex-col gap-2"><div className="flex items-center justify-between gap-2 border-b border-slate-200 bg-white px-2 py-1.5"><div className="flex items-center gap-2"><input type="text" value={gridSearchInput_heroui_app_table_grid_1785520940709_3evjs} onChange={(event) => handleGridSearchChange_heroui_app_table_grid_1785520940709_3evjs(event.target.value)} placeholder={"Search related contents…"} className="h-8 rounded-md border border-slate-200 px-2 text-sm" /></div><div className="flex items-center gap-2"><button type="button" onClick={() => { void refresh_gridData_heroui_app_table_grid_1785520940709_3evjs(); }} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 px-3 text-xs font-medium text-slate-700 hover:bg-slate-50">Refresh</button></div></div><AppTableGrid className="flex h-full min-h-0 w-full flex-1 flex-col" presentation="cards" cardBelow="phone" cardVariant="list" columns={gridColumns_heroui_app_table_grid_1785520940709_3evjs} rows={gridPaging_heroui_app_table_grid_1785520940709_3evjs.displayRows} getRowKey={(row) => String((row as Record<string, unknown>)["id"] ?? '')} enableColumnLayout={false} columnLayout={gridColumnLayout_heroui_app_table_grid_1785520940709_3evjs} onColumnLayoutChange={setGridColumnLayout_heroui_app_table_grid_1785520940709_3evjs} isLoading={false} loadingMessage={"Loading relations…"} emptyMessage={"No relations found."} isEmpty={gridFilteredRows_heroui_app_table_grid_1785520940709_3evjs.length === 0} errorContent={gridFilteredRows_heroui_app_table_grid_1785520940709_3evjs.length === 0 ? undefined : "Could not load relations."} gridQueryMode={"server"} query={gridQuery_heroui_app_table_grid_1785520940709_3evjs} onQueryChange={handleGridQueryChange_heroui_app_table_grid_1785520940709_3evjs} footer={<GridPagingFooter totalCount={gridTotalCount_heroui_app_table_grid_1785520940709_3evjs} safePage={gridPaging_heroui_app_table_grid_1785520940709_3evjs.safePage} pageSize={gridPageSize_heroui_app_table_grid_1785520940709_3evjs} onPageSizeChange={handleGridPageSizeChange_heroui_app_table_grid_1785520940709_3evjs} sortBy={gridQuery_heroui_app_table_grid_1785520940709_3evjs.sort?.columnId ?? ''} sortOptions={[{"value":"contentIdATitle","label":"Related content"}]} onSortByChange={handleGridSortByChange_heroui_app_table_grid_1785520940709_3evjs} sortDirection={gridQuery_heroui_app_table_grid_1785520940709_3evjs.sort?.direction ?? 'asc'} onToggleSortDirection={handleGridToggleSortDirection_heroui_app_table_grid_1785520940709_3evjs} showSortControls={false} totalPages={gridPaging_heroui_app_table_grid_1785520940709_3evjs.totalPages} pageNumbers={buildDataGridPageNumbers(gridPaging_heroui_app_table_grid_1785520940709_3evjs.safePage, gridPaging_heroui_app_table_grid_1785520940709_3evjs.totalPages)} onPageChange={handleGridPageChange_heroui_app_table_grid_1785520940709_3evjs} visibleInfiniteCount={gridListMode_heroui_app_table_grid_1785520940709_3evjs === 'infinite' ? gridPaging_heroui_app_table_grid_1785520940709_3evjs.displayRows.length : undefined} />} /></div>
                  </div>
                </div>
                <div className="flex flex-col space-y-2 pt-3">
                  <div className="flex min-h-4 items-center gap-0.5 ps-[4px]">
                    <p className="border-s-2 ps-1.5 text-[11px] font-bold uppercase tracking-wider leading-none text-violet-700 border-violet-400">Comments</p>
                  </div>
                  <div className="flex flex-col gap-2">
                    <form className="flex min-w-0 flex-col gap-2" data-designer-node-id="html-form-1785520940781-42isk">
                      <div className="flex min-w-0 items-center justify-between gap-3 overflow-hidden ps-[4px]">
                        <p className="text-[11px] font-normal normal-case tracking-normal text-slate-500">Publishing policy override</p>
                        <p className="min-w-0 overflow-hidden break-words text-sm font-medium text-slate-800 text-end" name="html-text-1785520940811-vf0rt">{regionData_cmsContents_html_form_1785520940781_42isk?.commentsPolicyCodeTitle ?? "Text"}</p>
                      </div>
                      <Button className="ms-[4px] h-auto w-fit rounded-none border-0 bg-transparent p-0 text-[11px] font-semibold text-violet-700 underline-offset-2 hover:bg-transparent hover:underline" type="button" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_heroui_button_outline_1785520940826_k9iza}>Override for this content →</Button>
                    </form>
                  </div>
                </div>
                <div className="flex flex-col space-y-2 pt-3">
                  <div className="flex min-h-4 items-center gap-0.5 ps-[4px]">
                    <p className="border-s-2 ps-1.5 text-[11px] font-bold uppercase tracking-wider leading-none text-amber-700 border-amber-400">History</p>
                  </div>
                  <div className="flex flex-col gap-2">
                    <form className="min-w-0" data-designer-node-id="html-form-1785520940891-47lmx">
                      <div className="flex items-center gap-1 ps-[4px]">
                        <p className="text-[11px] font-semibold text-amber-700" name="html-text-1785520940909-x9lmi">{regionData_cmsContents_html_form_1785520940891_47lmx?.revisionCount ?? "Text"}</p>
                        <Button className="h-auto w-fit rounded-none border-0 bg-transparent p-0 text-[11px] font-semibold text-amber-700 underline-offset-2 hover:bg-transparent hover:underline" type="button" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_heroui_button_outline_1785520940925_zls2g}>revisions →</Button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
            {evaluateDesignerCondition(designerStore, dataContext, ({}), "store.ui.visibility.heroui-modal-1785520940959-vxtiy !== false") && (
              <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["heroui-modal-1785520940959-vxtiy"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.heroui-modal-1785520940959-vxtiy", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Change content status</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.heroui-modal-1785520940959-vxtiy", false)}>×</button></Modal.Header><Modal.Body className="p-0">
            <p className="block bg-white p-[15px] text-sm text-slate-700">Choose the new status for this content.</p>
            <div className="flex w-full flex-wrap items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button className="inline-flex h-8 items-center justify-center gap-1.5 rounded-md bg-emerald-600 px-3 text-xs font-semibold text-white hover:bg-emerald-700" icon="Send" variant="primary" size="md" href="#" target="_self" onClick={handleonClick_heroui_button_solid_1785520941023_7ms5y}>Publish</Button>
              <Button className="inline-flex h-8 items-center justify-center gap-1.5 rounded-md border border-slate-300 bg-white px-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50" icon="Archive" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_heroui_button_outline_1785520941042_o6zu0}>Archive</Button>
              <Button className="inline-flex h-8 items-center justify-center gap-1.5 rounded-md border border-amber-200 bg-amber-50 px-2.5 text-xs font-semibold text-amber-800 hover:bg-amber-100" icon="Undo2" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_heroui_button_outline_1785520941062_74sai}>Back to draft</Button>
            </div>
          </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
            )}
        </div>
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.heroui-modal-1785520939904-1046r === true) && (store.ui.visibility.heroui-modal-1785520939904-1046r !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["heroui-modal-1785520939904-1046r"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.heroui-modal-1785520939904-1046r", false); } }} variant="blur"><Modal.Container size="xl" scroll="inside"><Modal.Dialog className="w-full max-w-5xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Preview content</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.heroui-modal-1785520939904-1046r", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <div className="flex min-h-[30rem] min-w-0 flex-col gap-3 overflow-hidden bg-white p-[15px]">
            <form className="flex min-w-0 flex-col gap-2" data-designer-node-id="html-form-1785520939911-fu8nt">
              <p className="text-xs font-bold uppercase tracking-wide text-slate-500">Preview</p>
              <p className="text-xl font-semibold text-slate-900" name="html-text-1785520939915-tyb9y">{regionData_cmsContents_html_form_1785520939911_fu8nt?.title ?? "Text"}</p>
              <p className="text-sm leading-relaxed text-slate-600" name="html-text-1785520939920-3gyu7">{regionData_cmsContents_html_form_1785520939911_fu8nt?.summary ?? "Text"}</p>
              <p className="rounded-md border border-violet-200 bg-violet-50 px-3 py-2 text-sm text-violet-900" name="html-text-1785520939925-yt3vq">{regionData_cmsContents_html_form_1785520939911_fu8nt?.tagSummary ?? "Text"}</p>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <p className="text-sm text-default-700" name="html-text-1785520939930-9s86q">{regionData_cmsContents_html_form_1785520939911_fu8nt?.bodyFormatCodeTitle ?? "Text"}</p>
              </div>
              <p className="min-h-44 whitespace-pre-wrap rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 text-sm leading-relaxed text-slate-700" name="html-text-1785520939933-lfd16">{regionData_cmsContents_html_form_1785520939911_fu8nt?.body ?? "Text"}</p>
            </form>
          </div>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-ece35d40-ae8a-44e5-9540-05cabf267f89 === true) && (store.ui.visibility.node-ece35d40-ae8a-44e5-9540-05cabf267f89 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-ece35d40-ae8a-44e5-9540-05cabf267f89"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-ece35d40-ae8a-44e5-9540-05cabf267f89", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Create asset</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-ece35d40-ae8a-44e5-9540-05cabf267f89", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <form className="flex min-h-0 flex-col gap-0 overflow-hidden bg-white" method="post" data-designer-node-id="node-8361b410-cbbf-43ad-852b-0f5ac1e69c69">
            <div className="flex flex-col gap-2 bg-white p-[15px]">
              <UiInput isRequired readOnly className="hidden" type="text" placeholder="Content ID" label="Content ID" defaultValue="routeParams.id" size="sm" value={regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69?.contentId} name="node-29441cd9-03df-4685-98b9-2f6d087258e0" />
              <label label="File" isRequired value={regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69?.file} name="node-c2031f05-c4b5-4561-a292-824d713ab953"><svg aria-hidden="true" className="h-8 w-8 text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75"><path d="M12 16V4m0 0 7 7m-7-7L5 11" /><path d="M4 20h16" /></svg><span className="text-sm font-medium text-slate-700">Click to upload or drag and drop</span><span className="text-xs text-slate-500">Files will upload when connected to an API</span><input type="file" accept="*/*" className="sr-only" /></label>
              <UiInput isRequired type="text" placeholder="File name" label="File name" size="sm" value={regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69?.fileName} name="node-250c311f-d07a-446b-8f9d-8ae43ce0486d" />
              <UiInput isRequired type="text" placeholder="File MIME" label="File MIME" size="sm" value={regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69?.fileMime} name="node-41b3f7f5-d1a3-47ad-bafd-49a37ef89735" />
              <UiInput isRequired type="number" placeholder="File size" label="File size" step={1} size="sm" value={regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69?.fileSize} name="node-47d2dd33-f694-4081-aa3c-1ff7b0e37763" />
              <UiInput isRequired type="text" placeholder="SHA-256" label="SHA-256" size="sm" value={regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69?.sha256} name="node-a301f4cf-416f-4b8d-a3cb-ebd1cdcc19e0" />
              <UiInput isRequired type="number" placeholder="Sort order" label="Sort order" step={1} size="sm" value={regionData_cmsContentAssets_node_8361b410_cbbf_43ad_852b_0f5ac1e69c69?.sortOrder} name="node-46691bc1-efe1-4efc-bf2a-ac29779f9c24" />
            </div>
            <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" onClick={handleonClick_node_8b27e93b_f5f9_4400_884b_bc22c2820974}>Cancel</Button>
              <Button type="submit" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" icon="Plus" variant="primary" size="md" href="#" target="_self" isDisabled={isSubmitting} onClick={handleonClick_node_e7486e00_cae0_4490_a687_36cf2241fb81}>Create asset</Button>
            </div>
          </form>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-41a85cab-7382-4ad6-b26f-b0a7a9b21aa9 === true) && (store.ui.visibility.node-41a85cab-7382-4ad6-b26f-b0a7a9b21aa9 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-41a85cab-7382-4ad6-b26f-b0a7a9b21aa9"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-41a85cab-7382-4ad6-b26f-b0a7a9b21aa9", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Edit asset</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-41a85cab-7382-4ad6-b26f-b0a7a9b21aa9", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <form className="flex min-h-0 flex-col gap-0 overflow-hidden bg-white" method="post" data-designer-node-id="node-96c7a90e-cfc1-41df-80d3-ce140dbdc93d">
            <div className="flex flex-col gap-2 bg-white p-[15px]">
              <UiInput isRequired readOnly className="hidden" type="text" placeholder="Content ID" label="Content ID" defaultValue="routeParams.id" size="sm" value={regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d?.contentId} name="node-5d63a6df-0969-4d30-b319-ca3b5f4f7725" />
              <label label="File" isRequired value={regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d?.file} name="node-e24ab20a-8ac8-462c-a5a3-aed192fda44d"><svg aria-hidden="true" className="h-8 w-8 text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75"><path d="M12 16V4m0 0 7 7m-7-7L5 11" /><path d="M4 20h16" /></svg><span className="text-sm font-medium text-slate-700">Click to upload or drag and drop</span><span className="text-xs text-slate-500">Files will upload when connected to an API</span><input type="file" accept="*/*" className="sr-only" /></label>
              <UiInput isRequired type="text" placeholder="File name" label="File name" size="sm" value={regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d?.fileName} name="node-808fc709-6952-4553-8e4f-43af1a7f7b1b" />
              <UiInput isRequired type="text" placeholder="File MIME" label="File MIME" size="sm" value={regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d?.fileMime} name="node-ba21d796-9868-4391-b156-4079913feefd" />
              <UiInput isRequired type="number" placeholder="File size" label="File size" step={1} size="sm" value={regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d?.fileSize} name="node-9521c419-838d-4115-b228-fd52b33df8f5" />
              <UiInput isRequired type="text" placeholder="SHA-256" label="SHA-256" size="sm" value={regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d?.sha256} name="node-ee011d48-c0ca-4776-8a3f-0a27e58b1086" />
              <UiInput isRequired type="number" placeholder="Sort order" label="Sort order" step={1} size="sm" value={regionData_cmsContentAssets_node_96c7a90e_cfc1_41df_80d3_ce140dbdc93d?.sortOrder} name="node-7b76ba08-b087-4a0c-8231-a98ba614380f" />
            </div>
            <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" onClick={handleonClick_node_4222597e_7768_4eb7_b9d0_6dd6c0d48cfd}>Cancel</Button>
              <Button type="submit" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" icon="Save" variant="primary" size="md" href="#" target="_self" isDisabled={isSubmitting} onClick={handleonClick_node_d64a3dc6_5294_4412_a545_6729671d3d12}>Save</Button>
            </div>
          </form>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-3f533133-b07b-429c-a396-8a3e7748ebda === true) && (store.ui.visibility.node-3f533133-b07b-429c-a396-8a3e7748ebda !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-3f533133-b07b-429c-a396-8a3e7748ebda"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-3f533133-b07b-429c-a396-8a3e7748ebda", false); } }} variant="blur"><Modal.Container><Modal.Dialog role="alertdialog" className="w-full max-w-md overflow-hidden rounded-xl border border-rose-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-rose-200 bg-rose-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-rose-800">Delete asset?</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-3f533133-b07b-429c-a396-8a3e7748ebda", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <p className="block bg-white p-[15px] text-sm text-slate-700">Delete this asset? This cannot be undone.</p>
          <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
            <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_node_0ae9132f_b9eb_4243_8d8a_02fcdfd8f921}>Cancel</Button>
            <Button icon="Trash2" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-rose-600 px-3 text-xs font-semibold text-white hover:bg-rose-700" variant="primary" size="md" href="#" target="_self" onClick={handleonClick_node_46261deb_59d5_4b74_b53f_957cb845a656}>Delete</Button>
          </div>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-81f75146-ffb7-4e51-ae27-f7802a32d793 === true) && (store.ui.visibility.node-81f75146-ffb7-4e51-ae27-f7802a32d793 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-81f75146-ffb7-4e51-ae27-f7802a32d793"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-81f75146-ffb7-4e51-ae27-f7802a32d793", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Create relation</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-81f75146-ffb7-4e51-ae27-f7802a32d793", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <form className="flex min-h-0 flex-col gap-0 overflow-hidden bg-white" method="post" data-designer-node-id="node-fbdb9eb2-fb81-40fd-97f3-bc21913ed133">
            <div className="flex flex-col gap-2 bg-white p-[15px]">
              <UiInput isRequired readOnly className="hidden" type="text" placeholder="Content A" label="Content A" defaultValue="routeParams.id" size="sm" value={regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133?.contentIdA} name="node-a2a92873-585b-4580-80ef-2b1c8f82e36a" />
              <UiSelect isRequired className="w-full" placeholder="Select content b…" label="Content B" size="sm" selectedKeys={regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133?.contentIdB} name="node-25100434-2df4-4e56-b35d-5a7687ea340b"><option value="3">Scheduled maintenance</option><option value="1">Welcome to CMS</option><option value="2">Product update — Q3</option></UiSelect>
              <UiTextarea placeholder="Note" label="Note" rows={3} size="sm" value={regionData_cmsContentRelations_node_fbdb9eb2_fb81_40fd_97f3_bc21913ed133?.note} name="node-9d087163-7aa2-44b1-8030-7aa43b6bba3a" />
            </div>
            <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" onClick={handleonClick_node_e17f82f0_33e4_44f5_b5a2_9c1ad0ceff3e}>Cancel</Button>
              <Button type="submit" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" icon="Plus" variant="primary" size="md" href="#" target="_self" isDisabled={isSubmitting} onClick={handleonClick_node_a55901d0_a746_41b9_91fe_61d6edde90e3}>Create relation</Button>
            </div>
          </form>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-132a0a55-4dab-49d3-897e-c1fac1254a15 === true) && (store.ui.visibility.node-132a0a55-4dab-49d3-897e-c1fac1254a15 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-132a0a55-4dab-49d3-897e-c1fac1254a15"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-132a0a55-4dab-49d3-897e-c1fac1254a15", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Edit relation</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-132a0a55-4dab-49d3-897e-c1fac1254a15", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <form className="flex min-h-0 flex-col gap-0 overflow-hidden bg-white" method="post" data-designer-node-id="node-bb48e4f6-4842-406f-9932-296984139f47">
            <div className="flex flex-col gap-2 bg-white p-[15px]">
              <UiInput isRequired readOnly className="hidden" type="text" placeholder="Content A" label="Content A" defaultValue="routeParams.id" size="sm" value={regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47?.contentIdA} name="node-f492ca21-1d4b-4c8d-928a-fb9146529c75" />
              <UiSelect isRequired className="w-full" placeholder="Select content b…" label="Content B" size="sm" selectedKeys={regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47?.contentIdB} name="node-2757002b-b3d6-421a-b348-511546c900c5"><option value="3">Scheduled maintenance</option><option value="1">Welcome to CMS</option><option value="2">Product update — Q3</option></UiSelect>
              <UiTextarea placeholder="Note" label="Note" rows={3} size="sm" value={regionData_cmsContentRelations_node_bb48e4f6_4842_406f_9932_296984139f47?.note} name="node-95b0d72c-d576-4d42-a615-7cf15f042607" />
            </div>
            <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" onClick={handleonClick_node_78092672_3b58_40fe_8f1a_7cd0549f6255}>Cancel</Button>
              <Button type="submit" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" icon="Save" variant="primary" size="md" href="#" target="_self" isDisabled={isSubmitting} onClick={handleonClick_node_3f73d495_3ae7_41af_9bdc_1b6d1a763b74}>Save</Button>
            </div>
          </form>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-5e28a7e2-a612-4531-9fb2-67244e8a4f43 === true) && (store.ui.visibility.node-5e28a7e2-a612-4531-9fb2-67244e8a4f43 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-5e28a7e2-a612-4531-9fb2-67244e8a4f43"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-5e28a7e2-a612-4531-9fb2-67244e8a4f43", false); } }} variant="blur"><Modal.Container><Modal.Dialog role="alertdialog" className="w-full max-w-md overflow-hidden rounded-xl border border-rose-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-rose-200 bg-rose-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-rose-800">Delete relation?</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-5e28a7e2-a612-4531-9fb2-67244e8a4f43", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <p className="block bg-white p-[15px] text-sm text-slate-700">Delete this relation? This cannot be undone.</p>
          <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
            <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" target="_self" onClick={handleonClick_node_ab345e7c_74be_4673_9395_31f822efc4fd}>Cancel</Button>
            <Button icon="Trash2" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-rose-600 px-3 text-xs font-semibold text-white hover:bg-rose-700" variant="primary" size="md" href="#" target="_self" onClick={handleonClick_node_b37f1911_abb6_4051_97ee_038831178be1}>Delete</Button>
          </div>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.heroui-modal-1785520941080-38heo === true) && (store.ui.visibility.heroui-modal-1785520941080-38heo !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["heroui-modal-1785520941080-38heo"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.heroui-modal-1785520941080-38heo", false); } }} variant="blur"><Modal.Container size="xl" scroll="inside"><Modal.Dialog className="w-full max-w-5xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Revision history</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.heroui-modal-1785520941080-38heo", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <div className="flex min-h-[30rem] min-w-0 flex-col overflow-hidden bg-white p-[15px]">
            <AppTableGrid className="flex h-full min-h-0 w-full flex-1 flex-col" presentation="auto" cardBelow="phone" cardVariant="list" columns={gridColumns_heroui_app_table_grid_1785520941117_h6zx4} rows={gridPaging_heroui_app_table_grid_1785520941117_h6zx4.displayRows} getRowKey={(row) => String((row as Record<string, unknown>)["id"] ?? '')} enableColumnLayout={false} columnLayout={gridColumnLayout_heroui_app_table_grid_1785520941117_h6zx4} onColumnLayoutChange={setGridColumnLayout_heroui_app_table_grid_1785520941117_h6zx4} isLoading={false} loadingMessage={"Loading revisions…"} emptyMessage={"No revisions found."} isEmpty={gridFilteredRows_heroui_app_table_grid_1785520941117_h6zx4.length === 0} errorContent={gridFilteredRows_heroui_app_table_grid_1785520941117_h6zx4.length === 0 ? undefined : "Could not load revisions."} gridQueryMode={"client"} query={gridQuery_heroui_app_table_grid_1785520941117_h6zx4} onQueryChange={handleGridQueryChange_heroui_app_table_grid_1785520941117_h6zx4} footer={<GridPagingFooter totalCount={gridTotalCount_heroui_app_table_grid_1785520941117_h6zx4} safePage={gridPaging_heroui_app_table_grid_1785520941117_h6zx4.safePage} pageSize={gridPageSize_heroui_app_table_grid_1785520941117_h6zx4} onPageSizeChange={handleGridPageSizeChange_heroui_app_table_grid_1785520941117_h6zx4} sortBy={gridQuery_heroui_app_table_grid_1785520941117_h6zx4.sort?.columnId ?? ''} sortOptions={[{"value":"revisionNo","label":"#"}]} onSortByChange={handleGridSortByChange_heroui_app_table_grid_1785520941117_h6zx4} sortDirection={gridQuery_heroui_app_table_grid_1785520941117_h6zx4.sort?.direction ?? 'asc'} onToggleSortDirection={handleGridToggleSortDirection_heroui_app_table_grid_1785520941117_h6zx4} showSortControls={false} totalPages={gridPaging_heroui_app_table_grid_1785520941117_h6zx4.totalPages} pageNumbers={buildDataGridPageNumbers(gridPaging_heroui_app_table_grid_1785520941117_h6zx4.safePage, gridPaging_heroui_app_table_grid_1785520941117_h6zx4.totalPages)} onPageChange={handleGridPageChange_heroui_app_table_grid_1785520941117_h6zx4} visibleInfiniteCount={gridListMode_heroui_app_table_grid_1785520941117_h6zx4 === 'infinite' ? gridPaging_heroui_app_table_grid_1785520941117_h6zx4.displayRows.length : undefined} />} />
          </div>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.heroui-modal-1785520941166-a4079 === true) && (store.ui.visibility.heroui-modal-1785520941166-a4079 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["heroui-modal-1785520941166-a4079"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.heroui-modal-1785520941166-a4079", false); } }} variant="blur"><Modal.Container size="xl" scroll="inside"><Modal.Dialog className="w-full max-w-5xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Submitted comments</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.heroui-modal-1785520941166-a4079", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <div className="flex min-h-[30rem] min-w-0 flex-col overflow-hidden bg-white p-[15px]">
            <AppTableGrid className="flex h-full min-h-0 w-full flex-1 flex-col" presentation="auto" cardBelow="phone" cardVariant="list" columns={gridColumns_heroui_app_table_grid_1785520941205_diay5} rows={gridPaging_heroui_app_table_grid_1785520941205_diay5.displayRows} getRowKey={(row) => String((row as Record<string, unknown>)["id"] ?? '')} enableColumnLayout={false} columnLayout={gridColumnLayout_heroui_app_table_grid_1785520941205_diay5} onColumnLayoutChange={setGridColumnLayout_heroui_app_table_grid_1785520941205_diay5} isLoading={false} loadingMessage={"Loading comments…"} emptyMessage={"No comments found."} isEmpty={gridFilteredRows_heroui_app_table_grid_1785520941205_diay5.length === 0} errorContent={gridFilteredRows_heroui_app_table_grid_1785520941205_diay5.length === 0 ? undefined : "Could not load comments."} gridQueryMode={"client"} query={gridQuery_heroui_app_table_grid_1785520941205_diay5} onQueryChange={handleGridQueryChange_heroui_app_table_grid_1785520941205_diay5} footer={<GridPagingFooter totalCount={gridTotalCount_heroui_app_table_grid_1785520941205_diay5} safePage={gridPaging_heroui_app_table_grid_1785520941205_diay5.safePage} pageSize={gridPageSize_heroui_app_table_grid_1785520941205_diay5} onPageSizeChange={handleGridPageSizeChange_heroui_app_table_grid_1785520941205_diay5} sortBy={gridQuery_heroui_app_table_grid_1785520941205_diay5.sort?.columnId ?? ''} sortOptions={[{"value":"authorDisplayName","label":"Author"},{"value":"createdAt","label":"Submitted"}]} onSortByChange={handleGridSortByChange_heroui_app_table_grid_1785520941205_diay5} sortDirection={gridQuery_heroui_app_table_grid_1785520941205_diay5.sort?.direction ?? 'asc'} onToggleSortDirection={handleGridToggleSortDirection_heroui_app_table_grid_1785520941205_diay5} showSortControls={false} totalPages={gridPaging_heroui_app_table_grid_1785520941205_diay5.totalPages} pageNumbers={buildDataGridPageNumbers(gridPaging_heroui_app_table_grid_1785520941205_diay5.safePage, gridPaging_heroui_app_table_grid_1785520941205_diay5.totalPages)} onPageChange={handleGridPageChange_heroui_app_table_grid_1785520941205_diay5} visibleInfiniteCount={gridListMode_heroui_app_table_grid_1785520941205_diay5 === 'infinite' ? gridPaging_heroui_app_table_grid_1785520941205_diay5.displayRows.length : undefined} />} />
          </div>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-7027b007-a233-4b5a-b327-e10e3360fdf1 === true) && (store.ui.visibility.node-7027b007-a233-4b5a-b327-e10e3360fdf1 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-7027b007-a233-4b5a-b327-e10e3360fdf1"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-7027b007-a233-4b5a-b327-e10e3360fdf1", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Edit content identity</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-7027b007-a233-4b5a-b327-e10e3360fdf1", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <form className="flex min-h-0 flex-col gap-0 overflow-hidden bg-white" method="post" data-designer-node-id="node-910583ce-e66a-44e2-a372-1c5144f11ffe">
            <div className="flex flex-col gap-2 bg-white p-[15px]">
              <UiSelect isRequired className="w-full" placeholder="Select content type…" label="Content Type" size="sm" selectedKeys={regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe?.contentTypeCode} name="node-0c44bd0e-e7c7-4fa7-8c05-535b20654570"><option value="101.001.001">Article</option><option value="101.001.002">News</option><option value="101.001.003">Announcement</option><option value="101.001.004">Gallery</option></UiSelect>
              <UiSelect isRequired className="w-full" placeholder="Select language…" label="Language" size="sm" selectedKeys={regionData_cmsContents_node_910583ce_e66a_44e2_a372_1c5144f11ffe?.languageCode} name="node-e8e98b24-39cc-486a-935f-427076bf0971"><option value="101.004.001">English</option><option value="101.004.002">Persian</option><option value="101.004.003">Arabic</option></UiSelect>
            </div>
            <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" onClick={handleonClick_node_97d030cb_3fe2_4b1e_afad_7b16b7926630}>Cancel</Button>
              <Button type="submit" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" icon="Save" variant="primary" size="md" href="#" target="_self" isDisabled={isSubmitting} onClick={handleonClick_node_1aa072bb_a65f_4dba_b70a_015aa7c01b9b}>Save identity</Button>
            </div>
          </form>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-d77d1af5-2bc5-4675-9882-3647524e0b9e === true) && (store.ui.visibility.node-d77d1af5-2bc5-4675-9882-3647524e0b9e !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-d77d1af5-2bc5-4675-9882-3647524e0b9e"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-d77d1af5-2bc5-4675-9882-3647524e0b9e", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Comments & publishing</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-d77d1af5-2bc5-4675-9882-3647524e0b9e", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <form className="flex min-h-0 flex-col gap-0 overflow-hidden bg-white" method="post" data-designer-node-id="node-bf16e7ef-f904-4f3e-ae1c-0f1b6bfd57ad">
            <div className="flex flex-col gap-2 bg-white p-[15px]">
              <Switch label="Allow comments for this content" aria-label="Allow comments for this content" size="md" isSelected={regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad?.commentsEnabled} name="node-efea763c-39c5-477c-8137-52058bf4d991"><Switch.Control><Switch.Thumb /></Switch.Control></Switch>
              <UiSelect className="w-full" placeholder="Use global default" label="Publishing policy" size="sm" selectedKeys={regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad?.commentsPolicyCode} name="node-7c888dd7-f3eb-43b8-81b7-227055cff693"><option value="101.006.001">Automatic</option><option value="101.006.002">Approve</option></UiSelect>
              <UiSelect className="w-full" placeholder="Use global default" label="Comment body format" size="sm" selectedKeys={regionData_cmsContents_node_bf16e7ef_f904_4f3e_ae1c_0f1b6bfd57ad?.commentsBodyFormatCode} name="node-18a60015-8bdc-4e4a-95d3-97c9fad0a106"><option value="101.003.001">Plain</option><option value="101.003.003">HTML</option></UiSelect>
            </div>
            <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" onClick={handleonClick_node_1709d617_1ccd_4012_8a68_9127a854f8fb}>Cancel</Button>
              <Button type="submit" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" icon="Save" variant="primary" size="md" href="#" target="_self" isDisabled={isSubmitting} onClick={handleonClick_node_a1d378e6_2a4e_43d8_a4b5_962c60dc0a10}>Save comments settings</Button>
            </div>
          </form>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-1696ccf3-e9cc-4a8b-a4e0-a4e2314c817d === true) && (store.ui.visibility.node-1696ccf3-e9cc-4a8b-a4e0-a4e2314c817d !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-1696ccf3-e9cc-4a8b-a4e0-a4e2314c817d"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-1696ccf3-e9cc-4a8b-a4e0-a4e2314c817d", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Edit operator note</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-1696ccf3-e9cc-4a8b-a4e0-a4e2314c817d", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <form className="flex min-h-0 flex-col gap-0 overflow-hidden bg-white" method="post" data-designer-node-id="node-80938477-50e9-441d-80da-62a7fc2f6634">
            <div className="flex flex-col gap-2 bg-white p-[15px]">
              <UiTextarea placeholder="Operator note" label="Operator note" rows={3} size="sm" value={regionData_cmsContents_node_80938477_50e9_441d_80da_62a7fc2f6634?.operatorNote} name="node-d3b91390-175d-492f-afda-ae9745c39113" />
            </div>
            <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" onClick={handleonClick_node_95de89ec_f63f_40bf_9248_328e1a5e070d}>Cancel</Button>
              <Button type="submit" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" icon="Save" variant="primary" size="md" href="#" target="_self" isDisabled={isSubmitting} onClick={handleonClick_node_0e47605c_0520_4b14_9c3d_6135d20e1890}>Save note</Button>
            </div>
          </form>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-4be6aeda-2057-4e95-a3e9-165b6fe46a54 === true) && (store.ui.visibility.node-4be6aeda-2057-4e95-a3e9-165b6fe46a54 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-4be6aeda-2057-4e95-a3e9-165b6fe46a54"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-4be6aeda-2057-4e95-a3e9-165b6fe46a54", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Edit SEO</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-4be6aeda-2057-4e95-a3e9-165b6fe46a54", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <form className="flex min-h-0 flex-col gap-0 overflow-hidden bg-white" method="post" data-designer-node-id="node-b9e0e569-9f05-4059-b144-5d9ad3dd99cd">
            <div className="flex flex-col gap-2 bg-white p-[15px]">
              <UiInput type="text" placeholder="SEO title" label="SEO title" size="sm" value={regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd?.seoTitle} name="node-693aa8b8-8bda-4844-ad8d-29a2a89ec8b4" />
              <UiTextarea placeholder="SEO description" label="SEO description" rows={3} size="sm" value={regionData_cmsContents_node_b9e0e569_9f05_4059_b144_5d9ad3dd99cd?.seoNote} name="node-08ef0595-d97b-486f-9952-c95ca41dd464" />
            </div>
            <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" onClick={handleonClick_node_1528be36_e1cd_4b16_901d_f215599aee69}>Cancel</Button>
              <Button type="submit" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" icon="Save" variant="primary" size="md" href="#" target="_self" isDisabled={isSubmitting} onClick={handleonClick_node_4a37d840_0384_4688_ac1f_772c1e54ab6a}>Save SEO</Button>
            </div>
          </form>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(ui.visibility.node-6fdbf622-b138-4b29-8042-4af78f284e06 === true) && (store.ui.visibility.node-6fdbf622-b138-4b29-8042-4af78f284e06 !== false)") && (
          <Modal><Modal.Backdrop isOpen={designerStore.ui.visibility["node-6fdbf622-b138-4b29-8042-4af78f284e06"] === true} onOpenChange={(isOpen) => { if (!isOpen) { patchDesignerStore("ui.visibility.node-6fdbf622-b138-4b29-8042-4af78f284e06", false); } }} variant="blur"><Modal.Container size="md" scroll="inside"><Modal.Dialog className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"><Modal.Header className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-slate-50/80 px-[15px]"><Modal.Heading className="text-sm font-semibold text-slate-800">Edit slug</Modal.Heading><button type="button" className="inline-flex h-7 w-7 items-center justify-center rounded text-base text-slate-500 outline-none transition-colors hover:bg-slate-100 hover:text-slate-700" aria-label="Close" onClick={() => patchDesignerStore("ui.visibility.node-6fdbf622-b138-4b29-8042-4af78f284e06", false)}>×</button></Modal.Header><Modal.Body className="p-0">
          <form className="flex min-h-0 flex-col gap-0 overflow-hidden bg-white" method="post" data-designer-node-id="node-d47908af-aca4-4737-91b3-b6d5d40d8cd7">
            <div className="flex flex-col gap-2 bg-white p-[15px]">
              <UiInput isRequired type="text" placeholder="Slug" label="Slug" size="sm" value={regionData_cmsContents_node_d47908af_aca4_4737_91b3_b6d5d40d8cd7?.slug} name="node-bb2393fb-2ca8-42eb-af1c-63a21b78937b" />
            </div>
            <div className="flex w-full items-center justify-end gap-2 border-t border-slate-200 bg-slate-100/90 px-[15px] py-2.5">
              <Button icon="X" type="button" className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700" variant="outline" size="md" href="#" onClick={handleonClick_node_5f5956ee_6b83_42ce_8555_11dc431a1ecc}>Cancel</Button>
              <Button type="submit" className="inline-flex h-8 items-center gap-1.5 rounded-md bg-indigo-600 px-3 text-xs font-semibold text-white hover:bg-indigo-700" icon="Save" variant="primary" size="md" href="#" target="_self" isDisabled={isSubmitting} onClick={handleonClick_node_1d352cea_9f68_41e8_8f80_5b0106ae2802}>Save slug</Button>
            </div>
          </form>
        </Modal.Body></Modal.Dialog></Modal.Container></Modal.Backdrop></Modal>
        )}
      </div>
    </>
  );
};
export default GeneratedComponent;
