-- Legacy MoarrefUserName_Deleted / MoarrefRelationId_Deleted parity for call-center referrer replace.
IF COL_LENGTH(N'dbo.hwy_members', N'referrer_username_deleted') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_members ADD referrer_username_deleted NVARCHAR(4000) NULL;
END;
GO

IF COL_LENGTH(N'dbo.hwy_members', N'referrer_relation_id_deleted') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_members ADD referrer_relation_id_deleted INT NULL;
END;
GO
