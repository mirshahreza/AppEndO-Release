-- Rename legacy-import parity tables on the AppEndO edge DB to hwy_member_* snake_case.
-- Idempotent: skips when the target name already exists.
-- Note: MembersV2 scalar functions (e.g. HWY_FN_Agg_AreaLimits*) imported separately may
-- still reference old table names until re-imported from legacy after this rename.

IF OBJECT_ID(N'dbo.HWY_Members_SecurityStatuses', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.hwy_member_security_statuses', N'U') IS NULL
  EXEC sp_rename N'dbo.HWY_Members_SecurityStatuses', N'hwy_member_security_statuses';
GO

IF OBJECT_ID(N'dbo.HWY_Members_SecurityProfile', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.hwy_member_security_profile_history', N'U') IS NULL
  EXEC sp_rename N'dbo.HWY_Members_SecurityProfile', N'hwy_member_security_profile_history';
GO

IF OBJECT_ID(N'dbo.HWY_Members_CardPrintingFlowSteps', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.hwy_member_card_printing_flow_steps', N'U') IS NULL
  EXEC sp_rename N'dbo.HWY_Members_CardPrintingFlowSteps', N'hwy_member_card_printing_flow_steps';
GO

IF OBJECT_ID(N'dbo.HWY_Members_CardPrintingHistory', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.hwy_member_card_printing_history', N'U') IS NULL
  EXEC sp_rename N'dbo.HWY_Members_CardPrintingHistory', N'hwy_member_card_printing_history';
GO

IF OBJECT_ID(N'dbo.HWY_Members_Interviews_2022', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.hwy_member_interviews_2022', N'U') IS NULL
  EXEC sp_rename N'dbo.HWY_Members_Interviews_2022', N'hwy_member_interviews_2022';
GO

IF OBJECT_ID(N'dbo.HWY_Members_Interviews_2022_R_Hazerin', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.hwy_member_interviews_2022_hazerin', N'U') IS NULL
  EXEC sp_rename N'dbo.HWY_Members_Interviews_2022_R_Hazerin', N'hwy_member_interviews_2022_hazerin';
GO

IF OBJECT_ID(N'dbo.HWY_Members_AreaLimits', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.hwy_member_area_limits', N'U') IS NULL
  EXEC sp_rename N'dbo.HWY_Members_AreaLimits', N'hwy_member_area_limits';
GO
