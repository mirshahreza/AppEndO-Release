-- AUTO-GENERATED — npx tsx scripts/hwy-phase1/db/gen-hwy-finance-functions-from-legacy.ts

-- HWY_FN_CalcPayAmount → hwy_payment_calc_pay_amount
CREATE OR ALTER FUNCTION dbo.hwy_payment_calc_pay_amount ( @member_id INT )
RETURNS INT
BEGIN
	DECLARE @PayAmount			INT=0;
	
	DECLARE @user_id				INT;
	DECLARE @gender_id			INT;
	DECLARE @MasooliatLevelId	INT;

	DECLARE @role_id				INT;
	DECLARE @AreaProvinceId		INT;
	DECLARE @AreaCircleId		INT;
	DECLARE @AreaTamvinId		INT;
	DECLARE @AreaId				INT;
	DECLARE @MasooliatOn		DATETIME;
	DECLARE @DaiesInMasooliat	INT;

	SELECT TOP 1
		@user_id=user_id,@gender_id=gender_id,@MasooliatLevelId= masooliat_level_id,
		@AreaProvinceId= area_limit_province_id,@AreaCircleId= area_limit_circle_id,@AreaTamvinId= area_limit_tamvin_id
	FROM hwy_members WHERE id=@member_id;

	--IF(@gender_id=10012) RETURN @PayAmount; -- Moannas

	SELECT TOP 1 @AreaId=item_id FROM hwy_member_area_limits WHERE approved=1 AND member_id=@member_id;

	IF(@AreaId IS NULL) RETURN @PayAmount;

	-- 1000004 : masool maktab
	-- 1000005 : masool mantagheh
	-- 1000027 : masool circle

	SELECT TOP 1 @role_id=role_id,@MasooliatOn= approved_on
	FROM vw_hwy_platform_user_roles_finance WHERE approved=1 AND user_id=@user_id AND role_id IN (1000004,1000005,1000027);

	IF(@role_id IS NULL) RETURN @PayAmount;


	SET @DaiesInMasooliat=DATEDIFF(DAY,@MasooliatOn,GETDATE());
	IF(@DaiesInMasooliat < 14) RETURN @PayAmount;


	--214987	بلافعاليه
	--214988	قليل الفاعلية
	--214989	متوسط الفاعلية
	--214990	فاعل
	--214991	فاعل جدًا

	IF(@gender_id=10011)
	BEGIN
		IF(@role_id=1000027) --Circle
		BEGIN
			IF (@MasooliatLevelId=214987) SET @PayAmount = 0;
			IF (@MasooliatLevelId=214988) SET @PayAmount = 225000;
			IF (@MasooliatLevelId=214989) SET @PayAmount = 375000;
			IF (@MasooliatLevelId=214990) SET @PayAmount = 525000;
			IF (@MasooliatLevelId=214991) SET @PayAmount = 750000;

			--IF(@AreaProvinceId=10102) -- Baghdad
			--BEGIN
			--	IF (@MasooliatLevelId=214987) SET @PayAmount = 0;
			--	IF (@MasooliatLevelId=214988) SET @PayAmount = 90000;
			--	IF (@MasooliatLevelId=214989) SET @PayAmount = 150000;
			--	IF (@MasooliatLevelId=214990) SET @PayAmount = 210000;
			--	IF (@MasooliatLevelId=214991) SET @PayAmount = 300000;
			--END
			--ELSE
			--BEGIN
			--	IF (@MasooliatLevelId=214987) SET @PayAmount = 0;
			--	IF (@MasooliatLevelId=214988) SET @PayAmount = 225000;
			--	IF (@MasooliatLevelId=214989) SET @PayAmount = 375000;
			--	IF (@MasooliatLevelId=214990) SET @PayAmount = 525000;
			--	IF (@MasooliatLevelId=214991) SET @PayAmount = 750000;
			--END
		END

		IF(@role_id=1000004) --Maktab
		BEGIN
				IF (@MasooliatLevelId=214987) SET @PayAmount = 0;
				IF (@MasooliatLevelId=214988) SET @PayAmount = 45000;
				IF (@MasooliatLevelId=214989) SET @PayAmount = 75000;
				IF (@MasooliatLevelId=214990) SET @PayAmount = 105000;
				IF (@MasooliatLevelId=214991) SET @PayAmount = 150000;
		END

		IF(@role_id=1000005) -- Mantagheh
		BEGIN
				IF (@MasooliatLevelId=214987) SET @PayAmount = 0;
				IF (@MasooliatLevelId=214988) SET @PayAmount = 15000;
				IF (@MasooliatLevelId=214989) SET @PayAmount = 25000;
				IF (@MasooliatLevelId=214990) SET @PayAmount = 35000;
				IF (@MasooliatLevelId=214991) SET @PayAmount = 50000;
		END
	END
	ELSE
	BEGIN
		IF(@role_id=1000027) --Circle
		BEGIN
			IF (@MasooliatLevelId=214987) SET @PayAmount = 0;
			IF (@MasooliatLevelId=214988) SET @PayAmount = 150000;
			IF (@MasooliatLevelId=214989) SET @PayAmount = 250000;
			IF (@MasooliatLevelId=214990) SET @PayAmount = 350000;
			IF (@MasooliatLevelId=214991) SET @PayAmount = 450000;

			--IF(@AreaProvinceId=10102) -- Baghdad
			--BEGIN
			--	IF (@MasooliatLevelId=214987) SET @PayAmount = 0;
			--	IF (@MasooliatLevelId=214988) SET @PayAmount = 75000;
			--	IF (@MasooliatLevelId=214989) SET @PayAmount = 175000;
			--	IF (@MasooliatLevelId=214990) SET @PayAmount = 250000;
			--	IF (@MasooliatLevelId=214991) SET @PayAmount = 350000;
			--END
			--ELSE
			--BEGIN
			--	IF (@MasooliatLevelId=214987) SET @PayAmount = 0;
			--	IF (@MasooliatLevelId=214988) SET @PayAmount = 150000;
			--	IF (@MasooliatLevelId=214989) SET @PayAmount = 250000;
			--	IF (@MasooliatLevelId=214990) SET @PayAmount = 350000;
			--	IF (@MasooliatLevelId=214991) SET @PayAmount = 450000;
			--END
			RETURN @PayAmount;
		END

		IF(@role_id=1000004) --Maktab
		BEGIN
				IF (@MasooliatLevelId=214987) SET @PayAmount = 0;
				IF (@MasooliatLevelId=214988) SET @PayAmount = 50000;
				IF (@MasooliatLevelId=214989) SET @PayAmount = 65000;
				IF (@MasooliatLevelId=214990) SET @PayAmount = 80000;
				IF (@MasooliatLevelId=214991) SET @PayAmount = 100000;
		END

		IF(@role_id=1000005) -- Mantagheh
		BEGIN
				IF (@MasooliatLevelId=214987) SET @PayAmount = 0;
				IF (@MasooliatLevelId=214988) SET @PayAmount = 0;
				IF (@MasooliatLevelId=214989) SET @PayAmount = 0;
				IF (@MasooliatLevelId=214990) SET @PayAmount = 0;
				IF (@MasooliatLevelId=214991) SET @PayAmount = 0;

				SET @PayAmount = 0;
		END
	END




	RETURN @PayAmount;

END
GO

-- HWY_FN_HasDuplicatedCircleMasool → hwy_payment_has_duplicated_circle_masool
CREATE OR ALTER FUNCTION dbo.hwy_payment_has_duplicated_circle_masool (@province_id INT,@JustErrors BIT=0)
RETURNS BIT
AS
BEGIN

DECLARE @MaleDuplicatedCount INT=0;
DECLARE @FemaleDuplicatedCount INT=0;

SET @MaleDuplicatedCount =
	(
		SELECT COUNT(*) FROM 
		(SELECT hwy_state_id,circle_id,
			(SELECT COUNT(*) C 
				FROM hwy_member_area_limits AL 
				LEFT OUTER JOIN hwy_members M ON M.id=AL.member_id
				LEFT OUTER JOIN vw_hwy_platform_user_roles_finance URR ON URR.user_id=M.user_id
				WHERE item_id=circle_id AND URR.approved=1 AND gender_id=10011 AND role_id=1000027 AND (@JustErrors=0 OR (@JustErrors=1 AND ISNULL(M.chief_masool,1)=1))
			) C 
		FROM hwy_ref_h_circles
		) TT
		WHERE TT.C>1 AND TT.hwy_state_id=@province_id
	);

SET @FemaleDuplicatedCount =
	(
		SELECT COUNT(*) FROM 
		(SELECT hwy_state_id,circle_id,
			(SELECT COUNT(*) C 
				FROM hwy_member_area_limits AL 
				LEFT OUTER JOIN hwy_members M ON M.id=AL.member_id
				LEFT OUTER JOIN vw_hwy_platform_user_roles_finance URR ON URR.user_id=M.user_id
				WHERE item_id=circle_id AND URR.approved=1 AND gender_id=10012 AND role_id=1000027 AND (@JustErrors=0 OR (@JustErrors=1 AND ISNULL(M.chief_masool,1)=1))
			) C 
		FROM hwy_ref_h_circles
		) TT
		WHERE TT.C>1 AND TT.hwy_state_id=@province_id
	);

IF (ISNULL(@MaleDuplicatedCount,0)+ISNULL(@FemaleDuplicatedCount,0)>0) RETURN 1;
RETURN 0;

END
GO

-- HWY_FN_HasDuplicatedTamvinMasool → hwy_payment_has_duplicated_tamvin_masool
CREATE OR ALTER FUNCTION dbo.hwy_payment_has_duplicated_tamvin_masool (@province_id INT,@JustErrors BIT=0)
RETURNS BIT
AS
BEGIN

DECLARE @MaleDuplicatedCount INT=0;
DECLARE @FemaleDuplicatedCount INT=0;

SET @MaleDuplicatedCount =
	(
		SELECT COUNT(*) FROM 
		(
			SELECT hwy_state_id,circle_id,tamvin_id,
				(
					SELECT COUNT(*) C 
					FROM hwy_members M  
					LEFT OUTER JOIN hwy_member_area_limits AL ON M.id=AL.member_id AND AL.approved=1
					LEFT OUTER JOIN vw_hwy_platform_user_roles_finance URR ON URR.user_id=M.user_id  AND URR.approved=1
					WHERE M.area_limit_province_id=hwy_ref_h_tamvinat.hwy_state_id AND M.area_limit_circle_id=hwy_ref_h_tamvinat.circle_id AND
						item_id=tamvin_id AND gender_id=10011 AND role_id=1000004 AND (@JustErrors=0 OR (@JustErrors=1 AND M.chief_masool=1))
				) C 
			FROM hwy_ref_h_tamvinat
			GROUP BY hwy_state_id,circle_id,tamvin_id
		) TT
		WHERE TT.C>1 AND TT.hwy_state_id=@province_id
	);

SET @FemaleDuplicatedCount =
	(
		SELECT COUNT(*) FROM 
		(
			SELECT hwy_state_id,circle_id,tamvin_id,
				(
					SELECT COUNT(*) C 
					FROM hwy_members M  
					LEFT OUTER JOIN hwy_member_area_limits AL ON M.id=AL.member_id AND AL.approved=1
					LEFT OUTER JOIN vw_hwy_platform_user_roles_finance URR ON URR.user_id=M.user_id  AND URR.approved=1
					WHERE M.area_limit_province_id=hwy_ref_h_tamvinat.hwy_state_id AND M.area_limit_circle_id=hwy_ref_h_tamvinat.circle_id AND
						item_id=tamvin_id AND URR.approved=1 AND gender_id=10012 AND role_id=1000004 AND (@JustErrors=0 OR (@JustErrors=1 AND M.chief_masool=1))
				) C 
			FROM hwy_ref_h_tamvinat
			GROUP BY hwy_state_id,circle_id,tamvin_id
		) TT
		WHERE TT.C>1 AND TT.hwy_state_id=@province_id
	);

IF (@MaleDuplicatedCount+@FemaleDuplicatedCount>0) RETURN 1;
RETURN 0;

END
GO

-- HWY_FN_HasDuplicatedEghteraMasool → hwy_payment_has_duplicated_eghtera_masool
CREATE OR ALTER FUNCTION dbo.hwy_payment_has_duplicated_eghtera_masool (@province_id INT,@JustErrors BIT=0)
RETURNS BIT
AS
BEGIN

DECLARE @MaleDuplicatedCount INT=0;
DECLARE @FemaleDuplicatedCount INT=0;

SET @MaleDuplicatedCount =
	(
		SELECT COUNT(*) FROM 
		(SELECT hwy_state_id,
			(SELECT COUNT(*) C 
				FROM hwy_member_area_limits AL 
				LEFT OUTER JOIN hwy_members M ON M.id=AL.member_id
				LEFT OUTER JOIN vw_hwy_platform_user_roles_finance URR ON URR.user_id=M.user_id
				WHERE item_id=eghtera_id AND URR.approved=1 AND gender_id=10011 AND role_id=1000005 AND (@JustErrors=0 OR (@JustErrors=1 AND M.chief_masool=1))
			) C 
		FROM hwy_ref_h_eghteraat WHERE deleted=0
		) TT
		WHERE TT.C>1 AND TT.hwy_state_id=@province_id
	);

SET @FemaleDuplicatedCount =
	(
		SELECT COUNT(*) FROM 
		(SELECT hwy_state_id,
			(SELECT COUNT(*) C 
				FROM hwy_member_area_limits AL 
				LEFT OUTER JOIN hwy_members M ON M.id=AL.member_id
				LEFT OUTER JOIN vw_hwy_platform_user_roles_finance URR ON URR.user_id=M.user_id
				WHERE item_id=eghtera_id AND URR.approved=1 AND gender_id=10012 AND role_id=1000005 AND (@JustErrors=0 OR (@JustErrors=1 AND M.chief_masool=1))
			) C 
		FROM hwy_ref_h_eghteraat WHERE deleted=0
		) TT
		WHERE TT.C>1 AND TT.hwy_state_id=@province_id
	);

IF (@MaleDuplicatedCount+@FemaleDuplicatedCount>0) RETURN 1;
RETURN 0;

END
GO

