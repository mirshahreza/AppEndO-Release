SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_picker_search
  @limit INT,
  @like_q NVARCHAR(256),
  @prefix_q NVARCHAR(256),
  @exact_q NVARCHAR(256)
AS
BEGIN
  SET NOCOUNT ON;

  SELECT TOP (@limit)
    CAST(v.id AS VARCHAR(32)) AS id,
    v.username,
    v.display_full_name,
    v.avatar_url,
    v.user_id,
    v.gender_code,
    v.phone1,
    v.has_profile_image
  FROM dbo.vw_hwy_members v
  WHERE (
    v.username LIKE @like_q
    OR v.display_full_name LIKE @like_q
    OR CAST(v.id AS VARCHAR(32)) = @exact_q
  )
  ORDER BY
    CASE
      WHEN CAST(v.id AS VARCHAR(32)) = @exact_q THEN 0
      WHEN v.username LIKE @prefix_q THEN 1
      ELSE 2
    END,
    v.username;
END;
GO
