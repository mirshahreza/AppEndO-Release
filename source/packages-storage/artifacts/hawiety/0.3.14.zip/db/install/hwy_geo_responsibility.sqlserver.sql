-- Geo responsibility (nomination ledger) — idempotent add-on for existing HWY SQL Server DBs.
--   npx tsx scripts/hwy-phase3/install-hwy-geo-responsibility-schema.ts

IF OBJECT_ID(N'dbo.hwy_geo_responsibility_requests', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_geo_responsibility_requests (
    id                 UNIQUEIDENTIFIER NOT NULL CONSTRAINT DF_hwy_geo_resp_req_id DEFAULT NEWID() PRIMARY KEY,
    member_id          BIGINT NOT NULL,
    user_id            BIGINT NULL,
    geo_level          NVARCHAR(16) NOT NULL,
    geo_base_info_id   NVARCHAR(128) NOT NULL,
    legacy_geo_id      INT NULL,
    role_name          NVARCHAR(128) NOT NULL,
    request_kind       NVARCHAR(32) NOT NULL CONSTRAINT DF_hwy_geo_resp_req_kind DEFAULT N'nomination',
    status             NVARCHAR(32) NOT NULL,
    nominated_by       BIGINT NOT NULL,
    nominated_at       DATETIME2 NOT NULL CONSTRAINT DF_hwy_geo_resp_req_nom_at DEFAULT SYSUTCDATETIME(),
    decided_by         BIGINT NULL,
    decided_at         DATETIME2 NULL,
    decision_note      NVARCHAR(512) NULL,
    revoked_at         DATETIME2 NULL,
    revoked_by         BIGINT NULL,
    CONSTRAINT FK_hwy_geo_resp_req_member FOREIGN KEY (member_id) REFERENCES dbo.hwy_members(id),
    CONSTRAINT FK_hwy_geo_resp_req_user FOREIGN KEY (user_id) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_hwy_geo_resp_req_nom_by FOREIGN KEY (nominated_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_hwy_geo_resp_req_dec_by FOREIGN KEY (decided_by) REFERENCES dbo.base_users(id),
    CONSTRAINT CK_hwy_geo_resp_req_kind CHECK (request_kind IN (N'nomination', N'official_removal'))
  );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_hwy_geo_resp_req_status' AND object_id = OBJECT_ID(N'dbo.hwy_geo_responsibility_requests'))
  CREATE INDEX idx_hwy_geo_resp_req_status ON dbo.hwy_geo_responsibility_requests (status, geo_level, nominated_at DESC);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_hwy_geo_resp_req_geo' AND object_id = OBJECT_ID(N'dbo.hwy_geo_responsibility_requests'))
  CREATE INDEX idx_hwy_geo_resp_req_geo ON dbo.hwy_geo_responsibility_requests (geo_base_info_id, status);
GO

-- Upgrade path for DBs created before assignments removal / revoked_at on requests.
IF COL_LENGTH(N'dbo.hwy_geo_responsibility_requests', N'revoked_at') IS NULL
  ALTER TABLE dbo.hwy_geo_responsibility_requests ADD revoked_at DATETIME2 NULL;
GO

IF COL_LENGTH(N'dbo.hwy_geo_responsibility_requests', N'revoked_by') IS NULL
  ALTER TABLE dbo.hwy_geo_responsibility_requests ADD revoked_by BIGINT NULL;
GO

IF OBJECT_ID(N'dbo.hwy_geo_responsibility_assignments', N'U') IS NOT NULL
BEGIN
  INSERT INTO dbo.hwy_geo_responsibility_requests (
    member_id, user_id, geo_level, geo_base_info_id, role_name, status,
    nominated_by, nominated_at, decided_by, decided_at
  )
  SELECT
    a.member_id,
    a.user_id,
    a.geo_level,
    a.geo_base_info_id,
    a.role_name,
    N'approved',
    a.assigned_by,
    a.assigned_at,
    a.assigned_by,
    a.assigned_at
  FROM dbo.hwy_geo_responsibility_assignments a
  WHERE a.revoked_at IS NULL
    AND NOT EXISTS (
      SELECT 1
      FROM dbo.hwy_geo_responsibility_requests r
      WHERE r.member_id = a.member_id
        AND r.geo_base_info_id = a.geo_base_info_id
        AND r.role_name = a.role_name
        AND r.status = N'approved'
        AND r.revoked_at IS NULL
    );
END;
GO

IF OBJECT_ID(N'dbo.hwy_geo_responsibility_assignments', N'U') IS NOT NULL
  DROP TABLE dbo.hwy_geo_responsibility_assignments;
GO

IF COL_LENGTH(N'dbo.hwy_geo_responsibility_requests', N'gender_slot') IS NOT NULL
BEGIN
  DECLARE @genderSlotDf SYSNAME;
  SELECT @genderSlotDf = dc.name
  FROM sys.default_constraints dc
  INNER JOIN sys.columns c
    ON c.object_id = dc.parent_object_id AND c.column_id = dc.parent_column_id
  WHERE dc.parent_object_id = OBJECT_ID(N'dbo.hwy_geo_responsibility_requests')
    AND c.name = N'gender_slot';
  IF @genderSlotDf IS NOT NULL
    EXEC(N'ALTER TABLE dbo.hwy_geo_responsibility_requests DROP CONSTRAINT [' + @genderSlotDf + N']');
  ALTER TABLE dbo.hwy_geo_responsibility_requests DROP COLUMN gender_slot;
END;
GO

IF COL_LENGTH(N'dbo.hwy_geo_responsibility_requests', N'assignment_id') IS NOT NULL
BEGIN
  DECLARE @assignmentFk SYSNAME;
  SELECT @assignmentFk = fk.name
  FROM sys.foreign_keys fk
  INNER JOIN sys.foreign_key_columns fkc ON fkc.constraint_object_id = fk.object_id
  INNER JOIN sys.columns c ON c.object_id = fkc.parent_object_id AND c.column_id = fkc.parent_column_id
  WHERE fk.parent_object_id = OBJECT_ID(N'dbo.hwy_geo_responsibility_requests')
    AND c.name = N'assignment_id';
  IF @assignmentFk IS NOT NULL
    EXEC(N'ALTER TABLE dbo.hwy_geo_responsibility_requests DROP CONSTRAINT [' + @assignmentFk + N']');
  ALTER TABLE dbo.hwy_geo_responsibility_requests DROP COLUMN assignment_id;
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_hwy_geo_resp_req_active_official' AND object_id = OBJECT_ID(N'dbo.hwy_geo_responsibility_requests'))
  CREATE INDEX idx_hwy_geo_resp_req_active_official
    ON dbo.hwy_geo_responsibility_requests (geo_base_info_id, role_name, geo_level, status, revoked_at);
GO

IF COL_LENGTH(N'dbo.hwy_geo_responsibility_requests', N'legacy_area_limits_id') IS NULL
  ALTER TABLE dbo.hwy_geo_responsibility_requests ADD legacy_area_limits_id UNIQUEIDENTIFIER NULL;
GO

IF NOT EXISTS (
  SELECT 1 FROM sys.indexes
  WHERE name = N'idx_hwy_geo_resp_req_legacy_area_limits'
    AND object_id = OBJECT_ID(N'dbo.hwy_geo_responsibility_requests')
)
  CREATE UNIQUE INDEX idx_hwy_geo_resp_req_legacy_area_limits
    ON dbo.hwy_geo_responsibility_requests (legacy_area_limits_id)
    WHERE legacy_area_limits_id IS NOT NULL;
GO

-- request_kind: nomination vs official_removal (replaces runtime inference).
IF COL_LENGTH(N'dbo.hwy_geo_responsibility_requests', N'request_kind') IS NULL
  ALTER TABLE dbo.hwy_geo_responsibility_requests ADD request_kind NVARCHAR(32) NULL;
GO

IF COL_LENGTH(N'dbo.hwy_geo_responsibility_requests', N'request_kind') IS NOT NULL
BEGIN
  UPDATE r
  SET request_kind = N'official_removal'
  FROM dbo.hwy_geo_responsibility_requests r
  WHERE r.request_kind IS NULL
    AND r.status = N'submitted'
    AND (
      EXISTS (
        SELECT 1
        FROM dbo.hwy_geo_responsibility_requests ar
        WHERE ar.member_id = r.member_id
          AND ar.geo_base_info_id = r.geo_base_info_id
          AND ar.role_name = r.role_name
          AND ar.status = N'approved'
          AND ar.revoked_at IS NULL
      )
      OR EXISTS (
        SELECT 1
        FROM dbo.base_scope_memberships sm
        INNER JOIN dbo.base_user_roles ur ON ur.user_id = sm.user_id AND ur.role_name = r.role_name
        INNER JOIN dbo.hwy_members m ON m.user_id = sm.user_id AND m.id = r.member_id
        WHERE sm.dimension_key = N'geo'
          AND sm.node_id = r.geo_base_info_id
          AND NOT EXISTS (
            SELECT 1
            FROM dbo.hwy_geo_responsibility_requests ar2
            INNER JOIN dbo.hwy_members am ON am.id= ar2.member_id
            INNER JOIN dbo.hwy_members rm ON rm.id= r.member_id
            WHERE ar2.geo_base_info_id = r.geo_base_info_id
              AND ar2.role_name = r.role_name
              AND ar2.geo_level = r.geo_level
              AND ar2.status = N'approved'
              AND ar2.revoked_at IS NULL
              AND (
                (
                  (am.gender_code = N'100.1.1' OR am.gender_code LIKE N'%10011%' OR LOWER(COALESCE(am.gender_code, N'')) LIKE N'%male%' OR am.gender_code LIKE N'%ذكر%')
                  AND (rm.gender_code = N'100.1.1' OR rm.gender_code LIKE N'%10011%' OR LOWER(COALESCE(rm.gender_code, N'')) LIKE N'%male%' OR rm.gender_code LIKE N'%ذكر%')
                )
                OR (
                  (am.gender_code = N'100.1.2' OR am.gender_code LIKE N'%10012%' OR LOWER(COALESCE(am.gender_code, N'')) LIKE N'%female%' OR am.gender_code LIKE N'%انث%' OR am.gender_code LIKE N'%أنث%')
                  AND (rm.gender_code = N'100.1.2' OR rm.gender_code LIKE N'%10012%' OR LOWER(COALESCE(rm.gender_code, N'')) LIKE N'%female%' OR rm.gender_code LIKE N'%انث%' OR rm.gender_code LIKE N'%أنث%')
                )
              )
          )
      )
    );

  UPDATE dbo.hwy_geo_responsibility_requests
  SET request_kind = N'nomination'
  WHERE request_kind IS NULL;
END;
GO

IF COL_LENGTH(N'dbo.hwy_geo_responsibility_requests', N'request_kind') IS NOT NULL
   AND NOT EXISTS (
     SELECT 1 FROM sys.default_constraints dc
     INNER JOIN sys.columns c ON c.object_id = dc.parent_object_id AND c.column_id = dc.parent_column_id
     WHERE dc.parent_object_id = OBJECT_ID(N'dbo.hwy_geo_responsibility_requests')
       AND c.name = N'request_kind'
   )
  ALTER TABLE dbo.hwy_geo_responsibility_requests
    ADD CONSTRAINT DF_hwy_geo_resp_req_kind DEFAULT N'nomination' FOR request_kind;
GO

IF COL_LENGTH(N'dbo.hwy_geo_responsibility_requests', N'request_kind') IS NOT NULL
BEGIN
  ALTER TABLE dbo.hwy_geo_responsibility_requests
    ALTER COLUMN request_kind NVARCHAR(32) NOT NULL;
END;
GO

IF NOT EXISTS (
  SELECT 1 FROM sys.check_constraints
  WHERE name = N'CK_hwy_geo_resp_req_kind'
    AND parent_object_id = OBJECT_ID(N'dbo.hwy_geo_responsibility_requests')
)
  ALTER TABLE dbo.hwy_geo_responsibility_requests
    ADD CONSTRAINT CK_hwy_geo_resp_req_kind
    CHECK (request_kind IN (N'nomination', N'official_removal'));
GO

IF NOT EXISTS (
  SELECT 1 FROM sys.indexes
  WHERE name = N'idx_hwy_geo_resp_req_status_kind'
    AND object_id = OBJECT_ID(N'dbo.hwy_geo_responsibility_requests')
)
  CREATE INDEX idx_hwy_geo_resp_req_status_kind
    ON dbo.hwy_geo_responsibility_requests (status, request_kind, geo_level, nominated_at DESC);
GO
