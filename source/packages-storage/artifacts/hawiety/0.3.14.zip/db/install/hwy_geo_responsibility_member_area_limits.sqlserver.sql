-- Keep hwy_member_area_limits aligned with Studio geo nominations (legacy hwy_member_area_limits parity).

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF OBJECT_ID(N'dbo.hwy_member_area_limits', N'U') IS NOT NULL
BEGIN
;WITH nomination_src AS (
  SELECT
    r.member_id,
    r.legacy_geo_id,
    CASE
      WHEN r.status = N'approved' AND r.revoked_at IS NULL THEN CAST(1 AS BIT)
      WHEN r.status = N'submitted' AND r.revoked_at IS NULL THEN CAST(0 AS BIT)
      ELSE NULL
    END AS approved,
    COALESCE(r.decided_at, r.nominated_at, SYSUTCDATETIME()) AS event_at,
    COALESCE(r.decided_by, r.nominated_by) AS actor_user_id
  FROM dbo.hwy_geo_responsibility_requests r WITH (NOLOCK)
  WHERE r.request_kind = N'nomination'
    AND r.legacy_geo_id IS NOT NULL
    AND r.legacy_geo_id > 0
    AND r.status IN (N'submitted', N'approved')
    AND r.revoked_at IS NULL
),
ranked AS (
  SELECT
    s.*,
    ROW_NUMBER() OVER (
      PARTITION BY s.member_id, s.legacy_geo_id
      ORDER BY CASE WHEN s.approved = 1 THEN 1 ELSE 0 END DESC, s.event_at DESC
    ) AS rn
  FROM nomination_src s
  WHERE s.approved IS NOT NULL
)
MERGE dbo.hwy_member_area_limits AS t
USING (
  SELECT member_id, legacy_geo_id, approved, event_at, actor_user_id
  FROM ranked
  WHERE rn = 1
) AS s
  ON t.member_id = s.member_id AND t.item_id = s.legacy_geo_id
WHEN MATCHED AND t.approved = 0 AND s.approved = 1 THEN UPDATE SET
  approved = 1,
  approved_by = COALESCE(
    (SELECT TOP 1 NULLIF(LTRIM(RTRIM(u.username)), N'') FROM dbo.base_users u WHERE u.id = s.actor_user_id),
    CAST(s.actor_user_id AS NVARCHAR(32))
  ),
  approved_on = s.event_at
WHEN NOT MATCHED BY TARGET THEN INSERT (
  id, member_id, item_id, approved, created_by, created_on, approved_by, approved_on
) VALUES (
  NEWID(),
  s.member_id,
  s.legacy_geo_id,
  s.approved,
  COALESCE(
    (SELECT TOP 1 NULLIF(LTRIM(RTRIM(u.username)), N'') FROM dbo.base_users u WHERE u.id = s.actor_user_id),
    CAST(s.actor_user_id AS NVARCHAR(32))
  ),
  s.event_at,
  CASE WHEN s.approved = 1 THEN COALESCE(
    (SELECT TOP 1 NULLIF(LTRIM(RTRIM(u.username)), N'') FROM dbo.base_users u WHERE u.id = s.actor_user_id),
    CAST(s.actor_user_id AS NVARCHAR(32))
  ) ELSE NULL END,
  CASE WHEN s.approved = 1 THEN s.event_at ELSE NULL END
);
END;
GO
