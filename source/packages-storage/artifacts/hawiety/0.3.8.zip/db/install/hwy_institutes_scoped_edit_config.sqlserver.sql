IF COL_LENGTH(N'dbo.hwy_institutes', N'allows_list_scoped_edit') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_institutes
    ADD allows_list_scoped_edit BIT NOT NULL
      CONSTRAINT DF_hwy_institutes_allows_list_scoped_edit DEFAULT 0;
END;
GO

IF COL_LENGTH(N'dbo.hwy_institutes', N'show_institute_character_in_dossier') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_institutes
    ADD show_institute_character_in_dossier BIT NOT NULL
      CONSTRAINT DF_hwy_institutes_show_institute_character_in_dossier DEFAULT 0;
END;
GO

/* Institute flag defaults are operator-configured via hwy-institutes (no re-apply on ensureHwyDbObjects). */
