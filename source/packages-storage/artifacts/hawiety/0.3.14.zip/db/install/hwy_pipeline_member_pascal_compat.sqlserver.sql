-- Retired: PascalCase computed aliases on dbo.hwy_members (snake_case via vw_hwy_members_legacy_row).

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

PRINT 'hwy_pipeline_member_pascal_compat retired — use snake_case columns on dbo.hwy_members';
GO
