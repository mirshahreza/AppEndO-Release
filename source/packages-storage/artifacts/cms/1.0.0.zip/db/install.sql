-- CMS package Phase 1 schema (SQL Server)
-- Opt-in only — never run from app bootstrap / controlPlaneSeed.
-- Idempotent: guarded by OBJECT_ID / sys.indexes checks.

IF OBJECT_ID(N'dbo.cms_contents', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.cms_contents (
    id                        BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    content_type_code         NVARCHAR(1000) NULL,
    language_code             NVARCHAR(1000) NULL,
    slug                      NVARCHAR(1000) NULL,
    status_code               NVARCHAR(1000) NULL,
    status_code_updated_at    DATETIME2 NULL,
    status_code_updated_by    BIGINT NULL,
    title                     NVARCHAR(MAX) NULL,
    summary                   NVARCHAR(MAX) NULL,
    body                      NVARCHAR(MAX) NULL,
    body_format_code          NVARCHAR(1000) NULL,
    seo_title                 NVARCHAR(MAX) NULL,
    seo_note                  NVARCHAR(MAX) NULL,
    published_at              DATETIME2 NULL,
    operator_note             NVARCHAR(MAX) NULL,
    comments_enabled          BIT NULL,
    comments_policy_code      NVARCHAR(1000) NULL,
    comments_body_format_code NVARCHAR(1000) NULL,
    parent_content_id         BIGINT NULL,
    author_display_name       NVARCHAR(MAX) NULL,
    author_email              NVARCHAR(MAX) NULL,
    moderated_by              BIGINT NULL,
    moderated_at              DATETIME2 NULL,
    created_by                BIGINT NULL,
    created_at                DATETIME2 NULL CONSTRAINT DF_cms_contents_created_at DEFAULT SYSUTCDATETIME(),
    updated_by                BIGINT NULL,
    updated_at                DATETIME2 NULL CONSTRAINT DF_cms_contents_updated_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_cms_contents_content_type FOREIGN KEY (content_type_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_cms_contents_language FOREIGN KEY (language_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_cms_contents_status FOREIGN KEY (status_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_cms_contents_body_format FOREIGN KEY (body_format_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_cms_contents_comments_policy FOREIGN KEY (comments_policy_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_cms_contents_comments_body_format FOREIGN KEY (comments_body_format_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_cms_contents_parent FOREIGN KEY (parent_content_id) REFERENCES dbo.cms_contents(id),
    CONSTRAINT FK_cms_contents_status_updated_by FOREIGN KEY (status_code_updated_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_cms_contents_created_by FOREIGN KEY (created_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_cms_contents_updated_by FOREIGN KEY (updated_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_cms_contents_moderated_by FOREIGN KEY (moderated_by) REFERENCES dbo.base_users(id)
  );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'uq_cms_contents_language_slug' AND object_id = OBJECT_ID(N'dbo.cms_contents'))
  CREATE UNIQUE INDEX uq_cms_contents_language_slug ON dbo.cms_contents (language_code, slug);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_contents_status_code' AND object_id = OBJECT_ID(N'dbo.cms_contents'))
  CREATE INDEX idx_cms_contents_status_code ON dbo.cms_contents (status_code);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_contents_content_type_code' AND object_id = OBJECT_ID(N'dbo.cms_contents'))
  CREATE INDEX idx_cms_contents_content_type_code ON dbo.cms_contents (content_type_code);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_contents_published_at' AND object_id = OBJECT_ID(N'dbo.cms_contents'))
  CREATE INDEX idx_cms_contents_published_at ON dbo.cms_contents (published_at);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_contents_parent_content_id' AND object_id = OBJECT_ID(N'dbo.cms_contents'))
  CREATE INDEX idx_cms_contents_parent_content_id ON dbo.cms_contents (parent_content_id);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_contents_parent_content_type' AND object_id = OBJECT_ID(N'dbo.cms_contents'))
  CREATE INDEX idx_cms_contents_parent_content_type ON dbo.cms_contents (parent_content_id, content_type_code);
GO

IF OBJECT_ID(N'dbo.cms_content_revisions', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.cms_content_revisions (
    id            BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    content_id    BIGINT NOT NULL,
    revision_no   INT NOT NULL,
    title         NVARCHAR(MAX) NULL,
    summary       NVARCHAR(MAX) NULL,
    body          NVARCHAR(MAX) NULL,
    created_by    BIGINT NULL,
    created_at    DATETIME2 NULL CONSTRAINT DF_cms_content_revisions_created_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_cms_content_revisions_content FOREIGN KEY (content_id) REFERENCES dbo.cms_contents(id) ON DELETE CASCADE,
    CONSTRAINT FK_cms_content_revisions_created_by FOREIGN KEY (created_by) REFERENCES dbo.base_users(id),
    CONSTRAINT uq_cms_content_revisions_content_rev UNIQUE (content_id, revision_no)
  );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_content_revisions_content_id' AND object_id = OBJECT_ID(N'dbo.cms_content_revisions'))
  CREATE INDEX idx_cms_content_revisions_content_id ON dbo.cms_content_revisions (content_id);
GO

IF OBJECT_ID(N'dbo.cms_content_assets', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.cms_content_assets (
    id            BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    content_id    BIGINT NOT NULL,
    [file]        VARBINARY(MAX) NOT NULL,
    file_xs       VARBINARY(MAX) NULL,
    file_size     INT NOT NULL,
    file_name     NVARCHAR(1000) NOT NULL,
    file_mime     NVARCHAR(1000) NOT NULL,
    sort_order    INT NOT NULL CONSTRAINT DF_cms_content_assets_sort_order DEFAULT 0,
    sha256        NVARCHAR(1000) NOT NULL,
    created_by    BIGINT NULL,
    created_at    DATETIME2 NOT NULL CONSTRAINT DF_cms_content_assets_created_at DEFAULT SYSUTCDATETIME(),
    updated_by    BIGINT NULL,
    updated_at    DATETIME2 NOT NULL CONSTRAINT DF_cms_content_assets_updated_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_cms_content_assets_content FOREIGN KEY (content_id) REFERENCES dbo.cms_contents(id) ON DELETE CASCADE,
    CONSTRAINT FK_cms_content_assets_created_by FOREIGN KEY (created_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_cms_content_assets_updated_by FOREIGN KEY (updated_by) REFERENCES dbo.base_users(id)
  );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_content_assets_content_id' AND object_id = OBJECT_ID(N'dbo.cms_content_assets'))
  CREATE INDEX idx_cms_content_assets_content_id ON dbo.cms_content_assets (content_id, sort_order);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_content_assets_sha256' AND object_id = OBJECT_ID(N'dbo.cms_content_assets'))
  CREATE INDEX idx_cms_content_assets_sha256 ON dbo.cms_content_assets (sha256);
GO

IF OBJECT_ID(N'dbo.cms_content_tags', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.cms_content_tags (
    content_id    BIGINT NOT NULL,
    tag_code      NVARCHAR(1000) NOT NULL,
    CONSTRAINT PK_cms_content_tags PRIMARY KEY (content_id, tag_code),
    CONSTRAINT FK_cms_content_tags_content FOREIGN KEY (content_id) REFERENCES dbo.cms_contents(id) ON DELETE CASCADE,
    CONSTRAINT FK_cms_content_tags_tag FOREIGN KEY (tag_code) REFERENCES dbo.base_info(id)
  );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_content_tags_tag_code' AND object_id = OBJECT_ID(N'dbo.cms_content_tags'))
  CREATE INDEX idx_cms_content_tags_tag_code ON dbo.cms_content_tags (tag_code);
GO

IF OBJECT_ID(N'dbo.cms_content_relations', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.cms_content_relations (
    id              BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    content_id_a    BIGINT NOT NULL,
    content_id_b    BIGINT NOT NULL,
    note            NVARCHAR(MAX) NULL,
    CONSTRAINT FK_cms_content_relations_a FOREIGN KEY (content_id_a) REFERENCES dbo.cms_contents(id) ON DELETE CASCADE,
    CONSTRAINT FK_cms_content_relations_b FOREIGN KEY (content_id_b) REFERENCES dbo.cms_contents(id),
    CONSTRAINT ck_cms_content_relations_ordered CHECK (content_id_a < content_id_b),
    CONSTRAINT uq_cms_content_relations_pair UNIQUE (content_id_a, content_id_b)
  );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_content_relations_a' AND object_id = OBJECT_ID(N'dbo.cms_content_relations'))
  CREATE INDEX idx_cms_content_relations_a ON dbo.cms_content_relations (content_id_a);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'idx_cms_content_relations_b' AND object_id = OBJECT_ID(N'dbo.cms_content_relations'))
  CREATE INDEX idx_cms_content_relations_b ON dbo.cms_content_relations (content_id_b);
GO

IF OBJECT_ID(N'dbo.cms_settings', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.cms_settings (
    id                          BIGINT NOT NULL CONSTRAINT PK_cms_settings PRIMARY KEY,
    comments_enabled            BIT NOT NULL,
    comments_policy_code        NVARCHAR(1000) NOT NULL,
    comments_body_format_code   NVARCHAR(1000) NOT NULL,
    public_cache_ttl_seconds    INT NOT NULL CONSTRAINT DF_cms_settings_public_cache_ttl_seconds DEFAULT 300,
    updated_by                  BIGINT NULL,
    updated_at                  DATETIME2 NULL CONSTRAINT DF_cms_settings_updated_at DEFAULT SYSUTCDATETIME(),
    CONSTRAINT ck_cms_settings_singleton CHECK (id = 1),
    CONSTRAINT FK_cms_settings_comments_policy FOREIGN KEY (comments_policy_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_cms_settings_comments_body_format FOREIGN KEY (comments_body_format_code) REFERENCES dbo.base_info(id),
    CONSTRAINT FK_cms_settings_updated_by FOREIGN KEY (updated_by) REFERENCES dbo.base_users(id)
  );
END;
GO

-- Captured 43 row(s) from base_info on 2026-08-24T12:52:58.981Z
-- WHERE title = 'CMS'
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101', NULL, 'CMS', 'CMS', 'CMS', 'CMS', NULL, 200, NULL, NULL, NULL, NULL, NULL, 1, TRUE, NULL, NULL, '2026-08-24T03:06:15.196Z', '1000000', '2026-08-24T03:08:32.616Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.001', '101', 'Content Types', 'Content Types', 'Content Types', 'Content Types', NULL, 1, NULL, NULL, NULL, NULL, NULL, 1, TRUE, NULL, NULL, '2026-08-24T03:06:15.224Z', '1000000', '2026-08-24T03:08:32.641Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.002', '101', 'Statuses', 'Statuses', 'Statuses', 'Statuses', NULL, 2, NULL, NULL, NULL, NULL, NULL, 2, TRUE, NULL, NULL, '2026-08-24T03:06:15.461Z', '1000000', '2026-08-24T03:08:32.833Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.003', '101', 'Body Formats', 'Body Formats', 'Body Formats', 'Body Formats', NULL, 3, NULL, NULL, NULL, NULL, NULL, 3, TRUE, NULL, NULL, '2026-08-24T03:06:15.592Z', '1000000', '2026-08-24T03:08:32.962Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.004', '101', 'Languages', 'Languages', 'Languages', 'Languages', NULL, 4, NULL, NULL, NULL, NULL, NULL, 4, TRUE, NULL, NULL, '2026-08-24T03:06:15.673Z', '1000000', '2026-08-24T03:08:33.042Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.005', '101', 'Content Tags', 'Content Tags', 'Content Tags', 'Content Tags', NULL, 5, NULL, NULL, NULL, NULL, NULL, 5, TRUE, NULL, NULL, '2026-08-24T03:06:15.745Z', '1000000', '2026-08-24T03:08:33.106Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.006', '101', 'Comment Policies', 'Comment Policies', 'Comment Policies', 'Comment Policies', NULL, 6, NULL, NULL, NULL, NULL, NULL, 6, TRUE, NULL, NULL, '2026-08-24T03:06:16.116Z', '1000000', '2026-08-24T03:08:33.381Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.001.001', '101.001', 'Article', 'Article', 'Article', 'Article', 'article', 1, NULL, NULL, NULL, NULL, NULL, 1, TRUE, '#0ea5e9', '<i data-lucide="Newspaper"></i>', '2026-08-24T03:06:15.250Z', '1000000', '2026-08-24T03:08:32.666Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.001.002', '101.001', 'News', 'News', 'News', 'News', 'news', 2, NULL, NULL, NULL, NULL, NULL, 2, TRUE, '#6366f1', '<i data-lucide="Rss"></i>', '2026-08-24T03:06:15.272Z', '1000000', '2026-08-24T03:08:32.689Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.001.003', '101.001', 'Announcement', 'Announcement', 'Announcement', 'Announcement', 'announcement', 3, NULL, NULL, NULL, NULL, NULL, 3, TRUE, '#f59e0b', '<i data-lucide="Megaphone"></i>', '2026-08-24T03:06:15.300Z', '1000000', '2026-08-24T03:08:32.712Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.001.004', '101.001', 'Gallery', 'Gallery', 'Gallery', 'Gallery', 'gallery', 4, NULL, NULL, NULL, NULL, NULL, 4, TRUE, '#8b5cf6', '<i data-lucide="Images"></i>', '2026-08-24T03:06:15.323Z', '1000000', '2026-08-24T03:08:32.729Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.001.005', '101.001', 'Comment', 'Comment', 'Comment', 'Comment', 'comment', 5, NULL, NULL, NULL, NULL, NULL, 5, TRUE, '#14b8a6', '<i data-lucide="MessageSquare"></i>', '2026-08-24T03:06:15.344Z', '1000000', '2026-08-24T03:08:32.746Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.001.006', '101.001', 'Page', 'Page', 'Page', 'Page', 'page', 6, NULL, NULL, NULL, NULL, NULL, 6, TRUE, '#0f766e', '<i data-lucide="FileText"></i>', '2026-08-24T03:06:15.372Z', '1000000', '2026-08-24T03:08:32.764Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.001.007', '101.001', 'Fragment', 'Fragment', 'Fragment', 'Fragment', 'fragment', 7, NULL, NULL, NULL, NULL, NULL, 7, TRUE, '#64748b', '<i data-lucide="Puzzle"></i>', '2026-08-24T03:06:15.404Z', '1000000', '2026-08-24T03:08:32.784Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.001.008', '101.001', 'How to', 'How to', 'How to', 'How to', 'howto', 8, NULL, NULL, NULL, NULL, NULL, 8, TRUE, '#0369a1', '<i data-lucide="ListChecks"></i>', '2026-08-24T03:06:15.439Z', '1000000', '2026-08-24T03:08:32.808Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.002.001', '101.002', 'Draft', 'Draft', 'Draft', 'Draft', 'draft', 1, 'Work in progress. Not visible on the public site.', 'Work in progress. Not visible on the public site.', NULL, NULL, NULL, 1, TRUE, '#94a3b8', '<i data-lucide="FilePenLine"></i>', '2026-08-24T03:06:15.483Z', '1000000', '2026-08-24T03:08:32.850Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.002.002', '101.002', 'In Review', 'In Review', 'In Review', 'In Review', 'in_review', 2, 'Awaiting editorial review before it can be published.', 'Awaiting editorial review before it can be published.', NULL, NULL, NULL, 2, TRUE, '#6366f1', '<i data-lucide="Eye"></i>', '2026-08-24T03:06:15.508Z', '1000000', '2026-08-24T03:08:32.872Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.002.003', '101.002', 'Published', 'Published', 'Published', 'Published', 'published', 3, 'Live and visible to public readers.', 'Live and visible to public readers.', NULL, NULL, NULL, 3, TRUE, '#10b981', '<i data-lucide="CheckCircle2"></i>', '2026-08-24T03:06:15.526Z', '1000000', '2026-08-24T03:08:32.891Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.002.004', '101.002', 'Archived', 'Archived', 'Archived', 'Archived', 'archived', 4, 'Retired from the public site; kept for history.', 'Retired from the public site; kept for history.', NULL, NULL, NULL, 4, TRUE, '#64748b', '<i data-lucide="Archive"></i>', '2026-08-24T03:06:15.549Z', '1000000', '2026-08-24T03:08:32.914Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.002.005', '101.002', 'Rejected', 'Rejected', 'Rejected', 'Rejected', 'rejected', 5, 'Declined in review; not for publication.', 'Declined in review; not for publication.', NULL, NULL, NULL, 5, TRUE, '#f43f5e', '<i data-lucide="XCircle"></i>', '2026-08-24T03:06:15.569Z', '1000000', '2026-08-24T03:08:32.936Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.003.001', '101.003', 'HTML', 'HTML', 'HTML', 'HTML', 'html', 1, NULL, NULL, NULL, NULL, NULL, 1, TRUE, '#f97316', NULL, '2026-08-24T03:06:15.609Z', '1000000', '2026-08-24T03:08:32.982Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.003.002', '101.003', 'Markdown', 'Markdown', 'Markdown', 'Markdown', 'markdown', 2, NULL, NULL, NULL, NULL, NULL, 2, TRUE, '#6366f1', NULL, '2026-08-24T03:06:15.628Z', '1000000', '2026-08-24T03:08:33.000Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.003.003', '101.003', 'Plain', 'Plain', 'Plain', 'Plain', 'plain', 3, NULL, NULL, NULL, NULL, NULL, 3, TRUE, '#64748b', NULL, '2026-08-24T03:06:15.650Z', '1000000', '2026-08-24T03:08:33.020Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.004.001', '101.004', 'English', 'English', 'English', 'English', 'en', 1, NULL, NULL, NULL, NULL, NULL, 1, TRUE, '#3b82f6', '<i data-lucide="Languages"></i>', '2026-08-24T03:06:15.692Z', '1000000', '2026-08-24T03:08:33.064Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.004.002', '101.004', 'Persian', 'Persian', 'Persian', 'Persian', 'fa', 2, NULL, NULL, NULL, NULL, NULL, 2, TRUE, '#0d9488', '<i data-lucide="Languages"></i>', '2026-08-24T03:06:15.712Z', '1000000', '2026-08-24T03:08:33.081Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.004.003', '101.004', 'Arabic', 'Arabic', 'Arabic', 'Arabic', 'ar', 3, NULL, NULL, NULL, NULL, NULL, 3, TRUE, '#d97706', '<i data-lucide="Languages"></i>', '2026-08-24T03:06:15.723Z', '1000000', '2026-08-24T03:08:33.090Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.005.001', '101.005', 'Featured', 'Featured', 'Featured', 'Featured', 'featured', 1, NULL, NULL, NULL, NULL, NULL, 1, TRUE, '#10b981', '<i data-lucide="BadgeCheck"></i>', '2026-08-24T03:06:15.753Z', '1000000', '2026-08-24T03:08:33.120Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.005.002', '101.005', 'Platform', 'Platform', 'Platform', 'Platform', 'platform', 2, NULL, NULL, NULL, NULL, NULL, 2, TRUE, '#0f766e', '<i data-lucide="AppWindow"></i>', '2026-08-24T03:06:15.769Z', '1000000', '2026-08-24T03:08:33.135Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.005.003', '101.005', 'Studio', 'Studio', 'Studio', 'Studio', 'studio', 3, NULL, NULL, NULL, NULL, NULL, 3, TRUE, '#0ea5e9', '<i data-lucide="Building2"></i>', '2026-08-24T03:06:15.790Z', '1000000', '2026-08-24T03:08:33.156Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.005.004', '101.005', 'Identity', 'Identity', 'Identity', 'Identity', 'identity', 4, NULL, NULL, NULL, NULL, NULL, 4, TRUE, '#6366f1', '<i data-lucide="Shield"></i>', '2026-08-24T03:06:15.809Z', '1000000', '2026-08-24T03:08:33.171Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.005.005', '101.005', 'Data', 'Data', 'Data', 'Data', 'data', 5, NULL, NULL, NULL, NULL, NULL, 5, TRUE, '#0284c7', '<i data-lucide="Database"></i>', '2026-08-24T03:06:15.821Z', '1000000', '2026-08-24T03:08:33.183Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.005.006', '101.005', 'Workflows', 'Workflows', 'Workflows', 'Workflows', 'workflows', 6, NULL, NULL, NULL, NULL, NULL, 6, TRUE, '#059669', '<i data-lucide="Workflow"></i>', '2026-08-24T03:06:15.839Z', '1000000', '2026-08-24T03:08:33.191Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.005.007', '101.005', 'Functions', 'Functions', 'Functions', 'Functions', 'functions', 7, NULL, NULL, NULL, NULL, NULL, 7, TRUE, '#0d9488', '<i data-lucide="FunctionSquare"></i>', '2026-08-24T03:06:15.859Z', '1000000', '2026-08-24T03:08:33.208Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.005.008', '101.005', 'Design', 'Design', 'Design', 'Design', 'design', 8, NULL, NULL, NULL, NULL, NULL, 8, TRUE, '#8b5cf6', '<i data-lucide="PenTool"></i>', '2026-08-24T03:06:15.884Z', '1000000', '2026-08-24T03:08:33.225Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.005.009', '101.005', 'Packages', 'Packages', 'Packages', 'Packages', 'packages', 9, NULL, NULL, NULL, NULL, NULL, 9, TRUE, '#7c3aed', '<i data-lucide="Package"></i>', '2026-08-24T03:06:15.911Z', '1000000', '2026-08-24T03:08:33.244Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.005.010', '101.005', 'Operations', 'Operations', 'Operations', 'Operations', 'operations', 10, NULL, NULL, NULL, NULL, NULL, 10, TRUE, '#f59e0b', '<i data-lucide="Settings"></i>', '2026-08-24T03:06:15.949Z', '1000000', '2026-08-24T03:08:33.267Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.005.011', '101.005', 'AI', 'AI', 'AI', 'AI', 'ai', 11, NULL, NULL, NULL, NULL, NULL, 11, TRUE, '#a855f7', '<i data-lucide="Sparkles"></i>', '2026-08-24T03:06:15.980Z', '1000000', '2026-08-24T03:08:33.284Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.005.012', '101.005', 'Security', 'Security', 'Security', 'Security', 'security', 12, NULL, NULL, NULL, NULL, NULL, 12, TRUE, '#f43f5e', '<i data-lucide="Lock"></i>', '2026-08-24T03:06:16.006Z', '1000000', '2026-08-24T03:08:33.304Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.005.013', '101.005', 'Install', 'Install', 'Install', 'Install', 'install', 13, NULL, NULL, NULL, NULL, NULL, 13, TRUE, '#ea580c', '<i data-lucide="Rocket"></i>', '2026-08-24T03:06:16.035Z', '1000000', '2026-08-24T03:08:33.324Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.005.014', '101.005', 'Front office', 'Front office', 'Front office', 'Front office', 'front_office', 14, NULL, NULL, NULL, NULL, NULL, 14, TRUE, '#2563eb', '<i data-lucide="Globe"></i>', '2026-08-24T03:06:16.065Z', '1000000', '2026-08-24T03:08:33.341Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.005.015', '101.005', 'How to', 'How to', 'How to', 'How to', 'howto', 15, NULL, NULL, NULL, NULL, NULL, 15, TRUE, '#0369a1', '<i data-lucide="ListChecks"></i>', '2026-08-24T03:06:16.092Z', '1000000', '2026-08-24T03:08:33.359Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.006.001', '101.006', 'Automatic', 'Automatic', 'Automatic', 'Automatic', 'auto', 1, NULL, NULL, NULL, NULL, NULL, 1, TRUE, '#f59e0b', '<i data-lucide="Zap"></i>', '2026-08-24T03:06:16.134Z', '1000000', '2026-08-24T03:08:33.398Z', NULL);
INSERT INTO [base_info] ([id], [parent_id], [title], [title_en], [title_fa], [title_ar], [short_name], [view_order], [note], [note_en], [note_fa], [note_ar], [metadata], [value], [is_active], [ui_color], [ui_html], [created_at], [created_by], [updated_at], [updated_by]) VALUES ('101.006.002', '101.006', 'Approve', 'Approve', 'Approve', 'Approve', 'approve', 2, NULL, NULL, NULL, NULL, NULL, 2, TRUE, '#10b981', '<i data-lucide="ShieldCheck"></i>', '2026-08-24T03:06:16.149Z', '1000000', '2026-08-24T03:08:33.415Z', NULL);
