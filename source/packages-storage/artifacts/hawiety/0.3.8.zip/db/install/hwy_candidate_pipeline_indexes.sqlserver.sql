-- Covering indexes for candidate pipeline interview stage (latest security + interview lookups).

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF OBJECT_ID(N'dbo.hwy_member_security_profile_history', N'U') IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.hwy_member_security_profile_history')
      AND name = N'IX_hwy_member_security_profile_history_member_created'
  )
BEGIN
  CREATE NONCLUSTERED INDEX IX_hwy_member_security_profile_history_member_created
    ON dbo.hwy_member_security_profile_history (member_id, created_on DESC)
    INCLUDE (can_get_masooliat);
END;
GO

IF OBJECT_ID(N'dbo.hwy_member_interviews_2022', N'U') IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.hwy_member_interviews_2022')
      AND name = N'IX_hwy_member_interviews_2022_member_created'
  )
BEGIN
  CREATE NONCLUSTERED INDEX IX_hwy_member_interviews_2022_member_created
    ON dbo.hwy_member_interviews_2022 (member_id, created_on DESC)
    INCLUDE (interview_on, final_result);
END;
GO

IF OBJECT_ID(N'dbo.AppEnd_Users_R_Roles', N'U') IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.AppEnd_Users_R_Roles')
      AND name = N'IX_AppEnd_Users_R_Roles_UserId_RoleId_pipeline'
  )
BEGIN
  CREATE NONCLUSTERED INDEX IX_AppEnd_Users_R_Roles_UserId_RoleId_pipeline
    ON dbo.AppEnd_Users_R_Roles (UserId, RoleId)
    INCLUDE (Approved, CreatedOn, CreatedBy);
END;
GO

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NOT NULL
  AND EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.hwy_members')
      AND name = N'IX_HWY_Members_MembershipStatus_UserId'
  )
BEGIN
  DROP INDEX IX_HWY_Members_MembershipStatus_UserId ON dbo.hwy_members;
END;
GO

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NOT NULL
  AND COL_LENGTH(N'dbo.hwy_members', N'membership_status_legacy') IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.hwy_members')
      AND name = N'IX_hwy_members_membership_status_legacy_user_id_pipeline'
  )
BEGIN
  CREATE NONCLUSTERED INDEX IX_hwy_members_membership_status_legacy_user_id_pipeline
    ON dbo.hwy_members (membership_status_legacy, user_id)
    INCLUDE (
      id, username, first_name, father_name, grandfather_name, family_name, phone1, gender_legacy_id,
      nakheb_join_province_id, nakheb_join_circle_id, nakheb_join_tamvin_id, nakheb_join_eghtera_id
    );
END;
GO
