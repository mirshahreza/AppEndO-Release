-- Masoolin star / chief masool fields on dbo.hwy_members (snake_case physical only).

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NOT NULL
BEGIN
  IF COL_LENGTH(N'dbo.hwy_members', N'MasooliatSumStars') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'masooliat_sum_stars') IS NULL
    EXEC sys.sp_rename N'dbo.hwy_members.masooliat_sum_stars', N'masooliat_sum_stars', N'COLUMN';
  IF COL_LENGTH(N'dbo.hwy_members', N'masooliat_sum_stars') IS NULL
    ALTER TABLE dbo.hwy_members ADD masooliat_sum_stars INT NULL;

  IF COL_LENGTH(N'dbo.hwy_members', N'MasooliatLevelId') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'masooliat_level_id') IS NULL
    EXEC sys.sp_rename N'dbo.hwy_members.masooliat_level_id', N'masooliat_level_id', N'COLUMN';
  IF COL_LENGTH(N'dbo.hwy_members', N'masooliat_level_id') IS NULL
    ALTER TABLE dbo.hwy_members ADD masooliat_level_id INT NULL;

  IF COL_LENGTH(N'dbo.hwy_members', N'MasooliatStarsCalculatedOn') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'masooliat_stars_calculated_on') IS NULL
    EXEC sys.sp_rename N'dbo.hwy_members.masooliat_stars_calculated_on', N'masooliat_stars_calculated_on', N'COLUMN';
  IF COL_LENGTH(N'dbo.hwy_members', N'masooliat_stars_calculated_on') IS NULL
    ALTER TABLE dbo.hwy_members ADD masooliat_stars_calculated_on DATETIME NULL;

  IF COL_LENGTH(N'dbo.hwy_members', N'MasooliatSumStarsCurrent') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'masooliat_sum_stars_current') IS NULL
    EXEC sys.sp_rename N'dbo.hwy_members.masooliat_sum_stars_current', N'masooliat_sum_stars_current', N'COLUMN';
  IF COL_LENGTH(N'dbo.hwy_members', N'masooliat_sum_stars_current') IS NULL
    ALTER TABLE dbo.hwy_members ADD masooliat_sum_stars_current INT NULL;

  IF COL_LENGTH(N'dbo.hwy_members', N'MasooliatLevelIdCurrent') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'masooliat_level_id_current') IS NULL
    EXEC sys.sp_rename N'dbo.hwy_members.masooliat_level_id_current', N'masooliat_level_id_current', N'COLUMN';
  IF COL_LENGTH(N'dbo.hwy_members', N'masooliat_level_id_current') IS NULL
    ALTER TABLE dbo.hwy_members ADD masooliat_level_id_current INT NULL;

  IF COL_LENGTH(N'dbo.hwy_members', N'Payable') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'chief_masool') IS NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'payable') IS NULL
    EXEC sys.sp_rename N'dbo.hwy_members.Payable', N'chief_masool', N'COLUMN';
  IF COL_LENGTH(N'dbo.hwy_members', N'payable') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'chief_masool') IS NULL
    EXEC sys.sp_rename N'dbo.hwy_members.payable', N'chief_masool', N'COLUMN';
  IF COL_LENGTH(N'dbo.hwy_members', N'chief_masool') IS NULL
    ALTER TABLE dbo.hwy_members ADD chief_masool BIT NULL;
END
GO

IF OBJECT_ID(N'dbo.hwy_legacy_app_end_roles', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_legacy_app_end_roles (
    id INT NOT NULL CONSTRAINT PK_hwy_legacy_app_end_roles PRIMARY KEY,
    role_name NVARCHAR(500) NULL,
    is_executive BIT NOT NULL CONSTRAINT DF_hwy_legacy_app_end_roles_exec DEFAULT (0)
  );
END
GO

IF OBJECT_ID(N'dbo.base_roles', N'U') IS NOT NULL
BEGIN
  EXEC(N'
    CREATE OR ALTER VIEW dbo.vw_hwy_platform_roles AS
    SELECT
      COALESCE(TRY_CAST(REPLACE(r.name, N''HWY_R_'', N'''') AS INT), CAST(r.id AS INT)) AS id,
      r.name AS role_name,
      CAST(COALESCE(ar.is_executive, 0) AS BIT) AS is_executive
    FROM dbo.base_roles r
    LEFT JOIN dbo.hwy_legacy_app_end_roles ar ON ar.id= COALESCE(
      TRY_CAST(REPLACE(r.name, N''HWY_R_'', N'''') AS INT),
      CAST(r.id AS INT)
    );
  ');
END
GO
