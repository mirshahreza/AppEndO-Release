-- Legacy meetings management (HWY_Meetings_Instances + BaseInformation meetings).

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_list_definitions
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.hwy_ref_base_information', N'U') IS NULL
    THROW 50400, N'hwy_ref_base_information is not available.', 1;

  SELECT
    CAST(bi.id AS VARCHAR(32)) AS id,
    bi.title AS title,
    CAST(bi.view_order AS INT) AS viewOrder
  FROM dbo.hwy_ref_base_information bi WITH (NOLOCK)
  WHERE bi.parent_id = 214040
  ORDER BY bi.view_order ASC, bi.id ASC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_instances_count
  @meeting_id BIGINT = NULL,
  @username NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_Meetings_Instances', N'U') IS NULL
    THROW 50400, N'Legacy HWY_Meetings_Instances is not available.', 1;

  SELECT COUNT(*) AS total
  FROM dbo.HWY_Meetings_Instances mi WITH (NOLOCK)
  WHERE (@meeting_id IS NULL OR mi.MeetingId = @meeting_id)
    AND (
      @username IS NULL
      OR mi.Id IN (
        SELECT H.InstanceId
        FROM dbo.HWY_Meetings_Hazerin H WITH (NOLOCK)
        INNER JOIN dbo.HWY_Members M WITH (NOLOCK) ON M.Id = H.MemberId
        WHERE M.UserName LIKE N'%' + @username + N'%'
      )
    );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_instances_list
  @meeting_id BIGINT = NULL,
  @username NVARCHAR(128) = NULL,
  @offset INT = 0,
  @page_size INT = 25
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_Meetings_Instances', N'U') IS NULL
    THROW 50400, N'Legacy HWY_Meetings_Instances is not available.', 1;

  SELECT
    CAST(mi.Id AS VARCHAR(32)) AS id,
    CAST(mi.MeetingId AS VARCHAR(32)) AS meetingId,
    CAST(creator.Id AS VARCHAR(32)) AS memberId,
    CONVERT(VARCHAR(32), mi.CreatedOn, 126) AS createdOn,
    CONVERT(VARCHAR(32), mi.EventDate, 126) AS eventDate,
    NULL AS title,
    bi.title AS meetingTitle,
    creator.UserName AS username,
    creator.FirstName AS firstName,
    creator.FatherName AS fatherName,
    creator.LastName AS lastName,
    (SELECT COUNT(*) FROM dbo.HWY_Meetings_Hazerin H WITH (NOLOCK) WHERE H.InstanceId = mi.Id) AS hazerinCount,
    (SELECT COUNT(*) FROM dbo.HWY_Meetings_Members MM WITH (NOLOCK) WHERE MM.MeetingId = mi.MeetingId AND MM.IsMemberYet = 1) AS membersYetCount,
    (SELECT COUNT(*) FROM dbo.HWY_Meetings_Members MM WITH (NOLOCK) WHERE MM.MeetingId = mi.MeetingId AND MM.IsMemberYet = 0) AS membersNotCount
  FROM dbo.HWY_Meetings_Instances mi WITH (NOLOCK)
  LEFT JOIN dbo.hwy_ref_base_information bi WITH (NOLOCK) ON bi.id = mi.MeetingId
  LEFT JOIN dbo.HWY_Members creator WITH (NOLOCK) ON creator.UserName = mi.CreatedBy
  WHERE (@meeting_id IS NULL OR mi.MeetingId = @meeting_id)
    AND (
      @username IS NULL
      OR mi.Id IN (
        SELECT H.InstanceId
        FROM dbo.HWY_Meetings_Hazerin H WITH (NOLOCK)
        INNER JOIN dbo.HWY_Members M WITH (NOLOCK) ON M.Id = H.MemberId
        WHERE M.UserName LIKE N'%' + @username + N'%'
      )
    )
  ORDER BY mi.CreatedOn DESC
  OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_remove_instance
  @instance_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_Meetings_Instances', N'U') IS NULL
    THROW 50400, N'Legacy HWY_Meetings_Instances is not available.', 1;
  DELETE FROM dbo.HWY_Meetings_Instances WHERE Id = @instance_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_add_instance
  @meeting_id BIGINT,
  @instance_date NVARCHAR(32),
  @actor NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_SP_Meetings_Instances_Add', N'P') IS NULL
    THROW 50400, N'Legacy HWY_SP_Meetings_Instances_Add is not available.', 1;
  EXEC dbo.HWY_SP_Meetings_Instances_Add @MeetingId = @meeting_id, @InstanceDate = @instance_date, @UserName = @actor;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_attendance_pivot
  @meeting_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_SP_Meetings_AttendancePivot', N'P') IS NULL
    THROW 50400, N'Legacy HWY_SP_Meetings_AttendancePivot is not available.', 1;
  EXEC dbo.HWY_SP_Meetings_AttendancePivot @MeetingId = @meeting_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_instance_hazerin_list
  @instance_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_Meetings_Hazerin', N'U') IS NULL
    THROW 50400, N'Legacy HWY_Meetings_Hazerin is not available.', 1;

  SELECT
    CAST(M.Id AS VARCHAR(32)) AS memberId,
    M.UserName AS username,
    M.FirstName AS firstName,
    M.FatherName AS fatherName,
    M.LastName AS lastName
  FROM dbo.HWY_Meetings_Hazerin H WITH (NOLOCK)
  INNER JOIN dbo.HWY_Members M WITH (NOLOCK) ON M.Id = H.MemberId
  WHERE H.InstanceId = @instance_id
  ORDER BY M.UserName ASC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_members_list
  @meeting_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_Meetings_Members', N'U') IS NULL
    THROW 50400, N'Legacy HWY_Meetings_Members is not available.', 1;

  SELECT
    CAST(mm.Id AS VARCHAR(32)) AS id,
    CAST(mm.MeetingId AS VARCHAR(32)) AS meetingId,
    CAST(mm.MemberId AS VARCHAR(32)) AS memberId,
    CAST(mm.IsMemberYet AS BIT) AS isMemberYet,
    CONVERT(VARCHAR(32), mm.IsMemberYetUpdatedOn, 126) AS isMemberYetUpdatedOn,
    M.UserName AS username,
    M.FirstName AS firstName,
    M.FatherName AS fatherName,
    M.LastName AS lastName
  FROM dbo.HWY_Meetings_Members mm WITH (NOLOCK)
  LEFT JOIN dbo.HWY_Members M WITH (NOLOCK) ON M.Id = mm.MemberId
  WHERE mm.MeetingId = @meeting_id
  ORDER BY M.UserName ASC, mm.Id ASC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_members_add
  @meeting_id BIGINT,
  @member_id BIGINT = NULL,
  @username NVARCHAR(128) = NULL,
  @actor NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_SP_Meetings_Members_Add', N'P') IS NULL
    THROW 50400, N'Legacy HWY_SP_Meetings_Members_Add is not available.', 1;
  DECLARE @mid BIGINT = @member_id;
  DECLARE @uname NVARCHAR(128) = NULLIF(LTRIM(RTRIM(@username)), N'');
  IF @mid IS NULL SET @mid = -1;
  IF @uname IS NULL SET @uname = N'-1';
  EXEC dbo.HWY_SP_Meetings_Members_Add @meeting_id, @mid, @uname, @actor;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_members_remove
  @row_id BIGINT,
  @actor NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_SP_Meetings_Members_Remove', N'P') IS NULL
    THROW 50400, N'Legacy HWY_SP_Meetings_Members_Remove is not available.', 1;
  EXEC dbo.HWY_SP_Meetings_Members_Remove @row_id, @actor;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_instance_attendance_list
  @instance_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_Meetings_Members', N'U') IS NULL
    THROW 50400, N'Legacy HWY_Meetings_Members is not available.', 1;

  IF OBJECT_ID(N'dbo.HWY_VW_Members_NoAdmin', N'V') IS NOT NULL
  BEGIN
    SELECT
      CAST(mm.Id AS VARCHAR(32)) AS id,
      CAST(@instance_id AS VARCHAR(32)) AS instanceId,
      CAST(mm.MeetingId AS VARCHAR(32)) AS meetingId,
      CAST(mm.MemberId AS VARCHAR(32)) AS memberId,
      M.UserName AS username,
      M.FirstName AS firstName,
      M.FatherName AS fatherName,
      M.LastName AS lastName,
      CAST(mm.IsMemberYet AS BIT) AS isMemberYet,
      CAST(CASE WHEN EXISTS (
        SELECT 1 FROM dbo.HWY_Meetings_Hazerin H WITH (NOLOCK)
        WHERE H.InstanceId = @instance_id AND H.MemberId = mm.MemberId
      ) THEN 1 ELSE 0 END AS BIT) AS present
    FROM dbo.HWY_Meetings_Members mm WITH (NOLOCK)
    INNER JOIN dbo.HWY_Meetings_Instances mi WITH (NOLOCK) ON mi.MeetingId = mm.MeetingId AND mi.Id = @instance_id
    LEFT JOIN dbo.HWY_VW_Members_NoAdmin M WITH (NOLOCK) ON M.Id = mm.MemberId AND M.MembershipStatus = 10851
    ORDER BY M.UserName ASC;
    RETURN;
  END;

  SELECT
    CAST(mm.Id AS VARCHAR(32)) AS id,
    CAST(@instance_id AS VARCHAR(32)) AS instanceId,
    CAST(mm.MeetingId AS VARCHAR(32)) AS meetingId,
    CAST(mm.MemberId AS VARCHAR(32)) AS memberId,
    M.UserName AS username,
    M.FirstName AS firstName,
    M.FatherName AS fatherName,
    M.LastName AS lastName,
    CAST(mm.IsMemberYet AS BIT) AS isMemberYet,
    CAST(CASE WHEN EXISTS (
      SELECT 1 FROM dbo.HWY_Meetings_Hazerin H WITH (NOLOCK)
      WHERE H.InstanceId = @instance_id AND H.MemberId = mm.MemberId
    ) THEN 1 ELSE 0 END AS BIT) AS present
  FROM dbo.HWY_Meetings_Members mm WITH (NOLOCK)
  INNER JOIN dbo.HWY_Meetings_Instances mi WITH (NOLOCK) ON mi.MeetingId = mm.MeetingId AND mi.Id = @instance_id
  LEFT JOIN dbo.HWY_Members M WITH (NOLOCK) ON M.Id = mm.MemberId
  ORDER BY M.UserName ASC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_hazerin_add
  @instance_id BIGINT,
  @member_id BIGINT = NULL,
  @username NVARCHAR(128) = NULL,
  @device_lat NVARCHAR(32) = NULL,
  @device_lon NVARCHAR(32) = NULL,
  @device_datetime NVARCHAR(32) = NULL,
  @device_id NVARCHAR(128) = NULL,
  @actor NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_SP_Meetings_Hazerin_Add', N'P') IS NULL
    THROW 50400, N'Legacy HWY_SP_Meetings_Hazerin_Add is not available.', 1;
  DECLARE @mid BIGINT = @member_id;
  DECLARE @uname NVARCHAR(128) = NULLIF(LTRIM(RTRIM(@username)), N'');
  IF @mid IS NULL SET @mid = -1;
  IF @uname IS NULL SET @uname = N'';
  IF @device_datetime IS NULL OR LTRIM(RTRIM(@device_datetime)) = N''
    SET @device_datetime = CONVERT(VARCHAR(32), GETDATE(), 120);
  EXEC dbo.HWY_SP_Meetings_Hazerin_Add
    @instance_id,
    @mid,
    @uname,
    @device_lat,
    @device_lon,
    @device_datetime,
    @device_id,
    @actor;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_hazerin_remove
  @instance_id BIGINT,
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_Meetings_Hazerin', N'U') IS NULL
    THROW 50400, N'Legacy HWY_Meetings_Hazerin is not available.', 1;
  DELETE FROM dbo.HWY_Meetings_Hazerin
  WHERE InstanceId = @instance_id AND MemberId = @member_id;
END;
GO
