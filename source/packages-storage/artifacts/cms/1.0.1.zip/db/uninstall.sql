-- CMS package Phase 1 uninstall (SQL Server)
-- Drops domain tables only. Base Info CMS root/subtree is removed by the seed rollback helper.

IF OBJECT_ID(N'dbo.cms_settings', N'U') IS NOT NULL DROP TABLE dbo.cms_settings;
IF OBJECT_ID(N'dbo.cms_content_relations', N'U') IS NOT NULL DROP TABLE dbo.cms_content_relations;
IF OBJECT_ID(N'dbo.cms_content_tags', N'U') IS NOT NULL DROP TABLE dbo.cms_content_tags;
IF OBJECT_ID(N'dbo.cms_content_assets', N'U') IS NOT NULL DROP TABLE dbo.cms_content_assets;
IF OBJECT_ID(N'dbo.cms_content_revisions', N'U') IS NOT NULL DROP TABLE dbo.cms_content_revisions;
IF OBJECT_ID(N'dbo.cms_contents', N'U') IS NOT NULL DROP TABLE dbo.cms_contents;

-- Removes exactly the 43 row(s) captured from base_info
DELETE FROM [base_info] WHERE [id] IN ('101', '101.001', '101.002', '101.003', '101.004', '101.005', '101.006', '101.001.001', '101.001.002', '101.001.003', '101.001.004', '101.001.005', '101.001.006', '101.001.007', '101.001.008', '101.002.001', '101.002.002', '101.002.003', '101.002.004', '101.002.005', '101.003.001', '101.003.002', '101.003.003', '101.004.001', '101.004.002', '101.004.003', '101.005.001', '101.005.002', '101.005.003', '101.005.004', '101.005.005', '101.005.006', '101.005.007', '101.005.008', '101.005.009', '101.005.010', '101.005.011', '101.005.012', '101.005.013', '101.005.014', '101.005.015', '101.006.001', '101.006.002');
