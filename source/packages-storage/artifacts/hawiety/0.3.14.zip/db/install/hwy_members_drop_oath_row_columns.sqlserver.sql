-- Oath document: SSOT dbo.hwy_member_files (oath_document). Drop redundant dbo.hwy_members columns.

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NOT NULL
BEGIN
  IF COL_LENGTH(N'dbo.hwy_members', N'oath_file_size') IS NOT NULL
    ALTER TABLE dbo.hwy_members DROP COLUMN oath_file_size;

  IF COL_LENGTH(N'dbo.hwy_members', N'oath_approved') IS NOT NULL
    ALTER TABLE dbo.hwy_members DROP COLUMN oath_approved;
END;
GO

PRINT 'hwy_members oath row columns dropped (if present)';
GO
