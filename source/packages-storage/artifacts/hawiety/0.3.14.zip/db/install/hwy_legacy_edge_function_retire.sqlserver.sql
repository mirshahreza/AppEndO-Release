-- Drop legacy HWY_FN_* / HWY_UFN_* on AppEndO edge when dbo.hwy_* replacement exists.
-- Keep in sync with src/domain/hwy/hwyLegacyEdgeSupersededFunctions.ts

IF OBJECT_ID(N'dbo.hwy_member_passed_necessary_dorat', N'FN') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_FN_PassedNecessaryDorat', N'FN') IS NOT NULL
  DROP FUNCTION dbo.HWY_FN_PassedNecessaryDorat;
GO

IF OBJECT_ID(N'dbo.hwy_member_calc_profile_percentage', N'FN') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_FN_Members_Calc_ProfilePercentage', N'FN') IS NOT NULL
  DROP FUNCTION dbo.HWY_FN_Members_Calc_ProfilePercentage;
GO

IF OBJECT_ID(N'dbo.hwy_member_has_not_tosigh_older_than_x_days', N'FN') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_FN_HasNotTosighOlderThanXDays', N'FN') IS NOT NULL
  DROP FUNCTION dbo.HWY_FN_HasNotTosighOlderThanXDays;
GO

IF (
     OBJECT_ID(N'dbo.hwy_member_select_points', N'TF') IS NOT NULL
     OR OBJECT_ID(N'dbo.hwy_member_select_points', N'IF') IS NOT NULL
   )
   AND (
     OBJECT_ID(N'dbo.HWY_UFN_SelectPoints', N'TF') IS NOT NULL
     OR OBJECT_ID(N'dbo.HWY_UFN_SelectPoints', N'IF') IS NOT NULL
   )
  DROP FUNCTION dbo.HWY_UFN_SelectPoints;
GO

IF OBJECT_ID(N'dbo.hwy_member_agg_area_limits', N'FN') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_FN_Agg_AreaLimits', N'FN') IS NOT NULL
  DROP FUNCTION dbo.HWY_FN_Agg_AreaLimits;
GO

IF OBJECT_ID(N'dbo.hwy_member_agg_area_limits_for_tarshih', N'FN') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_FN_Agg_AreaLimitsForTarshih', N'FN') IS NOT NULL
  DROP FUNCTION dbo.HWY_FN_Agg_AreaLimitsForTarshih;
GO

IF OBJECT_ID(N'dbo.hwy_base_info_title', N'FN') IS NOT NULL
  DROP FUNCTION dbo.hwy_base_info_title;
GO

IF OBJECT_ID(N'dbo.hwy_base_info_path_to_province', N'FN') IS NOT NULL
  DROP FUNCTION dbo.hwy_base_info_path_to_province;
GO

IF OBJECT_ID(N'dbo.hwy_member_residence_summary', N'FN') IS NOT NULL
  DROP FUNCTION dbo.hwy_member_residence_summary;
GO

IF OBJECT_ID(N'dbo.hwy_member_dossier_kasb_links_list', N'P') IS NOT NULL
  DROP PROCEDURE dbo.hwy_member_dossier_kasb_links_list;
GO

IF OBJECT_ID(N'dbo.hwy_member_kasb_sync_legacy_column', N'P') IS NOT NULL
  DROP PROCEDURE dbo.hwy_member_kasb_sync_legacy_column;
GO
