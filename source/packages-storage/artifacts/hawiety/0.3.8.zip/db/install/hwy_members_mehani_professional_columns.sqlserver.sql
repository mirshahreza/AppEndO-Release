-- Mehani (Professional Office) member fields — legacy Job_EttehadId / Job_EttehadDegreeId / Mehani_Expiry.
-- Legacy Mehani_FileBody (union ID photo) is intentionally not ported — see plans hwy-institute-dossier-display-contract.md.

IF COL_LENGTH(N'dbo.hwy_members', N'mehani_union_code') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_members ADD mehani_union_code NVARCHAR(1000) NULL;
END;
GO

IF COL_LENGTH(N'dbo.hwy_members', N'mehani_union_degree_code') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_members ADD mehani_union_degree_code NVARCHAR(1000) NULL;
END;
GO

IF COL_LENGTH(N'dbo.hwy_members', N'mehani_membership_expires_on') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_members ADD mehani_membership_expires_on DATE NULL;
END;
GO

IF NOT EXISTS (
  SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_hwy_members_mehani_union_code'
)
BEGIN
  ALTER TABLE dbo.hwy_members
    ADD CONSTRAINT FK_hwy_members_mehani_union_code
    FOREIGN KEY (mehani_union_code) REFERENCES dbo.base_info(id);
END;
GO

IF NOT EXISTS (
  SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_hwy_members_mehani_union_degree_code'
)
BEGIN
  ALTER TABLE dbo.hwy_members
    ADD CONSTRAINT FK_hwy_members_mehani_union_degree_code
    FOREIGN KEY (mehani_union_degree_code) REFERENCES dbo.base_info(id);
END;
GO
