-- Legacy parity: dbo.hwy_member_passed_necessary_dorat — required course subtypes for geo-responsibility candidates.
-- Uses migrated hwy_courses / hwy_course_attendances (legacy DoratSubTypeId + StatusId 215116 as NVARCHAR codes).

IF OBJECT_ID(N'dbo.hwy_member_passed_necessary_dorat', N'FN') IS NOT NULL
  DROP FUNCTION dbo.hwy_member_passed_necessary_dorat;
GO

CREATE FUNCTION dbo.hwy_member_passed_necessary_dorat(@member_id BIGINT)
RETURNS BIT
AS
BEGIN
  IF @member_id IS NULL OR @member_id <= 0
    RETURN 0;

  DECLARE @passed_count INT = (
    SELECT COUNT(DISTINCT c.course_subtype_code)
    FROM dbo.hwy_course_attendances ca WITH (NOLOCK)
    INNER JOIN dbo.hwy_courses c WITH (NOLOCK) ON c.id= ca.course_id
    INNER JOIN dbo.hwy_members m WITH (NOLOCK) ON m.id= @member_id
    WHERE ca.member_id = @member_id
      AND c.status_code = N'215116'
      AND c.course_subtype_code IN (
        N'11071',
        N'11152',
        CASE
          WHEN m.gender_code IN (N'100.1.1', N'10011') OR m.gender_code LIKE N'%10011%'
            THEN N'11028'
          ELSE N'11072'
        END
      )
  );

  IF (@passed_count >= 3)
    RETURN 1;

  RETURN 0;
END;
GO
