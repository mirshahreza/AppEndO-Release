-- HWY geographic helpers for vw_hwy_members list projections.
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

/** Culture-specific title path for one base_info node (Iraq / iq pack). */
CREATE OR ALTER FUNCTION dbo.hwy_base_info_iq_title_path(@base_info_id NVARCHAR(128))
RETURNS NVARCHAR(MAX)
AS
BEGIN
  IF @base_info_id IS NULL OR LTRIM(RTRIM(@base_info_id)) = N'' RETURN NULL;

  DECLARE @path NVARCHAR(MAX);

  SELECT @path = NULLIF(LTRIM(RTRIM(p.title_path)), N'')
  FROM dbo.base_info_title_path AS p
  WHERE p.base_info_id = LTRIM(RTRIM(@base_info_id))
    AND p.culture_id = N'iq';

  IF @path IS NOT NULL RETURN @path;

  SELECT @path = NULLIF(LTRIM(RTRIM(bi.title_path_ar)), N'')
  FROM dbo.base_info AS bi
  WHERE bi.id = LTRIM(RTRIM(@base_info_id));

  RETURN @path;
END;
GO

CREATE OR ALTER FUNCTION dbo.hwy_base_info_title_path_by_short_name(@short_name NVARCHAR(256))
RETURNS NVARCHAR(MAX)
AS
BEGIN
  IF @short_name IS NULL OR LTRIM(RTRIM(@short_name)) = N'' RETURN NULL;

  RETURN (
    SELECT TOP (1) dbo.hwy_base_info_iq_title_path(bi.id)
    FROM dbo.base_info AS bi
    WHERE bi.short_name = @short_name
  );
END;
GO

CREATE OR ALTER FUNCTION dbo.hwy_region_electoral_title_path(@region_ref NVARCHAR(128))
RETURNS NVARCHAR(MAX)
AS
BEGIN
  IF @region_ref IS NULL OR LTRIM(RTRIM(@region_ref)) = N'' RETURN NULL;

  DECLARE @trimmed NVARCHAR(128) = LTRIM(RTRIM(@region_ref));
  DECLARE @path NVARCHAR(MAX) = dbo.hwy_base_info_iq_title_path(@trimmed);

  IF @path IS NOT NULL RETURN @path;

  RETURN dbo.hwy_base_info_title_path_by_short_name(
    CONCAT(N'hwy-region-', @trimmed)
  );
END;
GO

/** Residence through province (mapped base_info id or legacy province id). */
CREATE OR ALTER FUNCTION dbo.hwy_member_residence_to_city(@addr_province_id NVARCHAR(128))
RETURNS NVARCHAR(MAX)
AS
BEGIN
  IF @addr_province_id IS NULL OR LTRIM(RTRIM(@addr_province_id)) = N'' RETURN NULL;

  DECLARE @trimmed NVARCHAR(128) = LTRIM(RTRIM(@addr_province_id));
  DECLARE @path NVARCHAR(MAX) = dbo.hwy_base_info_iq_title_path(@trimmed);

  IF @path IS NOT NULL RETURN @path;

  RETURN dbo.hwy_base_info_title_path_by_short_name(
    CONCAT(N'hwy-province-', @trimmed)
  );
END;
GO

/** Map legacy geo keys or raw base_info ids to `base_info.id`. */
CREATE OR ALTER FUNCTION dbo.hwy_resolve_raw_geo_to_base_info_id(@raw NVARCHAR(128))
RETURNS NVARCHAR(128)
AS
BEGIN
  DECLARE @trimmed NVARCHAR(128) = NULLIF(LTRIM(RTRIM(@raw)), N'');
  IF @trimmed IS NULL RETURN NULL;

  IF @trimmed LIKE N'100.5.%'
    AND EXISTS (SELECT 1 FROM dbo.base_info AS bi WHERE bi.id = @trimmed)
    RETURN @trimmed;

  DECLARE @mapped NVARCHAR(128);

  SELECT TOP (1) @mapped = gm.base_info_id
  FROM dbo.hwy_etl_geo_map AS gm
  WHERE CAST(gm.legacy_id AS NVARCHAR(32)) = @trimmed
    AND gm.legacy_kind IN (N'region', N'maktab', N'circle', N'province', N'ghavateh')
  ORDER BY CASE gm.legacy_kind
    WHEN N'region' THEN 1
    WHEN N'maktab' THEN 2
    WHEN N'circle' THEN 3
    WHEN N'ghavateh' THEN 4
    WHEN N'province' THEN 5
    ELSE 6
  END;

  IF @mapped IS NOT NULL RETURN @mapped;

  IF EXISTS (SELECT 1 FROM dbo.base_info AS bi WHERE bi.id = @trimmed)
    RETURN @trimmed;

  RETURN NULL;
END;
GO

/** Short Arabic/English label for one geo node (leaf title, not full path). */
CREATE OR ALTER FUNCTION dbo.hwy_geo_leaf_title(@base_info_id NVARCHAR(128))
RETURNS NVARCHAR(512)
AS
BEGIN
  DECLARE @id NVARCHAR(128) = NULLIF(LTRIM(RTRIM(@base_info_id)), N'');
  IF @id IS NULL RETURN NULL;

  DECLARE @title_ar NVARCHAR(512);
  DECLARE @title_en NVARCHAR(512);

  SELECT
    @title_ar = NULLIF(LTRIM(RTRIM(bi.title_ar)), N''),
    @title_en = NULLIF(LTRIM(RTRIM(bi.title_en)), N'')
  FROM dbo.base_info AS bi
  WHERE bi.id = @id;

  DECLARE @label NVARCHAR(512) = COALESCE(@title_ar, @title_en);

  IF @label IS NULL
  BEGIN
    SET @label = dbo.hwy_base_info_iq_title_path(@id);
    IF @label IS NULL OR LTRIM(RTRIM(@label)) = N'' RETURN @id;
  END;

  IF CHARINDEX(N'|', @label) > 0
  BEGIN
    DECLARE @rev NVARCHAR(MAX) = REVERSE(@label);
    DECLARE @sep INT = CHARINDEX(N'|', @rev);
    IF @sep > 0
      SET @label = LTRIM(RTRIM(REVERSE(SUBSTRING(@rev, 1, @sep - 1))));
  END;

  RETURN @label;
END;
GO

/** 1 when @patch_id equals @node_id or is an ancestor of @node_id in `base_info`. */
CREATE OR ALTER FUNCTION dbo.hwy_base_info_patch_contains_node(
  @patch_id NVARCHAR(128),
  @node_id NVARCHAR(128)
)
RETURNS BIT
AS
BEGIN
  DECLARE @patch NVARCHAR(128) = NULLIF(LTRIM(RTRIM(@patch_id)), N'');
  DECLARE @node NVARCHAR(128) = NULLIF(LTRIM(RTRIM(@node_id)), N'');
  IF @patch IS NULL OR @node IS NULL RETURN 0;
  IF @patch = @node RETURN 1;

  DECLARE @current NVARCHAR(128) = @node;
  DECLARE @parent NVARCHAR(128);
  DECLARE @guard INT = 0;

  WHILE @current IS NOT NULL AND @guard < 32
  BEGIN
    SELECT @parent = NULLIF(LTRIM(RTRIM(bi.parent_id)), N'')
    FROM dbo.base_info AS bi
    WHERE bi.id = @current;

    IF @parent IS NULL RETURN 0;
    IF @parent = @patch RETURN 1;

    SET @current = @parent;
    SET @guard = @guard + 1;
  END;

  RETURN 0;
END;
GO

PRINT 'hwy geo SQL functions ready';
GO
