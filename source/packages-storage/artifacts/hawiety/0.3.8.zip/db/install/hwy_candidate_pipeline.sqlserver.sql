-- Legacy parity: center candidate responsibility pipeline (stages security, interview, courses, install).

CREATE OR ALTER PROCEDURE dbo.hwy_legacy_operator_geo_scope
  @username NVARCHAR(128)
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @area_limit_id BIGINT = NULL;
  DECLARE @geo_limits_csv NVARCHAR(MAX) = NULL;

  IF NULLIF(LTRIM(RTRIM(@username)), N'') IS NOT NULL
  BEGIN
    SELECT TOP 1 @area_limit_id = m.AreaLimitId
    FROM dbo.AppEnd_Users u WITH (NOLOCK)
    INNER JOIN dbo.HWY_Members m WITH (NOLOCK) ON m.UserId = u.Id
    WHERE u.UserName = @username;

    SELECT @geo_limits_csv = STRING_AGG(CAST(v.GeoId AS NVARCHAR(32)), N',')
    FROM (
      SELECT DISTINCT al.item_id AS GeoId
      FROM dbo.AppEnd_Users u WITH (NOLOCK)
      INNER JOIN dbo.HWY_Members m WITH (NOLOCK) ON m.UserId = u.Id
      INNER JOIN dbo.hwy_member_area_limits al WITH (NOLOCK) ON al.member_id = m.Id AND al.approved = 1
      WHERE u.UserName = @username AND al.item_id IS NOT NULL
      UNION
      SELECT m.AreaLimitProvinceId FROM dbo.AppEnd_Users u WITH (NOLOCK) INNER JOIN dbo.HWY_Members m ON m.UserId = u.Id WHERE u.UserName = @username AND m.AreaLimitProvinceId IS NOT NULL
      UNION
      SELECT m.AreaLimitCircleId FROM dbo.AppEnd_Users u WITH (NOLOCK) INNER JOIN dbo.HWY_Members m ON m.UserId = u.Id WHERE u.UserName = @username AND m.AreaLimitCircleId IS NOT NULL
      UNION
      SELECT m.AreaLimitTamvinId FROM dbo.AppEnd_Users u WITH (NOLOCK) INNER JOIN dbo.HWY_Members m ON m.UserId = u.Id WHERE u.UserName = @username AND m.AreaLimitTamvinId IS NOT NULL
      UNION
      SELECT m.NakhebJoinEghteraId FROM dbo.AppEnd_Users u WITH (NOLOCK) INNER JOIN dbo.HWY_Members m ON m.UserId = u.Id WHERE u.UserName = @username AND m.NakhebJoinEghteraId IS NOT NULL
    ) v
    WHERE v.GeoId IS NOT NULL;
  END;

  SELECT @area_limit_id AS area_limit_id, @geo_limits_csv AS geo_limits_csv;
END;
GO

CREATE OR ALTER FUNCTION dbo.hwy_candidate_pipeline_where_clause(
  @stage NVARCHAR(32),
  @list_type NVARCHAR(64),
  @role_id NVARCHAR(32),
  @is_approved NVARCHAR(8),
  @approve_state NVARCHAR(8),
  @passed_or_not NVARCHAR(8),
  @interview_approve_state NVARCHAR(32),
  @scope_unrestricted BIT,
  @nakheb_province_id BIGINT,
  @nakheb_circle_id BIGINT,
  @nakheb_tamvin_id BIGINT,
  @date_start NVARCHAR(32),
  @date_end NVARCHAR(32),
  @username NVARCHAR(128),
  @phone NVARCHAR(64),
  @gender_id NVARCHAR(32),
  @alias NVARCHAR(8),
  @actor_user_name NVARCHAR(128) = NULL,
  @area_limit_id BIGINT = NULL,
  @geo_limits_csv NVARCHAR(MAX) = NULL
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
  DECLARE @w NVARCHAR(MAX) = N'';
  DECLARE @lt NVARCHAR(64) = NULLIF(LTRIM(RTRIM(@list_type)), N'');
  DECLARE @rid NVARCHAR(32) = NULLIF(LTRIM(RTRIM(@role_id)), N'');
  DECLARE @st NVARCHAR(32) = LOWER(LTRIM(RTRIM(@stage)));

  IF @st = N'security'
  BEGIN
    IF @lt IS NULL SET @lt = N'WaitForInitialVoteMembers';
    IF @lt = N'WaitForInitialVoteMembers'
      SET @w = @w + N' AND ((SELECT COUNT(*) FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.Id)=0 OR (SELECT TOP 1 SP.can_get_masooliat FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.Id ORDER BY SP.created_on DESC)=211753)';
    ELSE IF @lt = N'RejectedMembers'
      SET @w = @w + N' AND (SELECT TOP 1 SP.can_get_masooliat FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.Id ORDER BY SP.created_on DESC)=211752';
    ELSE IF @lt = N'AcceptedMembers'
      SET @w = @w + N' AND (SELECT TOP 1 SP.can_get_masooliat FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.Id ORDER BY SP.created_on DESC)=211751';
    ELSE IF @lt = N'' OR @lt = N'All'
      SET @w = @w + N'';
    IF NULLIF(LTRIM(RTRIM(@is_approved)), N'') IS NOT NULL AND @is_approved <> N'-1'
      SET @w = @w + N' AND ISNULL(' + @alias + N'.IsApproved, 0)=' + @is_approved;
    IF @rid IS NOT NULL
      SET @w = @w + N' AND EXISTS (SELECT 1 FROM dbo.AppEnd_Users_R_Roles URR WITH (NOLOCK) WHERE URR.UserId=' + @alias + N'.UserId AND URR.RoleId=' + @rid + N')';
  END
  ELSE IF @st = N'interview'
  BEGIN
    IF @lt IS NULL SET @lt = N'NotInterviewed';
    IF @lt = N'NotInterviewed'
      SET @w = @w + N' AND ' + @alias + N'.InterviewOn IS NULL';
    ELSE IF @lt = N'Interviewed'
      SET @w = @w + N' AND ' + @alias + N'.InterviewOn IS NOT NULL';
    DECLARE @ias NVARCHAR(32) = NULLIF(LTRIM(RTRIM(@interview_approve_state)), N'');
    IF @ias IS NOT NULL AND @ias <> N'All'
      SET @w = @w + N' AND ' + @alias + N'.InterviewFinalResult=''' + REPLACE(@ias, N'''', N'''''') + N'''';
    IF NULLIF(LTRIM(RTRIM(@approve_state)), N'') IS NOT NULL AND @approve_state <> N'-1'
      SET @w = @w + N' AND EXISTS (SELECT 1 FROM dbo.AppEnd_Users_R_Roles URR WITH (NOLOCK) WHERE URR.UserId=' + @alias + N'.UserId AND URR.RoleId=' + @alias + N'.RoleId AND URR.RoleId IN (1000004,1000005) AND URR.Approved=' + @approve_state + N')';
    IF @rid IS NOT NULL AND @rid <> N''
      SET @w = @w + N' AND ' + @alias + N'.RoleId=' + @rid;
  END
  ELSE IF @st = N'courses'
  BEGIN
    IF @lt IS NULL SET @lt = N'NotPassed';
    IF @lt = N'NotPassed'
      SET @w = @w + N' AND COALESCE(' + @alias + N'.PassedNecessaryDorat, 0)=0';
    ELSE IF @lt = N'Passed'
      SET @w = @w + N' AND COALESCE(' + @alias + N'.PassedNecessaryDorat, 0)=1';
    IF @rid IS NOT NULL AND @rid <> N''
      SET @w = @w + N' AND EXISTS (SELECT 1 FROM dbo.AppEnd_Users_R_Roles URR WITH (NOLOCK) WHERE URR.UserId=' + @alias + N'.UserId AND URR.RoleId=' + @rid + N')';
    IF NULLIF(LTRIM(RTRIM(@approve_state)), N'') IS NOT NULL AND @approve_state <> N'-1'
      SET @w = @w + N' AND EXISTS (SELECT 1 FROM dbo.AppEnd_Users_R_Roles URR WITH (NOLOCK) WHERE URR.UserId=' + @alias + N'.UserId AND URR.RoleId IN (1000004,1000005) AND URR.Approved=' + @approve_state + N')';
  END
  ELSE IF @st = N'install'
  BEGIN
    IF OBJECT_ID(N'dbo.HWY_FN_CanApproveResponsibility', N'FN') IS NOT NULL
      SET @w = @w + N' AND dbo.HWY_FN_CanApproveResponsibility(' + @alias + N'.Id)=1';
    SET @w = @w + N' AND ' + @alias + N'.SecurityStatus=211751';
    DECLARE @pon NVARCHAR(8) = NULLIF(LTRIM(RTRIM(@passed_or_not)), N'');
    IF @pon IS NULL SET @pon = N'-1';
    IF @pon <> N'-1'
      SET @w = @w + N' AND ' + @alias + N'.NecessaryDoratPassed=' + @pon;
    IF @rid IS NOT NULL AND @rid <> N''
      SET @w = @w + N' AND EXISTS (SELECT 1 FROM dbo.AppEnd_Users_R_Roles URR WITH (NOLOCK) WHERE URR.UserId=' + @alias + N'.UserId AND URR.RoleId=' + @rid + N')';
  END;

  DECLARE @tarshih_prov NVARCHAR(MAX) = N'(SELECT TOP 1 A.HWY_StateId FROM dbo.hwy_member_area_limits AL WITH (NOLOCK) LEFT JOIN dbo.HWY_VW_H_AllArea A ON A.AreaId=AL.item_id WHERE AL.member_id=' + @alias + N'.Id AND AL.approved=1 ORDER BY AL.id DESC)';
  DECLARE @tarshih_circle NVARCHAR(MAX) = N'(SELECT TOP 1 A.CircleId FROM dbo.hwy_member_area_limits AL WITH (NOLOCK) LEFT JOIN dbo.HWY_VW_H_AllArea A ON A.AreaId=AL.item_id WHERE AL.member_id=' + @alias + N'.Id AND AL.approved=1 ORDER BY AL.id DESC)';
  DECLARE @tarshih_tamvin NVARCHAR(MAX) = N'(SELECT TOP 1 A.TamvinId FROM dbo.hwy_member_area_limits AL WITH (NOLOCK) LEFT JOIN dbo.HWY_VW_H_AllArea A ON A.AreaId=AL.item_id WHERE AL.member_id=' + @alias + N'.Id AND AL.approved=1 ORDER BY AL.id DESC)';

  IF @nakheb_province_id IS NOT NULL
  BEGIN
    IF @st IN (N'interview', N'courses', N'install')
      SET @w = @w + N' AND ' + @tarshih_prov + N'=' + CAST(@nakheb_province_id AS NVARCHAR(32));
    ELSE
      SET @w = @w + N' AND ' + @alias + N'.NakhebJoinProvinceId=' + CAST(@nakheb_province_id AS NVARCHAR(32));
  END;
  IF @nakheb_circle_id IS NOT NULL
  BEGIN
    IF @st IN (N'interview', N'courses', N'install')
      SET @w = @w + N' AND ' + @tarshih_circle + N'=' + CAST(@nakheb_circle_id AS NVARCHAR(32));
    ELSE
      SET @w = @w + N' AND ' + @alias + N'.NakhebJoinCircleId=' + CAST(@nakheb_circle_id AS NVARCHAR(32));
  END;
  IF @nakheb_tamvin_id IS NOT NULL
  BEGIN
    IF @st IN (N'interview', N'courses', N'install')
      SET @w = @w + N' AND ' + @tarshih_tamvin + N'=' + CAST(@nakheb_tamvin_id AS NVARCHAR(32));
    ELSE
      SET @w = @w + N' AND ' + @alias + N'.NakhebJoinTamvinId=' + CAST(@nakheb_tamvin_id AS NVARCHAR(32));
  END;

  IF NULLIF(LTRIM(RTRIM(@date_start)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.DateOfTarshih >= ''' + REPLACE(@date_start, N'''', N'''''') + N' 00:00''';
  IF NULLIF(LTRIM(RTRIM(@date_end)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.DateOfTarshih <= ''' + REPLACE(@date_end, N'''', N'''''') + N' 23:59''';

  IF NULLIF(LTRIM(RTRIM(@username)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.UserName LIKE ''%'' + ''' + REPLACE(@username, N'''', N'''''') + N''' + ''%''';
  IF NULLIF(LTRIM(RTRIM(@phone)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.Phone1 LIKE ''%'' + ''' + REPLACE(@phone, N'''', N'''''') + N''' + ''%''';
  IF NULLIF(LTRIM(RTRIM(@gender_id)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.GenderId=' + @gender_id;

  DECLARE @actor NVARCHAR(128) = NULLIF(LTRIM(RTRIM(@actor_user_name)), N'');
  IF @actor IS NOT NULL AND @st = N'security'
  BEGIN
    IF @actor LIKE N'%,0'
      SET @w = @w + N' AND ' + @alias + N'.MoarasshehOfTarshih=''' + REPLACE(REPLACE(@actor, N',0', N''), N'''', N'''''') + N'''';
    ELSE IF @actor LIKE N'%,1'
      SET @w = @w + N' AND ' + @alias + N'.ApprovedBy=''' + REPLACE(REPLACE(@actor, N',1', N''), N'''', N'''''') + N'''';
    ELSE
      SET @w = @w + N' AND (' + @alias + N'.MoarasshehOfTarshih LIKE ''%'' + ''' + REPLACE(@actor, N'''', N'''''') + N''' + ''%'' OR ' + @alias + N'.ApprovedBy LIKE ''%'' + ''' + REPLACE(@actor, N'''', N'''''') + N''' + ''%'')';
  END;

  IF @scope_unrestricted = 0 AND @area_limit_id IS NOT NULL AND @geo_limits_csv IS NOT NULL AND LTRIM(RTRIM(@geo_limits_csv)) <> N''
  BEGIN
    DECLARE @geo NVARCHAR(MAX) = N' AND (1=0';
    IF @area_limit_id = 111321
      SET @geo = N'';
    ELSE IF @area_limit_id = 111322
    BEGIN
      IF @st IN (N'interview', N'courses', N'install')
        SET @geo = @geo + N' OR ' + @tarshih_prov + N' IN (' + @geo_limits_csv + N')';
      ELSE
        SET @geo = @geo + N' OR ' + @alias + N'.NakhebJoinProvinceId IN (' + @geo_limits_csv + N')';
    END
    ELSE IF @area_limit_id = 111325
    BEGIN
      IF @st IN (N'interview', N'courses', N'install')
        SET @geo = @geo + N' OR ' + @tarshih_circle + N' IN (' + @geo_limits_csv + N')';
      ELSE
        SET @geo = @geo + N' OR ' + @alias + N'.NakhebJoinCircleId IN (' + @geo_limits_csv + N')';
    END
    ELSE IF @area_limit_id = 111323
    BEGIN
      IF @st IN (N'interview', N'courses', N'install')
        SET @geo = @geo + N' OR ' + @tarshih_tamvin + N' IN (' + @geo_limits_csv + N')';
      ELSE
        SET @geo = @geo + N' OR ' + @alias + N'.NakhebJoinTamvinId IN (' + @geo_limits_csv + N')';
    END
    ELSE IF @area_limit_id = 111324
      SET @geo = @geo + N' OR ' + @alias + N'.NakhebJoinEghteraId IN (' + @geo_limits_csv + N')';
    IF @geo <> N''
      SET @w = @w + @geo + N')';
  END;

  RETURN @w;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_candidate_pipeline_count
  @stage NVARCHAR(32),
  @list_type NVARCHAR(64) = NULL,
  @role_id NVARCHAR(32) = NULL,
  @is_approved NVARCHAR(8) = NULL,
  @approve_state NVARCHAR(8) = NULL,
  @passed_or_not NVARCHAR(8) = NULL,
  @interview_approve_state NVARCHAR(32) = NULL,
  @scope_unrestricted BIT = 0,
  @nakheb_province_id BIGINT = NULL,
  @nakheb_circle_id BIGINT = NULL,
  @nakheb_tamvin_id BIGINT = NULL,
  @date_start NVARCHAR(32) = NULL,
  @date_end NVARCHAR(32) = NULL,
  @username NVARCHAR(128) = NULL,
  @phone NVARCHAR(64) = NULL,
  @gender_id NVARCHAR(32) = NULL,
  @actor_user_name NVARCHAR(128) = NULL,
  @area_limit_id BIGINT = NULL,
  @geo_limits_csv NVARCHAR(MAX) = NULL
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @view sysname = CASE LOWER(LTRIM(RTRIM(@stage)))
    WHEN N'security' THEN N'vw_hwy_candidate_pipeline_security'
    WHEN N'interview' THEN N'vw_hwy_candidate_pipeline_interview'
    WHEN N'courses' THEN N'vw_hwy_candidate_pipeline_courses'
    WHEN N'install' THEN N'vw_hwy_candidate_pipeline_install'
    ELSE NULL
  END;

  IF @view IS NULL OR OBJECT_ID(N'dbo.' + @view, N'V') IS NULL
    THROW 50400, N'Legacy candidate pipeline view is not available for this stage.', 1;

  DECLARE @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS total FROM dbo.' + QUOTENAME(@view) + N' V WITH (NOLOCK) WHERE 1=1';
  SET @sql = @sql + dbo.hwy_candidate_pipeline_where_clause(
    @stage, @list_type, @role_id, @is_approved, @approve_state, @passed_or_not,
    @interview_approve_state, @scope_unrestricted, @nakheb_province_id, @nakheb_circle_id,
    @nakheb_tamvin_id, @date_start, @date_end, @username, @phone, @gender_id, N'V',
    @actor_user_name, @area_limit_id, @geo_limits_csv);
  EXEC sp_executesql @sql;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_candidate_pipeline_list
  @stage NVARCHAR(32),
  @list_type NVARCHAR(64) = NULL,
  @role_id NVARCHAR(32) = NULL,
  @is_approved NVARCHAR(8) = NULL,
  @approve_state NVARCHAR(8) = NULL,
  @passed_or_not NVARCHAR(8) = NULL,
  @interview_approve_state NVARCHAR(32) = NULL,
  @scope_unrestricted BIT = 0,
  @nakheb_province_id BIGINT = NULL,
  @nakheb_circle_id BIGINT = NULL,
  @nakheb_tamvin_id BIGINT = NULL,
  @date_start NVARCHAR(32) = NULL,
  @date_end NVARCHAR(32) = NULL,
  @username NVARCHAR(128) = NULL,
  @phone NVARCHAR(64) = NULL,
  @gender_id NVARCHAR(32) = NULL,
  @actor_user_name NVARCHAR(128) = NULL,
  @area_limit_id BIGINT = NULL,
  @geo_limits_csv NVARCHAR(MAX) = NULL,
  @offset INT = 0,
  @page_size INT = 25
AS
BEGIN
  SET NOCOUNT ON;

  IF LOWER(LTRIM(RTRIM(@stage))) = N'interview'
  BEGIN
    DECLARE @interview_where NVARCHAR(MAX) = dbo.hwy_candidate_pipeline_where_clause(
      @stage, @list_type, @role_id, @is_approved, @approve_state, @passed_or_not,
      @interview_approve_state, @scope_unrestricted, @nakheb_province_id, @nakheb_circle_id,
      @nakheb_tamvin_id, @date_start, @date_end, @username, @phone, @gender_id, N'V',
      @actor_user_name, @area_limit_id, @geo_limits_csv);

    DECLARE @interview_sql NVARCHAR(MAX) = N'
;WITH eligible AS (
  SELECT
    M.Id,
    M.UserName,
    M.UserId,
    M.FirstName,
    M.FatherName,
    M.GrandFatherName,
    M.LastName,
    M.Phone1,
    M.GenderId,
    M.NakhebJoinProvinceId,
    M.NakhebJoinCircleId,
    M.NakhebJoinTamvinId,
    M.NakhebJoinEghteraId,
    iv.interview_on AS InterviewOn,
    iv.final_result AS InterviewFinalResult,
    R.RoleName AS RoleOfTarshih,
    URR.RoleId AS RoleId,
    URR.CreatedOn AS DateOfTarshih,
    URR.CreatedBy AS MoarasshehOfTarshih,
    sec.created_on AS DateOfSP
  FROM dbo.HWY_Members M WITH (NOLOCK)
  INNER JOIN dbo.AppEnd_Users_R_Roles URR WITH (NOLOCK)
    ON URR.UserId = M.UserId AND URR.RoleId IN (1000004, 1000005)
  LEFT OUTER JOIN dbo.AppEnd_Roles R WITH (NOLOCK) ON R.Id = URR.RoleId
  OUTER APPLY (
    SELECT TOP 1 SP.can_get_masooliat, SP.created_on
    FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK)
    WHERE SP.member_id = M.Id
    ORDER BY SP.created_on DESC
  ) sec
  OUTER APPLY (
    SELECT TOP 1 I.interview_on, I.final_result
    FROM dbo.hwy_member_interviews_2022 I WITH (NOLOCK)
    WHERE I.member_id = M.Id
    ORDER BY I.created_on DESC
  ) iv
  WHERE M.MembershipStatus = 10851
    AND sec.can_get_masooliat = 211751
),
filtered AS (
  SELECT V.*, COUNT(*) OVER() AS pipeline_total
  FROM eligible V
  WHERE 1=1' + @interview_where + N'
),
paged AS (
  SELECT *
  FROM filtered V
  ORDER BY V.DateOfTarshih DESC, V.Id DESC
  OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY
)
SELECT
  CAST(p.Id AS VARCHAR(32)) AS id,
  p.UserName AS username,
  CAST(p.UserId AS VARCHAR(32)) AS userId,
  p.FirstName AS firstName,
  p.FatherName AS fatherName,
  p.GrandFatherName AS grandFatherName,
  p.LastName AS lastName,
  p.Phone1 AS phone1,
  vm.electoral_division_path AS electoralDivisionPath,
  (SELECT TOP 1 BI.title FROM dbo.hwy_ref_base_information BI WITH (NOLOCK) WHERE BI.id = p.NakhebJoinProvinceId) AS nakhebJoinProvinceName,
  (SELECT TOP 1 C.circle_name FROM dbo.hwy_ref_h_circles C WITH (NOLOCK) WHERE C.circle_id = p.NakhebJoinCircleId) AS nakhebJoinCircleName,
  (SELECT TOP 1 T.tamvin_name FROM dbo.hwy_ref_h_tamvinat T WITH (NOLOCK) WHERE T.tamvin_id = p.NakhebJoinTamvinId) AS nakhebJoinTamvinName,
  (SELECT TOP 1 BI.title FROM dbo.hwy_ref_base_information BI WITH (NOLOCK) WHERE BI.id = p.NakhebJoinEghteraId) AS nakhebJoinEghteraName,
  CAST(p.NakhebJoinEghteraId AS VARCHAR(32)) AS nakhebJoinEghteraId,
  CAST(p.GenderId AS VARCHAR(32)) AS genderId,
  p.RoleOfTarshih AS roleOfTarshih,
  dbo.hwy_member_agg_area_limits_for_tarshih(p.Id) AS areaOfTarshih,
  CONVERT(VARCHAR(32), p.DateOfTarshih, 126) AS dateOfTarshih,
  p.MoarasshehOfTarshih AS moarasshehOfTarshih,
  CONVERT(VARCHAR(32), p.InterviewOn, 126) AS interviewOn,
  CAST(p.InterviewFinalResult AS VARCHAR(32)) AS interviewFinalResult,
  BI_iv.title AS interviewFinalResultTitle,
  CAST(p.RoleId AS VARCHAR(32)) AS roleId,
  DATEDIFF(DAY, p.DateOfTarshih, GETDATE()) AS daysFrom,
  p.pipeline_total,
  vm.display_full_name AS displayFullName,
  vm.avatar_url AS avatarUrl,
  vm.birth_year AS birthYear,
  vm.gender_code AS genderCode,
  CONVERT(VARCHAR(32), vm.membership_on, 126) AS membershipOn,
  vm.phone2 AS phone2,
  vm.tracking_code AS trackingCode,
  CAST(vm.addr_province_id AS VARCHAR(32)) AS addrProvinceId,
  CAST(vm.addr_region_id AS VARCHAR(32)) AS addrRegionId,
  CAST(vm.addr_maktab_id AS VARCHAR(32)) AS addrMaktabId,
  CAST(vm.nakhebin_region_id AS VARCHAR(32)) AS nakhebinRegionId,
  CAST(vm.nakhebin_maktab_id AS VARCHAR(32)) AS nakhebinMaktabId,
  CONVERT(VARCHAR(32), vm.created_at, 126) AS createdAt
FROM paged p
LEFT JOIN dbo.hwy_ref_base_information BI_iv WITH (NOLOCK) ON BI_iv.id = p.InterviewFinalResult
LEFT JOIN dbo.vw_hwy_members vm WITH (NOLOCK) ON vm.id = CAST(p.Id AS VARCHAR(32))';

    EXEC sp_executesql @interview_sql, N'@offset INT, @page_size INT', @offset = @offset, @page_size = @page_size;
    RETURN;
  END;

  DECLARE @view sysname = CASE LOWER(LTRIM(RTRIM(@stage)))
    WHEN N'security' THEN N'vw_hwy_candidate_pipeline_security'
    WHEN N'interview' THEN N'vw_hwy_candidate_pipeline_interview'
    WHEN N'courses' THEN N'vw_hwy_candidate_pipeline_courses'
    WHEN N'install' THEN N'vw_hwy_candidate_pipeline_install'
    ELSE NULL
  END;

  IF @view IS NULL OR OBJECT_ID(N'dbo.' + @view, N'V') IS NULL
    THROW 50400, N'Legacy candidate pipeline view is not available for this stage.', 1;

  DECLARE @areaCol NVARCHAR(MAX) = N'';
  IF LOWER(LTRIM(RTRIM(@stage))) = N'security'
    SET @areaCol = N', V.DaysFrom AS daysFrom, CAST(V.IsApproved AS INT) AS isApprovedRow, (SELECT TOP 1 SP.can_get_masooliat FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=V.Id ORDER BY SP.created_on DESC) AS lastSecurityProfileCanGetMasooliat';
  ELSE IF LOWER(LTRIM(RTRIM(@stage))) = N'interview'
    SET @areaCol = N', CONVERT(VARCHAR(32), V.InterviewOn, 126) AS interviewOn, CAST(V.InterviewFinalResult AS VARCHAR(32)) AS interviewFinalResult, (SELECT TOP 1 B.title FROM dbo.hwy_member_interviews_2022 I2022 WITH (NOLOCK) LEFT JOIN dbo.hwy_ref_base_information B WITH (NOLOCK) ON B.id = I2022.final_result WHERE I2022.member_id = V.Id ORDER BY I2022.created_on DESC) AS interviewFinalResultTitle, CAST(V.RoleId AS VARCHAR(32)) AS roleId';
  ELSE IF LOWER(LTRIM(RTRIM(@stage))) = N'courses'
    SET @areaCol = N', CAST(V.PassedNecessaryDorat AS BIT) AS passedNecessaryDorat';
  ELSE IF LOWER(LTRIM(RTRIM(@stage))) = N'install'
    SET @areaCol = N', CAST(V.AreaId AS VARCHAR(32)) AS areaId, CAST(V.NecessaryDoratPassed AS BIT) AS necessaryDoratPassed, V.InterviewFinalResultTitle AS interviewFinalResultTitle, CAST(V.ProfilePerfect AS INT) AS profilePerfect, CAST(V.AllImagesApproved AS BIT) AS allImagesApproved, CAST(V.HasOath AS BIT) AS hasOath';

  DECLARE @passedDoratCol NVARCHAR(128) = N'CAST(NULL AS NVARCHAR(MAX)) AS passedDoratHtml';
  IF LOWER(LTRIM(RTRIM(@stage))) = N'courses'
    SET @passedDoratCol = N'V.PassedDorat AS passedDoratHtml';

  DECLARE @sql NVARCHAR(MAX) = N'
    SELECT
      CAST(V.Id AS VARCHAR(32)) AS id,
      V.UserName AS username,
      CAST(V.UserId AS VARCHAR(32)) AS userId,
      V.FirstName AS firstName,
      V.FatherName AS fatherName,
      V.GrandFatherName AS grandFatherName,
      V.LastName AS lastName,
      V.Phone1 AS phone1,
      vm.electoral_division_path AS electoralDivisionPath,
      (SELECT TOP 1 BI.title FROM dbo.hwy_ref_base_information BI WITH (NOLOCK) WHERE BI.id = V.NakhebJoinProvinceId) AS nakhebJoinProvinceName,
      (SELECT TOP 1 C.circle_name FROM dbo.hwy_ref_h_circles C WITH (NOLOCK) WHERE C.circle_id = V.NakhebJoinCircleId) AS nakhebJoinCircleName,
      (SELECT TOP 1 T.tamvin_name FROM dbo.hwy_ref_h_tamvinat T WITH (NOLOCK) WHERE T.tamvin_id = V.NakhebJoinTamvinId) AS nakhebJoinTamvinName,
      (SELECT TOP 1 BI.title FROM dbo.hwy_ref_base_information BI WITH (NOLOCK) WHERE BI.id = V.NakhebJoinEghteraId) AS nakhebJoinEghteraName,
      CAST(V.NakhebJoinEghteraId AS VARCHAR(32)) AS nakhebJoinEghteraId,
      CAST(V.GenderId AS VARCHAR(32)) AS genderId,
      V.RoleOfTarshih AS roleOfTarshih,
      V.AreaOfTarshih AS areaOfTarshih,
      CONVERT(VARCHAR(32), V.DateOfTarshih, 126) AS dateOfTarshih,
      V.MoarasshehOfTarshih AS moarasshehOfTarshih,
      ' + @passedDoratCol + @areaCol + N',
      COUNT(*) OVER() AS pipeline_total,
      vm.display_full_name AS displayFullName,
      vm.avatar_url AS avatarUrl,
      vm.birth_year AS birthYear,
      vm.gender_code AS genderCode,
      CONVERT(VARCHAR(32), vm.membership_on, 126) AS membershipOn,
      vm.phone2 AS phone2,
      vm.tracking_code AS trackingCode,
      CAST(vm.addr_province_id AS VARCHAR(32)) AS addrProvinceId,
      CAST(vm.addr_region_id AS VARCHAR(32)) AS addrRegionId,
      CAST(vm.addr_maktab_id AS VARCHAR(32)) AS addrMaktabId,
      CAST(vm.nakhebin_region_id AS VARCHAR(32)) AS nakhebinRegionId,
      CAST(vm.nakhebin_maktab_id AS VARCHAR(32)) AS nakhebinMaktabId,
      CONVERT(VARCHAR(32), vm.created_at, 126) AS createdAt
    FROM dbo.' + QUOTENAME(@view) + N' V WITH (NOLOCK)
    LEFT JOIN dbo.vw_hwy_members vm WITH (NOLOCK) ON vm.id = CAST(V.Id AS VARCHAR(32))
    WHERE 1=1';

  SET @sql = @sql + dbo.hwy_candidate_pipeline_where_clause(
    @stage, @list_type, @role_id, @is_approved, @approve_state, @passed_or_not,
    @interview_approve_state, @scope_unrestricted, @nakheb_province_id, @nakheb_circle_id,
    @nakheb_tamvin_id, @date_start, @date_end, @username, @phone, @gender_id, N'V',
    @actor_user_name, @area_limit_id, @geo_limits_csv);

  SET @sql = @sql + N' ORDER BY V.DateOfTarshih DESC, V.Id DESC OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY';

  EXEC sp_executesql @sql, N'@offset INT, @page_size INT', @offset = @offset, @page_size = @page_size;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_candidate_pipeline_install_approve
  @member_id BIGINT,
  @area_id BIGINT,
  @actor NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @len INT = LEN(CAST(@area_id AS NVARCHAR(32)));
  IF @len = 4
  BEGIN
    IF OBJECT_ID(N'dbo.HWY_SP_H_Tamvin_Approve_SuggestedResponsible', N'P') IS NULL
      THROW 50400, N'Legacy tamvin approve SP is not available.', 1;
    DECLARE @r BIT;
    EXEC dbo.HWY_SP_H_Tamvin_Approve_SuggestedResponsible
      @MemberId = @member_id,
      @TamvinId = @area_id,
      @Actor = @actor,
      @Result = @r OUTPUT;
    IF @r = 0 THROW 50422, N'Tamvin responsibility approve failed.', 1;
    RETURN;
  END;
  IF OBJECT_ID(N'dbo.HWY_SP_H_Eghtera_Approve_SuggestedResponsible', N'P') IS NULL
    THROW 50400, N'Legacy eghtera approve SP is not available.', 1;
  DECLARE @re BIT;
  EXEC dbo.HWY_SP_H_Eghtera_Approve_SuggestedResponsible
    @MemberId = @member_id,
    @EghteraId = @area_id,
    @Actor = @actor,
    @Result = @re OUTPUT;
  IF @re = 0 THROW 50422, N'Eghtera responsibility approve failed.', 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_candidate_pipeline_security_record
  @member_id BIGINT,
  @can_get_identity_card INT,
  @can_get_identity_card_note NVARCHAR(1024) = NULL,
  @can_get_masooliat INT,
  @can_get_masooliat_note NVARCHAR(1024) = NULL,
  @can_be_member_of_aammeh INT,
  @can_be_member_of_aammeh_note NVARCHAR(1024) = NULL,
  @allows_responsibility INT,
  @allows_responsibility_note NVARCHAR(1024) = NULL,
  @actor NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.hwy_member_security_profile_history', N'U') IS NULL
    THROW 50400, N'hwy_member_security_profile_history table is not available.', 1;

  IF @can_get_masooliat NOT IN (211751, 211752, 211753)
    OR @can_get_identity_card NOT IN (211751, 211752, 211753)
    OR @can_be_member_of_aammeh NOT IN (211751, 211752, 211753)
    OR @allows_responsibility NOT IN (211751, 211752, 211753)
    THROW 50422, N'Invalid security opinion value.', 1;

  IF @can_get_masooliat = 211752 AND NULLIF(LTRIM(RTRIM(@can_get_masooliat_note)), N'') IS NULL
    THROW 50422, N'CanGetMasooliat rejection note is required.', 1;

  DECLARE @actor_name NVARCHAR(64) = COALESCE(NULLIF(LTRIM(RTRIM(@actor)), N''), N'system');
  INSERT INTO dbo.hwy_member_security_profile_history (
    id, member_id,
    can_get_identity_card, can_get_identity_card_note,
    can_get_masooliat, can_get_masooliat_note,
    can_be_member_of_aammeh, can_be_member_of_aammeh_note,
    allows_responsibility, allows_responsibility_note,
    created_by, created_on
  )
  VALUES (
    NEWID(), @member_id,
    @can_get_identity_card, COALESCE(@can_get_identity_card_note, N''),
    @can_get_masooliat, COALESCE(@can_get_masooliat_note, N''),
    @can_be_member_of_aammeh, COALESCE(@can_be_member_of_aammeh_note, N''),
    @allows_responsibility, COALESCE(@allows_responsibility_note, N''),
    @actor_name, SYSUTCDATETIME()
  );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_candidate_pipeline_interview_last
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.hwy_member_interviews_2022', N'U') IS NULL
    THROW 50400, N'hwy_member_interviews_2022 table is not available.', 1;

  SELECT TOP 1
    CAST(I.id AS VARCHAR(36)) AS interviewId,
    CAST(I.member_id AS VARCHAR(32)) AS memberId,
    CONVERT(VARCHAR(32), I.interview_on, 126) AS interviewOn,
    I.karizma AS karizma,
    I.like_to_learn_more AS likeToLearnMore,
    I.show_is_fan AS showIsFan,
    I.ability_to_make_team AS abilityToMakeTeam,
    I.ghodrat_elec AS ghodratElec,
    I.knows_masoolin AS knowsMasoolin,
    CAST(I.is_motefaregh AS BIT) AS isMotefaregh,
    I.is_motefaregh_saat AS isMotefareghSaat,
    I.note AS note,
    I.final_result AS finalResult,
    FR.Title AS finalResultTitle,
    I.created_by AS createdBy,
    CONVERT(VARCHAR(32), I.created_on, 126) AS createdOn,
    (
      SELECT
        CAST(M.Id AS VARCHAR(32)) AS memberId,
        M.UserName AS username,
        M.FirstName AS firstName,
        M.FatherName AS fatherName,
        M.GrandFatherName AS grandFatherName,
        M.LastName AS lastName
      FROM dbo.hwy_member_interviews_2022_hazerin H WITH (NOLOCK)
      INNER JOIN dbo.HWY_Members M WITH (NOLOCK) ON M.Id = H.hazer_id
      WHERE H.interview_id = I.id
      FOR JSON PATH
    ) AS hazerinJson
  FROM dbo.hwy_member_interviews_2022 I WITH (NOLOCK)
  LEFT JOIN dbo.hwy_ref_base_information FR WITH (NOLOCK) ON FR.id = I.final_result
  WHERE I.member_id = @member_id
  ORDER BY I.created_on DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_candidate_pipeline_interview_create
  @member_id BIGINT,
  @interview_on NVARCHAR(32),
  @karizma INT,
  @like_to_learn_more INT,
  @show_is_fan INT,
  @ability_to_make_team INT,
  @ghodrat_elec INT,
  @knows_masoolin INT,
  @is_motefaregh BIT,
  @is_motefaregh_saat INT,
  @note NVARCHAR(2048),
  @final_result INT,
  @hazerin_json NVARCHAR(MAX),
  @actor NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.hwy_member_interviews_2022', N'U') IS NULL
    THROW 50400, N'hwy_member_interviews_2022 table is not available.', 1;
  IF OBJECT_ID(N'dbo.hwy_member_interviews_2022_hazerin', N'U') IS NULL
    THROW 50400, N'hwy_member_interviews_2022_hazerin table is not available.', 1;
  IF @final_result NOT IN (213609, 213610, 213611)
    THROW 50422, N'Invalid interview final result.', 1;

  DECLARE @unset_score INT = 211525;
  IF @karizma = @unset_score OR @like_to_learn_more = @unset_score OR @show_is_fan = @unset_score
    OR @ability_to_make_team = @unset_score OR @ghodrat_elec = @unset_score OR @knows_masoolin = @unset_score
    THROW 50422, N'All interview score dimensions must be answered.', 1;

  IF @is_motefaregh_saat IS NULL OR @is_motefaregh_saat < 1 OR @is_motefaregh_saat > 24
    THROW 50422, N'IsMotefaregh_Saat must be between 1 and 24.', 1;

  IF @note IS NULL OR LEN(LTRIM(RTRIM(@note))) < 50
    THROW 50422, N'Interview note must be at least 50 characters.', 1;

  DECLARE @actor_name NVARCHAR(64) = COALESCE(NULLIF(LTRIM(RTRIM(@actor)), N''), N'system');
  DECLARE @interview_id UNIQUEIDENTIFIER = NEWID();

  INSERT INTO dbo.hwy_member_interviews_2022 (
    id, member_id, karizma, like_to_learn_more, show_is_fan, ability_to_make_team,
    ghodrat_elec, knows_masoolin, is_motefaregh, is_motefaregh_saat,
    final_result, interview_on, note, created_by, created_on
  )
  VALUES (
    @interview_id, @member_id, @karizma, @like_to_learn_more, @show_is_fan, @ability_to_make_team,
    @ghodrat_elec, @knows_masoolin, @is_motefaregh, @is_motefaregh_saat,
    @final_result, TRY_CONVERT(DATETIME, @interview_on, 126), @note,
    @actor_name, SYSUTCDATETIME()
  );

  IF @hazerin_json IS NOT NULL AND LTRIM(RTRIM(@hazerin_json)) <> N''
  BEGIN
    INSERT INTO dbo.hwy_member_interviews_2022_hazerin (id, interview_id, hazer_id)
    SELECT NEWID(), @interview_id, J.hazer_id
    FROM OPENJSON(@hazerin_json) WITH (hazer_id BIGINT '$.hazer_id') AS J
    WHERE J.hazer_id IS NOT NULL;
  END;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_candidate_pipeline_install_reject
  @member_id BIGINT,
  @area_id BIGINT,
  @actor NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @len INT = LEN(CAST(@area_id AS NVARCHAR(32)));
  IF @len = 4
  BEGIN
    IF OBJECT_ID(N'dbo.HWY_SP_H_Tamvin_Remove_SuggestedResponsible', N'P') IS NULL
      THROW 50400, N'Legacy tamvin remove suggestion SP is not available.', 1;
    EXEC dbo.HWY_SP_H_Tamvin_Remove_SuggestedResponsible
      @MemberId = @member_id,
      @TamvinId = @area_id,
      @Actor = @actor;
    RETURN;
  END;
  IF OBJECT_ID(N'dbo.HWY_SP_H_Eghtera_Remove_SuggestedResponsible', N'P') IS NULL
    THROW 50400, N'Legacy eghtera remove suggestion SP is not available.', 1;
  EXEC dbo.HWY_SP_H_Eghtera_Remove_SuggestedResponsible
    @MemberId = @member_id,
    @EghteraId = @area_id,
    @Actor = @actor;
END;
GO
