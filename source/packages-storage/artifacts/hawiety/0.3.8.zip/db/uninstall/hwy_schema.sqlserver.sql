-- HWY package Phase 1 uninstall (SQL Server)

IF OBJECT_ID(N'dbo.hwy_activity_attendances', N'U') IS NOT NULL DROP TABLE dbo.hwy_activity_attendances;
GO
IF OBJECT_ID(N'dbo.hwy_course_attendances', N'U') IS NOT NULL DROP TABLE dbo.hwy_course_attendances;
GO
IF OBJECT_ID(N'dbo.hwy_activity_approval_steps', N'U') IS NOT NULL DROP TABLE dbo.hwy_activity_approval_steps;
GO
IF OBJECT_ID(N'dbo.hwy_course_approval_steps', N'U') IS NOT NULL DROP TABLE dbo.hwy_course_approval_steps;
GO
IF OBJECT_ID(N'dbo.hwy_activity_files', N'U') IS NOT NULL DROP TABLE dbo.hwy_activity_files;
GO
IF OBJECT_ID(N'dbo.hwy_activities', N'U') IS NOT NULL DROP TABLE dbo.hwy_activities;
GO
IF OBJECT_ID(N'dbo.hwy_courses', N'U') IS NOT NULL DROP TABLE dbo.hwy_courses;
GO
GO
IF OBJECT_ID(N'dbo.hwy_geo_responsibility_requests', N'U') IS NOT NULL DROP TABLE dbo.hwy_geo_responsibility_requests;
GO
IF OBJECT_ID(N'dbo.hwy_username_repo', N'U') IS NOT NULL DROP TABLE dbo.hwy_username_repo;
GO
IF OBJECT_ID(N'dbo.hwy_tracking_codes', N'U') IS NOT NULL DROP TABLE dbo.hwy_tracking_codes;
GO
IF OBJECT_ID(N'dbo.hwy_member_list_defs', N'U') IS NOT NULL DROP TABLE dbo.hwy_member_list_defs;
GO
IF OBJECT_ID(N'dbo.hwy_member_security_profile', N'U') IS NOT NULL DROP TABLE dbo.hwy_member_security_profile;
GO
IF OBJECT_ID(N'dbo.hwy_member_notes', N'U') IS NOT NULL DROP TABLE dbo.hwy_member_notes;
GO
IF OBJECT_ID(N'dbo.hwy_member_files', N'U') IS NOT NULL DROP TABLE dbo.hwy_member_files;
GO
IF OBJECT_ID(N'dbo.hwy_member_institutes', N'U') IS NOT NULL DROP TABLE dbo.hwy_member_institutes;
GO
IF OBJECT_ID(N'dbo.FK_hwy_nakhebin_member_id', N'F') IS NOT NULL
  ALTER TABLE dbo.hwy_nakhebin DROP CONSTRAINT FK_hwy_nakhebin_member_id;
GO
IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NOT NULL DROP TABLE dbo.hwy_members;
GO
IF OBJECT_ID(N'dbo.hwy_nakhebin', N'U') IS NOT NULL DROP TABLE dbo.hwy_nakhebin;
GO
IF OBJECT_ID(N'dbo.hwy_institutes', N'U') IS NOT NULL DROP TABLE dbo.hwy_institutes;
GO
