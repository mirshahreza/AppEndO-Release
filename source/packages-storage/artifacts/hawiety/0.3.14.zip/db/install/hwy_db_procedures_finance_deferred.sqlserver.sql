-- AUTO-GENERATED — do not edit by hand
-- Source: MembersV2 via npm run hwy:gen-finance-procs
-- Standard names: dbo.hwy_* / dbo.vw_hwy_*

-- HWY_SP_Masoolin_BelowOfficials → hwy_masoolin_below_officials
CREATE OR ALTER PROCEDURE dbo.hwy_masoolin_below_officials
	@member_id BIGINT  --= 1326379
	,@CurrentUserName VARCHAR(50) --= '121971'
AS
BEGIN

--DECLARE 
--	@member_id BIGINT  = 1299730
--	,@CurrentUserName VARCHAR(50) = '633496'

DECLARE 
	@CurrentMemberId		INT,
	@user_id					INT,
	@area_limit_id			INT,
	@item_id					INT,
	@role_id					INT
	
	
SELECT TOP 1 

 @user_id					= T1.user_id
,@area_limit_id				= T1.area_limit_id
,@item_id					= T4.item_id
,@role_id					= T3.id

FROM hwy_members T1
INNER JOIN vw_hwy_platform_user_roles_finance T2 ON T2.user_id = T1.user_id
INNER JOIN vw_hwy_platform_roles T3 ON T3.id= T2.role_id AND T3.is_executive = 1
INNER JOIN hwy_member_area_limits T4 ON T4.member_id = T1.id
WHERE T1.id = @member_id


SELECT TOP 1
	@CurrentMemberId = id
FROM hwy_members  T1
WHERE T1.username = @CurrentUserName


IF(@role_id = 1000003)
BEGIN

	SELECT
		 T1.circle_id AS  item_id
		,T1.circle_name AS item_title
		,T5.role_name
		,T3.area_limit_id
		,T3.id
		,T3.username
		,T3.user_id
		,T3.nakhebin_id
		,T3.phone1
		,T3.phone2
		,T3.first_name
		,T3.father_name
		,T3.grandfather_name
		,T3.family_name
		,T3.gender_id
	FROM hwy_ref_h_circles T1 
	INNER JOIN hwy_member_area_limits T2 ON T2.item_id = T1.circle_id
	INNER JOIN hwy_members T3 ON T3.id= T2.member_id --AND T2.area_limit_id = 111325
	INNER JOIN vw_hwy_platform_user_roles_finance T4 ON T4.user_id = T3.user_id
	INNER JOIN vw_hwy_platform_roles T5 ON T5.id= T4.role_id AND T5.is_executive = 1 AND T5.id = 1000027
	WHERE T1.hwy_state_id = @item_id
	AND (@CurrentUserName = 'admin' OR T3.gender_id IN (SELECT item_id FROM hwy_ref_members_gender_limits TT WHERE TT.member_id = @CurrentMemberId))

END
ELSE IF (@role_id = 1000027)
BEGIN

	SELECT
		 T1.tamvin_id AS  item_id
		,T1.tamvin_name AS item_title
		,T5.role_name
		,T3.area_limit_id
		,T3.id
		,T3.username
		,T3.user_id
		,T3.nakhebin_id
		,T3.phone1
		,T3.phone2
		,T3.first_name
		,T3.father_name
		,T3.grandfather_name
		,T3.family_name
		,T3.gender_id
	FROM hwy_ref_h_tamvinat T1 
	INNER JOIN hwy_member_area_limits T2 ON T2.item_id = T1.tamvin_id
	INNER JOIN hwy_members T3 ON T3.id= T2.member_id --AND T2.area_limit_id = 111325
	INNER JOIN vw_hwy_platform_user_roles_finance T4 ON T4.user_id = T3.user_id
	INNER JOIN vw_hwy_platform_roles T5 ON T5.id= T4.role_id AND T5.is_executive = 1 AND T5.id = 1000004
	WHERE T1.circle_id = @item_id
	AND (@CurrentUserName = 'admin' OR T3.gender_id IN (SELECT item_id FROM hwy_ref_members_gender_limits TT WHERE TT.member_id = @CurrentMemberId))

END
ELSE IF (@role_id = 1000004)
BEGIN

	SELECT
		 T1.eghtera_id AS  item_id
		,T1.eghtera_name AS item_title
		,T5.role_name
		,T3.area_limit_id
		,T3.id
		,T3.username
		,T3.user_id
		,T3.nakhebin_id
		,T3.phone1
		,T3.phone2
		,T3.first_name
		,T3.father_name
		,T3.grandfather_name
		,T3.family_name
		,T3.gender_id
	FROM hwy_ref_h_eghteraat T1 
	INNER JOIN hwy_member_area_limits T2 ON T2.item_id = T1.eghtera_id
	INNER JOIN hwy_members T3 ON T3.id= T2.member_id --AND T2.area_limit_id = 111325
	INNER JOIN vw_hwy_platform_user_roles_finance T4 ON T4.user_id = T3.user_id
	INNER JOIN vw_hwy_platform_roles T5 ON T5.id= T4.role_id AND T5.is_executive = 1 AND T5.id = 1000005
	WHERE T1.tamvin_id = @item_id
	AND (@CurrentUserName = 'admin' OR T3.gender_id IN (SELECT item_id FROM hwy_ref_members_gender_limits TT WHERE TT.member_id = @CurrentMemberId))
END
ELSE IF (@role_id = 1000005)
BEGIN

	SELECT
		 T1.eghtera_id AS  item_id
		,T1.eghtera_name AS item_title
		,T5.role_name
		,T3.area_limit_id
		,T3.id
		,T3.username
		,T3.user_id
		,T3.nakhebin_id
		,T3.phone1
		,T3.phone2
		,T3.first_name
		,T3.father_name
		,T3.grandfather_name
		,T3.family_name
		,T3.gender_id
	FROM hwy_ref_h_eghteraat T1 
	INNER JOIN hwy_member_area_limits T2 ON T2.item_id = T1.eghtera_id
	INNER JOIN hwy_members T3 ON T3.id= T2.member_id 
	INNER JOIN vw_hwy_platform_user_roles_finance T4 ON T4.user_id = T3.user_id
	INNER JOIN vw_hwy_platform_roles T5 ON T5.id= T4.role_id AND T5.is_executive = 1 AND T5.id = 1000046
	WHERE T1.eghtera_id = @item_id
	AND (@CurrentUserName = 'admin' OR T3.gender_id IN (SELECT item_id FROM hwy_ref_members_gender_limits TT WHERE TT.member_id = @CurrentMemberId))
END


END
GO

-- HWY_SP_Masoolin_TopOfficials → hwy_masoolin_top_officials
CREATE OR ALTER PROCEDURE dbo.hwy_masoolin_top_officials
	@member_id BIGINT  --= 1326379
	,@CurrentUserName VARCHAR(50) --= '121971'
AS
BEGIN
DECLARE 
	@CurrentMemberId		INT,
	@user_id					INT,
	@area_limit_id			INT,
	@AreaLimitProvinceId	INT,
	@AreaLimitCircleId		INT,
	@AreaLimitTamvinId		INT
	
SELECT TOP 1 

 @user_id					= T1.user_id
,@area_limit_id				= T1.area_limit_id
,@AreaLimitProvinceId		= T1.area_limit_province_id
,@AreaLimitCircleId		= T1.area_limit_circle_id
,@AreaLimitTamvinId		= T1.area_limit_tamvin_id
FROM hwy_members T1
INNER JOIN vw_hwy_platform_user_roles_finance T2 ON T2.user_id = T1.user_id
INNER JOIN vw_hwy_platform_roles T3 ON T3.id= T2.role_id AND T3.is_executive = 1
WHERE T1.id = @member_id


SELECT TOP 1
	@CurrentMemberId = id
FROM hwy_members  T1
WHERE T1.username = @CurrentUserName

	SELECT
		 T2.area_limit_id
		,T1.item_id
		,T5.title AS item_title
		,T4.role_name
		,T2.id
		,T2.username
		,T2.user_id
		,T2.nakhebin_id
		,T2.phone1
		,T2.phone2
		,T2.first_name
		,T2.father_name
		,T2.grandfather_name
		,T2.family_name
		,T2.gender_id
	FROM hwy_member_area_limits T1
	INNER JOIN hwy_members T2 ON T2.id= T1.member_id AND T2.area_limit_id = 111322 
	INNER JOIN vw_hwy_platform_user_roles_finance T3 ON T3.user_id = T2.user_id
	INNER JOIN vw_hwy_platform_roles T4 ON T4.id= T3.role_id AND T4.is_executive = 1 AND T4.id = 1000003
	INNER JOIN hwy_ref_base_information T5 ON T5.id= T1.item_id
	WHERE T1.item_id = @AreaLimitProvinceId
	AND (@CurrentUserName = 'admin' OR T2.gender_id IN (SELECT item_id FROM hwy_ref_members_gender_limits TT WHERE TT.member_id = @CurrentMemberId))
	

UNION ALL

	SELECT
		T2.area_limit_id
		,T1.item_id
		,T5.circle_name AS item_title
		,T4.role_name
		,T2.id
		,T2.username
		,T2.user_id
		,T2.nakhebin_id
		,T2.phone1
		,T2.phone2
		,T2.first_name
		,T2.father_name
		,T2.grandfather_name
		,T2.family_name
		,T2.gender_id
	FROM hwy_member_area_limits T1
	INNER JOIN hwy_members T2 ON T2.id= T1.member_id AND T2.area_limit_id = 111325 
	INNER JOIN vw_hwy_platform_user_roles_finance T3 ON T3.user_id = T2.user_id
	INNER JOIN vw_hwy_platform_roles T4 ON T4.id= T3.role_id AND T4.is_executive = 1 AND T4.id = 1000027
	INNER JOIN hwy_ref_h_circles T5 ON T5.circle_id = T1.item_id
	WHERE T1.item_id = @AreaLimitCircleId
	AND (@CurrentUserName = 'admin' OR T2.gender_id IN (SELECT item_id FROM hwy_ref_members_gender_limits TT WHERE TT.member_id = @CurrentMemberId))

UNION ALL

	SELECT
		T2.area_limit_id
		,T1.item_id
		,T5.tamvin_name AS item_title
		,T4.role_name
		,T2.id
		,T2.username
		,T2.user_id
		,T2.nakhebin_id
		,T2.phone1
		,T2.phone2
		,T2.first_name
		,T2.father_name
		,T2.grandfather_name
		,T2.family_name
		,T2.gender_id
	FROM hwy_member_area_limits T1
	INNER JOIN hwy_members T2 ON T2.id= T1.member_id AND T2.area_limit_id = 111323 
	INNER JOIN vw_hwy_platform_user_roles_finance T3 ON T3.user_id = T2.user_id
	INNER JOIN vw_hwy_platform_roles T4 ON T4.id= T3.role_id AND T4.is_executive = 1 AND T4.id = 1000004
	INNER JOIN hwy_ref_h_tamvinat T5 ON T5.tamvin_id = T1.item_id
	WHERE T1.item_id = @AreaLimitTamvinId
	AND (@CurrentUserName = 'admin' OR T2.gender_id IN (SELECT item_id FROM hwy_ref_members_gender_limits TT WHERE TT.member_id = @CurrentMemberId))

	UNION ALL

	SELECT
		T2.area_limit_id
		,T1.item_id
		,T5.tamvin_name AS item_title
		,T4.role_name
		,T2.id
		,T2.username
		,T2.user_id
		,T2.nakhebin_id
		,T2.phone1
		,T2.phone2
		,T2.first_name
		,T2.father_name
		,T2.grandfather_name
		,T2.family_name
		,T2.gender_id
	FROM hwy_member_area_limits T1
	INNER JOIN hwy_members T2 ON T2.id= T1.member_id AND T2.area_limit_id = 111324 
	INNER JOIN vw_hwy_platform_user_roles_finance T3 ON T3.user_id = T2.user_id
	INNER JOIN vw_hwy_platform_roles T4 ON T4.id= T3.role_id AND T4.is_executive = 1 AND T4.id = 1000005
	INNER JOIN hwy_ref_h_tamvinat T5 ON T5.tamvin_id = T1.item_id
	WHERE T1.item_id = @AreaLimitTamvinId
	AND (@CurrentUserName = 'admin' OR T2.gender_id IN (SELECT item_id FROM hwy_ref_members_gender_limits TT WHERE TT.member_id = @CurrentMemberId))


END
GO

-- HWY_SP_Masoolin_SetPayableAuto → hwy_masoolin_set_payable_auto
CREATE OR ALTER PROCEDURE dbo.hwy_masoolin_set_payable_auto
    @AreaId INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @role_id INT;
    DECLARE @AreaStr VARCHAR(20) = CAST(@AreaId AS VARCHAR(20));

    -- Determine role_id based on AreaId string length
    IF (LEN(@AreaStr) = 4) SET @role_id = 1000004; -- Maktab
    IF (LEN(@AreaStr) = 6) SET @role_id = 1000005; -- Mantagheh
    IF (LEN(@AreaStr) = 7) SET @role_id = 1000027; -- Circle

    -- Return empty result set if no valid role_id was matched
    IF @role_id IS NULL
    BEGIN
        SELECT NULL AS user_id, NULL AS gender_id, NULL AS payable, NULL AS created_at WHERE 1 = 0;
        RETURN;
    END

    -- Table Variable to store initial qualified members data
    DECLARE @QualifiedMembers TABLE (
        member_id INT,
        user_id INT,
        gender_id INT,
        payable BIT,
        created_at DATETIME
    );

    -- Populate the table variable
    INSERT INTO @QualifiedMembers (member_id, user_id, gender_id, payable, created_at)
    SELECT
        M.id AS member_id,
        M.user_id,
        M.gender_id,
        M.chief_masool,
        MIN(AL.created_on) AS created_at
    FROM dbo.vw_hwy_members_legacy_row AS M
    INNER JOIN dbo.hwy_member_area_limits AS AL
        ON AL.member_id = M.id
    WHERE AL.item_id = @AreaId
      AND AL.approved = 1
      AND EXISTS (
          SELECT 1
          FROM dbo.vw_hwy_platform_user_roles_finance AS UR
          WHERE UR.user_id = M.user_id
            AND UR.role_id = @role_id
            AND UR.approved = 1
      )
    GROUP BY M.id, M.user_id, M.gender_id, M.chief_masool;

    -- CTE to rank members and check for existing president
    ;WITH Ranked AS (
        SELECT
            member_id,
            gender_id,
            ISNULL(payable, 0) AS payable,
            ROW_NUMBER() OVER (
                PARTITION BY gender_id
                ORDER BY created_at ASC, user_id ASC
            ) AS row_num,
            MAX(CASE WHEN ISNULL(payable, 0) = 1 THEN 1 ELSE 0 END)
                OVER (PARTITION BY gender_id) AS has_president
        FROM @QualifiedMembers
    )
    UPDATE M
    SET chief_masool = 1
    FROM dbo.hwy_members AS M
    INNER JOIN Ranked AS R
        ON R.member_id = M.id
    WHERE
        -- Promote the oldest member only if no president exists
        R.has_president = 0 
        AND R.row_num = 1;

    -- Return the updated list of members
    SELECT
        QM.user_id,
        QM.gender_id,
        M.chief_masool,
        QM.created_at
    FROM @QualifiedMembers AS QM
    INNER JOIN dbo.hwy_members AS M
        ON M.id= QM.member_id
    ORDER BY QM.gender_id, QM.created_at, QM.user_id;

END
GO

