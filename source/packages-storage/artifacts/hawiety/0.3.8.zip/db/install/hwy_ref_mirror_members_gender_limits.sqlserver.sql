-- Standardize dbo.HWY_Members_GenderLimits → physical hwy_ref_members_gender_limits (no legacy view alias).

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF OBJECT_ID(N'dbo.hwy_ref_members_gender_limits', N'U') IS NOT NULL
   AND EXISTS (
     SELECT 1
     FROM sys.columns c
     WHERE c.object_id = OBJECT_ID(N'dbo.hwy_ref_members_gender_limits')
       AND c.name = N'id'
       AND TYPE_NAME(c.user_type_id) <> N'uniqueidentifier'
   )
BEGIN
  DROP TABLE dbo.hwy_ref_members_gender_limits;
END;
GO

IF OBJECT_ID(N'dbo.hwy_ref_members_gender_limits', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_ref_members_gender_limits (
    id        UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    member_id BIGINT NOT NULL,
    item_id   BIGINT NOT NULL
  );
  CREATE INDEX IX_hwy_ref_members_gender_limits_member ON dbo.hwy_ref_members_gender_limits (member_id);
END;
GO

IF OBJECT_ID(N'dbo.HWY_Members_GenderLimits', N'U') IS NOT NULL
BEGIN
  INSERT INTO dbo.hwy_ref_members_gender_limits (id, member_id, item_id)
  SELECT g.Id, g.MemberId, g.ItemId
  FROM dbo.HWY_Members_GenderLimits g WITH (NOLOCK)
  WHERE NOT EXISTS (SELECT 1 FROM dbo.hwy_ref_members_gender_limits t WHERE t.id = g.Id);

  DROP TABLE dbo.HWY_Members_GenderLimits;
END;
GO

IF OBJECT_ID(N'dbo.HWY_Members_GenderLimits', N'V') IS NOT NULL
  DROP VIEW dbo.HWY_Members_GenderLimits;
GO
