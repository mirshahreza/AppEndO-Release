-- Legacy meetings management (HWY_Meetings_Instances + BaseInformation meetings).

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_list_definitions
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.hwy_ref_base_information', N'U') IS NULL
    THROW 50400, N'hwy_ref_base_information is not available.', 1;

  SELECT
    CAST(bi.id AS VARCHAR(32)) AS id,
    bi.title AS title,
    CAST(bi.view_order AS INT) AS view_order
  FROM dbo.hwy_ref_base_information bi WITH (NOLOCK)
  WHERE bi.parent_id = 214040
  ORDER BY bi.view_order ASC, bi.id ASC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_instances_count
  @meeting_id BIGINT = NULL,
  @username NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_Meetings_Instances', N'U') IS NULL
    THROW 50400, N'Legacy HWY_Meetings_Instances is not available.', 1;

  SELECT COUNT(*) AS total
  FROM dbo.HWY_Meetings_Instances mi WITH (NOLOCK)
  WHERE (@meeting_id IS NULL OR mi.MeetingId = @meeting_id)
    AND (
      @username IS NULL
      OR mi.id IN (
        SELECT H.InstanceId
        FROM dbo.HWY_Meetings_Hazerin H WITH (NOLOCK)
        INNER JOIN dbo.hwy_members M WITH (NOLOCK) ON M.id= H.member_id
        WHERE M.username LIKE N'%' + @username + N'%'
      )
    );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_instances_list
  @meeting_id BIGINT = NULL,
  @username NVARCHAR(128) = NULL,
  @offset INT = 0,
  @page_size INT = 25
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_Meetings_Instances', N'U') IS NULL
    THROW 50400, N'Legacy HWY_Meetings_Instances is not available.', 1;

  SELECT
    CAST(mi.id AS VARCHAR(32)) AS id,
    CAST(mi.MeetingId AS VARCHAR(32)) AS meeting_id,
    CAST(creator.id AS VARCHAR(32)) AS member_id,
    CONVERT(VARCHAR(32), mi.created_at, 126) AS created_at,
    CONVERT(VARCHAR(32), mi.EventDate, 126) AS event_date,
    NULL AS title,
    bi.title AS meeting_title,
    creator.username AS username,
    creator.first_name AS first_name,
    creator.father_name AS father_name,
    creator.family_name AS family_name,
    (SELECT COUNT(*) FROM dbo.HWY_Meetings_Hazerin H WITH (NOLOCK) WHERE H.InstanceId = mi.id) AS hazerin_count,
    (SELECT COUNT(*) FROM dbo.HWY_Meetings_Members MM WITH (NOLOCK) WHERE MM.MeetingId = mi.MeetingId AND MM.IsMemberYet = 1) AS members_yet_count,
    (SELECT COUNT(*) FROM dbo.HWY_Meetings_Members MM WITH (NOLOCK) WHERE MM.MeetingId = mi.MeetingId AND MM.IsMemberYet = 0) AS members_not_count
  FROM dbo.HWY_Meetings_Instances mi WITH (NOLOCK)
  LEFT JOIN dbo.hwy_ref_base_information bi WITH (NOLOCK) ON bi.id= mi.MeetingId
  LEFT JOIN dbo.hwy_members creator WITH (NOLOCK) ON creator.username= mi.created_by
  WHERE (@meeting_id IS NULL OR mi.MeetingId = @meeting_id)
    AND (
      @username IS NULL
      OR mi.id IN (
        SELECT H.InstanceId
        FROM dbo.HWY_Meetings_Hazerin H WITH (NOLOCK)
        INNER JOIN dbo.hwy_members M WITH (NOLOCK) ON M.id= H.member_id
        WHERE M.username LIKE N'%' + @username + N'%'
      )
    )
  ORDER BY mi.created_at DESC
  OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_remove_instance
  @instance_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_Meetings_Instances', N'U') IS NULL
    THROW 50400, N'Legacy HWY_Meetings_Instances is not available.', 1;
  DELETE FROM dbo.HWY_Meetings_Instances WHERE id= @instance_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_add_instance
  @meeting_id BIGINT,
  @instance_date NVARCHAR(32),
  @actor NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_SP_Meetings_Instances_Add', N'P') IS NULL
    THROW 50400, N'Legacy HWY_SP_Meetings_Instances_Add is not available.', 1;
  EXEC dbo.HWY_SP_Meetings_Instances_Add @MeetingId = @meeting_id, @InstanceDate = @instance_date, @UserName = @actor;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_attendance_pivot
  @meeting_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_SP_Meetings_AttendancePivot', N'P') IS NULL
    THROW 50400, N'Legacy HWY_SP_Meetings_AttendancePivot is not available.', 1;
  EXEC dbo.HWY_SP_Meetings_AttendancePivot @MeetingId = @meeting_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_instance_hazerin_list
  @instance_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_Meetings_Hazerin', N'U') IS NULL
    THROW 50400, N'Legacy HWY_Meetings_Hazerin is not available.', 1;

  SELECT
    CAST(M.id AS VARCHAR(32)) AS member_id,
    M.username AS username,
    M.first_name AS first_name,
    M.father_name AS father_name,
    M.family_name AS family_name
  FROM dbo.HWY_Meetings_Hazerin H WITH (NOLOCK)
  INNER JOIN dbo.hwy_members M WITH (NOLOCK) ON M.id= H.member_id
  WHERE H.InstanceId = @instance_id
  ORDER BY M.username ASC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_members_list
  @meeting_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_Meetings_Members', N'U') IS NULL
    THROW 50400, N'Legacy HWY_Meetings_Members is not available.', 1;

  SELECT
    CAST(mm.id AS VARCHAR(32)) AS id,
    CAST(mm.MeetingId AS VARCHAR(32)) AS meeting_id,
    CAST(mm.member_id AS VARCHAR(32)) AS member_id,
    CAST(mm.IsMemberYet AS BIT) AS is_member_yet,
    CONVERT(VARCHAR(32), mm.IsMemberYetUpdatedOn, 126) AS is_member_yet_updated_on,
    M.username AS username,
    M.first_name AS first_name,
    M.father_name AS father_name,
    M.family_name AS family_name
  FROM dbo.HWY_Meetings_Members mm WITH (NOLOCK)
  LEFT JOIN dbo.hwy_members M WITH (NOLOCK) ON M.id= mm.member_id
  WHERE mm.MeetingId = @meeting_id
  ORDER BY M.username ASC, mm.id ASC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_members_add
  @meeting_id BIGINT,
  @member_id BIGINT = NULL,
  @username NVARCHAR(128) = NULL,
  @actor NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_SP_Meetings_Members_Add', N'P') IS NULL
    THROW 50400, N'Legacy HWY_SP_Meetings_Members_Add is not available.', 1;
  DECLARE @mid BIGINT = @member_id;
  DECLARE @uname NVARCHAR(128) = NULLIF(LTRIM(RTRIM(@username)), N'');
  IF @mid IS NULL SET @mid = -1;
  IF @uname IS NULL SET @uname = N'-1';
  EXEC dbo.HWY_SP_Meetings_Members_Add @meeting_id, @mid, @uname, @actor;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_members_remove
  @row_id BIGINT,
  @actor NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_SP_Meetings_Members_Remove', N'P') IS NULL
    THROW 50400, N'Legacy HWY_SP_Meetings_Members_Remove is not available.', 1;
  EXEC dbo.HWY_SP_Meetings_Members_Remove @row_id, @actor;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_instance_attendance_list
  @instance_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_Meetings_Members', N'U') IS NULL
    THROW 50400, N'Legacy HWY_Meetings_Members is not available.', 1;

  IF OBJECT_ID(N'dbo.HWY_VW_Members_NoAdmin', N'V') IS NOT NULL
  BEGIN
    SELECT
      CAST(mm.id AS VARCHAR(32)) AS id,
      CAST(@instance_id AS VARCHAR(32)) AS instance_id,
      CAST(mm.MeetingId AS VARCHAR(32)) AS meeting_id,
      CAST(mm.member_id AS VARCHAR(32)) AS member_id,
      M.username AS username,
      M.first_name AS first_name,
      M.father_name AS father_name,
      M.family_name AS family_name,
      CAST(mm.IsMemberYet AS BIT) AS is_member_yet,
      CAST(CASE WHEN EXISTS (
        SELECT 1 FROM dbo.HWY_Meetings_Hazerin H WITH (NOLOCK)
        WHERE H.InstanceId = @instance_id AND H.member_id = mm.member_id
      ) THEN 1 ELSE 0 END AS BIT) AS present
    FROM dbo.HWY_Meetings_Members mm WITH (NOLOCK)
    INNER JOIN dbo.HWY_Meetings_Instances mi WITH (NOLOCK) ON mi.MeetingId = mm.MeetingId AND mi.id = @instance_id
    LEFT JOIN dbo.HWY_VW_Members_NoAdmin M WITH (NOLOCK) ON M.id= mm.member_id AND M.membership_status_legacy = 10851
    ORDER BY M.username ASC;
    RETURN;
  END;

  SELECT
    CAST(mm.id AS VARCHAR(32)) AS id,
    CAST(@instance_id AS VARCHAR(32)) AS instance_id,
    CAST(mm.MeetingId AS VARCHAR(32)) AS meeting_id,
    CAST(mm.member_id AS VARCHAR(32)) AS member_id,
    M.username AS username,
    M.first_name AS first_name,
    M.father_name AS father_name,
    M.family_name AS family_name,
    CAST(mm.IsMemberYet AS BIT) AS is_member_yet,
    CAST(CASE WHEN EXISTS (
      SELECT 1 FROM dbo.HWY_Meetings_Hazerin H WITH (NOLOCK)
      WHERE H.InstanceId = @instance_id AND H.member_id = mm.member_id
    ) THEN 1 ELSE 0 END AS BIT) AS present
  FROM dbo.HWY_Meetings_Members mm WITH (NOLOCK)
  INNER JOIN dbo.HWY_Meetings_Instances mi WITH (NOLOCK) ON mi.MeetingId = mm.MeetingId AND mi.id = @instance_id
  LEFT JOIN dbo.hwy_members M WITH (NOLOCK) ON M.id= mm.member_id
  ORDER BY M.username ASC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_hazerin_add
  @instance_id BIGINT,
  @member_id BIGINT = NULL,
  @username NVARCHAR(128) = NULL,
  @device_lat NVARCHAR(32) = NULL,
  @device_lon NVARCHAR(32) = NULL,
  @device_datetime NVARCHAR(32) = NULL,
  @device_id NVARCHAR(128) = NULL,
  @actor NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_SP_Meetings_Hazerin_Add', N'P') IS NULL
    THROW 50400, N'Legacy HWY_SP_Meetings_Hazerin_Add is not available.', 1;
  DECLARE @mid BIGINT = @member_id;
  DECLARE @uname NVARCHAR(128) = NULLIF(LTRIM(RTRIM(@username)), N'');
  IF @mid IS NULL SET @mid = -1;
  IF @uname IS NULL SET @uname = N'';
  IF @device_datetime IS NULL OR LTRIM(RTRIM(@device_datetime)) = N''
    SET @device_datetime = CONVERT(VARCHAR(32), GETDATE(), 120);
  EXEC dbo.HWY_SP_Meetings_Hazerin_Add
    @instance_id,
    @mid,
    @uname,
    @device_lat,
    @device_lon,
    @device_datetime,
    @device_id,
    @actor;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_meetings_hazerin_remove
  @instance_id BIGINT,
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_Meetings_Hazerin', N'U') IS NULL
    THROW 50400, N'Legacy HWY_Meetings_Hazerin is not available.', 1;
  DELETE FROM dbo.HWY_Meetings_Hazerin
  WHERE InstanceId = @instance_id AND member_id= @member_id;
END;
GO
