-- AUTO-GENERATED — do not edit by hand
-- Source: MembersV2 via npm run hwy:gen-finance-procs
-- Standard names: dbo.hwy_* / dbo.vw_hwy_*

-- HWY_SP_PaymentDocuments_CalcAggregations → hwy_payment_documents_calc_aggregations
CREATE OR ALTER PROCEDURE dbo.hwy_payment_documents_calc_aggregations @DocId INT
AS
BEGIN
	SET NOCOUNT ON;

	UPDATE hwy_payment_documents SET
		
		total_members_count = (ISNULL((SELECT COUNT(*) FROM hwy_payment_documents_members DM WITH(NOLOCK) WHERE DM.document_id=hwy_payment_documents.id),0)),
		payable_members_count_ok = (ISNULL((SELECT COUNT(*) FROM hwy_payment_documents_members DM WITH(NOLOCK) WHERE DM.document_id=hwy_payment_documents.id AND DM.payable=1 AND ISNULL(DM.pay_ok,0)=1),0)) ,
		payable_members_count_nok = (ISNULL((SELECT COUNT(*) FROM hwy_payment_documents_members DM WITH(NOLOCK) WHERE DM.document_id=hwy_payment_documents.id AND DM.payable=1 AND ISNULL(DM.pay_ok,0)=0),0)) ,
		not_payable_members_count = (ISNULL((SELECT COUNT(*) FROM hwy_payment_documents_members DM WITH(NOLOCK) WHERE DM.document_id=hwy_payment_documents.id AND DM.payable=0),0)) ,
		
		total_amount = (ISNULL((SELECT SUM(ISNULL(DM.pay_amount,0)) FROM hwy_payment_documents_members DM WITH(NOLOCK) WHERE DM.document_id=hwy_payment_documents.id),0)) ,
		payable_amount_ok = (ISNULL((SELECT SUM(ISNULL(DM.pay_amount,0)) FROM hwy_payment_documents_members DM WITH(NOLOCK) WHERE DM.document_id=hwy_payment_documents.id AND DM.payable=1 AND ISNULL(DM.pay_ok,0)=1),0)) ,
		payable_amount_nok = (ISNULL((SELECT SUM(ISNULL(DM.pay_amount,0)) FROM hwy_payment_documents_members DM WITH(NOLOCK) WHERE DM.document_id=hwy_payment_documents.id AND DM.payable=1 AND ISNULL(DM.pay_ok,0)=0),0)) ,
		not_payable_amount = (ISNULL((SELECT SUM(ISNULL(DM.pay_amount,0)) FROM hwy_payment_documents_members DM WITH(NOLOCK) WHERE DM.document_id=hwy_payment_documents.id AND DM.payable=0),0)) 

	WHERE id=@DocId

END
GO

-- HWY_SP_PaymentDocuments_Create → hwy_payment_documents_create
CREATE OR ALTER PROCEDURE dbo.hwy_payment_documents_create @DocYear INT,@DocMonth INT,@DocProvinceId INT,@DocGenderId INT,@Actor NVARCHAR(64)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Now DATETIME = GETDATE();
	DECLARE @DocId INT;

	IF(@DocGenderId!=10011 AND @DocGenderId!=10012) RETURN;

	-- Insert documents
	INSERT INTO hwy_payment_documents 
		(doc_year,	doc_month,	doc_province_id,		doc_circle_id,	doc_gender_id,	created_by,	created_on,area_ok,area_ok_by,area_ok_on)
	SELECT 
		@DocYear,	@DocMonth,	@DocProvinceId,		circle_id,		@DocGenderId,	@Actor,		@Now,1,'admin',@Now
	FROM hwy_ref_base_information P
	LEFT OUTER JOIN hwy_ref_h_circles HC ON HC.hwy_state_id=P.id
	WHERE P.parent_id=10101 AND P.id = @DocProvinceId AND ISNULL(HC.deleted,0)=0;

	INSERT INTO hwy_payment_documents_members
	(document_id,	
	member_id,	role_id,			pay_amount,											payable,	payable_by,	payable_on,	created_by,	created_on)
	SELECT 
	(SELECT TOP 1 PD.id FROM hwy_payment_documents PD WHERE PD.doc_province_id=T.province_id AND PD.doc_circle_id=T.circle_id AND PD.doc_gender_id=T.gender_id AND PD.doc_year=@DocYear AND PD.doc_month=@DocMonth),
	T.member_id,	T.role_id,		dbo.hwy_payment_calc_pay_amount ( T.member_id ),		1,			@Actor,		@Now,		@Actor,		@Now
	FROM 
	(

		SELECT P.id province_id,P.title province_title,HC.circle_id,HC.circle_name,AL.member_id,URR.role_id, M.gender_legacy_id AS gender_id
		FROM hwy_ref_base_information P
		LEFT OUTER JOIN hwy_ref_h_circles HC			ON HC.hwy_state_id=P.id
		LEFT OUTER JOIN hwy_member_area_limits AL	ON AL.item_id=HC.circle_id
		LEFT OUTER JOIN hwy_members M				ON M.id=AL.member_id
		LEFT OUTER JOIN vw_hwy_platform_user_roles_finance URR	ON URR.user_id=M.user_id
		WHERE P.parent_id=10101 AND P.id=@DocProvinceId AND ISNULL(M.chief_masool,1)=1 AND M.gender_legacy_id=@DocGenderId
			AND ISNULL(HC.deleted,0)=0 AND ISNULL(URR.approved,0)=1 AND URR.role_id=1000027
	
		UNION ALL

		SELECT P.id province_id,P.title province_title,HT.circle_id,HT.circle_name,AL.member_id,URR.role_id, M.gender_legacy_id AS gender_id
		FROM hwy_ref_base_information P
		LEFT OUTER JOIN hwy_ref_h_tamvinat HT			ON HT.hwy_state_id=P.id
		LEFT OUTER JOIN hwy_member_area_limits AL	ON AL.item_id=HT.tamvin_id
		LEFT OUTER JOIN hwy_members M				ON M.id=AL.member_id
		LEFT OUTER JOIN vw_hwy_platform_user_roles_finance URR	ON URR.user_id=M.user_id
		WHERE P.parent_id=10101 AND P.id = @DocProvinceId AND ISNULL(M.chief_masool,1)=1 AND M.gender_legacy_id=@DocGenderId
			AND ISNULL(HT.deleted,0)=0 AND ISNULL(URR.approved,0)=1 AND URR.role_id=1000004

		UNION ALL

		SELECT P.id province_id,P.title province_title,HE.circle_id,HE.circle_name,AL.member_id,URR.role_id, M.gender_legacy_id AS gender_id
		FROM hwy_ref_base_information P
		LEFT OUTER JOIN hwy_ref_h_eghteraat HE			ON HE.hwy_state_id=P.id
		LEFT OUTER JOIN hwy_member_area_limits AL	ON AL.item_id=HE.eghtera_id
		LEFT OUTER JOIN hwy_members M				ON M.id=AL.member_id
		LEFT OUTER JOIN vw_hwy_platform_user_roles_finance URR	ON URR.user_id=M.user_id
		WHERE P.parent_id=10101 AND P.id = @DocProvinceId AND ISNULL(M.chief_masool,1)=1 AND M.gender_legacy_id=@DocGenderId
			AND ISNULL(HE.deleted,0)=0 AND ISNULL(URR.approved,0)=1 AND URR.role_id=1000005

	) T


	DECLARE NotCalculated CURSOR
		FOR SELECT DISTINCT id FROM hwy_payment_documents WHERE total_amount IS NULL
	OPEN NotCalculated
	FETCH NEXT FROM NotCalculated INTO @DocId

	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC dbo.hwy_payment_documents_calc_aggregations @DocId;
		FETCH NEXT FROM NotCalculated INTO @DocId
	END
	CLOSE NotCalculated;
	DEALLOCATE NotCalculated;

END
GO

-- HWY_SP_PaymentDocuments_ReadStates → hwy_payment_documents_read_states
CREATE OR ALTER PROCEDURE dbo.hwy_payment_documents_read_states @DocYear INT,@DocMonth INT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT P.id province_id,P.title province_title,
		
		 (SELECT dbo.hwy_payment_has_duplicated_circle_masool(P.id,1))	HasCircleError
		,(SELECT dbo.hwy_payment_has_duplicated_tamvin_masool(P.id,1))	HasTamvinError
		,(SELECT dbo.hwy_payment_has_duplicated_eghtera_masool(P.id,1))	HasEghteraError
		,CAST(ISNULL((SELECT TOP 1 PD.id FROM hwy_payment_documents PD WHERE PD.doc_year=@DocYear AND PD.doc_month=@DocMonth AND PD.doc_province_id=P.id AND PD.doc_gender_id=10011),0) AS BIT) DocGenerated10011
		,CAST(ISNULL((SELECT TOP 1 PD.id FROM hwy_payment_documents PD WHERE PD.doc_year=@DocYear AND PD.doc_month=@DocMonth AND PD.doc_province_id=P.id AND PD.doc_gender_id=10012),0) AS BIT) DocGenerated10012

	FROM hwy_ref_base_information P
	WHERE P.parent_id=10101 AND P.id NOT IN (10114,10115,10116,10117,10118,10119,10120)
	ORDER BY view_order

END
GO

-- HWY_SP_PaymentDocuments_Remove → hwy_payment_documents_remove_batch
CREATE OR ALTER PROCEDURE dbo.hwy_payment_documents_remove_batch @DocYear INT,@DocMonth INT,@DocProvinceId INT,@DocGenderId INT,@Actor NVARCHAR(64)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Now DATETIME = GETDATE();
	DECLARE @DocId INT;

	DELETE hwy_payment_documents_members 
	WHERE document_id IN (SELECT PD.id FROM hwy_payment_documents PD WHERE PD.doc_year=@DocYear AND PD.doc_month=@DocMonth AND PD.doc_province_id=@DocProvinceId AND PD.doc_gender_id=@DocGenderId);

	DELETE hwy_payment_documents 
	WHERE id IN (SELECT PD.id FROM hwy_payment_documents PD WHERE PD.doc_year=@DocYear AND PD.doc_month=@DocMonth AND PD.doc_province_id=@DocProvinceId AND PD.doc_gender_id=@DocGenderId);

END
GO

-- HWY_SP_PaymentDocuments_RemoveById → hwy_payment_documents_remove_by_id
CREATE OR ALTER PROCEDURE dbo.hwy_payment_documents_remove_by_id @DocumentId INT
AS
BEGIN
	SET NOCOUNT ON;

	DELETE hwy_payment_documents_members WHERE document_id = @DocumentId;
	DELETE hwy_payment_documents WHERE id= @DocumentId;
END
GO

-- HWY_SP_PaymentDocuments_SwitchPayability → hwy_payment_documents_member_switch_payability
CREATE OR ALTER PROCEDURE dbo.hwy_payment_documents_member_switch_payability 
	@PaymentId BIGINT,@Actor NVARCHAR(64)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @ActorUserId INT;
	DECLARE @DocId BIGINT;
	DECLARE @DocIsPayable BIT=0;
	DECLARE @DocIsFinalized BIT=0;
	DECLARE @ActorIsMasoolMali BIT=0;
	DECLARE @ActorIsMasoolCircle BIT=0;
	DECLARE @CurPayable BIT=0;
	DECLARE @ToPayable BIT=0;
	DECLARE @ReasonId INT;

	SELECT @ActorUserId=user_id FROM hwy_members WHERE username=@Actor;
	SELECT @DocId=document_id FROM hwy_payment_documents_members WHERE id=@PaymentId;
	SELECT @DocIsPayable=ISNULL(final_ok,0),@DocIsFinalized=ISNULL(closed,0) FROM hwy_payment_documents WHERE id=@DocId;
	
	IF(@DocIsFinalized=1) 
	BEGIN
		SELECT 0; 
		RETURN;
	END

	SET @ActorIsMasoolMali		=CAST((SELECT COUNT(*) FROM vw_hwy_platform_user_roles_finance WHERE approved=1 AND role_id=1000051 AND user_id=@ActorUserId) AS BIT);
	SET @ActorIsMasoolCircle	=CAST((SELECT COUNT(*) FROM vw_hwy_platform_user_roles_finance WHERE approved=1 AND role_id=1000027 AND user_id=@ActorUserId) AS BIT);
	SET @CurPayable				=(SELECT TOP 1 payable FROM hwy_payment_documents_members WHERE id=@PaymentId);
	IF(@CurPayable=0)
	BEGIN
		SET @ToPayable = 1;
		SET @ReasonId = NULL;
	END
	ELSE
	BEGIN
		SET @ToPayable = 0;
		IF (@DocIsPayable=0) SET @ReasonId = 213949; --Remove from list
		ELSE SET @ReasonId = 213950; -- Return money
	END;

	IF(@CurPayable=1 AND @DocIsPayable=1) 
	BEGIN
		SELECT 0;
		RETURN;
	END

	IF(@ActorIsMasoolCircle=1 AND @DocIsPayable=1) 
	BEGIN
		SELECT 0;
		RETURN;
	END

	IF(@ActorIsMasoolMali=1 AND @DocIsFinalized=1) 
	BEGIN
		SELECT 0;
		RETURN;
	END

	UPDATE hwy_payment_documents_members SET 
		payable=@ToPayable,
		payable_by=@Actor,
		payable_reason_id=@ReasonId,
		payable_on=GETDATE() 
	WHERE id=@PaymentId;

	EXEC dbo.hwy_payment_documents_calc_aggregations @DocId;

	SELECT 1;
	
END
GO

-- HWY_SP_PaymentDocuments_UpdatePayAmount → hwy_payment_documents_member_update_pay_amount
CREATE OR ALTER PROCEDURE dbo.hwy_payment_documents_member_update_pay_amount
    @PaymentId BIGINT,
    @NewPayAmount INT,
    @Note NVARCHAR(2000),
    @Actor NVARCHAR(64),
    @IsAdmin BIT = 0
AS
BEGIN
    SET NOCOUNT ON;

    IF (@NewPayAmount IS NULL OR @NewPayAmount < 0)
    BEGIN
        SELECT 2;
        RETURN;
    END

    IF (@Note IS NULL OR LEN(LTRIM(RTRIM(@Note))) < 10)
    BEGIN
        SELECT 2;
        RETURN;
    END

    DECLARE @ActorUserId INT;
    DECLARE @DocId BIGINT;
    DECLARE @DocAreaOk BIT = 0;
    DECLARE @DocFinalOk BIT = 0;
    DECLARE @DocClosed BIT = 0;
    DECLARE @ActorIsMasoolMali BIT = 0;
    DECLARE @ActorIsMasoolCircle BIT = 0;
    DECLARE @OldPayAmount INT;

    SELECT @ActorUserId = user_id FROM hwy_members WHERE username = @Actor;
    SELECT @DocId = document_id, @OldPayAmount = pay_amount FROM hwy_payment_documents_members WHERE id= @PaymentId;

    IF (@DocId IS NULL)
    BEGIN
        SELECT 0;
        RETURN;
    END

    SELECT @DocAreaOk = ISNULL(area_ok, 0), @DocFinalOk = ISNULL(final_ok, 0), @DocClosed = ISNULL(closed, 0)
    FROM hwy_payment_documents WHERE id= @DocId;

    IF (@DocClosed = 1)
    BEGIN
        SELECT 0;
        RETURN;
    END

    SET @ActorIsMasoolMali = CAST((SELECT COUNT(*) FROM vw_hwy_platform_user_roles_finance WHERE approved= 1 AND role_id IN (1000051, 1000057) AND user_id = @ActorUserId) AS BIT);
    SET @ActorIsMasoolCircle = CAST((SELECT COUNT(*) FROM vw_hwy_platform_user_roles_finance WHERE approved= 1 AND role_id IN (1000027, 1000003) AND user_id = @ActorUserId) AS BIT);

    IF (@IsAdmin = 0)
    BEGIN
        IF (@ActorIsMasoolCircle = 1 AND @DocAreaOk = 1)
        BEGIN
            SELECT 0;
            RETURN;
        END

        IF (@ActorIsMasoolMali = 1 AND @DocFinalOk = 1)
        BEGIN
            SELECT 0;
            RETURN;
        END

        IF (@ActorIsMasoolCircle = 0 AND @ActorIsMasoolMali = 0)
        BEGIN
            SELECT 0;
            RETURN;
        END
    END

    IF (@OldPayAmount = @NewPayAmount)
    BEGIN
        SELECT 3;
        RETURN;
    END

    UPDATE hwy_payment_documents_members SET pay_amount = @NewPayAmount WHERE id= @PaymentId;

    INSERT INTO hwy_payment_documents_members_pay_amount_log (PaymentMemberId, old_pay_amount, new_pay_amount, Note, ChangedBy, ChangedOn)
    VALUES (@PaymentId, @OldPayAmount, @NewPayAmount, LTRIM(RTRIM(@Note)), @Actor, GETDATE());

    EXEC dbo.hwy_payment_documents_calc_aggregations @DocId;

    SELECT 1;
END
GO

