SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_targhin_admin_count
  @status_code NVARCHAR(32) = NULL,
  @nego_state NVARCHAR(32) = NULL,
  @search_like NVARCHAR(256) = NULL,
  @nego_actor_legacy NVARCHAR(256) = NULL
AS
BEGIN
  SET NOCOUNT ON;

  /* Fast path: member/requester name search is off — no vw_hwy_members join. */
  IF @search_like IS NULL
  BEGIN
    SELECT COUNT(*) AS total
    FROM dbo.hwy_member_targhin_requests t WITH (NOLOCK)
    WHERE (@status_code IS NULL OR t.status_code = @status_code)
      AND (
        @nego_state IS NULL OR LTRIM(RTRIM(@nego_state)) = N''
        OR (
          @nego_state = N'in_nego'
          AND EXISTS (
            SELECT 1 FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
            WHERE nn.member_id = t.member_id
          )
        )
        OR (
          @nego_state = N'not_in_nego'
          AND NOT EXISTS (
            SELECT 1 FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
            WHERE nn.member_id = t.member_id
          )
        )
        OR (
          @nego_state = N'in_nego_by_me'
          AND ISNULL((
            SELECT TOP 1 nn.created_by_legacy
            FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
            WHERE nn.member_id = t.member_id
            ORDER BY nn.created_at DESC, nn.id DESC
          ), N'') = @nego_actor_legacy
        )
        OR (
          @nego_state = N'in_nego_by_others'
          AND EXISTS (
            SELECT 1 FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
            WHERE nn.member_id = t.member_id
          )
          AND ISNULL((
            SELECT TOP 1 nn.created_by_legacy
            FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
            WHERE nn.member_id = t.member_id
            ORDER BY nn.created_at DESC, nn.id DESC
          ), N'') <> @nego_actor_legacy
        )
      );
    RETURN;
  END;

  SELECT COUNT(*) AS total
  FROM dbo.hwy_member_targhin_requests t WITH (NOLOCK)
  INNER JOIN dbo.vw_hwy_members vm WITH (NOLOCK) ON vm.id = t.member_id
  LEFT JOIN dbo.base_users req_u ON req_u.id = t.created_by
  LEFT JOIN dbo.vw_hwy_members req_vm ON req_vm.user_id = req_u.id
  OUTER APPLY (
    SELECT TOP 1
      vm2.id,
      vm2.username,
      vm2.display_full_name
    FROM dbo.vw_hwy_members vm2 WITH (NOLOCK)
    WHERE req_vm.id IS NULL
      AND NULLIF(LTRIM(RTRIM(t.request_by_legacy)), N'') IS NOT NULL
      AND (
        vm2.username = LTRIM(RTRIM(t.request_by_legacy))
        OR (
          TRY_CONVERT(BIGINT, LTRIM(RTRIM(t.request_by_legacy))) IS NOT NULL
          AND vm2.id = TRY_CONVERT(BIGINT, LTRIM(RTRIM(t.request_by_legacy)))
        )
      )
  ) req_vm_legacy
  WHERE (@status_code IS NULL OR t.status_code = @status_code)
    AND (
      vm.username LIKE @search_like
      OR vm.display_full_name LIKE @search_like
      OR req_vm.username LIKE @search_like
      OR req_vm.display_full_name LIKE @search_like
      OR req_vm_legacy.username LIKE @search_like
      OR req_vm_legacy.display_full_name LIKE @search_like
    )
    AND (
      @nego_state IS NULL OR LTRIM(RTRIM(@nego_state)) = N''
      OR (
        @nego_state = N'in_nego'
        AND EXISTS (
          SELECT 1 FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
          WHERE nn.member_id = t.member_id
        )
      )
      OR (
        @nego_state = N'not_in_nego'
        AND NOT EXISTS (
          SELECT 1 FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
          WHERE nn.member_id = t.member_id
        )
      )
      OR (
        @nego_state = N'in_nego_by_me'
        AND ISNULL((
          SELECT TOP 1 nn.created_by_legacy
          FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
          WHERE nn.member_id = t.member_id
          ORDER BY nn.created_at DESC, nn.id DESC
        ), N'') = @nego_actor_legacy
      )
      OR (
        @nego_state = N'in_nego_by_others'
        AND EXISTS (
          SELECT 1 FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
          WHERE nn.member_id = t.member_id
        )
        AND ISNULL((
          SELECT TOP 1 nn.created_by_legacy
          FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
          WHERE nn.member_id = t.member_id
          ORDER BY nn.created_at DESC, nn.id DESC
        ), N'') <> @nego_actor_legacy
      )
    );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_targhin_admin_list
  @status_code NVARCHAR(32) = NULL,
  @nego_state NVARCHAR(32) = NULL,
  @search_like NVARCHAR(256) = NULL,
  @nego_actor_legacy NVARCHAR(256) = NULL,
  @offset INT,
  @page_size INT
AS
BEGIN
  SET NOCOUNT ON;

  ;WITH page AS (
    SELECT
      t.id,
      t.member_id,
      t.request_reason_code,
      t.request_note,
      t.status_code,
      t.created_at,
      t.final_reason_code,
      t.final_note,
      t.final_at,
      t.created_by,
      t.request_by_legacy,
      t.final_by
    FROM dbo.hwy_member_targhin_requests t WITH (NOLOCK)
    WHERE (@status_code IS NULL OR t.status_code = @status_code)
      AND (
        @search_like IS NULL
        OR EXISTS (
          SELECT 1
          FROM dbo.vw_hwy_members vm_s WITH (NOLOCK)
          WHERE vm_s.id = t.member_id
            AND (
              vm_s.username LIKE @search_like
              OR vm_s.display_full_name LIKE @search_like
            )
        )
        OR EXISTS (
          SELECT 1
          FROM dbo.base_users req_u_s WITH (NOLOCK)
          INNER JOIN dbo.vw_hwy_members req_vm_s WITH (NOLOCK) ON req_vm_s.user_id = req_u_s.id
          WHERE req_u_s.id = t.created_by
            AND (
              req_vm_s.username LIKE @search_like
              OR req_vm_s.display_full_name LIKE @search_like
            )
        )
        OR EXISTS (
          SELECT 1
          FROM dbo.vw_hwy_members req_legacy_s WITH (NOLOCK)
          WHERE NULLIF(LTRIM(RTRIM(t.request_by_legacy)), N'') IS NOT NULL
            AND (
              req_legacy_s.username = LTRIM(RTRIM(t.request_by_legacy))
              OR (
                TRY_CONVERT(BIGINT, LTRIM(RTRIM(t.request_by_legacy))) IS NOT NULL
                AND req_legacy_s.id = TRY_CONVERT(BIGINT, LTRIM(RTRIM(t.request_by_legacy)))
              )
            )
            AND (
              req_legacy_s.username LIKE @search_like
              OR req_legacy_s.display_full_name LIKE @search_like
            )
        )
      )
      AND (
        @nego_state IS NULL OR LTRIM(RTRIM(@nego_state)) = N''
        OR (
          @nego_state = N'in_nego'
          AND EXISTS (
            SELECT 1 FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
            WHERE nn.member_id = t.member_id
          )
        )
        OR (
          @nego_state = N'not_in_nego'
          AND NOT EXISTS (
            SELECT 1 FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
            WHERE nn.member_id = t.member_id
          )
        )
        OR (
          @nego_state = N'in_nego_by_me'
          AND ISNULL((
            SELECT TOP 1 nn.created_by_legacy
            FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
            WHERE nn.member_id = t.member_id
            ORDER BY nn.created_at DESC, nn.id DESC
          ), N'') = @nego_actor_legacy
        )
        OR (
          @nego_state = N'in_nego_by_others'
          AND EXISTS (
            SELECT 1 FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
            WHERE nn.member_id = t.member_id
          )
          AND ISNULL((
            SELECT TOP 1 nn.created_by_legacy
            FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
            WHERE nn.member_id = t.member_id
            ORDER BY nn.created_at DESC, nn.id DESC
          ), N'') <> @nego_actor_legacy
        )
      )
    ORDER BY t.created_at DESC, t.id DESC
    OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY
  )
  SELECT
    CAST(t.id AS VARCHAR(32)) AS id,
    last_nego.note AS lastNegoNote,
    last_nego.created_by_legacy AS lastNegoNoteWriterLegacy,
    ISNULL(nego_counts.cnt, 0) AS negoNoteCount,
    t.request_reason_code AS requestReasonCode,
    t.request_note AS requestNote,
    t.status_code AS statusCode,
    t.created_at AS createdAt,
    t.final_reason_code AS finalReasonCode,
    t.final_note AS finalNote,
    t.final_at AS finalAt,
    CAST(vm.id AS VARCHAR(32)) AS memberId,
    vm.username AS memberUsername,
    vm.display_full_name AS memberDisplayFullName,
    vm.gender_code AS memberGenderCode,
    vm.avatar_url AS memberAvatarUrl,
    vm.has_profile_image AS memberHasProfileImage,
    CAST(vm.user_id AS VARCHAR(32)) AS memberUserId,
    vm.phone1 AS memberPhone,
    vm.electoral_division_path AS memberElectoralDivisionPath,
    CAST(req_vm.id AS VARCHAR(32)) AS requesterId,
    req_vm.username AS requesterUsername,
    req_vm.display_full_name AS requesterDisplayFullName,
    req_vm.gender_code AS requesterGenderCode,
    req_vm.avatar_url AS requesterAvatarUrl,
    req_vm.has_profile_image AS requesterHasProfileImage,
    CAST(req_vm.user_id AS VARCHAR(32)) AS requesterUserId,
    req_vm.phone1 AS requesterPhone,
    req_vm.electoral_division_path AS requesterElectoralDivisionPath,
    CAST(req_u.id AS VARCHAR(32)) AS requesterAccountUserId,
    req_u.username AS requesterAccountUsername,
    CAST(dec_vm.id AS VARCHAR(32)) AS deciderId,
    dec_vm.username AS deciderUsername,
    dec_vm.display_full_name AS deciderDisplayFullName,
    dec_vm.gender_code AS deciderGenderCode,
    dec_vm.avatar_url AS deciderAvatarUrl,
    dec_vm.has_profile_image AS deciderHasProfileImage,
    CAST(dec_vm.user_id AS VARCHAR(32)) AS deciderUserId,
    dec_vm.phone1 AS deciderPhone,
    dec_vm.electoral_division_path AS deciderElectoralDivisionPath
  FROM page t
  INNER JOIN dbo.vw_hwy_members vm WITH (NOLOCK) ON vm.id = t.member_id
  LEFT JOIN dbo.base_users req_u ON req_u.id = t.created_by
  LEFT JOIN dbo.vw_hwy_members req_vm ON req_vm.user_id = req_u.id
  LEFT JOIN dbo.base_users dec_u ON dec_u.id = t.final_by
  LEFT JOIN dbo.vw_hwy_members dec_vm ON dec_vm.user_id = dec_u.id
  OUTER APPLY (
    SELECT TOP 1 nn.note, nn.created_by_legacy
    FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
    WHERE nn.member_id = t.member_id
    ORDER BY nn.created_at DESC, nn.id DESC
  ) last_nego
  OUTER APPLY (
    SELECT COUNT(*) AS cnt
    FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
    WHERE nn.member_id = t.member_id
  ) nego_counts
  ORDER BY t.created_at DESC, t.id DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_targhin_members_count
  @targhin_status_code NVARCHAR(128),
  @search_like NVARCHAR(256) = NULL
AS
BEGIN
  SET NOCOUNT ON;

  SELECT COUNT(*) AS total
  FROM dbo.hwy_members m WITH (NOLOCK)
  WHERE m.membership_status_code = @targhin_status_code
    AND (
      @search_like IS NULL
      OR m.username LIKE @search_like
      OR m.phone1 LIKE @search_like
      OR CONCAT_WS(
        N' ',
        NULLIF(LTRIM(RTRIM(m.first_name)), N''),
        NULLIF(LTRIM(RTRIM(m.father_name)), N''),
        NULLIF(LTRIM(RTRIM(m.grandfather_name)), N''),
        NULLIF(LTRIM(RTRIM(m.family_name)), N'')
      ) LIKE @search_like
    );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_targhin_members_list
  @targhin_status_code NVARCHAR(128),
  @approved_status NVARCHAR(32),
  @search_like NVARCHAR(256) = NULL,
  @offset INT,
  @page_size INT
AS
BEGIN
  SET NOCOUNT ON;

  /* Paginate on dbo.hwy_members — join vw_hwy_members only for the current page. */
  ;WITH page AS (
    SELECT
      m.id,
      m.membership_status_updated_on,
      m.membership_on,
      m.membership_status_updated_by
    FROM dbo.hwy_members m WITH (NOLOCK)
    WHERE m.membership_status_code = @targhin_status_code
      AND (
        @search_like IS NULL
        OR m.username LIKE @search_like
        OR m.phone1 LIKE @search_like
        OR CONCAT_WS(
          N' ',
          NULLIF(LTRIM(RTRIM(m.first_name)), N''),
          NULLIF(LTRIM(RTRIM(m.father_name)), N''),
          NULLIF(LTRIM(RTRIM(m.grandfather_name)), N''),
          NULLIF(LTRIM(RTRIM(m.family_name)), N'')
        ) LIKE @search_like
      )
    ORDER BY m.membership_status_updated_on DESC, m.id DESC
    OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY
  )
  SELECT
    CAST(vm.id AS VARCHAR(32)) AS memberId,
    vm.username AS memberUsername,
    vm.display_full_name AS memberDisplayFullName,
    vm.gender_code AS memberGenderCode,
    vm.avatar_url AS memberAvatarUrl,
    vm.has_profile_image AS memberHasProfileImage,
    CAST(vm.user_id AS VARCHAR(32)) AS memberUserId,
    vm.phone1 AS memberPhone,
    vm.electoral_division_path AS memberElectoralDivisionPath,
    vm.membership_status_updated_on AS membershipStatusUpdatedOn,
    vm.membership_on AS membershipOn,
    latest.request_reason_code AS latestRequestReasonCode,
    latest.request_note AS latestRequestNote,
    latest.final_reason_code AS latestFinalReasonCode,
    latest.final_note AS latestFinalNote,
    latest.final_at AS latestFinalAt,
    latest.final_by_legacy AS latestFinalByLegacy,
    process_nego.note AS latestProcessNegoNote,
    CAST(COALESCE(exec_vm.id, exec_vm_legacy.id) AS VARCHAR(32)) AS executorId,
    COALESCE(exec_vm.username, exec_vm_legacy.username, exec_u.username) AS executorUsername,
    COALESCE(exec_vm.display_full_name, exec_vm_legacy.display_full_name) AS executorDisplayFullName,
    COALESCE(exec_vm.gender_code, exec_vm_legacy.gender_code) AS executorGenderCode,
    COALESCE(exec_vm.avatar_url, exec_vm_legacy.avatar_url) AS executorAvatarUrl,
    COALESCE(exec_vm.has_profile_image, exec_vm_legacy.has_profile_image) AS executorHasProfileImage,
    CAST(COALESCE(exec_vm.user_id, exec_vm_legacy.user_id) AS VARCHAR(32)) AS executorUserId,
    CAST(exec_u.id AS VARCHAR(32)) AS executorAccountUserId,
    COALESCE(exec_vm.phone1, exec_vm_legacy.phone1) AS executorPhone,
    COALESCE(exec_vm.electoral_division_path, exec_vm_legacy.electoral_division_path) AS executorElectoralDivisionPath,
    exec_roles.executorRoleTitlesCsv AS executorRoleTitlesCsv
  FROM page p
  INNER JOIN dbo.vw_hwy_members vm WITH (NOLOCK) ON vm.id = p.id
  OUTER APPLY (
    SELECT TOP 1
      t.request_reason_code,
      t.request_note,
      t.final_reason_code,
      t.final_note,
      t.final_at,
      t.final_by,
      NULLIF(LTRIM(RTRIM(t.final_by_legacy)), N'') AS final_by_legacy
    FROM dbo.hwy_member_targhin_requests t WITH (NOLOCK)
    WHERE t.member_id = vm.id
    ORDER BY
      CASE WHEN t.status_code = @approved_status THEN 0 ELSE 1 END,
      COALESCE(t.final_at, t.created_at) DESC,
      t.id DESC
  ) latest
  OUTER APPLY (
    SELECT TOP 1 nn.note AS note
    FROM dbo.hwy_member_targhin_nego_notes nn WITH (NOLOCK)
    WHERE nn.member_id = vm.id
    ORDER BY nn.created_at DESC, nn.id DESC
  ) process_nego
  LEFT JOIN dbo.base_users exec_u ON exec_u.id = COALESCE(latest.final_by, p.membership_status_updated_by)
  LEFT JOIN dbo.vw_hwy_members exec_vm ON exec_vm.user_id = exec_u.id
  LEFT JOIN dbo.hwy_members exec_legacy_m ON exec_vm.id IS NULL
    AND latest.final_by_legacy IS NOT NULL
    AND (
      exec_legacy_m.username = latest.final_by_legacy
      OR (
        TRY_CONVERT(BIGINT, latest.final_by_legacy) IS NOT NULL
        AND exec_legacy_m.id = TRY_CONVERT(BIGINT, latest.final_by_legacy)
      )
    )
  LEFT JOIN dbo.vw_hwy_members exec_vm_legacy ON exec_vm_legacy.id = exec_legacy_m.id
  OUTER APPLY (
    SELECT STRING_AGG(role_label, N'|') WITHIN GROUP (ORDER BY role_name) AS executorRoleTitlesCsv
    FROM (
      SELECT
        br.name AS role_name,
        CASE
          WHEN br.note IS NOT NULL AND CHARINDEX(N': ', br.note) > 0
            THEN LTRIM(RTRIM(SUBSTRING(br.note, CHARINDEX(N': ', br.note) + 2, 4000)))
          ELSE br.name
        END AS role_label
      FROM dbo.base_user_roles ur
      INNER JOIN dbo.base_roles br ON br.name = ur.role_name
      WHERE exec_u.id IS NOT NULL AND ur.user_id = exec_u.id
    ) role_rows
  ) exec_roles
  ORDER BY p.membership_status_updated_on DESC, p.id DESC;
END;
GO
