SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_directory_patch
  @id BIGINT,
  @first_name NVARCHAR(500) = NULL,
  @family_name NVARCHAR(500) = NULL,
  @father_name NVARCHAR(500) = NULL,
  @grandfather_name NVARCHAR(500) = NULL,
  @great_grandfather_name NVARCHAR(500) = NULL,
  @mother_first_name NVARCHAR(500) = NULL,
  @mother_father_name NVARCHAR(500) = NULL,
  @mother_grandfather_name NVARCHAR(500) = NULL,
  @nickname NVARCHAR(500) = NULL,
  @birth_year NVARCHAR(4000) = NULL,
  @birth_month NVARCHAR(4000) = NULL,
  @birth_day NVARCHAR(4000) = NULL,
  @gender_code NVARCHAR(1000) = NULL,
  @phone1 NVARCHAR(500) = NULL,
  @phone2 NVARCHAR(500) = NULL,
  @email NVARCHAR(500) = NULL,
  @facebook_id NVARCHAR(4000) = NULL,
  @twitter_id NVARCHAR(4000) = NULL,
  @tiktok_id NVARCHAR(4000) = NULL,
  @addr_province_id NVARCHAR(128) = NULL,
  @addr_district_id BIGINT = NULL,
  @addr_subdistrict_id BIGINT = NULL,
  @addr_quarter_name NVARCHAR(MAX) = NULL,
  @addr_quarter_no NVARCHAR(4000) = NULL,
  @addr_alley_no NVARCHAR(4000) = NULL,
  @addr_house_no NVARCHAR(4000) = NULL,
  @addr_nearest_landmark NVARCHAR(MAX) = NULL,
  @addr_most_important_place NVARCHAR(MAX) = NULL,
  @addr_maktab_id NVARCHAR(128) = NULL,
  @addr_region_id NVARCHAR(128) = NULL,
  @addr_circle_id NVARCHAR(128) = NULL,
  @education_level_code NVARCHAR(1000) = NULL,
  @education_level_in_code NVARCHAR(1000) = NULL,
  @education_entry_year NVARCHAR(4000) = NULL,
  @education_end_year NVARCHAR(4000) = NULL,
  @education_branch NVARCHAR(MAX) = NULL,
  @education_school NVARCHAR(MAX) = NULL,
  @education_university_code NVARCHAR(1000) = NULL,
  @education_university_faculty_code NVARCHAR(1000) = NULL,
  @job_type_code NVARCHAR(1000) = NULL,
  @job_place NVARCHAR(MAX) = NULL,
  @updated_at DATETIME2
AS
BEGIN
  SET NOCOUNT ON;

  UPDATE dbo.hwy_members
  SET
    first_name = @first_name,
    family_name = @family_name,
    father_name = @father_name,
    grandfather_name = @grandfather_name,
    great_grandfather_name = @great_grandfather_name,
    mother_first_name = @mother_first_name,
    mother_father_name = @mother_father_name,
    mother_grandfather_name = @mother_grandfather_name,
    nickname = @nickname,
    birth_year = @birth_year,
    birth_month = @birth_month,
    birth_day = @birth_day,
    gender_code = @gender_code,
    phone1 = @phone1,
    phone2 = @phone2,
    email = @email,
    facebook_id = @facebook_id,
    twitter_id = @twitter_id,
    tiktok_id = @tiktok_id,
    addr_province_id = @addr_province_id,
    addr_district_id = @addr_district_id,
    addr_subdistrict_id = @addr_subdistrict_id,
    addr_quarter_name = @addr_quarter_name,
    addr_quarter_no = @addr_quarter_no,
    addr_alley_no = @addr_alley_no,
    addr_house_no = @addr_house_no,
    addr_nearest_landmark = @addr_nearest_landmark,
    addr_most_important_place = @addr_most_important_place,
    addr_maktab_id = @addr_maktab_id,
    addr_region_id = @addr_region_id,
    addr_circle_id = @addr_circle_id,
    education_level_code = @education_level_code,
    education_level_in_code = @education_level_in_code,
    education_entry_year = @education_entry_year,
    education_end_year = @education_end_year,
    education_branch = @education_branch,
    education_school = @education_school,
    education_university_code = @education_university_code,
    education_university_faculty_code = @education_university_faculty_code,
    job_type_code = @job_type_code,
    job_place = @job_place,
    updated_at = @updated_at
  OUTPUT 1 AS updated
  WHERE id= @id;

  IF @@ROWCOUNT = 0
    THROW 56300, N'Member not found.', 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_self_registration_create_member
  @first_name NVARCHAR(500),
  @father_name NVARCHAR(500),
  @grandfather_name NVARCHAR(500) = NULL,
  @family_name NVARCHAR(500),
  @birth_year NVARCHAR(32) = NULL,
  @birth_month NVARCHAR(32) = NULL,
  @birth_day NVARCHAR(32) = NULL,
  @phone1 NVARCHAR(500),
  @phone2 NVARCHAR(500) = NULL,
  @email NVARCHAR(500) = NULL,
  @national_id NVARCHAR(128) = NULL,
  @gender_code NVARCHAR(128) = NULL,
  @addr_province_id NVARCHAR(128) = NULL,
  @addr_district_id BIGINT = NULL,
  @addr_quarter_name NVARCHAR(4000) = NULL,
  @addr_quarter_no NVARCHAR(128) = NULL,
  @addr_alley_no NVARCHAR(128) = NULL,
  @addr_house_no NVARCHAR(128) = NULL,
  @addr_nearest_landmark NVARCHAR(4000) = NULL,
  @education_level_code NVARCHAR(128) = NULL,
  @education_school NVARCHAR(4000) = NULL,
  @education_branch NVARCHAR(4000) = NULL,
  @education_entry_year NVARCHAR(32) = NULL,
  @education_end_year NVARCHAR(32) = NULL,
  @job_type_code NVARCHAR(128) = NULL,
  @job_place NVARCHAR(4000) = NULL,
  @referrer_username NVARCHAR(500) = NULL,
  @referrer_relation_id NVARCHAR(128) = NULL,
  @membership_status_code NVARCHAR(128),
  @registration_channel_code NVARCHAR(128),
  @note NVARCHAR(MAX) = NULL,
  @institute_id BIGINT = NULL,
  @institute_status_code NVARCHAR(128) = NULL,
  @join_path_code NVARCHAR(128) = NULL,
  @institute_member_accepted BIT = 0,
  @created_at DATETIME2,
  @updated_at DATETIME2
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  BEGIN TRAN;

  DECLARE @member_id BIGINT;
  SELECT @member_id = ISNULL(MAX(id), 0) + 1 FROM dbo.hwy_members WITH (UPDLOCK, HOLDLOCK);

  INSERT INTO dbo.hwy_members (
    id, first_name, father_name, grandfather_name, family_name,
    birth_year, birth_month, birth_day,
    phone1, phone2, email, national_id, gender_code,
    addr_province_id, addr_district_id, addr_quarter_name, addr_quarter_no,
    addr_alley_no, addr_house_no, addr_nearest_landmark,
    education_level_code, education_school, education_branch, education_entry_year, education_end_year,
    job_type_code, job_place, referrer_username, referrer_relation_id,
    membership_status_code, registration_channel_code, note,
    created_at, updated_at
  ) VALUES (
    @member_id, @first_name, @father_name, @grandfather_name, @family_name,
    @birth_year, @birth_month, @birth_day,
    @phone1, @phone2, @email, @national_id, @gender_code,
    @addr_province_id, @addr_district_id, @addr_quarter_name, @addr_quarter_no,
    @addr_alley_no, @addr_house_no, @addr_nearest_landmark,
    @education_level_code, @education_school, @education_branch, @education_entry_year, @education_end_year,
    @job_type_code, @job_place, @referrer_username, @referrer_relation_id,
    @membership_status_code, @registration_channel_code, @note,
    @created_at, @updated_at
  );

  IF @institute_id IS NOT NULL
  BEGIN
    INSERT INTO dbo.hwy_member_institutes (
      member_id, institute_id, status_code, join_path_code,
      member_accepted, created_at, updated_at
    ) VALUES (
      @member_id, @institute_id, @institute_status_code, @join_path_code,
      @institute_member_accepted, @created_at, @updated_at
    );
  END;

  COMMIT;

  SELECT @member_id AS member_id, CAST(@member_id AS NVARCHAR(32)) AS tracking_code;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_institute_admin_assign
  @member_id BIGINT,
  @institute_id BIGINT,
  @status_code NVARCHAR(128),
  @join_path_code NVARCHAR(128),
  @actor_user_id BIGINT = NULL,
  @created_at DATETIME2,
  @updated_at DATETIME2
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_members WHERE id= @member_id)
    THROW 56510, N'Member not found.', 1;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_institutes WHERE id= @institute_id)
    THROW 56511, N'Institute not found.', 1;

  MERGE dbo.hwy_member_institutes AS t
  USING (SELECT @member_id AS member_id, @institute_id AS institute_id) AS s
    ON t.member_id = s.member_id AND t.institute_id = s.institute_id
  WHEN MATCHED THEN UPDATE SET
    status_code = @status_code,
    join_path_code = @join_path_code,
    member_accepted = 1,
    invited_by = NULL,
    invited_at = NULL,
    updated_at = @updated_at,
    updated_by = @actor_user_id
  WHEN NOT MATCHED THEN INSERT (
    member_id, institute_id, status_code, join_path_code,
    member_accepted, created_at, updated_at, created_by, updated_by
  ) VALUES (
    @member_id, @institute_id, @status_code, @join_path_code,
    1, @created_at, @updated_at, @actor_user_id, @actor_user_id
  );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_file_upsert
  @member_id BIGINT,
  @file_kind_code NVARCHAR(1000),
  @existing_file_id BIGINT = NULL,
  @original_file_name NVARCHAR(512),
  @mime NVARCHAR(4000),
  @size_bytes BIGINT,
  @content VARBINARY(MAX),
  @updated_by BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_members WHERE id= @member_id)
    THROW 56400, N'Member not found.', 1;

  IF @existing_file_id IS NOT NULL
  BEGIN
    UPDATE dbo.hwy_member_files
    SET
      original_file_name = @original_file_name,
      mime = @mime,
      size_bytes = @size_bytes,
      content = @content,
      updated_by = @updated_by,
      updated_at = SYSUTCDATETIME()
    WHERE id= @existing_file_id;

    IF @@ROWCOUNT = 0
      THROW 56401, N'File not found.', 1;

    EXEC dbo.hwy_member_sync_registration_files_member_row @member_id = @member_id;

    SELECT CAST(@existing_file_id AS VARCHAR(32)) AS id, CAST(0 AS BIT) AS created;
    RETURN;
  END;

  DECLARE @new_file_id BIGINT;

  INSERT INTO dbo.hwy_member_files (
    member_id, file_kind_code, original_file_name, mime, size_bytes,
    content, is_approved, created_by, updated_by, created_at, updated_at
  )
  VALUES (
    @member_id, @file_kind_code, @original_file_name, @mime, @size_bytes,
    @content, NULL, @updated_by, @updated_by, SYSUTCDATETIME(), SYSUTCDATETIME()
  );

  SET @new_file_id = SCOPE_IDENTITY();

  EXEC dbo.hwy_member_sync_registration_files_member_row @member_id = @member_id;

  SELECT CAST(@new_file_id AS VARCHAR(32)) AS id, CAST(1 AS BIT) AS created;
END;
GO
