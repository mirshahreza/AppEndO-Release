-- Platform auth projection for Hawiety SQL (snake_case column aliases in SELECT).
-- Views: dbo.vw_hwy_platform_users | dbo.vw_hwy_platform_roles | dbo.vw_hwy_platform_user_roles
-- Retired compat view names (dropped on reinstall): dbo.vw_hwy_platform_users, dbo.vw_hwy_platform_roles, dbo.vw_hwy_platform_user_roles

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF OBJECT_ID(N'dbo.hwy_legacy_app_end_roles', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_legacy_app_end_roles (
    id INT NOT NULL CONSTRAINT PK_hwy_legacy_app_end_roles PRIMARY KEY,
    role_name NVARCHAR(500) NULL,
    is_executive BIT NOT NULL CONSTRAINT DF_hwy_legacy_app_end_roles_exec DEFAULT (0)
  );
END
GO

IF OBJECT_ID(N'dbo.vw_hwy_platform_users', N'V') IS NOT NULL
  DROP VIEW dbo.vw_hwy_platform_users;
GO
IF OBJECT_ID(N'dbo.vw_hwy_platform_roles', N'V') IS NOT NULL
  DROP VIEW dbo.vw_hwy_platform_roles;
GO
IF OBJECT_ID(N'dbo.vw_hwy_platform_user_roles', N'V') IS NOT NULL
  DROP VIEW dbo.vw_hwy_platform_user_roles;
GO

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NULL
BEGIN
  PRINT 'hwy_legacy_edge_pipeline_compat skipped — dbo.hwy_members missing';
END
ELSE
BEGIN
  IF OBJECT_ID(N'dbo.base_users', N'U') IS NOT NULL
  BEGIN
    UPDATE m
    SET user_id = u.id
    FROM dbo.hwy_members m
    INNER JOIN dbo.base_users u ON LTRIM(RTRIM(u.username)) = LTRIM(RTRIM(m.username))
    WHERE m.user_id IS NULL AND NULLIF(LTRIM(RTRIM(m.username)), N'') IS NOT NULL;
  END;

  IF OBJECT_ID(N'dbo.base_info', N'U') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'membership_status_legacy') IS NOT NULL
  BEGIN
    UPDATE m
    SET membership_status_legacy = CASE LTRIM(RTRIM(bi.short_name))
      WHEN N'active' THEN 10851
      WHEN N'pending_call_center' THEN 10852
      WHEN N'pending_local' THEN 10853
      WHEN N'rejected_call_center' THEN 10854
      WHEN N'pending_cancellation' THEN 10855
      WHEN N'rejected_local' THEN 10856
      WHEN N'rejected_local_verification' THEN 10857
      ELSE m.membership_status_legacy
    END
    FROM dbo.hwy_members m
    INNER JOIN dbo.base_info bi ON bi.id= m.membership_status_code
    WHERE m.membership_status_legacy IS NULL;
  END;

  PRINT 'hwy_legacy_edge_pipeline_compat member sync ready';
END
GO

IF OBJECT_ID(N'dbo.base_users', N'U') IS NOT NULL
BEGIN
  EXEC(N'
    CREATE OR ALTER VIEW dbo.vw_hwy_platform_users AS
    SELECT
      u.id,
      u.username,
      u.email,
      u.mobile,
      u.locked
    FROM dbo.base_users u;
  ');
END
GO

IF OBJECT_ID(N'dbo.base_roles', N'U') IS NOT NULL
BEGIN
  EXEC(N'
    CREATE OR ALTER VIEW dbo.vw_hwy_platform_roles AS
    SELECT
      COALESCE(TRY_CAST(REPLACE(r.name, N''HWY_R_'', N'''') AS INT), CAST(r.id AS INT)) AS id,
      r.name AS role_name,
      CAST(COALESCE(ar.is_executive, 0) AS BIT) AS is_executive
    FROM dbo.base_roles r
    LEFT JOIN dbo.hwy_legacy_app_end_roles ar ON ar.id= COALESCE(
      TRY_CAST(REPLACE(r.name, N''HWY_R_'', N'''') AS INT),
      CAST(r.id AS INT)
    );
  ');
END
GO

IF OBJECT_ID(N'dbo.base_user_roles', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.base_roles', N'U') IS NOT NULL
BEGIN
  EXEC(N'
    CREATE OR ALTER VIEW dbo.vw_hwy_platform_user_roles AS
    SELECT
      ROW_NUMBER() OVER (ORDER BY ur.user_id, ur.role_name) AS id,
      ur.user_id,
      TRY_CAST(
        REPLACE(ur.role_name, N''HWY_R_'', N'''')
        AS INT
      ) AS role_id,
      CAST(1 AS BIT) AS approved,
      ur.created_at,
      ur.created_by,
      ur.created_by AS approved_by
    FROM dbo.base_user_roles ur
    INNER JOIN dbo.base_roles r ON r.name = ur.role_name
    WHERE ur.role_name LIKE N''HWY_R[_]%'';
  ');
END
GO
