-- Masoolin stars overall — prior-month snapshots for performance grid (replaces legacy HWY_MasoolinStarsOveral_M*).
-- Requires dbo.hwy_masoolin_stars_overal on edge.

CREATE OR ALTER VIEW dbo.vw_hwy_masoolin_stars_overal_m1
AS
SELECT *
FROM dbo.hwy_masoolin_stars_overal WITH (NOLOCK)
WHERE calc_year = YEAR(DATEADD(MONTH, -1, GETDATE()))
  AND calc_month = MONTH(DATEADD(MONTH, -1, GETDATE()));
GO

CREATE OR ALTER VIEW dbo.vw_hwy_masoolin_stars_overal_m2
AS
SELECT *
FROM dbo.hwy_masoolin_stars_overal WITH (NOLOCK)
WHERE calc_year = YEAR(DATEADD(MONTH, -2, GETDATE()))
  AND calc_month = MONTH(DATEADD(MONTH, -2, GETDATE()));
GO

CREATE OR ALTER VIEW dbo.vw_hwy_masoolin_stars_overal_m3
AS
SELECT *
FROM dbo.hwy_masoolin_stars_overal WITH (NOLOCK)
WHERE calc_year = YEAR(DATEADD(MONTH, -3, GETDATE()))
  AND calc_month = MONTH(DATEADD(MONTH, -3, GETDATE()));
GO
