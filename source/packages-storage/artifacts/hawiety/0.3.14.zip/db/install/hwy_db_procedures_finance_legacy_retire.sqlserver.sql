-- Drop legacy MembersV2 finance object names on edge when dbo.hwy_* replacement exists.
-- Keep in sync with hwyFinanceLegacyProcCatalog.ts (HWY_FINANCE_LEGACY_RETIRE_TARGETS).

IF OBJECT_ID(N'dbo.hwy_payment_documents_calc_aggregations', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_PaymentDocuments_CalcAggregations', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_PaymentDocuments_CalcAggregations;
GO

IF OBJECT_ID(N'dbo.hwy_payment_documents_create', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_PaymentDocuments_Create', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_PaymentDocuments_Create;
GO

IF OBJECT_ID(N'dbo.hwy_payment_documents_read_states', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_PaymentDocuments_ReadStates', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_PaymentDocuments_ReadStates;
GO

IF OBJECT_ID(N'dbo.hwy_payment_documents_remove_batch', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_PaymentDocuments_Remove', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_PaymentDocuments_Remove;
GO

IF OBJECT_ID(N'dbo.hwy_payment_documents_remove_by_id', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_PaymentDocuments_RemoveById', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_PaymentDocuments_RemoveById;
GO

IF OBJECT_ID(N'dbo.hwy_payment_documents_member_switch_payability', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_PaymentDocuments_SwitchPayability', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_PaymentDocuments_SwitchPayability;
GO

IF OBJECT_ID(N'dbo.hwy_payment_documents_member_update_pay_amount', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_PaymentDocuments_UpdatePayAmount', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_PaymentDocuments_UpdatePayAmount;
GO

IF OBJECT_ID(N'dbo.vw_hwy_payment_documents_members', N'V') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_VW_PaymentDocuments_Members', N'V') IS NOT NULL
  DROP VIEW dbo.HWY_VW_PaymentDocuments_Members;
GO

IF OBJECT_ID(N'dbo.vw_hwy_payment_documents_members_m1', N'V') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_VW_PaymentDocuments_Members_M1', N'V') IS NOT NULL
  DROP VIEW dbo.HWY_VW_PaymentDocuments_Members_M1;
GO

IF OBJECT_ID(N'dbo.vw_hwy_payment_documents_members_m2', N'V') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_VW_PaymentDocuments_Members_M2', N'V') IS NOT NULL
  DROP VIEW dbo.HWY_VW_PaymentDocuments_Members_M2;
GO

IF OBJECT_ID(N'dbo.vw_hwy_payment_documents_members_m3', N'V') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_VW_PaymentDocuments_Members_M3', N'V') IS NOT NULL
  DROP VIEW dbo.HWY_VW_PaymentDocuments_Members_M3;
GO

IF OBJECT_ID(N'dbo.hwy_masoolin_stars_create_or_update_month', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_Masoolin_CreateOrUpdateStars', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_Masoolin_CreateOrUpdateStars;
GO

IF OBJECT_ID(N'dbo.hwy_masoolin_stars_create_or_update_current', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_Masoolin_CreateOrUpdateStars_Current', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_Masoolin_CreateOrUpdateStars_Current;
GO

IF OBJECT_ID(N'dbo.hwy_masoolin_performance_list', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_Masoolin_Performance', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_Masoolin_Performance;
GO

IF OBJECT_ID(N'dbo.hwy_masoolin_performance_export', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_Masoolin_PerformanceExport', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_Masoolin_PerformanceExport;
GO

IF OBJECT_ID(N'dbo.hwy_masoolin_stars_recalc_member', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_MasoolinCalcStars', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_MasoolinCalcStars;
GO

IF OBJECT_ID(N'dbo.hwy_masoolin_stars_get', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_MasoolinGetStars', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_MasoolinGetStars;
GO

IF OBJECT_ID(N'dbo.hwy_masoolin_stars_get_history', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_MasoolinGetStarsHistory', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_MasoolinGetStarsHistory;
GO

IF OBJECT_ID(N'dbo.hwy_masoolin_set_as_main_payable', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_Masoolin_SetAsMainPayable', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_Masoolin_SetAsMainPayable;
GO

IF OBJECT_ID(N'dbo.hwy_masoolin_performance_process', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_Masoolin_Performance_Process', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_Masoolin_Performance_Process;
GO

IF OBJECT_ID(N'dbo.hwy_masoolin_below_officials', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_Masoolin_BelowOfficials', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_Masoolin_BelowOfficials;
GO

IF OBJECT_ID(N'dbo.hwy_masoolin_top_officials', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_Masoolin_TopOfficials', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_Masoolin_TopOfficials;
GO

IF OBJECT_ID(N'dbo.hwy_masoolin_set_payable_auto', N'P') IS NOT NULL
   AND OBJECT_ID(N'dbo.HWY_SP_Masoolin_SetPayableAuto', N'P') IS NOT NULL
  DROP PROCEDURE dbo.HWY_SP_Masoolin_SetPayableAuto;
GO
