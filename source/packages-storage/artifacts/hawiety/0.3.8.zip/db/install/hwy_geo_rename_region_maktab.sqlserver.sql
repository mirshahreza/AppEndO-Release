-- Hawiety geo vocabulary rename: eghtera → region, tamvin/office → maktab.
-- Run once on control-plane DBs that already have the old column names and geo nodes.
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF COL_LENGTH(N'dbo.hwy_nakhebin', N'eghtera_id') IS NOT NULL
  AND COL_LENGTH(N'dbo.hwy_nakhebin', N'region_id') IS NULL
  EXEC sp_rename N'dbo.hwy_nakhebin.eghtera_id', N'region_id', N'COLUMN';
GO

IF COL_LENGTH(N'dbo.hwy_nakhebin', N'office_id') IS NOT NULL
  AND COL_LENGTH(N'dbo.hwy_nakhebin', N'maktab_id') IS NULL
  EXEC sp_rename N'dbo.hwy_nakhebin.office_id', N'maktab_id', N'COLUMN';
GO

IF COL_LENGTH(N'dbo.hwy_members', N'addr_office_id') IS NOT NULL
  AND COL_LENGTH(N'dbo.hwy_members', N'addr_maktab_id') IS NULL
  EXEC sp_rename N'dbo.hwy_members.addr_office_id', N'addr_maktab_id', N'COLUMN';
GO

IF COL_LENGTH(N'dbo.hwy_members', N'addr_area_id') IS NOT NULL
  AND COL_LENGTH(N'dbo.hwy_members', N'addr_region_id') IS NULL
  EXEC sp_rename N'dbo.hwy_members.addr_area_id', N'addr_region_id', N'COLUMN';
GO

IF COL_LENGTH(N'dbo.hwy_members', N'nakhebin_link_area_id') IS NOT NULL
  AND COL_LENGTH(N'dbo.hwy_members', N'nakhebin_link_region_id') IS NULL
  EXEC sp_rename N'dbo.hwy_members.nakhebin_link_area_id', N'nakhebin_link_region_id', N'COLUMN';
GO

IF OBJECT_ID(N'dbo.hwy_etl_geo_map', N'U') IS NOT NULL
BEGIN
  UPDATE dbo.hwy_etl_geo_map SET legacy_kind = N'region' WHERE legacy_kind = N'eghtera';
  UPDATE dbo.hwy_etl_geo_map SET legacy_kind = N'maktab' WHERE legacy_kind = N'tamvin';
END;
GO

UPDATE dbo.base_info
SET short_name = REPLACE(short_name, N'hwy-eghtera-', N'hwy-region-')
WHERE short_name LIKE N'hwy-eghtera-%';
GO

UPDATE dbo.base_info
SET short_name = REPLACE(short_name, N'hwy-tamvin-', N'hwy-maktab-')
WHERE short_name LIKE N'hwy-tamvin-%';
GO

UPDATE dbo.base_info
SET metadata = REPLACE(metadata, N'"hwyGeoKind":"eghtera"', N'"hwyGeoKind":"region"')
WHERE metadata LIKE N'%"hwyGeoKind":"eghtera"%';
GO

UPDATE dbo.base_info
SET metadata = REPLACE(metadata, N'"hwyGeoKind": "eghtera"', N'"hwyGeoKind": "region"')
WHERE metadata LIKE N'%"hwyGeoKind": "eghtera"%';
GO

UPDATE dbo.base_info
SET metadata = REPLACE(metadata, N'"hwyGeoKind":"tamvin"', N'"hwyGeoKind":"maktab"')
WHERE metadata LIKE N'%"hwyGeoKind":"tamvin"%';
GO

UPDATE dbo.base_info
SET metadata = REPLACE(metadata, N'"hwyGeoKind": "tamvin"', N'"hwyGeoKind": "maktab"')
WHERE metadata LIKE N'%"hwyGeoKind": "tamvin"%';
GO

IF OBJECT_ID(N'dbo.hwy_eghtera_electoral_title_path', N'FN') IS NOT NULL
  DROP FUNCTION dbo.hwy_eghtera_electoral_title_path;
GO

PRINT 'hwy geo region/maktab rename migration complete — re-run hwy_geo_sql_functions.sqlserver.sql and vw_hwy_members.sqlserver.sql';
GO
