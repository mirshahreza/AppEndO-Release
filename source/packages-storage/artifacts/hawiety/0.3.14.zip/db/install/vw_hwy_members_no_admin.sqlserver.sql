-- Finance / masoolin parity: legacy column aliases on snake_case dbo.hwy_members (no PascalCase computed on table).

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER VIEW dbo.vw_hwy_members_no_admin
AS
SELECT
  m.id,
  m.user_id,
  m.username AS user_name,
  m.first_name,
  m.father_name,
  m.grandfather_name AS grand_father_name,
  m.family_name AS last_name,
  m.phone1,
  m.phone2,
  m.email,
  m.national_id,
  m.gender_code,
  m.gender_id,
  m.gender_legacy_id,
  m.nakhebin_id AS nakheb_id,
  m.nakhebin_id,
  m.membership_status_code,
  m.membership_status_legacy,
  m.membership_status,
  m.membership_on,
  m.area_limit_id,
  m.area_limit_province_id,
  m.area_limit_circle_id,
  m.area_limit_tamvin_id,
  m.stat_fields_completed,
  m.chief_masool,
  m.masooliat_sum_stars,
  m.masooliat_level_id,
  m.masooliat_level_id_current,
  m.masooliat_sum_stars_current,
  m.created_at,
  m.updated_at
FROM dbo.hwy_members m;
GO

-- Legacy proc identifier (same projection).
CREATE OR ALTER VIEW dbo.HWY_VW_Members_NoAdmin
AS
SELECT * FROM dbo.vw_hwy_members_no_admin;
GO

PRINT 'vw_hwy_members_no_admin ready';
GO
