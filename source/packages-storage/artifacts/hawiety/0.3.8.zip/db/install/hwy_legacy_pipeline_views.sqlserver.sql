-- Candidate pipeline stage views (edge). Idempotent CREATE OR ALTER.

CREATE OR ALTER VIEW [dbo].[vw_hwy_candidate_pipeline_security]
AS
SELECT T.id, Picture_FileBody_xs, FirstName, FatherName, GrandFatherName, LastName, GenderId, Phone1, UserName, UserId,
	NakhebJoinProvinceId, NakhebJoinCircleId, NakhebJoinTamvinId, NakhebJoinEghteraId,
	SecurityStatusId,SecurityStatusOn, SecurityStatusResult, IsEmployee, IsApproved, RoleOfTarshih, DateOfTarshih,
	MoarasshehOfTarshih,ApprovedBy, AreaOfTarshih,
	DATEDIFF(DAY, DateOfTarshih, GETDATE()) DaysFrom
FROM
(
	SELECT HWY_Members.Id,T.id SecurityStatusId,FirstName,FatherName,GrandFatherName,LastName,UserName, UserId, Phone1,
	NakhebJoinProvinceId, NakhebJoinCircleId, NakhebJoinTamvinId, NakhebJoinEghteraId,
	HWY_Members.GenderId , Picture_FileBody_xs,T.created_on SecurityStatusOn,T.final_result SecurityStatusResult,
	CAST((SELECT COUNT(*) FROM AppEnd_Users_R_Roles URR WITH(NOLOCK) WHERE URR.UserId=HWY_Members.UserId AND URR.RoleId IN (1000004,1000005)) AS BIT) AS IsEmployee,
	(SELECT TOP 1 ISNULL(URR.Approved,0)
		FROM AppEnd_Users_R_Roles URR
		LEFT OUTER JOIN AppEnd_Roles R ON R.Id=URR.RoleId
		WHERE URR.UserId=HWY_Members.UserId AND RoleId IN (1000004,1000005)
	) AS IsApproved,
	(SELECT TOP 1 RoleName
		FROM AppEnd_Users_R_Roles URR
		LEFT OUTER JOIN AppEnd_Roles R ON R.Id=URR.RoleId
		WHERE URR.UserId=HWY_Members.UserId AND RoleId IN (1000004,1000005)
	) AS RoleOfTarshih,
	(SELECT TOP 1 URR.CreatedOn
		FROM AppEnd_Users_R_Roles URR
		WHERE URR.UserId=HWY_Members.UserId AND RoleId IN (1000004,1000005)
	) AS DateOfTarshih,
	(SELECT TOP 1 URR.CreatedBy
		FROM AppEnd_Users_R_Roles URR
		WHERE URR.UserId=HWY_Members.UserId AND RoleId IN (1000004,1000005)
	) AS MoarasshehOfTarshih,
	(SELECT TOP 1 URR.ApprovedBy
		FROM AppEnd_Users_R_Roles URR
		WHERE URR.UserId=HWY_Members.UserId AND RoleId IN (1000004,1000005)
	) AS ApprovedBy,
	(SELECT dbo.hwy_member_agg_area_limits_for_tarshih(HWY_Members.Id)) AS AreaOfTarshih
	FROM  HWY_Members WITH(NOLOCK)
	LEFT OUTER JOIN hwy_member_security_statuses T WITH(NOLOCK) ON T.member_id=HWY_Members.Id
	WHERE MembershipStatus=10851
) T
WHERE IsEmployee=1;
GO

CREATE OR ALTER VIEW [dbo].[vw_hwy_candidate_pipeline_interview]
AS
SELECT
  M.Id AS id,
  M.Picture_FileBody_xs,
  M.FirstName,
  M.FatherName,
  M.GrandFatherName,
  M.LastName,
  M.GenderId,
  M.Phone1,
  M.UserName,
  M.UserId,
  M.NakhebJoinProvinceId,
  M.NakhebJoinCircleId,
  M.NakhebJoinTamvinId,
  M.NakhebJoinEghteraId,
  iv.id AS InterviewId,
  iv.interview_on AS InterviewOn,
  iv.final_result AS InterviewFinalResult,
  R.RoleName AS RoleOfTarshih,
  URR.RoleId AS RoleId,
  URR.CreatedOn AS DateOfTarshih,
  URR.CreatedBy AS MoarasshehOfTarshih,
  dbo.hwy_member_agg_area_limits_for_tarshih(M.Id) AS AreaOfTarshih,
  sec.created_on AS DateOfSP
FROM dbo.HWY_Members M WITH (NOLOCK)
INNER JOIN dbo.AppEnd_Users_R_Roles URR WITH (NOLOCK)
  ON URR.UserId = M.UserId AND URR.RoleId IN (1000004, 1000005)
LEFT OUTER JOIN dbo.AppEnd_Roles R WITH (NOLOCK) ON R.Id = URR.RoleId
OUTER APPLY (
  SELECT TOP 1 SP.can_get_masooliat, SP.created_on
  FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK)
  WHERE SP.member_id = M.Id
  ORDER BY SP.created_on DESC
) sec
OUTER APPLY (
  SELECT TOP 1 I.id, I.interview_on, I.final_result
  FROM dbo.hwy_member_interviews_2022 I WITH (NOLOCK)
  WHERE I.member_id = M.Id
  ORDER BY I.created_on DESC
) iv
WHERE M.MembershipStatus = 10851
  AND sec.can_get_masooliat = 211751;
GO

CREATE OR ALTER VIEW [dbo].[vw_hwy_candidate_pipeline_install]
AS
SELECT HWY_Members.Id,FirstName,FatherName,GrandFatherName,LastName,UserName, HWY_Members.UserId, Phone1, ISNULL(Stat_FieldsCompleted,0) ProfilePerfect, Stat_FieldsCompleted,
	NakhebJoinProvinceId, NakhebJoinCircleId, NakhebJoinTamvinId, NakhebJoinEghteraId,
	HWY_Members.GenderId , Picture_FileBody_xs,
	RoleId AS RoleOfTarshih_Id,RoleName AS RoleOfTarshih,URR.CreatedOn AS DateOfTarshih , URR.CreatedBy AS MoarasshehOfTarshih,CAST(A.item_id AS VARCHAR(32)) AS AreaId,
	dbo.hwy_member_passed_necessary_dorat(HWY_Members.Id) NecessaryDoratPassed,
	HWY_Members.AreaLimitId,BI_AreaLimitId.title AS AreaLimitId_Title ,
	AreaLimitProvinceId,BI_AreaLimitProvince.title AS AreaLimitProvinceId_Title,
	AreaLimitCircleId,T_AreaLimitCircle.circle_name AS AreaLimitCircleId_Title,
	AreaLimitTamvinId,T_AreaLimitTamvin.tamvin_name AS AreaLimitTamvinId_Title,
	(SELECT TOP 1 I2022.final_result FROM hwy_member_interviews_2022 I2022 WITH(NOLOCK) WHERE member_id=HWY_Members.Id ORDER BY I2022.created_on DESC) AS InterviewFinalResultId,
	(SELECT TOP 1 B.title FROM hwy_member_interviews_2022 I2022 WITH(NOLOCK) LEFT OUTER JOIN dbo.hwy_ref_base_information B ON B.id=I2022.final_result WHERE member_id=HWY_Members.Id ORDER BY I2022.created_on DESC) AS InterviewFinalResultTitle,
	(SELECT STRING_AGG(bi.title, ' , ') FROM dbo.hwy_ref_members_gender_limits gl WITH(NOLOCK) LEFT OUTER JOIN dbo.hwy_ref_base_information bi ON bi.id=gl.item_id WHERE gl.member_id=[HWY_Members].[Id]) AS GenderLimits,
	(SELECT dbo.hwy_member_agg_area_limits(HWY_Members.Id)) AS AreasLimits,
	(SELECT STRING_AGG(RoleName, ' , ') FROM HWY_Members ForAgg WITH(NOLOCK) LEFT OUTER JOIN AppEnd_Users_R_Roles WITH(NOLOCK) on ForAgg.UserId=AppEnd_Users_R_Roles.UserId LEFT OUTER JOIN AppEnd_Roles WITH(NOLOCK) on AppEnd_Users_R_Roles.RoleId=AppEnd_Roles.Id WHERE ForAgg.Id=[HWY_Members].[Id] AND AppEnd_Users_R_Roles.Approved=1) AS RolesLimits,
	(SELECT dbo.hwy_member_agg_area_limits_for_tarshih(HWY_Members.Id)) AS AreaOfTarshih,
	(SELECT TOP 1 CAST(ISNULL(MM.Oath_FileSize,0) AS BIT) FROM HWY_Members MM WHERE MM.Id=HWY_Members.Id) HasOath,
	(CASE WHEN ISNULL(NakhebCard_Front_Approved,0) = 0 OR ISNULL(NationalCard_Front_Approved,0) = 0 OR ISNULL(NationalCard_Behind_Approved,0) = 0 OR ISNULL(Picture_Approved,0) = 0 OR ISNULL(Oath_Approved,0) = 0 OR ISNULL(MaskanCard_Front_Approved,0) = 0 THEN CAST(0 AS BIT) ELSE CAST(1 AS BIT) END) AllImagesApproved,
	(SELECT TOP 1 SP.can_get_masooliat FROM hwy_member_security_profile_history SP WHERE SP.member_id=HWY_Members.Id ORDER BY SP.created_on DESC) SecurityStatus
	FROM  HWY_Members WITH(NOLOCK)
	LEFT OUTER JOIN AppEnd_Users_R_Roles URR WITH(NOLOCK) ON URR.UserId=HWY_Members.UserId AND URR.RoleId IN (1000004, 1000005)
	LEFT OUTER JOIN AppEnd_Roles R ON R.Id=URR.RoleId
	OUTER APPLY (
		SELECT TOP 1 AL.item_id
		FROM dbo.hwy_member_area_limits AL WITH (NOLOCK)
		WHERE AL.member_id = HWY_Members.Id AND ISNULL(AL.approved, 0) IN (0, 1)
		ORDER BY AL.approved DESC, AL.id DESC
	) A
	LEFT OUTER JOIN dbo.hwy_ref_base_information BI_AreaLimitId WITH(NOLOCK) ON BI_AreaLimitId.id=HWY_Members.AreaLimitId
	LEFT OUTER JOIN dbo.hwy_ref_base_information BI_AreaLimitProvince WITH(NOLOCK) ON BI_AreaLimitProvince.id=AreaLimitProvinceId
	LEFT OUTER JOIN dbo.hwy_ref_h_circles T_AreaLimitCircle WITH(NOLOCK) ON T_AreaLimitCircle.circle_id=AreaLimitCircleId
	LEFT OUTER JOIN dbo.hwy_ref_h_tamvinat T_AreaLimitTamvin WITH(NOLOCK) ON T_AreaLimitTamvin.tamvin_id=AreaLimitTamvinId
	WHERE MembershipStatus=10851 AND ISNULL(URR.Approved, 0) <> 1;
GO

CREATE OR ALTER VIEW [dbo].[vw_hwy_candidate_pipeline_courses]
AS
SELECT T.id, Picture_FileBody_xs, FirstName, FatherName, GrandFatherName, LastName, GenderId, Phone1, UserName, UserId,EducationLevelId,
	NakhebJoinProvinceId, NakhebJoinCircleId, NakhebJoinTamvinId, NakhebJoinEghteraId,
	PassedDorat, IsEmployee, RoleOfTarshih, DateOfTarshih, MoarasshehOfTarshih, AreaOfTarshih, PassedNecessaryDorat, InterviewFinalResult
FROM
(
	SELECT HWY_Members.Id,FirstName,FatherName,GrandFatherName,LastName,UserName, UserId, Phone1,
	NakhebJoinProvinceId, NakhebJoinCircleId, NakhebJoinTamvinId, NakhebJoinEghteraId,
	HWY_Members.GenderId , Picture_FileBody_xs,EducationLevelId,
	CAST((SELECT COUNT(*) FROM AppEnd_Users_R_Roles URR WITH(NOLOCK) WHERE URR.UserId=HWY_Members.UserId AND URR.RoleId IN (1000004,1000005)) AS BIT) AS IsEmployee,
	dbo.hwy_member_passed_necessary_dorat(HWY_Members.Id) PassedNecessaryDorat,
	(SELECT STRING_AGG('<div data-doratid="'+CAST(T.id AS VARCHAR)+'" class="badge bg-success text-light fs-d9 m-1">'+T.title+'</div>','') FROM
		(
		SELECT DISTINCT B.id,B.title FROM dbo.hwy_ref_members_dorat md
		LEFT OUTER JOIN dbo.hwy_ref_dorat d ON d.id=md.dorat_id
		LEFT OUTER JOIN dbo.hwy_ref_base_information B ON B.id=d.dorat_sub_type_id
		WHERE md.member_id=HWY_Members.Id AND d.dorat_sub_type_id IN (11071,11152,11028,11123,111533,11077,213957,213959,11072) AND d.status_id=215116
		) T
	) AS PassedDorat,
	(SELECT TOP 1 RoleName
		FROM AppEnd_Users_R_Roles URR
		LEFT OUTER JOIN AppEnd_Roles R ON R.Id=URR.RoleId
		WHERE URR.UserId=HWY_Members.UserId AND RoleId IN (1000004,1000005)
	) AS RoleOfTarshih,
	(SELECT TOP 1 URR.CreatedOn
		FROM AppEnd_Users_R_Roles URR
		WHERE URR.UserId=HWY_Members.UserId AND RoleId IN (1000004,1000005)
	) AS DateOfTarshih,
	(SELECT TOP 1 URR.CreatedBy
		FROM AppEnd_Users_R_Roles URR
		WHERE URR.UserId=HWY_Members.UserId AND RoleId IN (1000004,1000005)
	) AS MoarasshehOfTarshih,
	(SELECT dbo.hwy_member_agg_area_limits_for_tarshih(HWY_Members.Id)) AS AreaOfTarshih,
	(SELECT TOP 1 I2022.final_result FROM hwy_member_interviews_2022 I2022 WITH(NOLOCK) WHERE member_id=HWY_Members.Id ORDER BY I2022.created_on DESC) AS InterviewFinalResult
	FROM  HWY_Members WITH(NOLOCK)
	WHERE MembershipStatus=10851 AND (SELECT TOP 1 SP.can_get_masooliat FROM hwy_member_security_profile_history SP WHERE SP.member_id=HWY_Members.Id ORDER BY SP.created_on DESC)=211751
) T
WHERE
	InterviewFinalResult=213609
	OR
	(
		InterviewFinalResult=213610
		AND
		(SELECT TOP 1 URR.RoleId FROM AppEnd_Users_R_Roles URR WITH(NOLOCK) WHERE RoleId=1000005 AND URR.UserId=T.UserId)=1000005
	);
GO

IF OBJECT_ID(N'dbo.HWY_VW_Employees_SecurityStatuses', N'V') IS NOT NULL
  DROP VIEW dbo.HWY_VW_Employees_SecurityStatuses;
GO
IF OBJECT_ID(N'dbo.HWY_VW_Employees_InterviewManagement', N'V') IS NOT NULL
  DROP VIEW dbo.HWY_VW_Employees_InterviewManagement;
GO
IF OBJECT_ID(N'dbo.HWY_VW_Employees_PassedNecessaryDoratManagement', N'V') IS NOT NULL
  DROP VIEW dbo.HWY_VW_Employees_PassedNecessaryDoratManagement;
GO
IF OBJECT_ID(N'dbo.HWY_VW_Employees_ToApproveResponsibility', N'V') IS NOT NULL
  DROP VIEW dbo.HWY_VW_Employees_ToApproveResponsibility;
GO
