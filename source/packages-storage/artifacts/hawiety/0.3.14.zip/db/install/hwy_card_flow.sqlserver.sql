-- Legacy badge (card) printing workflow — list/count per step + step writes.

CREATE OR ALTER FUNCTION dbo.hwy_card_flow_latest_step_id(@member_id BIGINT)
RETURNS INT
AS
BEGIN
  DECLARE @sid INT;
  SELECT TOP 1 @sid = FS.step_id
  FROM dbo.hwy_member_card_printing_flow_steps FS WITH (NOLOCK)
  WHERE FS.member_id = @member_id
  ORDER BY FS.step_on DESC, FS.id DESC;
  RETURN @sid;
END;
GO

CREATE OR ALTER FUNCTION dbo.hwy_card_flow_geo_or_clause(
  @alias NVARCHAR(8),
  @area_limit_id BIGINT,
  @geo_limits_csv NVARCHAR(MAX),
  @include_gender BIT,
  @gender_limits_csv NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
  IF @area_limit_id IS NULL OR NULLIF(LTRIM(RTRIM(@geo_limits_csv)), N'') IS NULL
    RETURN N'';

  IF @area_limit_id = 111321
    RETURN N'';

  DECLARE @w NVARCHAR(MAX) = N' AND (1=0';
  IF @area_limit_id = 111322
    SET @w = @w + N' OR ' + @alias + N'.nakheb_join_province_id IN (' + @geo_limits_csv + N')';
  ELSE IF @area_limit_id = 111325
    SET @w = @w + N' OR ' + @alias + N'.nakheb_join_circle_id IN (' + @geo_limits_csv + N')';
  ELSE IF @area_limit_id = 111323
    SET @w = @w + N' OR ' + @alias + N'.nakheb_join_tamvin_id IN (' + @geo_limits_csv + N')';
  ELSE IF @area_limit_id = 111324
    SET @w = @w + N' OR ' + @alias + N'.nakheb_join_eghtera_id IN (' + @geo_limits_csv + N')';

  RETURN @w + N')';
END;
GO

CREATE OR ALTER FUNCTION dbo.hwy_card_flow_where_clause(
  @step NVARCHAR(32),
  @list_type NVARCHAR(64),
  @visibility NVARCHAR(16),
  @role_id NVARCHAR(32),
  @username NVARCHAR(128),
  @phone NVARCHAR(64),
  @alias NVARCHAR(8),
  @scope_unrestricted BIT,
  @area_limit_id BIGINT,
  @geo_limits_csv NVARCHAR(MAX),
  @gender_limits_csv NVARCHAR(MAX),
  @nakheb_province_id BIGINT,
  @nakheb_circle_id BIGINT,
  @nakheb_tamvin_id BIGINT
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
  DECLARE @w NVARCHAR(MAX) = N'';
  DECLARE @st NVARCHAR(32) = LOWER(LTRIM(RTRIM(@step)));
  DECLARE @lt NVARCHAR(64) = NULLIF(LTRIM(RTRIM(@list_type)), N'');
  DECLARE @rid NVARCHAR(32) = NULLIF(LTRIM(RTRIM(@role_id)), N'');
  DECLARE @latest NVARCHAR(200) = N'(SELECT TOP 1 FS.step_id FROM dbo.hwy_member_card_printing_flow_steps FS WITH (NOLOCK) WHERE FS.member_id=' + @alias + N'.id ORDER BY FS.step_on DESC, FS.id DESC)';

  SET @w = @w + N' AND ISNULL(' + @alias + N'.device_os_type_legacy_id,0)<>213991';

  IF @st = N'start'
  BEGIN
    IF @lt IS NULL OR @lt LIKE N'CanStart%'
      SET @w = @w + N' AND ' + @alias + N'.card_flow_last_status_id IS NULL AND ISNULL(' + @alias + N'.stat_fields_completed,0)=100';
    ELSE IF @lt LIKE N'Started%'
      SET @w = @w + N' AND ' + @alias + N'.card_flow_last_status_id IS NOT NULL';
    ELSE
      SET @w = @w + N' AND ' + @alias + N'.card_flow_last_status_id IS NULL';
  END
  ELSE IF @st = N'security'
  BEGIN
    SET @w = @w + N' AND ' + @alias + N'.card_flow_last_status_id IS NOT NULL AND EXISTS (SELECT 1 FROM dbo.hwy_member_card_printing_flow_steps CPF WITH (NOLOCK) WHERE CPF.member_id=' + @alias + N'.id)';
    IF @lt IS NULL OR @lt = N'WaitForInitialVoteMembers'
      SET @w = @w + N' AND ((SELECT COUNT(*) FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.id)=0 OR (SELECT TOP 1 SP.can_get_identity_card FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.id ORDER BY SP.created_on DESC)=211753)';
    ELSE IF @lt = N'RejectedMembers'
      SET @w = @w + N' AND (SELECT TOP 1 SP.can_get_identity_card FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.id ORDER BY SP.created_on DESC)=211752';
    ELSE IF @lt = N'AcceptedMembers'
      SET @w = @w + N' AND (SELECT TOP 1 SP.can_get_identity_card FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.id ORDER BY SP.created_on DESC)=211751';
  END
  ELSE IF @st = N'central'
  BEGIN
    SET @w = @w + N' AND ' + @alias + N'.card_flow_last_status_id IS NOT NULL AND ' + @latest + N' IN (213876,213931)';
    SET @w = @w + N' AND (SELECT TOP 1 SP.can_get_identity_card FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.id ORDER BY SP.created_on DESC)=211751';
  END
  ELSE IF @st = N'province'
  BEGIN
    SET @w = @w + N' AND ' + @alias + N'.card_flow_last_status_id IS NOT NULL AND ' + @latest + N'=213888';
    SET @w = @w + N' AND (SELECT TOP 1 SP.can_get_identity_card FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.id ORDER BY SP.created_on DESC)=211751';
  END
  ELSE IF @st = N'print'
  BEGIN
    SET @w = @w + N' AND ' + @alias + N'.card_flow_last_status_id IS NOT NULL AND ' + @latest + N' IN (213877,213878)';
    SET @w = @w + N' AND (SELECT TOP 1 SP.can_get_identity_card FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.id ORDER BY SP.created_on DESC)=211751';
  END
  ELSE IF @st = N'province-delivery'
  BEGIN
    SET @w = @w + N' AND ' + @alias + N'.card_flow_last_status_id IS NOT NULL AND ' + @latest + N' IN (213879,213935)';
    SET @w = @w + N' AND (SELECT TOP 1 SP.can_get_identity_card FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.id ORDER BY SP.created_on DESC)=211751';
  END
  ELSE IF @st = N'member-delivery'
  BEGIN
    SET @w = @w + N' AND ' + @alias + N'.card_flow_last_status_id IS NOT NULL';
    SET @w = @w + N' AND (SELECT TOP 1 SP.can_get_identity_card FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=' + @alias + N'.id ORDER BY SP.created_on DESC)=211751';
    IF @lt IS NOT NULL AND @lt <> N''
      SET @w = @w + N' AND ' + @latest + N'=' + @lt;
    ELSE
      SET @w = @w + N' AND ' + @latest + N'=213880';
  END;

  IF NULLIF(LTRIM(RTRIM(@visibility)), N'') = N'visible'
    SET @w = @w + N' AND ISNULL(' + @alias + N'.card_flow_visibility,1)=1';
  IF NULLIF(LTRIM(RTRIM(@visibility)), N'') = N'invisible'
    SET @w = @w + N' AND ISNULL(' + @alias + N'.card_flow_visibility,1)=0';

  IF @rid IS NOT NULL
    SET @w = @w + N' AND EXISTS (SELECT 1 FROM dbo.vw_hwy_platform_user_roles URR WITH (NOLOCK) WHERE URR.user_id=' + @alias + N'.user_id AND URR.role_id=' + @rid + N')';

  IF @nakheb_province_id IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.nakheb_join_province_id=' + CAST(@nakheb_province_id AS NVARCHAR(32));
  IF @nakheb_circle_id IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.nakheb_join_circle_id=' + CAST(@nakheb_circle_id AS NVARCHAR(32));
  IF @nakheb_tamvin_id IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.nakheb_join_tamvin_id=' + CAST(@nakheb_tamvin_id AS NVARCHAR(32));

  IF NULLIF(LTRIM(RTRIM(@username)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.username LIKE ''%'' + ''' + REPLACE(@username, N'''', N'''''') + N''' + ''%''';
  IF NULLIF(LTRIM(RTRIM(@phone)), N'') IS NOT NULL
    SET @w = @w + N' AND ' + @alias + N'.phone1 LIKE ''%'' + ''' + REPLACE(@phone, N'''', N'''''') + N''' + ''%''';

  IF @scope_unrestricted = 0 AND @area_limit_id IS NOT NULL
    SET @w = @w + dbo.hwy_card_flow_geo_or_clause(@alias, @area_limit_id, @geo_limits_csv, 1, @gender_limits_csv);

  RETURN @w;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_card_flow_count
  @step NVARCHAR(32),
  @list_type NVARCHAR(64) = NULL,
  @visibility NVARCHAR(16) = NULL,
  @role_id NVARCHAR(32) = NULL,
  @username NVARCHAR(128) = NULL,
  @phone NVARCHAR(64) = NULL,
  @scope_unrestricted BIT = 1,
  @area_limit_id BIGINT = NULL,
  @geo_limits_csv NVARCHAR(MAX) = NULL,
  @gender_limits_csv NVARCHAR(MAX) = NULL,
  @nakheb_province_id BIGINT = NULL,
  @nakheb_circle_id BIGINT = NULL,
  @nakheb_tamvin_id BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NULL
    THROW 50400, N'dbo.hwy_members is not available.', 1;

  DECLARE @where NVARCHAR(MAX) = dbo.hwy_card_flow_where_clause(
    @step, @list_type, @visibility, @role_id, @username, @phone, N'M',
    @scope_unrestricted, @area_limit_id, @geo_limits_csv, @gender_limits_csv,
    @nakheb_province_id, @nakheb_circle_id, @nakheb_tamvin_id);
  DECLARE @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS total FROM dbo.hwy_members M WITH (NOLOCK) WHERE M.membership_status_legacy=10851' + @where;
  EXEC sp_executesql @sql;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_card_flow_list
  @step NVARCHAR(32),
  @list_type NVARCHAR(64) = NULL,
  @visibility NVARCHAR(16) = NULL,
  @role_id NVARCHAR(32) = NULL,
  @username NVARCHAR(128) = NULL,
  @phone NVARCHAR(64) = NULL,
  @scope_unrestricted BIT = 1,
  @area_limit_id BIGINT = NULL,
  @geo_limits_csv NVARCHAR(MAX) = NULL,
  @gender_limits_csv NVARCHAR(MAX) = NULL,
  @nakheb_province_id BIGINT = NULL,
  @nakheb_circle_id BIGINT = NULL,
  @nakheb_tamvin_id BIGINT = NULL,
  @offset INT = 0,
  @page_size INT = 25
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NULL
    THROW 50400, N'dbo.hwy_members is not available.', 1;

  DECLARE @where NVARCHAR(MAX) = dbo.hwy_card_flow_where_clause(
    @step, @list_type, @visibility, @role_id, @username, @phone, N'M',
    @scope_unrestricted, @area_limit_id, @geo_limits_csv, @gender_limits_csv,
    @nakheb_province_id, @nakheb_circle_id, @nakheb_tamvin_id);
  DECLARE @sql NVARCHAR(MAX) = N'
    SELECT
      CAST(M.id AS VARCHAR(32)) AS id,
      M.username AS username,
      M.first_name AS first_name,
      M.father_name AS father_name,
      M.grandfather_name AS grandfather_name,
      M.family_name AS family_name,
      M.phone1 AS phone1,
      CAST(M.gender_legacy_id AS VARCHAR(32)) AS gender_id,
      CAST(M.card_flow_last_status_id AS VARCHAR(32)) AS card_flow_last_status_id,
      CONVERT(VARCHAR(32), M.card_flow_started_on, 126) AS card_flow_started_on,
      CAST(M.card_flow_visibility AS BIT) AS card_flow_visibility,
      CAST(dbo.hwy_card_flow_latest_step_id(M.id) AS VARCHAR(32)) AS latest_step_id,
      (SELECT TOP 1 SP.can_get_identity_card FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=M.id ORDER BY SP.created_on DESC) AS last_can_get_identity_card,
      (SELECT TOP 1 SP.can_get_identity_card FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK) WHERE SP.member_id=M.id ORDER BY SP.created_on DESC) AS last_security_profile_can_get_identity_card,
      ISNULL(M.stat_fields_completed, 0) AS stat_fields_completed,
      (SELECT TOP 1 BI.title FROM dbo.hwy_ref_base_information BI WITH (NOLOCK) WHERE BI.id=M.nakheb_join_province_id) AS nakheb_join_province_name,
      (SELECT TOP 1 C.circle_name FROM dbo.hwy_ref_h_circles C WITH (NOLOCK) WHERE C.circle_id=M.nakheb_join_circle_id) AS nakheb_join_circle_name,
      (SELECT TOP 1 T.tamvin_name FROM dbo.hwy_ref_h_tamvinat T WITH (NOLOCK) WHERE T.tamvin_id=M.nakheb_join_tamvin_id) AS nakheb_join_tamvin_name
    FROM dbo.hwy_members M WITH (NOLOCK)
    WHERE M.membership_status_legacy=10851' + @where + N'
    ORDER BY M.card_flow_started_on DESC, M.id DESC
    OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY';

  EXEC sp_executesql @sql, N'@offset INT, @page_size INT', @offset = @offset, @page_size = @page_size;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_card_flow_printed_history_count
  @username NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.hwy_member_card_printing_history', N'U') IS NULL
    THROW 50400, N'Legacy card printing history is not available.', 1;

  SELECT COUNT(*) AS total
  FROM dbo.hwy_member_card_printing_history H WITH (NOLOCK)
  LEFT JOIN dbo.hwy_members M WITH (NOLOCK) ON M.id= H.member_id
  WHERE @username IS NULL OR M.username LIKE N'%' + @username + N'%';
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_card_flow_printed_history_list
  @username NVARCHAR(128) = NULL,
  @offset INT = 0,
  @page_size INT = 25
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.hwy_member_card_printing_history', N'U') IS NULL
    THROW 50400, N'Legacy card printing history is not available.', 1;

  IF OBJECT_ID(N'dbo.HWY_VW_Members_CardPrintingHistoryPlusEntema', N'V') IS NOT NULL
  BEGIN
    DECLARE @sql NVARCHAR(MAX) = N'
      SELECT
        CAST(V.id AS VARCHAR(64)) AS id,
        CAST(V.member_id AS VARCHAR(32)) AS member_id,
        V.RFID AS rfid,
        CAST(V.TypeId AS VARCHAR(32)) AS type_id,
        V.TypeId_Title AS type_title,
        CONVERT(VARCHAR(32), V.ExpirationDate, 126) AS expiration_date,
        V.created_by AS created_by,
        CONVERT(VARCHAR(32), V.created_at, 126) AS created_at,
        M.username AS username,
        M.first_name AS first_name,
        M.father_name AS father_name,
        M.family_name AS family_name
      FROM dbo.HWY_VW_Members_CardPrintingHistoryPlusEntema V WITH (NOLOCK)
      LEFT JOIN dbo.hwy_members M WITH (NOLOCK) ON M.id= V.member_id
      WHERE (@username IS NULL OR M.username LIKE N''%'' + @username + N''%'')
      ORDER BY V.created_on DESC
      OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY';
    EXEC sp_executesql @sql, N'@username NVARCHAR(128), @offset INT, @page_size INT', @username = @username, @offset = @offset, @page_size = @page_size;
    RETURN;
  END;

  SELECT
    CAST(H.id AS VARCHAR(64)) AS id,
    CAST(H.member_id AS VARCHAR(32)) AS member_id,
    H.rfid AS rfid,
    CAST(H.type_id AS VARCHAR(32)) AS type_id,
    NULL AS type_title,
    CONVERT(VARCHAR(32), H.expiration_date, 126) AS expiration_date,
    H.created_by AS created_by,
    CONVERT(VARCHAR(32), H.created_on, 126) AS created_at,
    M.username AS username,
    M.first_name AS first_name,
    M.father_name AS father_name,
    M.family_name AS family_name
  FROM dbo.hwy_member_card_printing_history H WITH (NOLOCK)
  LEFT JOIN dbo.hwy_members M WITH (NOLOCK) ON M.id= H.member_id
  WHERE @username IS NULL OR M.username LIKE N'%' + @username + N'%'
  ORDER BY H.created_on DESC
  OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_card_flow_insert_step
  @member_id BIGINT,
  @step_id INT,
  @actor NVARCHAR(128) = NULL,
  @reason_id BIGINT = NULL,
  @note NVARCHAR(MAX) = NULL,
  @set_visibility BIT = 0
AS
BEGIN
  SET NOCOUNT ON;
  INSERT INTO dbo.hwy_member_card_printing_flow_steps (member_id, step_id, reason_id, note, step_by, step_on)
  VALUES (@member_id, @step_id, @reason_id, @note, @actor, GETDATE());

  DECLARE @new_id BIGINT = SCOPE_IDENTITY();

  UPDATE dbo.hwy_members
  SET card_flow_last_status_id = @new_id,
      card_flow_visibility = CASE WHEN @set_visibility = 1 THEN 1 ELSE card_flow_visibility END,
      card_flow_started_by = CASE WHEN card_flow_started_by IS NULL OR card_flow_started_by = N'' THEN @actor ELSE card_flow_started_by END,
      card_flow_started_on = CASE WHEN card_flow_started_on IS NULL THEN SYSUTCDATETIME() ELSE card_flow_started_on END
  WHERE id= @member_id;

  SELECT @new_id AS flow_step_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_card_flow_recalc_can_start
AS
BEGIN
  SET NOCOUNT ON;
  IF OBJECT_ID(N'dbo.HWY_SP_Members_CalcStats2', N'P') IS NULL
    THROW 50400, N'Legacy HWY_SP_Members_CalcStats2 is not available.', 1;
  EXEC dbo.HWY_SP_Members_CalcStats2 NULL;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_card_flow_apply_step
  @step NVARCHAR(32),
  @action NVARCHAR(32),
  @member_id BIGINT,
  @actor NVARCHAR(128) = NULL,
  @reason_id BIGINT = NULL,
  @note NVARCHAR(MAX) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @st NVARCHAR(32) = LOWER(LTRIM(RTRIM(@step)));
  DECLARE @act NVARCHAR(32) = LOWER(LTRIM(RTRIM(@action)));

  IF @st = N'start' AND @act = N'start'
  BEGIN
    IF OBJECT_ID(N'dbo.HWY_SP_Members_CardFlowStart', N'P') IS NOT NULL
    BEGIN
      EXEC dbo.HWY_SP_Members_CardFlowStart @MemberId = @member_id, @Actor = @actor;
      RETURN;
    END;
    EXEC dbo.hwy_card_flow_insert_step @member_id = @member_id, @step_id = 213876, @actor = @actor, @set_visibility = 1;
    RETURN;
  END;

  IF @act = N'recalc-can-start'
  BEGIN
    EXEC dbo.hwy_card_flow_recalc_can_start;
    RETURN;
  END;

  IF @act = N'toggle-visibility'
  BEGIN
    UPDATE dbo.hwy_members SET card_flow_visibility = ~ISNULL(card_flow_visibility, 1) WHERE id= @member_id;
    RETURN;
  END;

  IF @act = N'reject-permanent'
  BEGIN
    DELETE FROM dbo.hwy_member_card_printing_flow_steps WHERE member_id = @member_id;
    UPDATE dbo.hwy_members
    SET card_flow_last_status_id = NULL, card_flow_visibility = 0, card_flow_started_by = NULL, card_flow_started_on = NULL,
        picture_file_body = NULL, picture_file_body_xs = NULL, picture_file_name = NULL, picture_file_size = NULL, picture_file_mime = NULL
    WHERE id= @member_id;
    IF OBJECT_ID(N'dbo.HWY_SP_Members_UpdateStats', N'P') IS NOT NULL
      EXEC dbo.HWY_SP_Members_UpdateStats @MemberId = @member_id;
    RETURN;
  END;

  DECLARE @step_id INT = NULL;
  DECLARE @set_vis BIT = 0;

  IF @st = N'central' AND @act = N'accept' SET @step_id = 213877;
  ELSE IF @st = N'central' AND @act = N'reject' SET @step_id = 213888;
  ELSE IF @st = N'province' AND @act = N'accept' SET @step_id = 213876;
  ELSE IF @st = N'print' AND @act = N'printed' SET @step_id = 213879;
  ELSE IF @st = N'print' AND @act = N'reject' SET @step_id = 213931;
  ELSE IF @st = N'province-delivery' AND @act = N'deliver' SET @step_id = 213880;
  ELSE IF @st = N'member-delivery' AND @act = N'deliver' SET @step_id = 213881;
  ELSE IF @st = N'member-delivery' AND @act = N'reject' SET @step_id = 213935;
  ELSE IF @st = N'central' AND @act = N'reject-to-first' SET @step_id = 213943;

  IF @step_id IS NULL
    THROW 50400, N'Card flow action is not available for this step.', 1;

  IF @st = N'central' AND @act = N'accept' SET @set_vis = 1;

  EXEC dbo.hwy_card_flow_insert_step
    @member_id = @member_id,
    @step_id = @step_id,
    @actor = @actor,
    @reason_id = @reason_id,
    @note = @note,
    @set_visibility = @set_vis;
END;
GO
