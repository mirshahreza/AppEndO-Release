SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_activity_insert_draft
  @id BIGINT,
  @title NVARCHAR(512),
  @note NVARCHAR(MAX) = NULL,
  @activity_date NVARCHAR(64) = NULL,
  @activity_type_code NVARCHAR(128),
  @activity_subtype_code NVARCHAR(128) = NULL,
  @status_code NVARCHAR(128),
  @nashat_location NVARCHAR(512) = NULL,
  @enable_self_announcement BIT,
  @require_submission_device_metadata BIT = NULL,
  @legacy_created_by NVARCHAR(256)
AS
BEGIN
  SET NOCOUNT ON;

  INSERT INTO dbo.hwy_activities (
    id, title, note, activity_date, activity_type_code, activity_subtype_code,
    status_code, nashat_location, enable_self_announcement, require_submission_device_metadata,
    legacy_created_by, created_at
  ) VALUES (
    @id, @title, @note, @activity_date, @activity_type_code, @activity_subtype_code,
    @status_code, @nashat_location, @enable_self_announcement, @require_submission_device_metadata,
    @legacy_created_by, SYSUTCDATETIME()
  );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_activity_update_draft
  @activity_id BIGINT,
  @expected_status_code NVARCHAR(128),
  @title NVARCHAR(512),
  @note NVARCHAR(MAX) = NULL,
  @activity_date NVARCHAR(64) = NULL,
  @activity_type_code NVARCHAR(128),
  @activity_subtype_code NVARCHAR(128) = NULL,
  @nashat_location NVARCHAR(512) = NULL,
  @enable_self_announcement BIT,
  @require_submission_device_metadata BIT = NULL,
  @legacy_updated_by NVARCHAR(256)
AS
BEGIN
  SET NOCOUNT ON;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_activities WHERE id = @activity_id)
    THROW 56000, N'Activity not found.', 1;

  IF (SELECT status_code FROM dbo.hwy_activities WHERE id = @activity_id) <> @expected_status_code
    THROW 56001, N'Only draft activities can be edited.', 1;

  UPDATE dbo.hwy_activities
  SET
    title = @title,
    note = @note,
    activity_date = @activity_date,
    activity_type_code = @activity_type_code,
    activity_subtype_code = @activity_subtype_code,
    nashat_location = @nashat_location,
    enable_self_announcement = @enable_self_announcement,
    require_submission_device_metadata = @require_submission_device_metadata,
    legacy_updated_by = @legacy_updated_by,
    updated_at = SYSUTCDATETIME()
  WHERE id = @activity_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_course_insert_draft
  @id BIGINT,
  @trainer_member_id BIGINT = NULL,
  @legacy_province_id INT = NULL,
  @course_type_code NVARCHAR(128),
  @course_subtype_code NVARCHAR(128) = NULL,
  @note NVARCHAR(MAX) = NULL,
  @course_date NVARCHAR(64) = NULL,
  @status_code NVARCHAR(128),
  @legacy_created_by NVARCHAR(256)
AS
BEGIN
  SET NOCOUNT ON;

  INSERT INTO dbo.hwy_courses (
    id, trainer_member_id, legacy_province_id, course_type_code, course_subtype_code, note,
    course_date, status_code, legacy_created_by, created_at
  ) VALUES (
    @id, @trainer_member_id, @legacy_province_id, @course_type_code, @course_subtype_code, @note,
    @course_date, @status_code, @legacy_created_by, SYSUTCDATETIME()
  );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_course_update_draft
  @course_id BIGINT,
  @expected_status_code NVARCHAR(128),
  @trainer_member_id BIGINT = NULL,
  @legacy_province_id INT = NULL,
  @course_type_code NVARCHAR(128),
  @course_subtype_code NVARCHAR(128) = NULL,
  @note NVARCHAR(MAX) = NULL,
  @course_date NVARCHAR(64) = NULL,
  @legacy_updated_by NVARCHAR(256)
AS
BEGIN
  SET NOCOUNT ON;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_courses WHERE id = @course_id)
    THROW 56100, N'Course not found.', 1;

  IF (SELECT status_code FROM dbo.hwy_courses WHERE id = @course_id) <> @expected_status_code
    THROW 56101, N'Only draft courses can be edited.', 1;

  UPDATE dbo.hwy_courses
  SET
    trainer_member_id = @trainer_member_id,
    legacy_province_id = @legacy_province_id,
    course_type_code = @course_type_code,
    course_subtype_code = @course_subtype_code,
    note = @note,
    course_date = @course_date,
    legacy_updated_by = @legacy_updated_by,
    updated_at = SYSUTCDATETIME()
  WHERE id = @course_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_activity_add_file
  @file_id UNIQUEIDENTIFIER,
  @activity_id BIGINT,
  @expected_status_code NVARCHAR(128),
  @original_file_name NVARCHAR(256),
  @mime NVARCHAR(32),
  @size_bytes INT,
  @content VARBINARY(MAX),
  @legacy_created_by NVARCHAR(256)
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  DECLARE @file_count INT;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_activities WHERE id = @activity_id)
    THROW 56200, N'Activity not found.', 1;

  SELECT @file_count = COUNT(*) FROM dbo.hwy_activity_files WHERE activity_id = @activity_id;

  IF (SELECT status_code FROM dbo.hwy_activities WHERE id = @activity_id) <> @expected_status_code
    THROW 56201, N'Files can only be added to draft activities.', 1;

  IF @file_count >= 4
    THROW 56202, N'An activity can have at most four files.', 1;

  INSERT INTO dbo.hwy_activity_files (
    id, activity_id, original_file_name, mime, size_bytes, content, legacy_created_by, created_at
  ) VALUES (
    @file_id, @activity_id, @original_file_name, @mime, @size_bytes, @content, @legacy_created_by, SYSUTCDATETIME()
  );
END;
GO
