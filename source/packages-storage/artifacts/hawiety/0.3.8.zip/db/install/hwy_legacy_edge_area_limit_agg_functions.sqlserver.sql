-- Member area-limit aggregates for candidate pipeline views (edge hwy_member_area_limits).

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER FUNCTION dbo.hwy_member_agg_area_limits(@member_id BIGINT)
RETURNS NVARCHAR(MAX)
AS
BEGIN
  DECLARE @out NVARCHAR(MAX) = NULL;
  IF OBJECT_ID(N'dbo.hwy_member_area_limits', N'U') IS NULL
    RETURN NULL;

  SELECT @out = STRING_AGG(CAST(al.item_id AS NVARCHAR(32)), N', ')
  FROM dbo.hwy_member_area_limits al WITH (NOLOCK)
  WHERE al.member_id = @member_id;

  RETURN @out;
END;
GO

CREATE OR ALTER FUNCTION dbo.hwy_member_agg_area_limits_for_tarshih(@member_id BIGINT)
RETURNS NVARCHAR(MAX)
AS
BEGIN
  DECLARE @out NVARCHAR(MAX) = NULL;
  IF OBJECT_ID(N'dbo.hwy_member_area_limits', N'U') IS NULL
    RETURN NULL;

  SELECT @out = STRING_AGG(CAST(al.item_id AS NVARCHAR(32)), N', ')
  FROM dbo.hwy_member_area_limits al WITH (NOLOCK)
  WHERE al.member_id = @member_id
    AND ISNULL(al.approved, 0) = 1;

  RETURN @out;
END;
GO

IF OBJECT_ID(N'dbo.HWY_FN_Agg_AreaLimits', N'FN') IS NOT NULL
  DROP FUNCTION dbo.HWY_FN_Agg_AreaLimits;
GO

IF OBJECT_ID(N'dbo.HWY_FN_Agg_AreaLimitsForTarshih', N'FN') IS NOT NULL
  DROP FUNCTION dbo.HWY_FN_Agg_AreaLimitsForTarshih;
GO
