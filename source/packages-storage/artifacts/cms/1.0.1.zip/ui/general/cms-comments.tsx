import React from 'react';
import { buildAppTableGridColumns } from '@/domain/component-designer/DesignerRuntimeAppTableGrid';
import { applyClientGridQuery, EMPTY_GRID_QUERY, type GridQueryState } from '@/shared/lib/appTableGridQuery';
import { resolveDataGridTotalCount, sliceDataGridRowsForDisplay, buildDataGridPageNumbers, applyGridAggregation } from '@/domain/component-designer/designerDataGridRuntime';
import { applyDesignerGridToolbarClientFilters } from '@/domain/component-designer/designerGridToolbarConfig';
import { createDefaultColumnLayout } from '@/shared/lib/appTableGridColumnLayout';
import { AppTableGrid, ConfirmDialogShell, CreateEditModalShell, GridPagingFooter, ToolbarFilterSelect } from '@/shared/ui';
import { Button, Toast, toast } from '@heroui/react';
import { Check, Trash2, X } from 'lucide-react';

const parseApiErrorMessage = async (response: Response): Promise<string> => {
  try {
    const payload = await response.json();
    if (payload && typeof payload === "object") {
      const record = payload as Record<string, unknown>;
      const message = record.message ?? record.error ?? record.detail;
      if (typeof message === "string" && message.trim().length > 0) {
        return message.trim();
      }
    }
  } catch {
    // fall through to status text
  }
  return response.statusText || `Request failed (${response.status})`;
};

const readBindingParamValue = (
  context: Record<string, unknown> | null | undefined,
  dataPath: string,
): unknown => {
  const segments = dataPath.split(".").map((segment) => segment.trim()).filter(Boolean);
  let cursor: unknown = context;
  for (const segment of segments) {
    if (cursor && typeof cursor === "object" && segment in (cursor as Record<string, unknown>)) {
      cursor = (cursor as Record<string, unknown>)[segment];
    } else {
      return undefined;
    }
  }
  return cursor;
};

const resolveBindingTemplateValue = (
  template: string,
  context: Record<string, unknown> | null | undefined,
  paramPaths: Record<string, string>,
): string =>
  template.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, paramName: string) => {
    const dataPath = paramPaths[paramName];
    if (!dataPath) {
      return "";
    }
    const cursor = readBindingParamValue(context, dataPath);
    return cursor === undefined || cursor === null ? "" : String(cursor);
  });

const resolveBindingUrl = (
  endpointTemplate: string,
  context: Record<string, unknown> | null | undefined,
  paramPaths: Record<string, string>,
): string => {
  const usedParamNames = new Set<string>();
  let resolvedPath = endpointTemplate.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, paramName: string) => {
    usedParamNames.add(paramName);
    const dataPath = paramPaths[paramName];
    if (!dataPath) {
      return "";
    }
    const cursor = readBindingParamValue(context, dataPath);
    return cursor === undefined || cursor === null ? "" : String(cursor);
  });
  for (const [paramName, dataPath] of Object.entries(paramPaths)) {
    if (usedParamNames.has(paramName)) {
      continue;
    }
    const colonParamPattern = new RegExp(`:${paramName}(?=/|$)`, "g");
    if (!colonParamPattern.test(resolvedPath)) {
      continue;
    }
    usedParamNames.add(paramName);
    const cursor = readBindingParamValue(context, dataPath);
    const text = cursor === undefined || cursor === null ? "" : String(cursor);
    resolvedPath = resolvedPath.replace(new RegExp(`:${paramName}(?=/|$)`, "g"), text);
  }
  const searchParams = new URLSearchParams();
  for (const [paramName, dataPath] of Object.entries(paramPaths)) {
    if (usedParamNames.has(paramName)) {
      continue;
    }
    const cursor = readBindingParamValue(context, dataPath);
    if (cursor === undefined || cursor === null) {
      continue;
    }
    const text = String(cursor).trim();
    if (text.length === 0) {
      continue;
    }
    searchParams.set(paramName, text);
  }
  const queryString = searchParams.toString();
  if (!queryString) {
    return resolvedPath;
  }
  return resolvedPath.includes("?") ? `${resolvedPath}&${queryString}` : `${resolvedPath}?${queryString}`;
};

const resolveBindingHeaders = (
  context: Record<string, unknown> | null | undefined,
  headerTemplates: Record<string, string>,
  paramPaths: Record<string, string>,
): Record<string, string> =>
  Object.fromEntries(
    Object.entries(headerTemplates).map(([key, template]) => [
      key,
      resolveBindingTemplateValue(template, context, paramPaths),
    ]),
  );

const setNestedPayloadValue = (target: Record<string, unknown>, path: string, value: unknown): void => {
  const segments = path.split(".").map((segment) => segment.trim()).filter(Boolean);
  if (segments.length === 0) {
    return;
  }
  let cursor: Record<string, unknown> = target;
  for (let index = 0; index < segments.length - 1; index += 1) {
    const segment = segments[index];
    const next = cursor[segment];
    if (!next || typeof next !== "object" || Array.isArray(next)) {
      cursor[segment] = {};
    }
    cursor = cursor[segment] as Record<string, unknown>;
  }
  cursor[segments[segments.length - 1]] = value;
};

const mapDesignerListBoxItems = (rawItems: unknown): Array<{ id: string; textValue: string }> => {
  const items = Array.isArray(rawItems) ? rawItems : [];
  return items
    .map((entry) => {
      if (!entry || typeof entry !== "object") {
        return null;
      }
      const record = entry as Record<string, unknown>;
      const id = String(record.id ?? "").trim();
      if (!id || id === "100" || id === "102") {
        return null;
      }
      const textValue = String(record.textValue ?? record.label ?? record.title ?? id).trim();
      return { id, textValue: textValue || id };
    })
    .filter((entry): entry is { id: string; textValue: string } => entry !== null);
};

const mapDesignerLovItems = (
  rawItems: unknown,
  returnColumn: string,
  displayColumn: string,
): Array<{ id: string; textValue: string }> => {
  const items = Array.isArray(rawItems) ? rawItems : [];
  return items
    .map((entry) => {
      if (!entry || typeof entry !== "object") {
        return null;
      }
      const record = entry as Record<string, unknown>;
      const id = String(record[returnColumn] ?? "").trim();
      if (!id) {
        return null;
      }
      const textValue = String(record[displayColumn] ?? id).trim();
      return { id, textValue: textValue || id };
    })
    .filter((entry): entry is { id: string; textValue: string } => entry !== null);
};

const collectRegionFormDataFromContainer = (
  container: ParentNode,
  formFieldNames: readonly string[],
): FormData => {
  const formData = new FormData();
  for (const formFieldName of formFieldNames) {
    const escapedName = formFieldName.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    const field = container.querySelector(`[name="${escapedName}"]`);
    if (!field) {
      continue;
    }
    if (field instanceof HTMLInputElement) {
      if (field.type === "checkbox" || field.type === "radio") {
        formData.set(formFieldName, field.checked ? "true" : "false");
      } else {
        formData.set(formFieldName, field.value);
      }
      continue;
    }
    if (field instanceof HTMLTextAreaElement || field instanceof HTMLSelectElement) {
      formData.set(formFieldName, field.value);
      continue;
    }
    formData.set(formFieldName, field.getAttribute("value") ?? "");
  }
  return formData;
};

const applyPayloadFieldTransform = (value: FormDataEntryValue | null, transform?: string): unknown => {
  const raw = value === null ? "" : String(value);
  switch (transform) {
    case "number": {
      const parsed = Number(raw);
      return Number.isFinite(parsed) ? parsed : raw;
    }
    case "boolean":
      return raw === "true" || raw === "1" || raw === "on";
    case "nullableString":
      return raw.trim().length > 0 ? raw : null;
    case "nullableBoolean": {
      const trimmed = raw.trim().toLowerCase();
      if (!trimmed) return null;
      if (trimmed === "true" || trimmed === "1" || trimmed === "on") return true;
      if (trimmed === "false" || trimmed === "0" || trimmed === "off") return false;
      return null;
    }
    case "commaSeparatedArray":
      return raw.split(",").map((entry) => entry.trim()).filter(Boolean);
    default:
      return raw;
  }
};

// --- AUTH / TOKEN LIFECYCLE INJECTION POINT ---
// Register your application-wide 401 interceptor and token refresh handler here before production.
// Example: const designerFetch = createAuthenticatedFetch({ getAccessToken, refreshTokens, onSessionExpired });
const designerFetch: typeof fetch = fetch;

function useDataFetch<T>(url: string, options: { headers?: Record<string, string> } = {}) {
  const [data, setData] = React.useState<T | null>(null);
  const [isLoading, setIsLoading] = React.useState(Boolean(url));
  const [error, setError] = React.useState<string | null>(null);
  const [refreshNonce, setRefreshNonce] = React.useState(0);
  const headersKey = JSON.stringify(options.headers ?? {});

  const refresh = React.useCallback(async () => {
    setRefreshNonce((previous) => previous + 1);
  }, []);

  React.useEffect(() => {
    if (!url) {
      setData(null);
      setIsLoading(false);
      setError(null);
      return undefined;
    }

    let cancelled = false;
    const load = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const response = await designerFetch(url, {
          method: "GET",
          headers: options.headers,
        });
        if (!response.ok) {
          throw new Error(await parseApiErrorMessage(response));
        }
        const payload = (await response.json()) as T;
        if (!cancelled) {
          setData(payload);
        }
      } catch (loadError) {
        if (!cancelled) {
          setData(null);
          setError(loadError instanceof Error ? loadError.message : "Request failed");
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, [url, headersKey, refreshNonce]);

  return { data, setData, isLoading, error, refresh };
}

const readNestedContextValue = (
  context: Record<string, unknown> | null | undefined,
  path: string,
): unknown => {
  const segments = path.split(".").map((segment) => segment.trim()).filter(Boolean);
  let cursor: unknown = context;
  for (const segment of segments) {
    if (cursor && typeof cursor === "object" && segment in (cursor as Record<string, unknown>)) {
      cursor = (cursor as Record<string, unknown>)[segment];
    } else {
      return undefined;
    }
  }
  return cursor;
};

const applyResponseDataPath = (
  payload: unknown,
  responseMapping?: { dataPath?: string; arrayPath?: string },
): unknown => {
  if (!responseMapping) {
    return payload;
  }
  const arrayPath = responseMapping.arrayPath?.trim();
  if (arrayPath) {
    const arrayValue = readNestedContextValue(
      payload && typeof payload === "object" ? payload as Record<string, unknown> : {},
      arrayPath,
    );
    if (Array.isArray(arrayValue)) {
      return arrayValue;
    }
  }
  const dataPath = responseMapping.dataPath?.trim();
  if (!dataPath || !payload || typeof payload !== "object") {
    return payload;
  }
  return readNestedContextValue(payload as Record<string, unknown>, dataPath);
};

const coerceApiRecordValue = (value: unknown): Record<string, unknown> | undefined => {
  if (value === undefined || value === null) {
    return undefined;
  }
  if (Array.isArray(value)) {
    return value.find(
      (entry): entry is Record<string, unknown> =>
        typeof entry === "object" && entry !== null && !Array.isArray(entry),
    );
  }
  if (typeof value === "object") {
    return value as Record<string, unknown>;
  }
  return undefined;
};

const transformApiRowsToChartData = (
  rows: Array<Record<string, unknown>>,
  mapping: { categoryField: string; categoryAs?: string; series: Array<{ apiField: string; seriesKey: string; aggregation?: string }>; seriesGroupField?: string; sortBy?: { field: string; direction: "asc"|"desc" }; limitTopN?: { count: number; groupRestAsLabel: string } },
): Array<Record<string, string | number>> => {
  const categoryKey = mapping.categoryAs?.trim() || "label";
  const parseNum = (raw: unknown): number => {
    if (typeof raw === "number" && Number.isFinite(raw)) return raw;
    if (typeof raw === "string") { const p = Number(raw); return Number.isFinite(p) ? p : 0; }
    return 0;
  };
  const sourceRows = mapping.categoryField === "__rowIndex"
    ? rows.map((row, index) => ({ ...row, __rowIndex: String(index + 1) }))
    : rows;
  const aggregate = (values: number[], agg: string): number => {
    if (values.length === 0) return 0;
    if (agg === "count") return values.length;
    if (agg === "avg") return values.reduce((s, v) => s + v, 0) / values.length;
    if (agg === "min") return Math.min(...values);
    if (agg === "max") return Math.max(...values);
    if (agg === "sum") return values.reduce((s, v) => s + v, 0);
    return values[0] ?? 0;
  };
  let chartRows: Array<Record<string, string | number>> = [];
  const groupField = mapping.seriesGroupField?.trim();
  if (groupField) {
    const valueField = mapping.series[0]?.apiField ?? "value";
    const grouped = new Map<string, Map<string, number[]>>();
    for (const row of sourceRows) {
      const category = String(row[mapping.categoryField] ?? "");
      const seriesName = String(row[groupField] ?? "Series");
      let catBucket = grouped.get(category);
      if (!catBucket) { catBucket = new Map(); grouped.set(category, catBucket); }
      const values = catBucket.get(seriesName) ?? [];
      values.push(parseNum(row[valueField]));
      catBucket.set(seriesName, values);
    }
    chartRows = Array.from(grouped.entries()).map(([category, seriesMap]) => {
      const chartRow: Record<string, string | number> = { [categoryKey]: category };
      for (const [seriesName, values] of seriesMap.entries()) {
        chartRow[seriesName] = aggregate(values, "sum");
      }
      return chartRow;
    });
  } else {
    const needsGrouping = mapping.series.some((s) => s.aggregation && s.aggregation !== "none");
    if (!needsGrouping) {
      chartRows = sourceRows.map((row) => {
        const chartRow: Record<string, string | number> = { [categoryKey]: String(row[mapping.categoryField] ?? "") };
        for (const series of mapping.series) { chartRow[series.seriesKey] = parseNum(row[series.apiField]); }
        return chartRow;
      });
    } else {
      const grouped = new Map<string, Array<Record<string, unknown>>>();
      for (const row of sourceRows) {
        const cat = String(row[mapping.categoryField] ?? "");
        const bucket = grouped.get(cat);
        if (bucket) bucket.push(row); else grouped.set(cat, [row]);
      }
      chartRows = Array.from(grouped.entries()).map(([category, groupRows]) => {
        const chartRow: Record<string, string | number> = { [categoryKey]: category };
        for (const series of mapping.series) {
          const values = groupRows.map((r) => parseNum(r[series.apiField]));
          chartRow[series.seriesKey] = aggregate(values, series.aggregation ?? "sum");
        }
        return chartRow;
      });
    }
  }
  if (mapping.sortBy?.field) {
    const field = mapping.sortBy.field;
    const direction = mapping.sortBy.direction;
    chartRows = [...chartRows].sort((a, b) => {
      const an = parseNum(a[field]); const bn = parseNum(b[field]);
      return direction === "asc" ? an - bn : bn - an;
    });
  }
  if (mapping.limitTopN && mapping.limitTopN.count > 0 && chartRows.length > mapping.limitTopN.count) {
    const top = chartRows.slice(0, mapping.limitTopN.count);
    const rest = chartRows.slice(mapping.limitTopN.count);
    const restRow: Record<string, string | number> = { [categoryKey]: mapping.limitTopN.groupRestAsLabel || "Other" };
    for (const series of mapping.series) {
      restRow[series.seriesKey] = rest.reduce((sum, row) => sum + parseNum(row[series.seriesKey]), 0);
    }
    chartRows = [...top, restRow];
  }
  return chartRows;
};

const mergeMultiSourceChartData = (
  datasets: Array<Array<Record<string, string | number>>>,
  xAxisKey: string,
): Array<Record<string, string | number>> => {
  if (datasets.length === 0) return [];
  if (datasets.length === 1) return datasets[0] ?? [];
  const merged = new Map<string, Record<string, string | number>>();
  for (const dataset of datasets) {
    for (const row of dataset) {
      const category = String(row[xAxisKey] ?? "");
      const existing = merged.get(category);
      merged.set(category, existing ? { ...existing, ...row } : { ...row });
    }
  }
  return Array.from(merged.values());
};

const readVizStringField = (row: Record<string, unknown>, field: string, fallback = ""): string => {
  const value = row[field];
  if (value === undefined || value === null) return fallback;
  return String(value);
};

const transformApiRowsToTreeNodes = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "tree"; idField: string; labelField: string; parentIdField?: string },
): Array<{ id: string; label: string; children?: unknown[] }> => {
  const parentField = mapping.parentIdField?.trim();
  if (!parentField) {
    return rows.map((row, index) => ({
      id: readVizStringField(row, mapping.idField, `node-${index + 1}`),
      label: readVizStringField(row, mapping.labelField, `Item ${index + 1}`),
    }));
  }
  const nodeMap = new Map<string, { id: string; label: string; children: unknown[] }>();
  rows.forEach((row) => {
    const id = readVizStringField(row, mapping.idField);
    if (!id) return;
    nodeMap.set(id, { id, label: readVizStringField(row, mapping.labelField, id), children: [] });
  });
  const roots: Array<{ id: string; label: string; children?: unknown[] }> = [];
  rows.forEach((row) => {
    const id = readVizStringField(row, mapping.idField);
    if (!id) return;
    const node = nodeMap.get(id);
    if (!node) return;
    const parentId = readVizStringField(row, parentField);
    if (parentId && nodeMap.has(parentId)) {
      nodeMap.get(parentId)!.children.push(node);
    } else {
      roots.push(node);
    }
  });
  return roots;
};

const readVizNumberField = (row: Record<string, unknown>, field: string): number | undefined => {
  const value = row[field];
  const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(parsed) ? parsed : undefined;
};

const transformApiRowsToTimelineEvents = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "timeline" | "gantt"; idField?: string; titleField: string; startField: string; endField?: string; descriptionField?: string; progressField?: string },
): Array<{ id?: string; title: string; start: string; end?: string; description?: string; progress?: number }> =>
  rows.map((row, index) => {
    const progress = mapping.progressField ? readVizNumberField(row, mapping.progressField) : undefined;
    return {
      id: mapping.idField ? readVizStringField(row, mapping.idField, `evt-${index + 1}`) : `evt-${index + 1}`,
      title: readVizStringField(row, mapping.titleField, `Event ${index + 1}`),
      start: readVizStringField(row, mapping.startField),
      ...(mapping.endField ? { end: readVizStringField(row, mapping.endField) } : {}),
      ...(mapping.descriptionField ? { description: readVizStringField(row, mapping.descriptionField) } : {}),
      ...(progress !== undefined ? { progress } : {}),
    };
  });

const transformApiRowsToKanbanBoard = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "kanban"; cardIdField: string; cardTitleField: string; cardDescriptionField?: string; cardColumnField: string; columnOrder?: Array<{ id: string; title: string }> },
): { columns: Array<{ id: string; title: string; cards: Array<{ id: string; title: string; description?: string }> }> } => {
  const cardsByColumn = new Map<string, Array<{ id: string; title: string; description?: string }>>();
  rows.forEach((row, index) => {
    const columnKey = readVizStringField(row, mapping.cardColumnField, "default");
    const card = {
      id: readVizStringField(row, mapping.cardIdField, `card-${index + 1}`),
      title: readVizStringField(row, mapping.cardTitleField, `Card ${index + 1}`),
      ...(mapping.cardDescriptionField ? { description: readVizStringField(row, mapping.cardDescriptionField) } : {}),
    };
    cardsByColumn.set(columnKey, [...(cardsByColumn.get(columnKey) ?? []), card]);
  });
  const columnOrder = mapping.columnOrder && mapping.columnOrder.length > 0
    ? mapping.columnOrder
    : Array.from(cardsByColumn.keys()).map((key) => ({ id: key, title: key }));
  const columns = columnOrder.map((columnDef) => ({
    id: columnDef.id,
    title: columnDef.title,
    cards: cardsByColumn.get(columnDef.id) ?? cardsByColumn.get(columnDef.title) ?? [],
  }));
  cardsByColumn.forEach((cards, columnKey) => {
    if (!columns.some((column) => column.id === columnKey || column.title === columnKey)) {
      columns.push({ id: columnKey, title: columnKey, cards });
    }
  });
  return { columns };
};

const transformApiRowsToSheetData = (
  rows: Array<Record<string, unknown>>,
  mapping: { kind: "sheet"; columns: Array<{ header: string; field: string; type?: "text" | "number" | "select" | "formula"; options?: string[]; formula?: string; onCellChangeAction?: unknown[] }> },
): { columns: Array<{ key: string; header: string; type?: "text" | "number" | "select" | "formula"; options?: string[]; formula?: string; onCellChangeAction?: unknown[] }>; rows: Array<Record<string, unknown>> } => ({
  columns: mapping.columns.map((column) => ({
    key: column.field,
    header: column.header,
    type: column.type ?? "text",
    ...(Array.isArray(column.options) && column.options.length > 0 ? { options: [...column.options] } : {}),
    ...(column.type === "formula" && column.formula ? { formula: column.formula } : {}),
    ...(Array.isArray(column.onCellChangeAction) && column.onCellChangeAction.length > 0 ? { onCellChangeAction: [...column.onCellChangeAction] } : {}),
  })),
  rows: rows.map((row) => mapping.columns.reduce<Record<string, unknown>>((acc, column) => {
    acc[column.field] = row[column.field];
    return acc;
  }, {})),
});

type EntityPickerOption = { id: string; textValue: string };
type EntityPickerFieldMapping = { returnField: string; displayField: string };

function normalizeEntityPickerItems(payload: unknown, mapping?: EntityPickerFieldMapping): EntityPickerOption[] {
  const returnField = mapping?.returnField?.trim() || "id";
  const displayField = mapping?.displayField?.trim() || "label";
  if (Array.isArray(payload)) {
    return payload
      .map((entry) => {
        if (!entry || typeof entry !== "object") {
          return null;
        }
        const record = entry as Record<string, unknown>;
        const mappedId = record[returnField];
        const id = typeof mappedId === "string" && mappedId.trim()
          ? mappedId.trim()
          : typeof record.id === "string" && record.id.trim()
            ? record.id.trim()
            : typeof record.value === "string" && record.value.trim()
              ? record.value.trim()
              : "";
        const mappedLabel = record[displayField];
        const textValue = typeof mappedLabel === "string" && mappedLabel.trim()
          ? mappedLabel.trim()
          : typeof record.textValue === "string" && record.textValue.trim()
            ? record.textValue.trim()
            : typeof record.label === "string" && record.label.trim()
              ? record.label.trim()
              : typeof record.name === "string" && record.name.trim()
                ? record.name.trim()
                : id;
        if (!id || !textValue) {
          return null;
        }
        return { id, textValue };
      })
      .filter((entry): entry is EntityPickerOption => entry !== null);
  }

  if (payload && typeof payload === "object") {
    const record = payload as Record<string, unknown>;
    const items = record.items ?? record.results ?? record.data;
    return normalizeEntityPickerItems(items, mapping);
  }

  return [];
}

function useEntityPickerOptions(entityRef: string, searchParam: string, mapping?: EntityPickerFieldMapping) {
  const [items, setItems] = React.useState<EntityPickerOption[]>([]);
  const [isLoading, setIsLoading] = React.useState(false);

  const loadOptions = React.useCallback(async (query: string) => {
    if (!entityRef) {
      setItems([]);
      return;
    }

    setIsLoading(true);
    try {
      const url = entityRef.startsWith("http")
        ? new URL(entityRef)
        : new URL(entityRef, window.location.origin);
      // Option A (parity audit items 31/32): Autocomplete is Select-based — no live typing.
      // Still honour an explicit non-empty query if a caller passes one, but initial load uses "".
      if (query.trim()) {
        url.searchParams.set(searchParam, query);
      }
      const response = await fetch(url.toString());
      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }
      const payload = await response.json();
      setItems(normalizeEntityPickerItems(payload, mapping));
    } catch {
      setItems([]);
    } finally {
      setIsLoading(false);
    }
  }, [entityRef, searchParam, mapping?.returnField, mapping?.displayField]);

  React.useEffect(() => {
    void loadOptions("");
  }, [loadOptions]);

  return { items, isLoading, loadOptions };
}

type DesignerLiveConnectionStatus = "idle" | "connecting" | "open" | "error" | "closed";

const parseLivePushPayload = (raw: string): { kind: "snapshot" | "append" | "refresh"; data?: unknown } | null => {
  const text = raw.trim();
  if (!text) { return null; }
  try {
    const parsed: unknown = JSON.parse(text);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      const record = parsed as Record<string, unknown>;
      const type = typeof record.type === "string" ? record.type.trim().toLowerCase() : "";
      if (type === "refresh") { return { kind: "refresh" }; }
      if (type === "append") { return { kind: "append", data: record.data ?? record.payload ?? record.row ?? record.rows }; }
      if (type === "snapshot" || type === "data" || type === "message") {
        return { kind: "snapshot", data: "data" in record ? record.data : ("payload" in record ? record.payload : parsed) };
      }
      if ("data" in record) { return { kind: "snapshot", data: record.data }; }
    }
    return { kind: "snapshot", data: parsed };
  } catch {
    return { kind: "snapshot", data: text };
  }
};

const applyLiveAppend = (current: unknown, incoming: unknown): unknown => {
  const incomingRows = Array.isArray(incoming) ? incoming : [incoming];
  if (Array.isArray(current)) { return [...current, ...incomingRows]; }
  if (current && typeof current === "object") {
    const record = current as Record<string, unknown>;
    for (const key of ["data", "rows", "items", "results"] as const) {
      const value = record[key];
      if (Array.isArray(value)) { return { ...record, [key]: [...value, ...incomingRows] }; }
    }
  }
  return incomingRows;
};

const absolutizeLiveStreamUrl = (url: string, type: "sse" | "websocket"): string => {
  if (!url) { return ""; }
  if (type === "websocket") {
    if (url.startsWith("ws://") || url.startsWith("wss://")) { return url; }
    if (url.startsWith("http://") || url.startsWith("https://")) { return url.replace(/^http/, "ws"); }
    const absoluteHttp = new URL(url, window.location.origin).href;
    return absoluteHttp.replace(/^http/, "ws");
  }
  return url;
};

function useLiveDataSource(options: {
  url: string;
  type: "sse" | "websocket";
  enabled?: boolean;
  onSnapshot: (data: unknown) => void;
  onAppend?: (data: unknown) => void;
  onRefresh?: () => void;
}) {
  const { url, type, enabled = true, onSnapshot, onAppend, onRefresh } = options;
  const [status, setStatus] = React.useState<DesignerLiveConnectionStatus>("idle");
  const onSnapshotRef = React.useRef(onSnapshot);
  const onAppendRef = React.useRef(onAppend);
  const onRefreshRef = React.useRef(onRefresh);
  onSnapshotRef.current = onSnapshot;
  onAppendRef.current = onAppend;
  onRefreshRef.current = onRefresh;
  React.useEffect(() => {
    if (!enabled || !url.trim()) { setStatus("idle"); return undefined; }
    const absoluteUrl = absolutizeLiveStreamUrl(url, type);
    let closed = false;
    setStatus("connecting");
    const dispatchPayload = (raw: string) => {
      const message = parseLivePushPayload(raw);
      if (!message) { return; }
      if (message.kind === "refresh") { onRefreshRef.current?.(); return; }
      if (message.kind === "append") {
        if (onAppendRef.current) { onAppendRef.current(message.data); }
        else { onSnapshotRef.current(message.data); }
        return;
      }
      onSnapshotRef.current(message.data);
    };
    if (type === "sse") {
      const source = new EventSource(absoluteUrl, { withCredentials: true });
      source.onopen = () => { if (!closed) { setStatus("open"); } };
      source.onmessage = (event) => { if (!closed) { dispatchPayload(String(event.data ?? "")); } };
      source.onerror = () => { if (!closed) { setStatus("error"); } };
      return () => { closed = true; source.close(); setStatus("closed"); };
    }
    const socket = new WebSocket(absoluteUrl);
    socket.onopen = () => { if (!closed) { setStatus("open"); } };
    socket.onmessage = (event) => { if (!closed) { dispatchPayload(typeof event.data === "string" ? event.data : String(event.data)); } };
    socket.onerror = () => { if (!closed) { setStatus("error"); } };
    socket.onclose = () => { if (!closed) { setStatus("closed"); } };
    return () => { closed = true; try { socket.close(); } catch {} setStatus("closed"); };
  }, [enabled, url, type]);
  return { status };
}

function useDesignerStore<T extends Record<string, unknown>>(initial: T) {
  const [store, setStore] = React.useState<T>(initial);
  const patch = React.useCallback((path: string, value: unknown) => {
    setStore((previous) => {
      const next = { ...previous };
      setNestedPayloadValue(next, path, value);
      return next as T;
    });
  }, []);
  return { store, patch };
}
function evaluateDesignerCondition(
  designerStore: Record<string, unknown>,
  dataContext: Record<string, unknown> | null,
  scope: { item?: unknown; index?: number },
  condition: string,
): boolean {
  const trimmed = condition.trim();
  if (!trimmed) {
    return true;
  }
  try {
    const formatPathChain = (root: string, path: string): string => {
      const chain = path
        .split('.')
        .filter(Boolean)
        .map((segment) => {
          if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(segment)) {
            return `?.${segment}`;
          }
          return `?.[${JSON.stringify(segment)}]`;
        })
        .join('');
      return `(${root}${chain})`;
    };
    let compiled = trimmed
      .replace(/\bstore\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('designerStore', path))
      .replace(/\bdata\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('dataContext', path))
      .replace(/\bdataContext\.([A-Za-z0-9_.-]+)/g, (_, path: string) => formatPathChain('dataContext', path));
    const evaluator = new Function('designerStore', 'dataContext', 'item', 'index', `return Boolean(${compiled});`);
    return Boolean(evaluator(designerStore, dataContext, scope.item, scope.index));
  } catch {
    return false;
  }
}

export const GeneratedComponent: React.FC = () => {
  const { store: designerStore, patch: patchDesignerStore } = useDesignerStore<Record<string, unknown>>({"selection":{"id":null}});
  const handleGridRowAction_heroui_app_table_grid_1785881605849_tvf3b = React.useCallback((row: Record<string, unknown>, actionId: string) => {
    switch (actionId) {
      case "approve": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-b7ed94f9-c112-4486-96af-42695ff51b80", true);
        return;
      }
      case "reject": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-0156a210-96f2-4e09-8ec3-ebc4abae3d2d", true);
        return;
      }
      case "spam": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-a8eec2a6-d9dd-4dbb-810f-ef390a67b4ef", true);
        return;
      }
      case "delete": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-c9793e46-f48c-4cd7-9563-9493f2d96354", true);
        return;
      }
      default:
        return;
    }
  }, [patchDesignerStore]);
  const handleGridCellClick_heroui_app_table_grid_1785881605849_tvf3b = React.useCallback(async (row: Record<string, unknown>, column: { key?: string; id?: string }) => {
    const columnKey = String(column.key ?? column.id ?? '');
    switch (columnKey) {
      case "statusCode": {
        patchDesignerStore("selection.id", row["id"] ?? null);
        patchDesignerStore("ui.visibility.node-45c15de4-873b-4fca-aae5-ee2628c202d4", true);
        return;
      }
      default:
        return;
    }
  }, [patchDesignerStore, handleGridRowAction_heroui_app_table_grid_1785881605849_tvf3b]);
  const { data: raw_gridData_heroui_app_table_grid_1785881605849_tvf3b, isLoading: isLoading_gridData_heroui_app_table_grid_1785881605849_tvf3b, error: error_gridData_heroui_app_table_grid_1785881605849_tvf3b, refresh: refresh_gridData_heroui_app_table_grid_1785881605849_tvf3b } = useDataFetch<unknown>(resolveBindingUrl("/api/cms/comments", designerStore, { "search": "gridToolbar.search", "filter[statusCode][eq]": "gridToolbar.filters.statusCode", "sortBy": "gridQuery.sortBy", "sortDir": "gridQuery.sortDir", "page": "gridQuery.page", "pageSize": "gridQuery.pageSize", "filter[body][like]": "gridQuery.filters.body", "filter[authorDisplayName][like]": "gridQuery.filters.authorDisplayName", "filter[createdAt][gte]": "gridQuery.filters.createdAt.from", "filter[createdAt][lte]": "gridQuery.filters.createdAt.to", "view": "static:summary", "filter[contentId][eq]": "routeParams.contentId" }), {});
  const gridData_heroui_app_table_grid_1785881605849_tvf3b = React.useMemo(() => applyResponseDataPath(raw_gridData_heroui_app_table_grid_1785881605849_tvf3b, {"dataPath":"data","arrayPath":"data","totalPath":"count"}), [raw_gridData_heroui_app_table_grid_1785881605849_tvf3b]);
  const gridColumns_heroui_app_table_grid_1785881605849_tvf3b = React.useMemo(() => buildAppTableGridColumns([{"key":"body","label":"Comment","sort":true,"filter":true,"filterType":"text","cardRole":"title"},{"key":"authorDisplayName","label":"Author","sort":true,"filter":true,"filterType":"text","cardRole":"field"},{"key":"contentTitle","label":"Content","cellKind":"link","cellFields":{"labelField":"contentTitle","labelFallbackField":"contentId","hrefTemplate":"/studio/cms/contents/edit/{contentId}"},"cardRole":"field"},{"key":"statusCode","label":"Status","sort":true,"cellKind":"status-badge","cellFields":{"labelField":"statusCodeTitle","labelFallbackField":"statusCode","htmlField":"statusCodeUiHtml"},"cellClickBehavior":{"kind":"open-modal","modalNodeId":"node-45c15de4-873b-4fca-aae5-ee2628c202d4","primaryKeyField":"id","selectionStorePath":"selection.id"},"cardRole":"meta"},{"key":"createdAt","label":"Created","sort":true,"filter":true,"filterType":"dateRange","cellKind":"date","cardRole":"meta"},{"key":"actions","label":"","kind":"action-group","actions":[{"actionId":"approve","icon":"BadgeCheck","intent":"utility","tooltip":"Approve","behavior":{"kind":"open-modal","modalNodeId":"node-b7ed94f9-c112-4486-96af-42695ff51b80","primaryKeyField":"id","selectionStorePath":"selection.id"}},{"actionId":"reject","icon":"XCircle","intent":"delete","tooltip":"Reject","behavior":{"kind":"open-modal","modalNodeId":"node-0156a210-96f2-4e09-8ec3-ebc4abae3d2d","primaryKeyField":"id","selectionStorePath":"selection.id"},"disabledWhen":{"preset":"expression","expression":"row.statusCode === '102.002.007'"}},{"actionId":"spam","icon":"ShieldAlert","intent":"warning","tooltip":"Mark as spam","behavior":{"kind":"open-modal","modalNodeId":"node-a8eec2a6-d9dd-4dbb-810f-ef390a67b4ef","primaryKeyField":"id","selectionStorePath":"selection.id"}},{"actionId":"delete","icon":"Trash2","intent":"delete","tooltip":"Delete","behavior":{"kind":"open-modal","modalNodeId":"node-c9793e46-f48c-4cd7-9563-9493f2d96354","primaryKeyField":"id","selectionStorePath":"selection.id"}}],"cardRole":"actions","layoutHideable":false,"layoutResizable":false,"layoutReorderable":false,"width":"140px"}], "server", {
    mode: 'runtime',
    detailFlowRef: { current: null },
    rowActionHandlerRef: { current: handleGridRowAction_heroui_app_table_grid_1785881605849_tvf3b },
    cellClickHandlerRef: { current: handleGridCellClick_heroui_app_table_grid_1785881605849_tvf3b },
    designerStoreRef: { current: designerStore },
  }), [designerStore, handleGridRowAction_heroui_app_table_grid_1785881605849_tvf3b, handleGridCellClick_heroui_app_table_grid_1785881605849_tvf3b]);
  const [gridQuery_heroui_app_table_grid_1785881605849_tvf3b, setGridQuery_heroui_app_table_grid_1785881605849_tvf3b] = React.useState<GridQueryState>(() => ({ ...EMPTY_GRID_QUERY, sort: { columnId: "createdAt", direction: 'asc' } }));
  const [gridPage_heroui_app_table_grid_1785881605849_tvf3b, setGridPage_heroui_app_table_grid_1785881605849_tvf3b] = React.useState(1);
  const [gridPageSize_heroui_app_table_grid_1785881605849_tvf3b, setGridPageSize_heroui_app_table_grid_1785881605849_tvf3b] = React.useState(50);
  const [gridListMode_heroui_app_table_grid_1785881605849_tvf3b, setGridListMode_heroui_app_table_grid_1785881605849_tvf3b] = React.useState<'paging' | 'infinite'>("paging");
  const [gridColumnLayout_heroui_app_table_grid_1785881605849_tvf3b, setGridColumnLayout_heroui_app_table_grid_1785881605849_tvf3b] = React.useState(() => createDefaultColumnLayout(gridColumns_heroui_app_table_grid_1785881605849_tvf3b));
  const [gridSearchInput_heroui_app_table_grid_1785881605849_tvf3b, setGridSearchInput_heroui_app_table_grid_1785881605849_tvf3b] = React.useState('');
  const [gridDebouncedSearch_heroui_app_table_grid_1785881605849_tvf3b, setGridDebouncedSearch_heroui_app_table_grid_1785881605849_tvf3b] = React.useState('');
  const [gridCheckboxSelections_heroui_app_table_grid_1785881605849_tvf3b, setGridCheckboxSelections_heroui_app_table_grid_1785881605849_tvf3b] = React.useState<Record<string, Record<string, boolean>>>({});
  const [gridRadioSelections_heroui_app_table_grid_1785881605849_tvf3b, setGridRadioSelections_heroui_app_table_grid_1785881605849_tvf3b] = React.useState<Record<string, string>>({"statusCode":""});
  const [gridMatchLogic_heroui_app_table_grid_1785881605849_tvf3b, setGridMatchLogic_heroui_app_table_grid_1785881605849_tvf3b] = React.useState<Record<string, 'and' | 'or'>>({});
  const gridRoleFilters_heroui_app_table_grid_1785881605849_tvf3b = {};
  const gridFilteredRows_heroui_app_table_grid_1785881605849_tvf3b = React.useMemo(() => applyClientGridQuery(((Array.isArray(gridData_heroui_app_table_grid_1785881605849_tvf3b) ? gridData_heroui_app_table_grid_1785881605849_tvf3b : []) ?? []), gridQuery_heroui_app_table_grid_1785881605849_tvf3b, gridColumns_heroui_app_table_grid_1785881605849_tvf3b, "server"), [gridQuery_heroui_app_table_grid_1785881605849_tvf3b, gridColumns_heroui_app_table_grid_1785881605849_tvf3b]);
  const gridAggregatedRows_heroui_app_table_grid_1785881605849_tvf3b = gridFilteredRows_heroui_app_table_grid_1785881605849_tvf3b;
  const gridApiTotal_heroui_app_table_grid_1785881605849_tvf3b = React.useMemo(() => {
    const raw = raw_gridData_heroui_app_table_grid_1785881605849_tvf3b;
    const value = readNestedContextValue((raw && typeof raw === 'object' ? raw as Record<string, unknown> : {}), "count");
    const parsed = typeof value === 'number' ? value : Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : 0;
  }, [raw_gridData_heroui_app_table_grid_1785881605849_tvf3b]);
  const gridTotalCount_heroui_app_table_grid_1785881605849_tvf3b = resolveDataGridTotalCount({ page: gridPage_heroui_app_table_grid_1785881605849_tvf3b, pageSize: gridPageSize_heroui_app_table_grid_1785881605849_tvf3b, total: gridApiTotal_heroui_app_table_grid_1785881605849_tvf3b, gridQueryMode: "server" }, gridAggregatedRows_heroui_app_table_grid_1785881605849_tvf3b.length);
  const gridPaging_heroui_app_table_grid_1785881605849_tvf3b = sliceDataGridRowsForDisplay(gridAggregatedRows_heroui_app_table_grid_1785881605849_tvf3b, gridPage_heroui_app_table_grid_1785881605849_tvf3b, gridPageSize_heroui_app_table_grid_1785881605849_tvf3b, gridTotalCount_heroui_app_table_grid_1785881605849_tvf3b, "server");
  const handleGridQueryChange_heroui_app_table_grid_1785881605849_tvf3b = React.useCallback((nextQuery: GridQueryState) => {
    setGridQuery_heroui_app_table_grid_1785881605849_tvf3b(nextQuery);
    setGridPage_heroui_app_table_grid_1785881605849_tvf3b(1);
    patchDesignerStore("gridQuery.sortBy", nextQuery.sort?.columnId ?? '');
    patchDesignerStore("gridQuery.sortDir", nextQuery.sort?.direction ?? '');
  }, [patchDesignerStore]);
  const handleGridPageChange_heroui_app_table_grid_1785881605849_tvf3b = React.useCallback((nextPage: number) => {
    setGridPage_heroui_app_table_grid_1785881605849_tvf3b(nextPage);
    patchDesignerStore("gridQuery.page", nextPage);
  }, [patchDesignerStore]);
  const handleGridPageSizeChange_heroui_app_table_grid_1785881605849_tvf3b = React.useCallback((nextSize: number) => {
    setGridPageSize_heroui_app_table_grid_1785881605849_tvf3b(nextSize);
    setGridPage_heroui_app_table_grid_1785881605849_tvf3b(1);
    patchDesignerStore("gridQuery.pageSize", nextSize);
  }, [patchDesignerStore]);
  const handleGridSortByChange_heroui_app_table_grid_1785881605849_tvf3b = React.useCallback((nextSortBy: string) => {
    setGridQuery_heroui_app_table_grid_1785881605849_tvf3b((current: GridQueryState) => ({ ...current, sort: nextSortBy ? { columnId: nextSortBy, direction: current.sort?.direction ?? 'asc' } : null }));
  }, []);
  const handleGridToggleSortDirection_heroui_app_table_grid_1785881605849_tvf3b = React.useCallback(() => {
    setGridQuery_heroui_app_table_grid_1785881605849_tvf3b((current: GridQueryState) => (current.sort ? { ...current, sort: { ...current.sort, direction: current.sort.direction === 'asc' ? 'desc' : 'asc' } } : current));
  }, []);
  const searchDebounceTimer_heroui_app_table_grid_1785881605849_tvf3b = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const handleGridSearchChange_heroui_app_table_grid_1785881605849_tvf3b = React.useCallback((nextValue: string) => {
    setGridSearchInput_heroui_app_table_grid_1785881605849_tvf3b(nextValue);
    if (searchDebounceTimer_heroui_app_table_grid_1785881605849_tvf3b.current) {
      clearTimeout(searchDebounceTimer_heroui_app_table_grid_1785881605849_tvf3b.current);
    }
    searchDebounceTimer_heroui_app_table_grid_1785881605849_tvf3b.current = setTimeout(() => {
      setGridDebouncedSearch_heroui_app_table_grid_1785881605849_tvf3b(nextValue);
      setGridPage_heroui_app_table_grid_1785881605849_tvf3b(1);
      patchDesignerStore("gridToolbar.search", nextValue);
    }, 300);
  }, [patchDesignerStore]);
  const handleGridRadioFilterChange_heroui_app_table_grid_1785881605849_tvf3b = React.useCallback((filterId: string, value: string) => {
    setGridRadioSelections_heroui_app_table_grid_1785881605849_tvf3b((current: Record<string, string>) => {
      const next = { ...current, [filterId]: value };
      setGridPage_heroui_app_table_grid_1785881605849_tvf3b(1);
      if (filterId === "statusCode") {
        patchDesignerStore("gridToolbar.filters.statusCode", value);
      }
      return next;
    });
  }, [patchDesignerStore]);

  const dataContext: Record<string, unknown> | null = null;
  const handleonClick_node_70230fdb_2afb_4b34_8c1f_77586801d92f = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-c9793e46-f48c-4cd7-9563-9493f2d96354", false);
  }, [patchDesignerStore]);
  const handleonClick_node_ce78cae2_fc15_44c9_b0e0_bb480d8ff34a = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_msf7sq8t_mx3wy = true;
      try {
        const response = await designerFetch(("/api/cms/comments/" + encodeURIComponent(String(designerStore?.selection?.id)) + ""), {
          method: "DELETE",
          headers: { 'Content-Type': 'application/json' },
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_msf7sq8t_mx3wy = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_msf7sq8t_mx3wy = false;
      }
      if (mutationOk_da_msf7sq8t_mx3wy) {
        await refresh_gridData_heroui_app_table_grid_1785881605849_tvf3b();
        toast("Deleted", { variant: "success", timeout: 4000 });
        patchDesignerStore("ui.visibility.node-c9793e46-f48c-4cd7-9563-9493f2d96354", false);
      }
    })();
  }, [patchDesignerStore, refresh_gridData_heroui_app_table_grid_1785881605849_tvf3b]);
  const handleonClick_node_6e90a02c_3f94_4c65_a7cf_81096a62b31a = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-b7ed94f9-c112-4486-96af-42695ff51b80", false);
  }, [patchDesignerStore]);
  const handleonClick_node_ffba40b0_3daf_4b99_b18c_94ecfa21b80f = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_msf7sq8u_0oudd = true;
      try {
        const response = await designerFetch(("/api/cms/comments/" + encodeURIComponent(String(designerStore?.selection?.id)) + ""), {
          method: "PUT",
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({"statusCode":null}),
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_msf7sq8u_0oudd = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_msf7sq8u_0oudd = false;
      }
      if (mutationOk_da_msf7sq8u_0oudd) {
        await refresh_gridData_heroui_app_table_grid_1785881605849_tvf3b();
        toast("Comment approved", { variant: "success", timeout: 4000 });
        patchDesignerStore("ui.visibility.node-b7ed94f9-c112-4486-96af-42695ff51b80", false);
      }
    })();
  }, [patchDesignerStore, refresh_gridData_heroui_app_table_grid_1785881605849_tvf3b]);
  const handleonClick_node_a803210e_8d49_47c2_bc7a_d0886c692eed = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-0156a210-96f2-4e09-8ec3-ebc4abae3d2d", false);
  }, [patchDesignerStore]);
  const handleonClick_node_2d421b42_ba16_41c6_bcf0_88739838466c = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_msf7sq8v_aqga0 = true;
      try {
        const response = await designerFetch(("/api/cms/comments/" + encodeURIComponent(String(designerStore?.selection?.id)) + ""), {
          method: "PUT",
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({"statusCode":"102.002.007"}),
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_msf7sq8v_aqga0 = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_msf7sq8v_aqga0 = false;
      }
      if (mutationOk_da_msf7sq8v_aqga0) {
        await refresh_gridData_heroui_app_table_grid_1785881605849_tvf3b();
        toast("Comment rejected", { variant: "success", timeout: 4000 });
        patchDesignerStore("ui.visibility.node-0156a210-96f2-4e09-8ec3-ebc4abae3d2d", false);
      }
    })();
  }, [patchDesignerStore, refresh_gridData_heroui_app_table_grid_1785881605849_tvf3b]);
  const handleonClick_node_f7abb8e9_6e19_4bcc_9aca_12332310d067 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    patchDesignerStore("ui.visibility.node-a8eec2a6-d9dd-4dbb-810f-ef390a67b4ef", false);
  }, [patchDesignerStore]);
  const handleonClick_node_e29b5bcb_1ff4_4d49_b94e_73e6c9817ae7 = React.useCallback(async (event: React.MouseEvent<HTMLElement>) => {
    void (async () => {
      let mutationOk_da_msf7sq8v_3s5cy = true;
      try {
        const response = await designerFetch(("/api/cms/comments/" + encodeURIComponent(String(designerStore?.selection?.id)) + ""), {
          method: "PUT",
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({"statusCode":null}),
        });
        if (!response.ok) {
          toast(await parseApiErrorMessage(response), { variant: 'danger' });
          mutationOk_da_msf7sq8v_3s5cy = false;
        }
      } catch (mutationFailure) {
        toast(mutationFailure instanceof Error ? mutationFailure.message : 'Request failed', { variant: 'danger' });
        mutationOk_da_msf7sq8v_3s5cy = false;
      }
      if (mutationOk_da_msf7sq8v_3s5cy) {
        await refresh_gridData_heroui_app_table_grid_1785881605849_tvf3b();
        toast("Comment marked as spam", { variant: "success", timeout: 4000 });
        patchDesignerStore("ui.visibility.node-a8eec2a6-d9dd-4dbb-810f-ef390a67b4ef", false);
      }
    })();
  }, [patchDesignerStore, refresh_gridData_heroui_app_table_grid_1785881605849_tvf3b]);
  return (
    <>
      <Toast.Provider />
      <div className="space-y-3">
        <div className="flex w-full flex-col gap-2"><div className="flex items-center justify-between gap-2 border-b border-slate-200 bg-white px-2 py-1.5"><div className="flex items-center gap-2"><input type="text" value={gridSearchInput_heroui_app_table_grid_1785881605849_tvf3b} onChange={(event) => handleGridSearchChange_heroui_app_table_grid_1785881605849_tvf3b(event.target.value)} placeholder={"Search comments…"} className="h-8 rounded-md border border-slate-200 px-2 text-sm" /></div><div className="flex items-center gap-2"><button type="button" onClick={() => { void refresh_gridData_heroui_app_table_grid_1785881605849_tvf3b(); }} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-slate-200 px-3 text-xs font-medium text-slate-700 hover:bg-slate-50">Refresh</button></div></div><AppTableGrid className="flex h-full min-h-0 w-full flex-1 flex-col" showPagingFooter presentation="auto" cardBelow="phone" cardVariant="list" columns={gridColumns_heroui_app_table_grid_1785881605849_tvf3b} rows={gridPaging_heroui_app_table_grid_1785881605849_tvf3b.displayRows} getRowKey={(row) => String((row as Record<string, unknown>)["id"] ?? '')} enableColumnLayout={false} columnLayout={gridColumnLayout_heroui_app_table_grid_1785881605849_tvf3b} onColumnLayoutChange={setGridColumnLayout_heroui_app_table_grid_1785881605849_tvf3b} isLoading={false} loadingMessage={"Loading comments…"} emptyMessage={"No comments found."} isEmpty={gridAggregatedRows_heroui_app_table_grid_1785881605849_tvf3b.length === 0} errorContent={gridAggregatedRows_heroui_app_table_grid_1785881605849_tvf3b.length === 0 ? undefined : "Could not load comments."} gridQueryMode={"server"} query={gridQuery_heroui_app_table_grid_1785881605849_tvf3b} onQueryChange={handleGridQueryChange_heroui_app_table_grid_1785881605849_tvf3b} onGridRowAction={handleGridRowAction_heroui_app_table_grid_1785881605849_tvf3b} footer={<GridPagingFooter totalCount={gridTotalCount_heroui_app_table_grid_1785881605849_tvf3b} safePage={gridPaging_heroui_app_table_grid_1785881605849_tvf3b.safePage} pageSize={gridPageSize_heroui_app_table_grid_1785881605849_tvf3b} onPageSizeChange={handleGridPageSizeChange_heroui_app_table_grid_1785881605849_tvf3b} sortBy={gridQuery_heroui_app_table_grid_1785881605849_tvf3b.sort?.columnId ?? ''} sortOptions={[{"value":"body","label":"Comment"},{"value":"authorDisplayName","label":"Author"},{"value":"statusCode","label":"Status"},{"value":"createdAt","label":"Created"}]} onSortByChange={handleGridSortByChange_heroui_app_table_grid_1785881605849_tvf3b} sortDirection={gridQuery_heroui_app_table_grid_1785881605849_tvf3b.sort?.direction ?? 'asc'} onToggleSortDirection={handleGridToggleSortDirection_heroui_app_table_grid_1785881605849_tvf3b} showSortControls={false} totalPages={gridPaging_heroui_app_table_grid_1785881605849_tvf3b.totalPages} pageNumbers={buildDataGridPageNumbers(gridPaging_heroui_app_table_grid_1785881605849_tvf3b.safePage, gridPaging_heroui_app_table_grid_1785881605849_tvf3b.totalPages)} onPageChange={handleGridPageChange_heroui_app_table_grid_1785881605849_tvf3b} visibleInfiniteCount={gridListMode_heroui_app_table_grid_1785881605849_tvf3b === 'infinite' ? gridPaging_heroui_app_table_grid_1785881605849_tvf3b.displayRows.length : undefined} />} /></div>
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(store.ui.visibility.node-c9793e46-f48c-4cd7-9563-9493f2d96354 === true) && (store.ui.visibility.node-c9793e46-f48c-4cd7-9563-9493f2d96354 !== false)") && (
          <ConfirmDialogShell title={"Delete comment?"} size="sm" onClose={() => { patchDesignerStore("ui.visibility.node-c9793e46-f48c-4cd7-9563-9493f2d96354", false); }} onBackdropClick={() => { patchDesignerStore("ui.visibility.node-c9793e46-f48c-4cd7-9563-9493f2d96354", false); }} tone="danger" hideCancel hideConfirm icon={<Trash2 className="h-4 w-4" />} bodyClassName="!p-0" footer={
            <div className="flex w-full shrink-0 items-center justify-end gap-2">
              <Button type="button" className="inline-flex items-center justify-center gap-1.5 h-8 px-3 rounded-md text-xs font-semibold transition-colors cursor-pointer disabled:cursor-not-allowed disabled:opacity-50 [@media(pointer:coarse)]:min-h-11 border border-slate-200 text-slate-600 hover:bg-slate-100" variant="outline" size="md" onClick={handleonClick_node_70230fdb_2afb_4b34_8c1f_77586801d92f}><X className="h-3.5 w-3.5" /> Cancel</Button>
              <Button type="button" className="inline-flex items-center justify-center gap-1.5 h-8 px-3 rounded-md text-xs font-semibold transition-colors cursor-pointer disabled:cursor-not-allowed disabled:opacity-50 [@media(pointer:coarse)]:min-h-11 bg-rose-600 hover:bg-rose-700 text-white" variant="primary" size="md" onClick={handleonClick_node_ce78cae2_fc15_44c9_b0e0_bb480d8ff34a}><Trash2 className="h-3.5 w-3.5" /> Delete</Button>
            </div>
          }>
            <p className="block p-[15px] text-sm text-slate-700">Delete this comment? This cannot be undone.</p>
          </ConfirmDialogShell>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(store.ui.visibility.node-b7ed94f9-c112-4486-96af-42695ff51b80 === true) && (store.ui.visibility.node-b7ed94f9-c112-4486-96af-42695ff51b80 !== false)") && (
          <ConfirmDialogShell title={"Approve comment?"} size="sm" onClose={() => { patchDesignerStore("ui.visibility.node-b7ed94f9-c112-4486-96af-42695ff51b80", false); }} onBackdropClick={() => { patchDesignerStore("ui.visibility.node-b7ed94f9-c112-4486-96af-42695ff51b80", false); }} tone="default" hideCancel hideConfirm bodyClassName="!p-0" footer={
            <div className="flex w-full shrink-0 items-center justify-end gap-2">
              <Button type="button" className="inline-flex items-center justify-center gap-1.5 h-8 px-3 rounded-md text-xs font-semibold transition-colors cursor-pointer disabled:cursor-not-allowed disabled:opacity-50 [@media(pointer:coarse)]:min-h-11 border border-slate-200 text-slate-600 hover:bg-slate-100" variant="outline" size="md" onClick={handleonClick_node_6e90a02c_3f94_4c65_a7cf_81096a62b31a}><X className="h-3.5 w-3.5" /> Cancel</Button>
              <Button type="button" className="inline-flex items-center justify-center gap-1.5 h-8 px-3 rounded-md text-xs font-semibold transition-colors cursor-pointer disabled:cursor-not-allowed disabled:opacity-50 [@media(pointer:coarse)]:min-h-11 bg-indigo-600 hover:bg-indigo-700 text-white" variant="primary" size="md" onClick={handleonClick_node_ffba40b0_3daf_4b99_b18c_94ecfa21b80f}><Check className="h-3.5 w-3.5" /> Approve</Button>
            </div>
          }>
            <p className="block p-[15px] text-sm leading-relaxed text-slate-700">Approve this comment and make it available to public delivery?</p>
          </ConfirmDialogShell>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(store.ui.visibility.node-0156a210-96f2-4e09-8ec3-ebc4abae3d2d === true) && (store.ui.visibility.node-0156a210-96f2-4e09-8ec3-ebc4abae3d2d !== false)") && (
          <ConfirmDialogShell title={"Reject comment?"} size="sm" onClose={() => { patchDesignerStore("ui.visibility.node-0156a210-96f2-4e09-8ec3-ebc4abae3d2d", false); }} onBackdropClick={() => { patchDesignerStore("ui.visibility.node-0156a210-96f2-4e09-8ec3-ebc4abae3d2d", false); }} tone="default" hideCancel hideConfirm bodyClassName="!p-0" footer={
            <div className="flex w-full shrink-0 items-center justify-end gap-2">
              <Button type="button" className="inline-flex items-center justify-center gap-1.5 h-8 px-3 rounded-md text-xs font-semibold transition-colors cursor-pointer disabled:cursor-not-allowed disabled:opacity-50 [@media(pointer:coarse)]:min-h-11 border border-slate-200 text-slate-600 hover:bg-slate-100" variant="outline" size="md" onClick={handleonClick_node_a803210e_8d49_47c2_bc7a_d0886c692eed}><X className="h-3.5 w-3.5" /> Cancel</Button>
              <Button type="button" className="inline-flex items-center justify-center gap-1.5 h-8 px-3 rounded-md text-xs font-semibold transition-colors cursor-pointer disabled:cursor-not-allowed disabled:opacity-50 [@media(pointer:coarse)]:min-h-11 bg-indigo-600 hover:bg-indigo-700 text-white" variant="primary" size="md" onClick={handleonClick_node_2d421b42_ba16_41c6_bcf0_88739838466c}><Check className="h-3.5 w-3.5" /> Reject</Button>
            </div>
          }>
            <p className="block p-[15px] text-sm leading-relaxed text-slate-700">Reject this comment? It will remain hidden from public delivery.</p>
          </ConfirmDialogShell>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "(store.ui.visibility.node-a8eec2a6-d9dd-4dbb-810f-ef390a67b4ef === true) && (store.ui.visibility.node-a8eec2a6-d9dd-4dbb-810f-ef390a67b4ef !== false)") && (
          <ConfirmDialogShell title={"Mark as spam?"} size="sm" onClose={() => { patchDesignerStore("ui.visibility.node-a8eec2a6-d9dd-4dbb-810f-ef390a67b4ef", false); }} onBackdropClick={() => { patchDesignerStore("ui.visibility.node-a8eec2a6-d9dd-4dbb-810f-ef390a67b4ef", false); }} tone="default" hideCancel hideConfirm bodyClassName="!p-0" footer={
            <div className="flex w-full shrink-0 items-center justify-end gap-2">
              <Button type="button" className="inline-flex items-center justify-center gap-1.5 h-8 px-3 rounded-md text-xs font-semibold transition-colors cursor-pointer disabled:cursor-not-allowed disabled:opacity-50 [@media(pointer:coarse)]:min-h-11 border border-slate-200 text-slate-600 hover:bg-slate-100" variant="outline" size="md" onClick={handleonClick_node_f7abb8e9_6e19_4bcc_9aca_12332310d067}><X className="h-3.5 w-3.5" /> Cancel</Button>
              <Button type="button" className="inline-flex items-center justify-center gap-1.5 h-8 px-3 rounded-md text-xs font-semibold transition-colors cursor-pointer disabled:cursor-not-allowed disabled:opacity-50 [@media(pointer:coarse)]:min-h-11 bg-indigo-600 hover:bg-indigo-700 text-white" variant="primary" size="md" onClick={handleonClick_node_e29b5bcb_1ff4_4d49_b94e_73e6c9817ae7}><Check className="h-3.5 w-3.5" /> Mark as spam</Button>
            </div>
          }>
            <p className="block p-[15px] text-sm leading-relaxed text-slate-700">Mark this comment as spam? It will remain hidden from public delivery.</p>
          </ConfirmDialogShell>
        )}
        {evaluateDesignerCondition(designerStore, dataContext, ({}), "store.ui.visibility.node-45c15de4-873b-4fca-aae5-ee2628c202d4 === true") && (
          <CreateEditModalShell title={"Change status"} size="lg" onClose={() => { patchDesignerStore("ui.visibility.node-45c15de4-873b-4fca-aae5-ee2628c202d4", false); }} onBackdropClick={() => { patchDesignerStore("ui.visibility.node-45c15de4-873b-4fca-aae5-ee2628c202d4", false); }} gradient={false} bodyClassName="!p-0">
            <div className="flex flex-col gap-2 bg-white p-[15px]" contentStatusPicker contentStatusPickerLovRef="cmsStatuses" contentStatusPickerDataSourceRef="cmsComments" contentStatusPickerRecordIdPath="selection.id" contentStatusPickerModalNodeId="node-45c15de4-873b-4fca-aae5-ee2628c202d4" contentStatusPickerSuccessToast="Status updated">
              <div />
            </div>
          </CreateEditModalShell>
        )}
      </div>
    </>
  );
};
export default GeneratedComponent;
