-- Payment document member lines — snake_case physical table; view exposes same names for edge reads/procs.

-- vw_hwy_payment_documents_members
CREATE OR ALTER VIEW dbo.vw_hwy_payment_documents_members
AS
SELECT
  pm.id,
  pm.document_id,
  pm.member_id,
  pm.role_id,
  pm.pay_amount,
  pm.payable,
  pm.payable_by,
  pm.payable_on,
  pm.payable_reason_id,
  pm.pay_ok,
  pm.pay_ok_by,
  pm.pay_ok_on,
  pm.created_by,
  pm.created_on,
  pm.nb_location_lat,
  pm.nb_location_lon,
  pm.nb_selfi_file_name,
  pm.nb_selfi_file_size,
  pm.nb_selfi_file_mime,
  pm.nb_device_os,
  pm.nb_device_id,
  pm.nb_device_datetime,
  (
    SELECT COUNT(*)
    FROM dbo.hwy_payment_documents_members DM WITH (NOLOCK)
    WHERE DM.nb_device_id + DM.nb_device_os = pm.nb_device_id + pm.nb_device_os
      AND DM.member_id <> pm.member_id
      AND DM.nb_device_id IS NOT NULL AND DM.nb_device_id <> N''
      AND DM.nb_device_os IS NOT NULL AND DM.nb_device_os <> N''
  ) AS same_device_count
FROM dbo.hwy_payment_documents_members pm WITH (NOLOCK);
GO

CREATE OR ALTER VIEW dbo.vw_hwy_payment_documents_members_m1
AS
SELECT pm.*, pd.doc_year, pd.doc_month, pd.doc_gender_id, pd.doc_province_id, pd.doc_circle_id
FROM dbo.hwy_payment_documents_members pm WITH (NOLOCK)
LEFT JOIN dbo.hwy_payment_documents pd WITH (NOLOCK) ON pd.id= pm.document_id
WHERE pd.doc_year = YEAR(DATEADD(MONTH, -1, GETDATE()))
  AND pd.doc_month = MONTH(DATEADD(MONTH, -1, GETDATE()));
GO

CREATE OR ALTER VIEW dbo.vw_hwy_payment_documents_members_m2
AS
SELECT pm.*, pd.doc_year, pd.doc_month, pd.doc_gender_id, pd.doc_province_id, pd.doc_circle_id
FROM dbo.hwy_payment_documents_members pm WITH (NOLOCK)
LEFT JOIN dbo.hwy_payment_documents pd WITH (NOLOCK) ON pd.id= pm.document_id
WHERE pd.doc_year = YEAR(DATEADD(MONTH, -2, GETDATE()))
  AND pd.doc_month = MONTH(DATEADD(MONTH, -2, GETDATE()));
GO

CREATE OR ALTER VIEW dbo.vw_hwy_payment_documents_members_m3
AS
SELECT pm.*, pd.doc_year, pd.doc_month, pd.doc_gender_id, pd.doc_province_id, pd.doc_circle_id
FROM dbo.hwy_payment_documents_members pm WITH (NOLOCK)
LEFT JOIN dbo.hwy_payment_documents pd WITH (NOLOCK) ON pd.id= pm.document_id
WHERE pd.doc_year = YEAR(DATEADD(MONTH, -3, GETDATE()))
  AND pd.doc_month = MONTH(DATEADD(MONTH, -3, GETDATE()));
GO
