-- Single source of truth: dbo.hwy_member_files for registration document bytes.
-- dbo.hwy_members keeps legacy flags/metadata only (no VARBINARY on new writes); vw_hwy_members_legacy_row projects blobs from files.

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER FUNCTION dbo.hwy_member_registration_file_pick (
  @member_id BIGINT,
  @kind_short_name NVARCHAR(64)
)
RETURNS TABLE
AS
RETURN (
  SELECT TOP (1)
    f.content,
    f.thumbnail_content,
    f.size_bytes,
    f.original_file_name,
    f.mime,
    f.is_approved
  FROM dbo.hwy_member_files f WITH (NOLOCK)
  INNER JOIN dbo.base_info kind WITH (NOLOCK) ON kind.id = f.file_kind_code
  INNER JOIN dbo.base_info cat WITH (NOLOCK) ON cat.id = kind.parent_id AND cat.title = N'Member File Kind'
  WHERE f.member_id = @member_id
    AND kind.short_name = @kind_short_name
  ORDER BY f.updated_at DESC, f.id DESC
);
GO

CREATE OR ALTER FUNCTION dbo.hwy_member_has_oath_document (@member_id BIGINT)
RETURNS BIT
AS
BEGIN
  IF EXISTS (
    SELECT 1
    FROM dbo.hwy_member_registration_file_pick(@member_id, N'oath_document') f
    WHERE f.content IS NOT NULL
      OR ISNULL(f.size_bytes, 0) > 0
  )
    RETURN 1;
  RETURN 0;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_sync_registration_files_member_row
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_members WHERE id = @member_id)
    RETURN;

  UPDATE m
  SET
    picture_file_name = pic.original_file_name,
    picture_file_size = pic.size_bytes,
    picture_file_mime = pic.mime,
    picture_approved = pic.is_approved,
    picture_file_body = NULL,
    picture_file_body_xs = NULL,
    national_card_front_file_body = NULL,
    national_card_front_approved = ncf.is_approved,
    national_card_behind_file_body = NULL,
    national_card_behind_approved = ncb.is_approved,
    nakheb_card_front_file_body = NULL,
    nakheb_card_front_approved = vot.is_approved,
    maskan_card_front_file_body = NULL,
    maskan_card_front_approved = res.is_approved
  FROM dbo.hwy_members m
  OUTER APPLY dbo.hwy_member_registration_file_pick(m.id, N'personal_photo') pic
  OUTER APPLY dbo.hwy_member_registration_file_pick(m.id, N'national_card_front') ncf
  OUTER APPLY dbo.hwy_member_registration_file_pick(m.id, N'national_card_back') ncb
  OUTER APPLY dbo.hwy_member_registration_file_pick(m.id, N'voter_card_front') vot
  OUTER APPLY dbo.hwy_member_registration_file_pick(m.id, N'residence_card_front') res
  WHERE m.id = @member_id;
END;
GO

PRINT 'hwy_member_registration_files_unified ready';
GO
