SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_center_stats
  @geo_level NVARCHAR(32),
  @geo_base_info_id NVARCHAR(128),
  @montadhemin_membership_status_code NVARCHAR(32),
  @nomination_province_id NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @level NVARCHAR(32) = LOWER(LTRIM(RTRIM(@geo_level)));

  IF @level = N'province'
  BEGIN
    SELECT
      COUNT(*) AS total_members,
      SUM(CASE WHEN dbo.hwy_member_passed_necessary_dorat(m.id) = 1 THEN 1 ELSE 0 END) AS necessary_courses_yes,
      SUM(CASE WHEN dbo.hwy_member_passed_necessary_dorat(m.id) = 0 THEN 1 ELSE 0 END) AS necessary_courses_no,
      SUM(CASE WHEN ISNULL(hm.stat_fields_completed, 0) >= 100 THEN 1 ELSE 0 END) AS profile_complete_yes,
      SUM(CASE WHEN ISNULL(hm.stat_fields_completed, 0) < 100 THEN 1 ELSE 0 END) AS profile_complete_no
    FROM dbo.vw_hwy_members m WITH (NOLOCK)
    INNER JOIN dbo.hwy_members hm WITH (NOLOCK) ON hm.id= m.id
      AND hm.membership_status_code = @montadhemin_membership_status_code
    WHERE m.addr_province_id = @geo_base_info_id;
    RETURN;
  END;

  IF @level = N'region'
  BEGIN
    SELECT
      COUNT(*) AS total_members,
      SUM(CASE WHEN dbo.hwy_member_passed_necessary_dorat(m.id) = 1 THEN 1 ELSE 0 END) AS necessary_courses_yes,
      SUM(CASE WHEN dbo.hwy_member_passed_necessary_dorat(m.id) = 0 THEN 1 ELSE 0 END) AS necessary_courses_no,
      SUM(CASE WHEN ISNULL(hm.stat_fields_completed, 0) >= 100 THEN 1 ELSE 0 END) AS profile_complete_yes,
      SUM(CASE WHEN ISNULL(hm.stat_fields_completed, 0) < 100 THEN 1 ELSE 0 END) AS profile_complete_no
    FROM dbo.vw_hwy_members m WITH (NOLOCK)
    LEFT JOIN dbo.hwy_nakhebin n WITH (NOLOCK) ON n.id= m.nakhebin_id
    INNER JOIN dbo.hwy_members hm WITH (NOLOCK) ON hm.id= m.id
      AND hm.membership_status_code = @montadhemin_membership_status_code
    WHERE (
      CAST(n.region_id AS NVARCHAR(128)) = @geo_base_info_id
      OR EXISTS (
        SELECT 1 FROM dbo.hwy_etl_geo_map gm WITH (NOLOCK)
        WHERE gm.base_info_id = @geo_base_info_id
          AND gm.legacy_kind = N'region'
          AND TRY_CAST(n.region_id AS BIGINT) IS NOT NULL
          AND gm.legacy_id = TRY_CAST(n.region_id AS BIGINT)
      )
    );
    RETURN;
  END;

  IF @level = N'circle'
  BEGIN
    CREATE TABLE #countHolderCircle (total INT NOT NULL);
    INSERT INTO #countHolderCircle (total)
    EXEC dbo.hwy_geo_responsibility_nomination_candidates_count_circle
      @geo_base_info_id = @geo_base_info_id,
      @nomination_province_id = @nomination_province_id,
      @montadhemin_membership_status_code = @montadhemin_membership_status_code;
    SELECT
      (SELECT total FROM #countHolderCircle) AS total_members,
      CAST(NULL AS INT) AS necessary_courses_yes,
      CAST(NULL AS INT) AS necessary_courses_no,
      CAST(NULL AS INT) AS profile_complete_yes,
      CAST(NULL AS INT) AS profile_complete_no;
    DROP TABLE #countHolderCircle;
    RETURN;
  END;

  IF @level = N'maktab'
  BEGIN
    CREATE TABLE #countHolderMaktab (total INT NOT NULL);
    INSERT INTO #countHolderMaktab (total)
    EXEC dbo.hwy_geo_responsibility_nomination_candidates_count_maktab
      @geo_base_info_id = @geo_base_info_id,
      @nomination_province_id = @nomination_province_id,
      @montadhemin_membership_status_code = @montadhemin_membership_status_code;
    SELECT
      (SELECT total FROM #countHolderMaktab) AS total_members,
      CAST(NULL AS INT) AS necessary_courses_yes,
      CAST(NULL AS INT) AS necessary_courses_no,
      CAST(NULL AS INT) AS profile_complete_yes,
      CAST(NULL AS INT) AS profile_complete_no;
    DROP TABLE #countHolderMaktab;
    RETURN;
  END;

  IF @level = N'ghavateh'
  BEGIN
    CREATE TABLE #countHolderGhavateh (total INT NOT NULL);
    INSERT INTO #countHolderGhavateh (total)
    EXEC dbo.hwy_geo_responsibility_nomination_candidates_count_ghavateh
      @geo_base_info_id = @geo_base_info_id,
      @nomination_province_id = @nomination_province_id,
      @montadhemin_membership_status_code = @montadhemin_membership_status_code;
    SELECT
      (SELECT total FROM #countHolderGhavateh) AS total_members,
      CAST(NULL AS INT) AS necessary_courses_yes,
      CAST(NULL AS INT) AS necessary_courses_no,
      CAST(NULL AS INT) AS profile_complete_yes,
      CAST(NULL AS INT) AS profile_complete_no;
    DROP TABLE #countHolderGhavateh;
    RETURN;
  END;

  THROW 50400, N'Unsupported geo level for center stats.', 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_patch_nakhebin_count
  @geo_level NVARCHAR(32),
  @geo_base_info_id NVARCHAR(128),
  @nomination_province_id NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @level NVARCHAR(32) = LOWER(LTRIM(RTRIM(@geo_level)));

  IF @level = N'province'
  BEGIN
    SELECT COUNT(DISTINCT n.id) AS total
    FROM dbo.hwy_nakhebin n WITH (NOLOCK)
    INNER JOIN dbo.vw_hwy_members m WITH (NOLOCK) ON m.nakhebin_id = n.id
    WHERE m.addr_province_id = @geo_base_info_id;
    RETURN;
  END;

  IF @level = N'region'
  BEGIN
    SELECT COUNT(DISTINCT n.id) AS total
    FROM dbo.hwy_nakhebin n WITH (NOLOCK)
    WHERE (
      CAST(n.region_id AS NVARCHAR(128)) = @geo_base_info_id
      OR EXISTS (
        SELECT 1 FROM dbo.hwy_etl_geo_map gm WITH (NOLOCK)
        WHERE gm.base_info_id = @geo_base_info_id
          AND gm.legacy_kind = N'region'
          AND TRY_CAST(n.region_id AS BIGINT) IS NOT NULL
          AND gm.legacy_id = TRY_CAST(n.region_id AS BIGINT)
      )
    );
    RETURN;
  END;

  IF @level IN (N'circle', N'maktab', N'ghavateh')
  BEGIN
    ;WITH patch_nodes AS (
      SELECT CAST(@geo_base_info_id AS NVARCHAR(128)) AS id
      UNION ALL
      SELECT CAST(bi.id AS NVARCHAR(128))
      FROM dbo.base_info bi
      INNER JOIN patch_nodes pn ON bi.parent_id = pn.id
    ),
    patch_region_ids AS (
      SELECT pn.id
      FROM patch_nodes pn
      INNER JOIN dbo.hwy_etl_geo_map gm ON gm.base_info_id = pn.id
      WHERE gm.legacy_kind = N'region'
    ),
    patch_maktab_ids AS (
      SELECT pn.id
      FROM patch_nodes pn
      INNER JOIN dbo.hwy_etl_geo_map gm ON gm.base_info_id = pn.id
      WHERE gm.legacy_kind = N'maktab'
    )
    SELECT COUNT(DISTINCT n.id) AS total
    FROM dbo.hwy_nakhebin n WITH (NOLOCK)
    WHERE (
      CAST(n.region_id AS NVARCHAR(128)) IN (SELECT id FROM patch_region_ids)
      OR EXISTS (
        SELECT 1
        FROM dbo.hwy_etl_geo_map gm WITH (NOLOCK)
        INNER JOIN patch_region_ids pri ON pri.id= gm.base_info_id
        WHERE gm.legacy_kind = N'region'
          AND TRY_CAST(n.region_id AS BIGINT) IS NOT NULL
          AND gm.legacy_id = TRY_CAST(n.region_id AS BIGINT)
      )
      OR (
        @level IN (N'maktab', N'circle')
        AND CAST(COALESCE(n.maktab_id, 0) AS NVARCHAR(128)) IN (SELECT id FROM patch_maktab_ids)
      )
    );
    RETURN;
  END;

  THROW 50400, N'Unsupported geo level for patch nakhebin count.', 1;
END;
GO
