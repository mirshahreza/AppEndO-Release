SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF OBJECT_ID(N'dbo.hwy_member_phone_change_requests', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_member_phone_change_requests (
    id              UNIQUEIDENTIFIER NOT NULL CONSTRAINT DF_hwy_member_phone_change_requests_id DEFAULT (NEWID()),
    member_id       BIGINT NOT NULL,
    phone_slot      TINYINT NOT NULL,
    old_phone       VARCHAR(16) NOT NULL CONSTRAINT DF_hwy_member_phone_change_requests_old_phone DEFAULT ('-1'),
    new_phone       VARCHAR(16) NOT NULL,
    request_note    NVARCHAR(512) NULL,
    request_by      BIGINT NULL,
    request_at      DATETIME2 NOT NULL CONSTRAINT DF_hwy_member_phone_change_requests_request_at DEFAULT SYSUTCDATETIME(),
    final_result    BIT NULL,
    final_reason_code NVARCHAR(1000) NULL,
    final_note      NVARCHAR(512) NULL,
    final_by        BIGINT NULL,
    final_at        DATETIME2 NULL,
    CONSTRAINT PK_hwy_member_phone_change_requests PRIMARY KEY CLUSTERED (id),
    CONSTRAINT FK_hwy_member_phone_change_requests_member FOREIGN KEY (member_id) REFERENCES dbo.hwy_members(id) ON DELETE CASCADE,
    CONSTRAINT FK_hwy_member_phone_change_requests_request_by FOREIGN KEY (request_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_hwy_member_phone_change_requests_final_by FOREIGN KEY (final_by) REFERENCES dbo.base_users(id)
  );

  CREATE INDEX IX_hwy_member_phone_change_requests_member_request_at
    ON dbo.hwy_member_phone_change_requests (member_id, request_at DESC);

  CREATE UNIQUE INDEX UX_hwy_member_phone_change_requests_pending_slot
    ON dbo.hwy_member_phone_change_requests (member_id, phone_slot)
    WHERE final_result IS NULL;
END;
GO

IF OBJECT_ID(N'dbo.hwy_member_phone_swap_requests', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.hwy_member_phone_swap_requests (
    id              UNIQUEIDENTIFIER NOT NULL CONSTRAINT DF_hwy_member_phone_swap_requests_id DEFAULT (NEWID()),
    member_id       BIGINT NOT NULL,
    phone1_before   VARCHAR(16) NOT NULL,
    phone2_before   VARCHAR(16) NOT NULL,
    request_note    NVARCHAR(512) NULL,
    request_by      BIGINT NULL,
    request_at      DATETIME2 NOT NULL CONSTRAINT DF_hwy_member_phone_swap_requests_request_at DEFAULT SYSUTCDATETIME(),
    final_result    BIT NULL,
    final_reason_code NVARCHAR(1000) NULL,
    final_note      NVARCHAR(512) NULL,
    final_by        BIGINT NULL,
    final_at        DATETIME2 NULL,
    CONSTRAINT PK_hwy_member_phone_swap_requests PRIMARY KEY CLUSTERED (id),
    CONSTRAINT FK_hwy_member_phone_swap_requests_member FOREIGN KEY (member_id) REFERENCES dbo.hwy_members(id) ON DELETE CASCADE,
    CONSTRAINT FK_hwy_member_phone_swap_requests_request_by FOREIGN KEY (request_by) REFERENCES dbo.base_users(id),
    CONSTRAINT FK_hwy_member_phone_swap_requests_final_by FOREIGN KEY (final_by) REFERENCES dbo.base_users(id)
  );

  CREATE INDEX IX_hwy_member_phone_swap_requests_member_request_at
    ON dbo.hwy_member_phone_swap_requests (member_id, request_at DESC);

  CREATE UNIQUE INDEX UX_hwy_member_phone_swap_requests_pending_member
    ON dbo.hwy_member_phone_swap_requests (member_id)
    WHERE final_result IS NULL;
END;
GO
