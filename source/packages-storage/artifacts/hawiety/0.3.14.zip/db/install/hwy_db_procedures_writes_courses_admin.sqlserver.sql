CREATE OR ALTER PROCEDURE dbo.hwy_courses_cleanup_drafted
  @draft_status_code NVARCHAR(64)
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  BEGIN TRAN;

  DELETE att
  FROM dbo.hwy_course_attendances att
  INNER JOIN dbo.hwy_courses c ON c.id= att.course_id
  WHERE c.status_code = @draft_status_code;

  DELETE s
  FROM dbo.hwy_course_approval_steps s
  INNER JOIN dbo.hwy_courses c ON c.id= s.course_id
  WHERE c.status_code = @draft_status_code;

  DECLARE @deleted_courses INT;
  DELETE FROM dbo.hwy_courses WHERE status_code = @draft_status_code;
  SET @deleted_courses = @@ROWCOUNT;

  COMMIT;

  SELECT @deleted_courses AS deleted_courses;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_activities_cleanup_drafted
  @draft_status_code NVARCHAR(64)
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  BEGIN TRAN;

  DELETE att
  FROM dbo.hwy_activity_attendances att
  INNER JOIN dbo.hwy_activities a ON a.id= att.activity_id
  WHERE a.status_code = @draft_status_code;

  DELETE f
  FROM dbo.hwy_activity_files f
  INNER JOIN dbo.hwy_activities a ON a.id= f.activity_id
  WHERE a.status_code = @draft_status_code;

  DELETE s
  FROM dbo.hwy_activity_approval_steps s
  INNER JOIN dbo.hwy_activities a ON a.id= s.activity_id
  WHERE a.status_code = @draft_status_code;

  DECLARE @deleted_activities INT;
  DELETE FROM dbo.hwy_activities WHERE status_code = @draft_status_code;
  SET @deleted_activities = @@ROWCOUNT;

  COMMIT;

  SELECT @deleted_activities AS deleted_activities;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_course_copy_attendances
  @source_course_id BIGINT,
  @target_course_id BIGINT,
  @actor_user_id BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_courses WHERE id= @source_course_id)
    THROW 56610, N'Source course not found.', 1;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_courses WHERE id= @target_course_id)
    THROW 56611, N'Target course not found.', 1;

  IF @source_course_id = @target_course_id
    THROW 56612, N'Source and target course must differ.', 1;

  DECLARE @now DATETIME2 = SYSUTCDATETIME();

  INSERT INTO dbo.hwy_course_attendances (
    id, member_id, course_id, note,
    nb_location_lat, nb_location_lon, nb_device_os, nb_device_id, nb_device_datetime,
    legacy_created_by, legacy_updated_by, created_at, updated_at
  )
  SELECT
    ISNULL((SELECT MAX(id) FROM dbo.hwy_course_attendances WITH (UPDLOCK, HOLDLOCK)), 0)
      + ROW_NUMBER() OVER (ORDER BY src.id),
    src.member_id,
    @target_course_id,
    src.note,
    src.nb_location_lat,
    src.nb_location_lon,
    src.nb_device_os,
    src.nb_device_id,
    src.nb_device_datetime,
    src.legacy_created_by,
    src.legacy_updated_by,
    @now,
    @now
  FROM dbo.hwy_course_attendances src
  WHERE src.course_id = @source_course_id
    AND NOT EXISTS (
      SELECT 1 FROM dbo.hwy_course_attendances existing
      WHERE existing.course_id = @target_course_id AND existing.member_id = src.member_id
    );

  SELECT @@ROWCOUNT AS copied_count;
END;
GO
