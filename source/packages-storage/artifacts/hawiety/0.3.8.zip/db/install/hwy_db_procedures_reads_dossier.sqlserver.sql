SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_files_list
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(f.id AS VARCHAR(32)) AS id,
    CAST(f.member_id AS VARCHAR(32)) AS memberId,
    f.file_kind_code AS fileKindCode,
    bk.short_name AS fileKindSlug,
    f.original_file_name AS originalFileName,
    f.mime AS mime,
    f.size_bytes AS sizeBytes,
    f.is_approved AS isApproved,
    CASE WHEN f.thumbnail_content IS NULL THEN 0 ELSE 1 END AS hasThumbnail,
    f.created_at AS createdAt
  FROM dbo.hwy_member_files f
  LEFT JOIN dbo.base_info bk ON bk.id = f.file_kind_code
  WHERE f.member_id = @member_id
  ORDER BY f.file_kind_code, f.id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_institutes_list
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(mi.id AS VARCHAR(32)) AS id,
    CAST(mi.member_id AS VARCHAR(32)) AS memberId,
    mi.institute_id AS instituteId,
    i.code AS instituteCode,
    i.title_ar AS instituteTitle,
    mi.status_code AS statusCode,
    mi.join_path_code AS joinPathCode,
    mi.member_accepted AS memberAccepted,
    mi.activated_at AS activatedAt,
    mi.character_code AS characterCode,
    mi.institute_state_code AS instituteStateCode,
    mi.institute_state_note AS instituteStateNote,
    mi.institute_state_updated_on AS instituteStateUpdatedOn,
    CAST(mi.institute_state_updated_by AS VARCHAR(32)) AS instituteStateUpdatedBy,
    u_state.username AS instituteStateUpdatedByDisplay,
    mi.current_org_employment_id AS currentOrgEmploymentId,
    mi.current_org_employment_note AS currentOrgEmploymentNote,
    CAST(i.show_institute_character_in_dossier AS BIT) AS showInstituteCharacterInDossier,
    mi.created_at AS createdAt
  FROM dbo.hwy_member_institutes mi
  LEFT JOIN dbo.hwy_institutes i ON i.id = mi.institute_id
  LEFT JOIN dbo.base_users u_state ON u_state.id = mi.institute_state_updated_by
  WHERE mi.member_id = @member_id
  ORDER BY i.title_ar, mi.institute_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_notes_list
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(n.id AS VARCHAR(32)) AS id,
    CAST(n.member_id AS VARCHAR(32)) AS memberId,
    n.body AS body,
    n.subject_code AS subjectCode,
    n.created_at AS createdAt,
    CAST(n.created_by AS VARCHAR(32)) AS createdBy
  FROM dbo.hwy_member_notes n
  WHERE n.member_id = @member_id
  ORDER BY n.created_at DESC, n.id DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_targhin_requests_list
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(t.id AS VARCHAR(32)) AS id,
    CAST(t.member_id AS VARCHAR(32)) AS memberId,
    t.request_reason_code AS requestReasonCode,
    t.request_note AS requestNote,
    t.status_code AS statusCode,
    t.created_at AS createdAt,
    CAST(t.created_by AS VARCHAR(32)) AS createdBy,
    t.final_reason_code AS finalReasonCode,
    t.final_note AS finalNote,
    t.final_at AS finalAt,
    CAST(t.final_by AS VARCHAR(32)) AS finalBy
  FROM dbo.hwy_member_targhin_requests t
  WHERE t.member_id = @member_id
  ORDER BY t.created_at DESC, t.id DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_change_log_member
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(m.id AS VARCHAR(32)) AS memberId,
    CAST(m.user_id AS VARCHAR(32)) AS userId,
    CAST(m.nakhebin_id AS VARCHAR(32)) AS nakhebinId,
    m.username AS username,
    m.created_at AS createdAt,
    m.updated_at AS updatedAt,
    m.membership_on AS membershipOn,
    m.membership_status_code AS membershipStatusCode,
    m.membership_status_updated_on AS membershipStatusUpdatedOn,
    m.registration_channel_code AS registrationChannelCode,
    m.created_by AS createdBy,
    m.updated_by AS updatedBy
  FROM dbo.hwy_members m
  WHERE m.id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_change_log_files
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(f.id AS VARCHAR(32)) AS id,
    f.original_file_name AS originalFileName,
    f.file_kind_code AS fileKindCode,
    f.created_at AS createdAt,
    f.updated_at AS updatedAt,
    CAST(f.created_by AS VARCHAR(32)) AS createdBy,
    CAST(f.updated_by AS VARCHAR(32)) AS updatedBy
  FROM dbo.hwy_member_files f
  WHERE f.member_id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_change_log_notes
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(n.id AS VARCHAR(32)) AS id,
    n.body AS body,
    n.created_at AS createdAt,
    CAST(n.created_by AS VARCHAR(32)) AS createdBy
  FROM dbo.hwy_member_notes n
  WHERE n.member_id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_change_log_institutes
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(mi.id AS VARCHAR(32)) AS id,
    CAST(mi.institute_id AS VARCHAR(32)) AS instituteId,
    i.title_ar AS instituteTitle,
    mi.created_at AS createdAt,
    mi.invited_at AS invitedAt,
    mi.activated_at AS activatedAt,
    CAST(mi.created_by AS VARCHAR(32)) AS createdBy,
    CAST(mi.invited_by AS VARCHAR(32)) AS invitedBy,
    CAST(mi.institute_state_updated_by AS VARCHAR(32)) AS instituteStateUpdatedBy
  FROM dbo.hwy_member_institutes mi
  INNER JOIN dbo.hwy_institutes i ON i.id = mi.institute_id
  WHERE mi.member_id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_change_log_targhin
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(t.id AS VARCHAR(32)) AS id,
    t.request_note AS requestNote,
    t.status_code AS statusCode,
    t.created_at AS createdAt,
    CAST(t.created_by AS VARCHAR(32)) AS createdBy,
    t.final_note AS finalNote,
    t.final_at AS finalAt,
    CAST(t.final_by AS VARCHAR(32)) AS finalBy,
    t.final_reason_code AS finalReasonCode
  FROM dbo.hwy_member_targhin_requests t
  WHERE t.member_id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_change_log_security
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(sp.id AS VARCHAR(32)) AS id,
    sp.created_at AS createdAt,
    CAST(sp.created_by AS VARCHAR(32)) AS createdBy
  FROM dbo.hwy_member_security_profile sp
  WHERE sp.member_id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_change_log_tracking
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(m.id AS VARCHAR(32)) AS id,
    CAST(m.id AS NVARCHAR(32)) AS code,
    CAST(NULL AS NVARCHAR(64)) AS status,
    m.created_at AS createdAt
  FROM dbo.hwy_members m
  WHERE m.id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_change_log_username_repo
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(u.id AS VARCHAR(32)) AS id,
    u.username AS username,
    u.reserved_at AS reservedAt
  FROM dbo.hwy_username_repo u
  WHERE u.member_id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_kasb_acquired_list
  @host_member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(km.id AS VARCHAR(32)) AS kasbMemberId,
    km.username AS kasbUsername,
    CASE
      WHEN LTRIM(RTRIM(km.referrer_username)) = LTRIM(RTRIM(host.username)) THEN N'referrer'
      ELSE N'secondReferrer'
    END AS linkSlot,
    CASE
      WHEN LTRIM(RTRIM(km.referrer_username)) = LTRIM(RTRIM(host.username))
        THEN CAST(km.referrer_relation_id AS VARCHAR(32))
      ELSE CAST(km.second_referrer_relation_id AS VARCHAR(32))
    END AS referrerRelationId
  FROM dbo.hwy_members host
  INNER JOIN dbo.hwy_members km ON 1 = 1
  WHERE host.id = @host_member_id
    AND NULLIF(LTRIM(RTRIM(host.username)), N'') IS NOT NULL
    AND (
      LTRIM(RTRIM(km.referrer_username)) = LTRIM(RTRIM(host.username))
      OR LTRIM(RTRIM(km.second_referrer_username)) = LTRIM(RTRIM(host.username))
    )
  ORDER BY km.id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_nakhebin_join_candidates
  @member_id BIGINT,
  @match_first_name BIT = 1,
  @match_father_name BIT = 1,
  @match_grandfather_name BIT = 1,
  @match_birth_year BIT = 0,
  @match_family_code BIT = 0,
  @scope_region_geo_id NVARCHAR(128) = NULL,
  @row_limit INT = 100
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @scope_region_id NVARCHAR(128) = dbo.hwy_resolve_raw_geo_to_base_info_id(@scope_region_geo_id);

  DECLARE @firstname NVARCHAR(4000);
  DECLARE @fathername NVARCHAR(4000);
  DECLARE @grandfathername NVARCHAR(4000);
  DECLARE @birth_year NVARCHAR(32);
  DECLARE @family_code NVARCHAR(4000);

  SELECT
    @firstname = LTRIM(RTRIM(ISNULL(first_name, N''))),
    @fathername = LTRIM(RTRIM(ISNULL(father_name, N''))),
    @grandfathername = LTRIM(RTRIM(ISNULL(grandfather_name, N''))),
    @birth_year = LTRIM(RTRIM(ISNULL(CAST(birth_year AS NVARCHAR(32)), N''))),
    @family_code = LTRIM(RTRIM(ISNULL(family_code, N'')))
  FROM dbo.hwy_members
  WHERE id = @member_id;

  IF @@ROWCOUNT = 0
    THROW 57300, N'Member not found.', 1;

  SELECT TOP (@row_limit)
    CAST(n.id AS VARCHAR(32)) AS id,
    n.first_name AS firstName,
    n.father_name AS fatherName,
    n.grandfather_name AS grandfatherName,
    n.family_name AS familyName,
    n.birth_year AS birthYear,
    n.family_code AS familyCode,
    CAST(n.member_id AS VARCHAR(32)) AS linkedMemberId
  FROM dbo.hwy_nakhebin n WITH (NOLOCK)
  WHERE
    (@match_first_name = 0 OR @firstname = N'' OR LTRIM(RTRIM(ISNULL(n.first_name, N''))) = @firstname)
    AND (@match_father_name = 0 OR @fathername = N'' OR LTRIM(RTRIM(ISNULL(n.father_name, N''))) = @fathername)
    AND (@match_grandfather_name = 0 OR @grandfathername = N'' OR LTRIM(RTRIM(ISNULL(n.grandfather_name, N''))) = @grandfathername)
    AND (@match_birth_year = 0 OR @birth_year = N'' OR LTRIM(RTRIM(ISNULL(n.birth_year, N''))) = @birth_year)
    AND (
      @match_family_code = 0
      OR @family_code = N''
      OR LTRIM(RTRIM(ISNULL(n.family_code, N''))) = @family_code
    )
    AND (
      @scope_region_id IS NULL
      OR LTRIM(RTRIM(ISNULL(n.region_id, N''))) = @scope_region_id
      OR (
        @scope_region_geo_id IS NOT NULL
        AND LTRIM(RTRIM(@scope_region_geo_id)) <> N''
        AND LTRIM(RTRIM(ISNULL(n.region_id, N''))) = LTRIM(RTRIM(@scope_region_geo_id))
      )
    )
  ORDER BY n.id ASC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_nakhebin_eghtera_region_list
  @province_raw NVARCHAR(128) = NULL,
  @ancestor_raw NVARCHAR(128) = NULL,
  @search_like NVARCHAR(256) = NULL,
  @offset INT = 0,
  @page_size INT = 100
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @province_id NVARCHAR(128) = dbo.hwy_resolve_raw_geo_to_base_info_id(@province_raw);
  DECLARE @ancestor_id NVARCHAR(128) = dbo.hwy_resolve_raw_geo_to_base_info_id(@ancestor_raw);
  DECLARE @patch_id NVARCHAR(128) = COALESCE(@ancestor_id, @province_id);
  DECLARE @safe_offset INT = CASE WHEN @offset IS NULL OR @offset < 0 THEN 0 ELSE @offset END;
  DECLARE @safe_page_size INT = CASE
    WHEN @page_size IS NULL OR @page_size < 1 THEN 100
    WHEN @page_size > 500 THEN 500
    ELSE @page_size
  END;

  SELECT
    gm.base_info_id AS geoBaseInfoId,
    gm.legacy_id AS legacyGeoId,
    dbo.hwy_geo_leaf_title(gm.base_info_id) AS title,
    COALESCE(
      NULLIF(LTRIM(RTRIM(dbo.hwy_base_info_iq_title_path(gm.base_info_id))), N''),
      NULLIF(LTRIM(RTRIM(b.title_path_ar)), N''),
      NULLIF(LTRIM(RTRIM(b.title_path_en)), N'')
    ) AS titlePath
  FROM dbo.hwy_etl_geo_map gm
  INNER JOIN dbo.base_info b ON b.id = gm.base_info_id
  WHERE gm.legacy_kind = N'region'
    AND b.is_active = 1
    AND (
      @patch_id IS NULL
      OR dbo.hwy_base_info_patch_contains_node(@patch_id, gm.base_info_id) = 1
    )
    AND (
      @search_like IS NULL
      OR dbo.hwy_geo_leaf_title(gm.base_info_id) LIKE @search_like
      OR COALESCE(
        NULLIF(LTRIM(RTRIM(dbo.hwy_base_info_iq_title_path(gm.base_info_id))), N''),
        NULLIF(LTRIM(RTRIM(b.title_path_ar)), N''),
        NULLIF(LTRIM(RTRIM(b.title_path_en)), N'')
      ) LIKE @search_like
    )
  ORDER BY title ASC, gm.legacy_id ASC
  OFFSET @safe_offset ROWS FETCH NEXT @safe_page_size ROWS ONLY;
END;
GO
