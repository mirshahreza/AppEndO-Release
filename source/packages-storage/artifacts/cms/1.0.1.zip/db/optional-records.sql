-- Captured 49 row(s) from cms_contents on 2026-08-24T12:57:05.369Z
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('1', '101.001.007', '101.004.001', 'site-brand', '101.002.003', NULL, NULL, 'AppEndO', 'Self-hosted platform for back-office Studio and front-office apps.', '', '101.003.003', NULL, NULL, '2026-08-01T08:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-24T03:07:08.900Z', NULL, '2026-08-24T03:08:34.086Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('2', '101.001.007', '101.004.001', 'site-footer', '101.002.003', NULL, NULL, 'Footer', 'This public site is published from CMS Contents on the same AppEndO stack as Studio.', '', '101.003.003', NULL, NULL, '2026-08-01T08:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-24T03:07:08.923Z', NULL, '2026-08-24T03:08:34.123Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('3', '101.001.007', '101.004.001', 'site-cta', '101.002.003', NULL, NULL, 'Get started', 'get-started', '', '101.003.003', NULL, NULL, '2026-08-01T08:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-24T03:07:08.946Z', NULL, '2026-08-24T03:08:34.156Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('4', '101.001.007', '101.004.001', 'site-talk', '101.002.003', NULL, NULL, 'Talk', 'hello@append.os', '', '101.003.003', NULL, NULL, '2026-08-01T08:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-24T03:07:08.960Z', NULL, '2026-08-24T03:08:34.190Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('5', '101.001.007', '101.004.001', 'site-legal', '101.002.003', NULL, NULL, 'Legal', '', '© AppEndO. Self-hosted enterprise platform.', '101.003.003', NULL, NULL, '2026-08-01T08:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-24T03:07:08.976Z', NULL, '2026-08-24T03:08:34.220Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('6', '101.001.007', '101.004.001', 'slide-01', '101.002.003', NULL, NULL, 'One Studio. Every platform surface.', '01 — Dashboard', 'Callout 1 is the Studio nav. Callout 2 is the page title. Callout 3 is the workspace — this is Home after sign-in.', '101.003.003', NULL, NULL, '2026-08-02T08:00:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:07:08.990Z', NULL, '2026-08-24T03:08:34.253Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('7', '101.001.007', '101.004.001', 'slide-02', '101.002.003', NULL, NULL, 'Model tables. Publish a Data API.', '02 — Data Studio', 'Data Studio is where builders design Edge models and publish REST Data APIs without a separate backend project.', '101.003.003', NULL, NULL, '2026-08-02T08:10:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:34.316Z', NULL, '2026-08-24T03:08:34.316Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('8', '101.001.007', '101.004.001', 'slide-03', '101.002.003', NULL, NULL, 'Durable workflows, human work items.', '03 — Workflows', 'The Workflow Engine authors, publishes, and runs long-lived processes with waits, webhooks, and an inbox.', '101.003.003', NULL, NULL, '2026-08-02T08:20:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:34.370Z', NULL, '2026-08-24T03:08:34.370Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('9', '101.001.007', '101.004.001', 'slide-04', '101.002.003', NULL, NULL, 'Server Functions in a sandbox.', '04 — Functions', 'Write TypeScript APIs in Studio. They run in a restricted runtime with OpenAPI, not as unmanaged Node processes.', '101.003.003', NULL, NULL, '2026-08-02T08:30:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:34.420Z', NULL, '2026-08-24T03:08:34.420Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('10', '101.001.007', '101.004.001', 'slide-05', '101.002.003', NULL, NULL, 'Front office for people who never open Studio.', '05 — Public site', 'Portals, cultures, and public pages share the same control plane. This site is one of those pages.', '101.003.003', NULL, NULL, '2026-08-02T08:40:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:34.476Z', NULL, '2026-08-24T03:08:34.476Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('11', '101.001.006', '101.004.001', 'home', '101.002.003', NULL, NULL, 'Study AppEndO — the platform, not a brochure CMS.', 'Self-hosted back-office Studio and front-office apps on one control plane. Every guide below is a published CMS row, illustrated with annotated screenshots from this workspace.', 'AppEndO is for organizations that run **custom business applications**. Operators and builders work in Studio. Everyday staff, customers, and public visitors use portals and sites — no Studio access required.

## What you can read here

- **What AppEndO is** — audiences, what ships in core, what lives in packages.

- **Studio map** — every nav group, with callouts on the real shell.

- **Feature guides** — open **Guide** in the top nav for the full table of contents and detail pages.

- **How-tos** — short, numbered recipes for the tasks operators do every week.

Click any screenshot to open it full size. Numbered overlays mark the nav, the page title, and the workspace the copy is talking about.', '101.003.002', 'AppEndO — platform guide', 'Features, Studio map, and annotated screenshots of the self-hosted AppEndO platform.', '2026-08-03T08:00:00.000Z', 'Home hero. Keep the first paragraph; the public layout uses it as the lead.', FALSE, '101.006.001', NULL, NULL, 'Platform desk', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:34.526Z', NULL, '2026-08-24T03:08:34.526Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('12', '101.001.006', '101.004.001', 'about', '101.002.003', NULL, NULL, 'A platform for builders, operators, and everyone else.', 'AppEndO is not a blogging CMS and not an out-of-the-box ERP. It is a self-hosted stack: Studio for people who configure systems, portals for people who just need to get work done.', 'The control plane is relational (PostgreSQL primary, with MySQL, SQLite, and SQL Server adapters). Optional **edge data sources** connect extra Postgres, SQL Server, MySQL, Oracle, MongoDB, Redis, and SQLite databases. Traffic is routed by **culture × portal × page**.

## Who it is for

- **Builders** — Data Studio, Server Functions, Client Components, Workflows, custom packages.

- **Operators** — install packages, configure settings, manage users, roles, org and geo scope.

- **End users** — browse information, submit forms, complete work items, use self-service portals.

## What ships in core

Identity, the admin shell, Data Studio and Data API, Workflow Engine, Server Functions, Client Components, Base Components, Theme Designer, Packages hub, Portals, Git, cache, jobs, File Manager, SSH Hub, AI/MCP, Settings, and the install wizard.

LOB modules such as CRM or commerce are **ecosystem packages**, not the core product. **CMS** is a shipped editorial package — this public site is that package, running on the same toolchain.

## How this site is made

The skin is a Client Component layout (`SiteLayout`). Headings, photographs, tags, and nav labels are published CMS rows. Drafts, operator notes, and comments still in review never leave Studio.', '101.003.002', 'About AppEndO', 'What AppEndO is, who it is for, and what ships in the core install.', '2026-08-03T08:10:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'Platform desk', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:34.606Z', NULL, '2026-08-24T03:08:34.606Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('13', '101.001.001', '101.004.001', 'install-and-sign-in', '101.002.003', NULL, NULL, 'Install, sign in, open Studio.', 'Local development uses a simple username and password. Production uses the same identity stack with lockout, OAuth, and HttpOnly cookies.', 'On a fresh machine run the **install wizard** in the browser, or `npm run setup` for local PostgreSQL. After schema is applied, sign in at `/login`.

## Dev credentials on this workspace

On a development seed, username `admin@append.os` (or `admin`) and password `admin123`. The annotated screenshot marks the product mark (1), username (2), password (3), and Sign in (4). Production must not keep that password.

## Where to go next

- `/us` — this public site (Home portal, no Studio chrome).

- `/us/studio` — Dashboard after you are authenticated.

- `/us/studio/base-components` — the living UI catalog every Studio form is supposed to match.

Sessions are JWTs in **HttpOnly cookies**, never `localStorage`. Google, GitHub, Microsoft Entra, and generic OIDC adapters ship as system extensions.', '101.003.002', 'Install and sign in to AppEndO', 'Install, sign in, and open Studio. Dev login and production identity notes.', '2026-08-03T08:20:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'Platform desk', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:34.716Z', NULL, '2026-08-24T03:08:34.716Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('14', '101.001.006', '101.004.001', 'contact', '101.002.003', NULL, NULL, 'Talk to the team', 'Bugs, questions, and feedback about the platform — not install or package questions, those already have a page.', 'An install question belongs on [Install and sign in](/us/install-and-sign-in). A package idea belongs on [Packages and CMS](/us/packages-and-cms). Everything else — something broken, something unclear, something you want — goes here.

## Where this goes

Sending this form opens a real ticket in AppEndO’s own **Feedback** inbox, the same queue Studio operators triage from the Dashboard. This is not a stub mailbox; it is the platform receiving its own traffic, in public.', '101.003.002', 'Contact AppEndO', 'Send feedback straight into the platform’s own Feedback inbox.', '2026-08-23T09:00:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'Platform desk', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:34.800Z', NULL, '2026-08-24T03:08:34.800Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('15', '101.001.006', '101.004.001', 'guide', '101.002.003', NULL, NULL, 'Guide', 'Complete handbook of every Studio section: table of contents, detail pages, and how-tos for the work operators do every week.', 'Use this page as the **table of contents**. Each link opens a detail article. Screenshots on those pages enlarge when you click them. How-tos at the bottom are short recipes, not essays.

## Start here

- [What AppEndO is](/us/what-is-appendo) — back office, front office, packages versus core.

- [Studio map](/us/studio-map) — every nav group after a greenfield install.

- [A working path](/us/get-started) — sign in, walk the shell, open the public site.

## Development

- [Data Studio and the Data API](/us/data-studio-and-data-api) — model tables, publish REST.

- [Data sources and engines](/us/data-sources-and-engines) — control plane plus extra databases.

- [Server Functions](/us/server-functions) — sandboxed TypeScript APIs and OpenAPI.

- [Developer Reference](/us/developer-reference) — what a function may call.

- [Client Components and Base Components](/us/client-and-base-components) — compose UI; match the catalog.

- [Theme Designer](/us/theme-designer) — named shell atmosphere presets.

- [Portals and the front office](/us/portals-and-front-office) — cultures, shells, public routes.

- [Packages and CMS](/us/packages-and-cms) — ZIP extensions, this public site.

## Operations

- [Workflow Engine](/us/workflow-engine) — designer, durable run, work items.

- [Operations](/us/operations) — files, SSH, RDP, jobs, cache, Git, logs, transfer.

- [AI and MCP](/us/ai-and-mcp) — in-app agent, 15 packs, chat history.

## Records and access

- [Identity and access](/us/identity-and-access) — users, roles, HttpOnly sessions.

- [Record Policy, org, and geo](/us/record-policy-org-and-geo) — row scope, Base Info.

- [Settings, install, and security](/us/settings-install-and-security) — wizard, providers, baseline.

## How-tos

Common jobs, in the order most teams hit them:

1. [Sign in to Studio](/us/howto-sign-in)

2. [Create a user](/us/howto-create-user)

3. [Create a role and assign it](/us/howto-assign-role)

4. [Publish a Data API](/us/howto-publish-data-api)

5. [Write and run a Server Function](/us/howto-create-server-function)

6. [Publish a workflow](/us/howto-publish-workflow)

7. [Install a package](/us/howto-install-package)

8. [Publish a public CMS page](/us/howto-publish-public-page)

9. [Apply a Theme Designer preset](/us/howto-switch-theme)

10. [Register a data source](/us/howto-add-data-source)

11. [Clear cache](/us/howto-clear-cache)

12. [Open the public site](/us/howto-open-public-site)', '101.003.002', 'AppEndO platform handbook', 'Table of contents for every Studio section, with detail pages and how-tos.', '2026-08-22T08:00:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'Platform desk', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:34.836Z', NULL, '2026-08-24T03:08:34.836Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('16', '101.001.001', '101.004.001', 'what-is-appendo', '101.002.003', NULL, NULL, 'What AppEndO is', 'Self-hosted enterprise platform: one stack for back-office Studio and front-office apps, extensible with packages instead of a second product.', 'AppEndO is **platform-first**. You do not start by picking a CMS theme. You install a control plane, sign in to Studio, and either configure what already ships or install a package.

## The two offices

**Back office** is Studio — dashboard, Data Studio, Workflows, Users, Settings. The screenshot on this page is that shell: (1) Studio nav grouped into Home, Development, Operations, Records, and CMS; (2) the page title; (3) the workspace.

**Front office** is everything an everyday user sees: public sites, customer portals, partner apps, vertical apps with their own branding and routes. They share identity, data, and workflows with Studio without exposing Studio navigation.

## Extensibility without a second stack

Ready-made packages install from the Packages hub. Server Functions, Data Studio, and the Workflow Engine are the customization layer when a package is not enough. A marketplace for one-click extras is on the roadmap; the hub already installs ZIP extensions and vertical apps.

## What it is not

It is not WordPress. It is not a generic ERP you configure by ticking modules. CMS exists, but as a **package** built with Data Studio + Server Functions + Client Components — the same path you would use for CRM or inventory.', '101.003.002', 'What AppEndO is — platform overview', 'Back office, front office, packages, and what ships in core versus ecosystem.', '2026-08-20T09:00:00.000Z', 'Lead overview. Keep three callouts in the screenshot copy.', TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:34.923Z', NULL, '2026-08-24T03:08:34.923Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('17', '101.001.001', '101.004.001', 'studio-map', '101.002.003', NULL, NULL, 'Studio map — every page in the shell', 'After a greenfield install, Studio nav is grouped into Home, Development, Operations, Records, and CMS when that package is present.', 'Open `/us/studio`. Callout **1** is the sidebar. Callout **2** is the compact page title. Callout **3** is the workspace. Callout **4** (when present) marks the current nav item.

## Home

**Dashboard** (`/us/studio`) — system overview and widgets. Packages can drop extra widgets into `core.dashboard.widgets`.

## Development

- **Data Studio** — Edge models, Sequelize runtime, published Data API.

- **Server Functions** — sandboxed TypeScript/JavaScript APIs + OpenAPI.

- **Developer Reference** — sandbox globals, `util.*`, `req`/`res`, `db`, `auth`, examples.

- **Client Components** — Component Designer for composed UI and layouts (including this public SiteLayout).

- **Base Components** — the living catalog Studio forms must use.

- **Portals** — URL portals, shells, in-app pages.

- **Package Manager** — install, build, export ZIP extensions and vertical apps.

## Operations

- **Workflows** — author, validate, publish, simulate, run.

- **File Manager** / **File Hub** — workspace files; saved SFTP/FTP.

- **SSH Hub** / **RDP Hub** — in-browser remote shells and desktops.

- **Scheduled Tasks** — cron for Server Functions.

- **Jobs** — long-running background work with live progress.

- **Cache Control** — memory and Redis.

- **Data Sources** — control plane plus extra edge engines.

- **Git** — local changes, stage, sync.

- **Theme Designer** — named shell atmosphere presets (sidebar footer).

- **Settings** — auth, email, cultures, AI, MCP, identity providers, PWA, logs.

- **Platform Transfer** — selective backup and restore of settings bundles.

## Records

**Users**, **Roles**, **Base Info**, **Organization Chart**, **Geographic Divisions**, **Chat History**, **Logs**.

## CMS (package)

**Contents** and **CMS Settings** appear when the CMS package is installed. This public site is edited there.', '101.003.002', 'AppEndO Studio map', 'Complete nav map of Studio groups and pages after a greenfield install.', '2026-08-19T09:00:00.000Z', NULL, TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:35.016Z', NULL, '2026-08-24T03:08:35.016Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('18', '101.001.001', '101.004.001', 'identity-and-access', '101.002.003', NULL, NULL, 'Identity, roles, and sessions', 'Users, roles, JWT sessions in HttpOnly cookies, login lockout, OAuth/OIDC, and Individual/Company profiles.', 'Open **Users** (`/us/studio/users`) and **Roles** (`/us/studio/roles`). The annotated screenshots mark the same Studio chrome: nav (1), title (2), workspace grid (3).

## Users

Create and update accounts and credentials. Dev installs use a simple username/password. Production should keep that form, then add providers — not replace it with a second login invention.

## Roles and RBAC

Roles are permission groups. Studio pages declare `allowRoles` in the nav registry. Unlisted users never see gated Development and Operations items. The public Home portal does not require a session.

## Sessions

JWTs live in **HttpOnly cookies** only — never `localStorage` or `sessionStorage`. Login lockout is part of the identity service. Google, GitHub, Microsoft Entra, and generic OIDC ship as system extensions; enterprise SAML is on the roadmap.

## Profiles

Individual and Company profiles attach to the same identity records. They are not a second user table.', '101.003.002', 'AppEndO identity and access', 'Users, roles, HttpOnly JWT sessions, OAuth/OIDC, and profiles.', '2026-08-18T09:00:00.000Z', NULL, TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:35.096Z', NULL, '2026-08-24T03:08:35.096Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('19', '101.001.001', '101.004.001', 'data-studio-and-data-api', '101.002.003', NULL, NULL, 'Data Studio and the Data API', 'Model edge tables visually, publish REST Data APIs with a Sequelize runtime, and introspect connected schemas.', 'Open **Data Studio** (`/us/studio/data-studio`). Callout 1 is still Studio nav. The workspace (3) is the modeler — objects, fields, and publish — not a SQL scratch pad pretending to be a product.

## What you build

Each Edge model becomes a managed resource. Publishing exposes a REST Data API the rest of the platform (grids, forms, Server Functions, packages) can call. Introspection reads connected schemas instead of forcing you to retype every column.

## Control plane versus edge

`base_*` tables stay on the **control plane**. External/business data goes through **EdgeDbRouter** and registered data sources. Do not mix those paths.

## Record Policy

Row-level **Capability versus Scope** (organization and geography) applies on Data APIs. See the Record Policy guide — it is not the same as a Studio role.', '101.003.002', 'AppEndO Data Studio and Data API', 'Visual Edge models, published REST Data APIs, and control-plane versus edge data.', '2026-08-18T10:00:00.000Z', NULL, TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:35.206Z', NULL, '2026-08-24T03:08:35.206Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('20', '101.001.001', '101.004.001', 'data-sources-and-engines', '101.002.003', NULL, NULL, 'Data sources and engines', 'PostgreSQL is the verified production control plane. Extra edge sources include Postgres, SQL Server, MySQL, Oracle, MongoDB, Redis, and SQLite.', 'Open **Data Sources** (`/us/studio/data-sources`). The workspace lists connections: the default control-plane database plus any extra engines you register.

## Control plane

Greenfield production path is **PostgreSQL**. MySQL, SQLite, and SQL Server adapters exist; wizard E2E for MySQL/SQLite is still being hardened. `npm run setup` provisions local PostgreSQL.

## Edge sources

Register extra databases for LOB data. Queries from Data Studio models and Server Functions must go through **EdgeDbRouter** — never ad-hoc connection strings in package UI.

## Cache

Hot keys and Redis live under **Cache Control**, not inside a data source row. See the Operations guide.', '101.003.002', 'AppEndO data sources', 'Control-plane engines and extra edge connections including Oracle, MongoDB, and Redis.', '2026-08-17T09:00:00.000Z', NULL, TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:35.293Z', NULL, '2026-08-24T03:08:35.293Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('21', '101.001.001', '101.004.001', 'workflow-engine', '101.002.003', NULL, NULL, 'Workflow Engine', 'Author, simulate, publish, and run durable workflows with human work items, webhooks, timers, parallel branches, and subflows.', 'Open **Workflows** (`/us/studio/workflows`). The workspace is the definition list and designer entry — not a drawing that disappears when you refresh.

## Authoring

Definitions are first-class records: validate, publish, import, and export. The engine is native to AppEndO, not a bolted-on BPM vendor.

## Runtime

Runs are durable. Waits, timers, webhooks, parallel paths, and subflows are part of the core action pack. Human **work items** land in an inbox for people who may never open the designer.

## How it connects

Workflows call Server Functions and Data APIs. They do not replace them. Scheduled Tasks can wake functions on cron; Jobs show long-running progress for work the engine or functions enqueue.', '101.003.002', 'AppEndO Workflow Engine', 'Durable workflow designer, work items, webhooks, timers, and core actions.', '2026-08-17T10:00:00.000Z', NULL, TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:35.396Z', NULL, '2026-08-24T03:08:35.396Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('22', '101.001.001', '101.004.001', 'server-functions', '101.002.003', NULL, NULL, 'Server Functions', 'Author, version, and execute TypeScript or JavaScript APIs in a restricted Node runtime with OpenAPI documentation.', 'Open **Server Functions** (`/us/studio/server-functions`). The workspace lists folders and functions you can edit, version, and execute without deploying a separate Node service.

## Sandbox

Functions run with a documented surface: `req`, `res`, `db`, `auth`, `util.*`. They are not free-range processes. **Developer Reference** (`/us/studio/dev-reference`) is the living manual for that surface, with runnable examples.

## OpenAPI

Managed functions participate in the platform OpenAPI aggregation. Other Studio pages, MCP tools, and packages discover them the same way.

## Scheduling and jobs

Cron schedules are **Scheduled Tasks**. Long runs show up under **Jobs**. Do not invent a second worker UI.', '101.003.002', 'AppEndO Server Functions', 'Sandboxed TypeScript APIs, OpenAPI, Developer Reference, schedules, and jobs.', '2026-08-16T09:00:00.000Z', NULL, TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:35.523Z', NULL, '2026-08-24T03:08:35.523Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('23', '101.001.001', '101.004.001', 'developer-reference', '101.002.003', NULL, NULL, 'Developer Reference', 'Sandbox reference for Server Functions — globals, util.*, req/res, db, auth, and examples you can run in Studio.', 'Open **Developer Reference** (`/us/studio/dev-reference`). This is not marketing copy. It is the contract of what a Server Function may call.

## Why it exists

The sandbox is intentionally smaller than Node. If a helper is not in this reference, a function should not assume it. That is how AppEndO keeps package APIs portable across installs.

## Pair with

Write the function in **Server Functions**, confirm the helper here, then expose it through OpenAPI or a workflow action.', '101.003.002', 'AppEndO Developer Reference', 'Server Function sandbox globals, utilities, and runnable examples.', '2026-08-16T10:00:00.000Z', NULL, TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:35.630Z', NULL, '2026-08-24T03:08:35.630Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('24', '101.001.001', '101.004.001', 'client-and-base-components', '101.002.003', NULL, NULL, 'Client Components and Base Components', 'Compose layouts in Component Designer. Shared primitives live on the Base Components catalog — Studio UI must match that catalog.', 'Open **Client Components** (`/us/studio/client-components`) and **Base Components** (`/us/studio/base-components`). Two different jobs, one design system.

## Base Components

Every Studio control — fields, checkboxes, dialogs, toolbars, grids — comes from this catalog (`pageKey: base-components`). Do not invent raw HTML inputs or a parallel widget set when a catalog section exists. The page you screenshot is the visual source of truth.

## Client Components

Component Designer composes those primitives (and slots) into pages, shells, and public layouts. This marketing site uses `SiteLayout` from Client Components. Publish a layout, bind it to a portal shell, and the front office changes without a core rewrite.

## Theme Designer

Named atmosphere presets and accent tokens live under **Theme Designer**. Large surfaces stay slate/neutral; color is for small-area meaning (text, icons, badges).', '101.003.002', 'AppEndO Client Components and Base Components', 'Component Designer, the Base Components catalog, and Theme Designer presets.', '2026-08-15T09:00:00.000Z', NULL, TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:35.716Z', NULL, '2026-08-24T03:08:35.716Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('25', '101.001.001', '101.004.001', 'theme-designer', '101.002.003', NULL, NULL, 'Theme Designer', 'Named shell atmosphere presets with full accent token control — not a one-off CSS file per page.', 'Open **Theme Designer** (`/us/studio/theme-designer`). It sits in the sidebar footer next to Settings because it is a platform preset, not a one-page paint tool.

## What you edit

Named presets control atmosphere and accent tokens for the admin shell. Semantic color belongs on text, icons, badges, and small objects. Large surfaces stay slate/neutral so operators can scan.

## Front office

Public SiteLayout has its own tokens. Changing a Studio preset does not silently restyle the public site — that is intentional. Bind public chrome through Client Components and CMS fragments.', '101.003.002', 'AppEndO Theme Designer', 'Named shell atmosphere presets and accent tokens for Studio.', '2026-08-15T10:00:00.000Z', NULL, TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:35.820Z', NULL, '2026-08-24T03:08:35.820Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('26', '101.001.001', '101.004.001', 'portals-and-front-office', '101.002.003', NULL, NULL, 'Portals, cultures, and the front office', 'Multiple portals and shells, culture-localized URLs, per-route auth, and public pages for people who never open Studio.', 'Open **Portals** (`/us/studio/portals`). You are looking at how URLs are carved: culture packs, portal segments, shells, and page bindings.

## Cultures

US, IR, and IQ culture packs ship as system extensions (locale, calendar, direction, web fonts). Paths look like `/us/...` — culture first, then portal.

## Portals and shells

**Studio** is the back-office portal (`/us/studio/...`) with AdminLayout. **Home** is the public portal (`/us`, `/us/about`) with SiteLayout. Vertical apps add branded routes and static assets on the same router.

## Auth per route

Routes declare public, authenticated, or admin access. This guide site is public. `/us/studio/users` stays Studio even if a CMS page wished it were a blog slug — bound Studio routes win.

## This site

Home at `/us` is CMS-backed SiteLayout. The screenshot of Portals (1 nav, 3 workspace) is where you would add another public or partner portal.', '101.003.002', 'AppEndO portals and front office', 'Culture-aware routing, portals, shells, and public sites for non-technical users.', '2026-08-14T09:00:00.000Z', NULL, TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:35.896Z', NULL, '2026-08-24T03:08:35.896Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('27', '101.001.001', '101.004.001', 'packages-and-cms', '101.002.003', NULL, NULL, 'Packages, CMS, and the ecosystem', 'Install, build, and export ZIP packages. CMS is a shipped editorial package — this site is that package in public.', 'Open **Package Manager** (`/us/studio/package-manager`) and **CMS Contents** (`/us/studio/cms/contents`). Packages are how AppEndO grows without forking core.

## Package Manager

Install extension and vertical-app ZIPs, configure them, build reference packages from this repo, and export. Operators who prefer install-over-code live here. A central marketplace is on the roadmap; the hub already does the install.

## What already ships as packages or extensions

- Reference extensions: hello widget, hello API, hello page.

- **inventory** vertical app — routes, APIs, DB scripts, branding, propose→apply deploy.

- **CMS** — editorial content, vocabularies, Studio CMS nav.

- Culture packs and identity-provider adapters.

- **15 in-process MCP packs** for the AppEndO agent.

## CMS

Contents, tags (Base Info), assets, relations, revisions, comments, and public read APIs. This page is a CMS article. The screenshot of Contents is where you would edit it. CMS Settings holds vocabularies (types, statuses, tags, languages).

## Planned packages

CRM, commerce, HR, forum, calendar, DbEnricher, Database Manager, payment gateways, and more sit on the packages backlog — same toolchain, not new cores.', '101.003.002', 'AppEndO packages and CMS', 'Package Manager, shipped CMS package, reference ZIPs, and ecosystem backlog.', '2026-08-14T10:00:00.000Z', NULL, TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:36.000Z', NULL, '2026-08-24T03:08:36.000Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('28', '101.001.001', '101.004.001', 'operations', '101.002.003', NULL, NULL, 'Operations: files, remotes, jobs, cache, Git', 'File Manager, File Hub, SSH Hub, RDP Hub, Jobs, Scheduled Tasks, Cache, Git, logs, and Platform Transfer.', 'Operations is the Studio group for keeping an install healthy after builders leave the room. Screenshots on this page are the real pages, with the same nav/title/workspace callouts.

## Files and remotes

- **File Manager** — browse `workspace/` (optional project-root access).

- **File Hub** — saved SFTP/FTP connections.

- **SSH Hub** — saved SSH connections and an in-browser terminal.

- **RDP Hub** — saved RDP connections and an in-browser desktop for Windows servers.

## Work that runs later

- **Scheduled Tasks** — cron-based Server Function schedules in platform settings.

- **Jobs** — long-running background jobs with live progress.

- **Cache Control** — in-memory and Redis layers.

## Source and move

- **Git** — review local changes, stage, sync the repository.

- **Platform Transfer** — selective backup and restore of platform settings bundles.

- **Logs** — runtime logs and per-method logging behavior.', '101.003.002', 'AppEndO operations', 'Files, SSH, RDP, jobs, cache, Git, logs, and platform transfer.', '2026-08-13T09:00:00.000Z', NULL, TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:36.073Z', NULL, '2026-08-24T03:08:36.073Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('29', '101.001.001', '101.004.001', 'ai-and-mcp', '101.002.003', NULL, NULL, 'AppEndO agent, chat history, and MCP', 'In-app agent, 15 built-in MCP capability packs, optional remote MCP servers, field assist, and Chat History.', 'The agent is docked in Studio (not a third-party sidecar). **Chat History** (`/us/studio/chat-history`) is the operator archive of sessions across users.

## What the agent can use

Fifteen in-process MCP packs: files, web, HTTP, Git, codebase, standards, data, context, designer, Server Functions, jobs, packages, memory, cache, OpenAPI. That is how it can draft a layout or a Server Function against *this* install.

## Guardrails

Optional external MCP servers are SSRF-guarded. Writes go through draft → proposal → apply. MCP access is configured in Settings, not in a hidden env file on the side.

## Field assist

End-user assist on forms, textarea, and the image editor is the same AI gateway — not a second chatbot product.', '101.003.002', 'AppEndO AI and MCP', 'In-app agent, 15 MCP packs, remote servers, field assist, and chat history.', '2026-08-13T10:00:00.000Z', NULL, TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:36.236Z', NULL, '2026-08-24T03:08:36.236Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('30', '101.001.001', '101.004.001', 'settings-install-and-security', '101.002.003', NULL, NULL, 'Settings, install wizard, and security baseline', 'First-run wizard, system config hub, PWA, email, cultures, AI models, identity providers, and cookie-only JWTs.', 'Open **Settings** (`/us/studio/settings`). This is the system config hub: auth, email, cultures, AI models, MCP access, identity providers, PWA, and logs.

## Install

The **install wizard** runs in the browser before a database is required. It collects topology (single-node vs role-based), cache, database, admin, and email, then applies schema. `npm run setup` is the local PostgreSQL path. MySQL/SQLite wizard E2E is still being completed; PostgreSQL is the verified production path.

## Security baseline

- JWTs in HttpOnly cookies only.

- Login lockout on the identity service.

- RBAC on Studio pages.

- Record Policy on Data APIs (org/geo scope).

- Sandboxed Server Functions.

- SSRF guards on remote MCP.

## Platform Transfer

Move settings bundles between installs without copying the whole database by hand (`/us/studio/platform-transfer`).', '101.003.002', 'AppEndO settings, install, and security', 'Install wizard, Settings hub, PWA, providers, and the platform security baseline.', '2026-08-12T09:00:00.000Z', NULL, TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:36.323Z', NULL, '2026-08-24T03:08:36.323Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('31', '101.001.001', '101.004.001', 'record-policy-org-and-geo', '101.002.003', NULL, NULL, 'Record Policy, organization, and geography', 'Row-level Capability versus Scope on Data APIs, plus Organization Chart, Geographic Divisions, and Base Info vocabularies.', 'Roles decide whether you may open **Users**. Record Policy decides **which rows** a Data API returns. They are not the same switch.

## Organization Chart

`/us/studio/organization-chart` is the company tree used as scope, not a pretty org poster.

## Geographic Divisions

`/us/studio/geographic-divisions` holds countries, provinces, and cities for geo scope.

## Base Info

`/us/studio/base-info` is the shared hierarchical code/title dictionary. CMS tags, statuses, and languages are Base Info categories — not a second tagging product.

## Capability versus Scope

Capability is what the role may do (read, write). Scope is the org/geo slice those verbs apply to. Data APIs honor both. See Studio Record Policy docs when you wire a new model.', '101.003.002', 'AppEndO Record Policy, org, and geo', 'Row-level scope, organization chart, geographic divisions, and Base Info.', '2026-08-12T10:00:00.000Z', NULL, TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:36.410Z', NULL, '2026-08-24T03:08:36.410Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('32', '101.001.003', '101.004.001', 'get-started', '101.002.003', NULL, NULL, 'A working path through the product', 'Sign in, walk the Studio map, publish a Data API, write a function, open the public site — the shortest loop that touches the real product.', '1. **Sign in** at `/login` (screenshot: mark, username, password, Sign in).

2. **Dashboard** at `/us/studio` — learn the nav groups from the Studio map guide.

3. **Base Components** — see the controls every Studio form should use.

4. **Data Studio** — open a model, understand publish.

5. **Server Functions** — open one function; skim Developer Reference.

6. **Workflows** — open a definition even if you do not run it yet.

7. **Portals** — confirm Home versus Studio.

8. **CMS Contents** — this article is a row you can edit; **Home** at `/us` is the public read.

That loop is the product. Packages and AI sit on top of it, they do not replace it.', '101.003.002', 'Get started with AppEndO Studio', 'A short path: login, dashboard, data, functions, workflows, portals, public site.', '2026-08-21T09:00:00.000Z', NULL, TRUE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:36.510Z', NULL, '2026-08-24T03:08:36.510Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('33', '101.001.008', '101.004.001', 'howto-sign-in', '101.002.003', NULL, NULL, 'How to sign in to Studio', 'Open /login, enter the operator account, and land on the Studio dashboard.', 'Studio is behind a session. The public site at `/us` does not require sign-in.

## Steps

1. Go to `/login`. The annotated screenshot on this page marks the product mark (1), username (2), password (3), and Sign in (4).

2. Enter the operator username or email. On a development seed that is `admin` or `admin@append.os`.

3. Enter the password. Click **Sign in**.

4. After success the app may land on `/`. Open `/us/studio` for the dashboard.

## If it fails

Invalid credentials stay on the login form. OTP, when enabled, asks for a code before the dashboard. Sessions are HttpOnly cookies — do not look for a token in `localStorage`.

Next: [Create a user](/us/howto-create-user) · [Studio map](/us/studio-map)', '101.003.002', 'How to sign in to AppEndO Studio', 'Sign in at /login and open the Studio dashboard.', '2026-08-22T09:00:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:36.606Z', NULL, '2026-08-24T03:08:36.606Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('34', '101.001.008', '101.004.001', 'howto-create-user', '101.002.003', NULL, NULL, 'How to create a user', 'Add an account from Records → Users without leaving Studio.', 'Operators create people in **Users**, not in a SQL window.

## Steps

1. Sign in and open `/us/studio/users`.

2. Use **Create** (the catalogued create action on that page).

3. Fill username, email, and password. Keep identifier fields in English; do not invent a second email column.

4. Save. The grid lists the new row.

5. If the person needs Studio pages, assign a role next — [create a role and assign it](/us/howto-assign-role).

## Notes

Individual and Company profiles attach to the same user. Google / GitHub / Entra / OIDC can log existing users in; they do not replace this form on a greenfield install.', '101.003.002', 'How to create an AppEndO user', 'Create an account from Studio Users.', '2026-08-22T09:10:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:36.666Z', NULL, '2026-08-24T03:08:36.666Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('35', '101.001.008', '101.004.001', 'howto-assign-role', '101.002.003', NULL, NULL, 'How to create a role and assign it', 'Roles gate Studio pages. Users without an allowed role never see Development and Operations items.', 'A user record is not enough. Studio nav checks **roles**.

## Steps

1. Open `/us/studio/roles`.

2. Create a role (for example a builder role that may use Data Studio).

3. Open `/us/studio/users`, edit the person, and attach that role.

4. Sign out and sign in as that person. Confirm the sidebar shows only what the role allows.

## Do not confuse with Record Policy

Roles decide whether a **page** opens. [Record Policy](/us/record-policy-org-and-geo) decides **which rows** a Data API returns. Set both when you publish a business table.', '101.003.002', 'How to assign an AppEndO role', 'Create a role and attach it to a user.', '2026-08-22T09:20:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:36.726Z', NULL, '2026-08-24T03:08:36.726Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('36', '101.001.008', '101.004.001', 'howto-publish-data-api', '101.002.003', NULL, NULL, 'How to publish a Data API', 'Open Data Studio, model the table, publish, then call the REST Data API from grids and functions.', 'This is the usual path from “we have columns” to “the rest of Studio can list them”.

## Steps

1. Open `/us/studio/data-studio`.

2. Create or select an Edge model on the correct **data source** (control plane vs edge — see [data sources](/us/data-sources-and-engines)).

3. Add fields. Do not type a parallel schema in SQL if the modeler already owns the object.

4. Publish. The platform exposes a REST Data API for that model.

5. Confirm the object appears for grids, forms, and Server Functions.

## After publish

If rows must be sliced by org or geography, wire [Record Policy](/us/record-policy-org-and-geo) before you give the API to end users.', '101.003.002', 'How to publish an AppEndO Data API', 'Model in Data Studio and publish a REST Data API.', '2026-08-22T09:30:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:36.800Z', NULL, '2026-08-24T03:08:36.800Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('37', '101.001.008', '101.004.001', 'howto-create-server-function', '101.002.003', NULL, NULL, 'How to write and run a Server Function', 'Author TypeScript in Studio, execute it in the sandbox, and read it from OpenAPI.', 'Server Functions are not a second Node repo. They live in Studio.

## Steps

1. Open `/us/studio/server-functions`.

2. Create a function in a folder. Keep the sandbox surface from [Developer Reference](/us/developer-reference) (`req`, `res`, `db`, `auth`, `util.*`).

3. Save a version. Run it from the page.

4. Confirm it appears in OpenAPI if other tools must discover it.

5. For a clock, add a **Scheduled Task**. For a long run, watch **Jobs**.

## Do not

Do not assume full Node APIs. If it is not in Developer Reference, the sandbox will not pretend it exists.', '101.003.002', 'How to create an AppEndO Server Function', 'Author, run, and document a sandboxed Server Function.', '2026-08-22T09:40:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:36.850Z', NULL, '2026-08-24T03:08:36.850Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('38', '101.001.008', '101.004.001', 'howto-publish-workflow', '101.002.003', NULL, NULL, 'How to publish a workflow', 'Author a definition, validate, publish, then run it so work items can land in an inbox.', 'A drawing that never publishes is not a workflow.

## Steps

1. Open `/us/studio/workflows`.

2. Create or open a definition. Add waits, webhooks, or human work items as needed.

3. Validate. Fix errors the designer reports.

4. Publish. Simulate if you need a dry run.

5. Start a run. People who should never open the designer pick up **work items** from their inbox.

## Pair with

Call [Server Functions](/us/howto-create-server-function) and Data APIs from actions. Use [Scheduled Tasks](/us/operations) when the engine should wake on a clock.', '101.003.002', 'How to publish an AppEndO workflow', 'Validate, publish, and run a durable workflow.', '2026-08-22T09:50:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:36.913Z', NULL, '2026-08-24T03:08:36.913Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('39', '101.001.008', '101.004.001', 'howto-install-package', '101.002.003', NULL, NULL, 'How to install a package', 'Install an extension or vertical-app ZIP from Package Manager instead of forking core.', 'Packages are how AppEndO grows. CMS on this site is one of them.

## Steps

1. Open `/us/studio/package-manager`.

2. Install the ZIP (reference extensions, a vertical app, or a domain package).

3. Follow any propose → apply step the package requires.

4. Confirm new nav items, APIs, or dashboard widgets appeared.

5. Configure the package from its own settings, not by editing `src/features/`.

## After install

CMS adds **Contents** and **CMS Settings**. Publish public pages with [this how-to](/us/howto-publish-public-page).', '101.003.002', 'How to install an AppEndO package', 'Install a ZIP from Package Manager.', '2026-08-22T10:00:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:36.960Z', NULL, '2026-08-24T03:08:36.960Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('40', '101.001.008', '101.004.001', 'howto-publish-public-page', '101.002.003', NULL, NULL, 'How to publish a public CMS page', 'Create a Page in CMS Contents, set Published, and it appears in the Home portal nav.', 'This public site is CMS. You do not edit `SiteHome.tsx` to add a top-level page.

## Steps

1. Sign in. Open `/us/studio/cms/contents`.

2. Create a row. Type **Page**, language **English**, a unique slug (for example `pricing`).

3. Write title, summary, and body. Attach screenshots as content assets if the page needs pictures.

4. Set status to **Published** and save.

5. Open `/us/{slug}` (culture first). The new item shows in the top nav next to About and Guide.

## Fragments

`site-brand`, `site-cta`, and `slide-01` are fragments, not nav pages. Drafts and in-review comments never leave Studio.', '101.003.002', 'How to publish a public AppEndO page', 'Publish a CMS Page so it appears on the Home portal.', '2026-08-22T10:10:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:37.020Z', NULL, '2026-08-24T03:08:37.020Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('41', '101.001.008', '101.004.001', 'howto-switch-theme', '101.002.003', NULL, NULL, 'How to apply a Theme Designer preset', 'Pick a named atmosphere preset so Studio chrome changes without a one-off CSS file.', 'Theme Designer sits in the sidebar footer next to Settings.

## Steps

1. Open `/us/studio/theme-designer`.

2. Select or create a named preset.

3. Adjust accent tokens. Keep large surfaces slate/neutral; put color on text, icons, and badges.

4. Save and apply. Reload Studio to confirm the shell atmosphere.

## Front office

The public SiteLayout has its own tokens. A Studio preset does not silently restyle `/us`. Change public chrome through Client Components and CMS fragments.', '101.003.002', 'How to change the AppEndO Studio theme', 'Apply a Theme Designer atmosphere preset.', '2026-08-22T10:20:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:37.090Z', NULL, '2026-08-24T03:08:37.090Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('42', '101.001.008', '101.004.001', 'howto-add-data-source', '101.002.003', NULL, NULL, 'How to register a data source', 'Add an extra database for LOB data. Keep base_* tables on the control plane.', 'The default source is the control plane. Extra engines are edge sources.

## Steps

1. Open `/us/studio/data-sources`.

2. Add a connection (Postgres, SQL Server, MySQL, Oracle, MongoDB, Redis, or SQLite as supported).

3. Test the connection. Save.

4. In Data Studio, build models on that source — not by pasting a connection string into a package UI.

## Rule

`base_*` tables stay on the control plane. Business tables go through EdgeDbRouter. See [Data Studio](/us/data-studio-and-data-api).', '101.003.002', 'How to add an AppEndO data source', 'Register an extra database from Data Sources.', '2026-08-22T10:30:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:37.140Z', NULL, '2026-08-24T03:08:37.140Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('43', '101.001.008', '101.004.001', 'howto-clear-cache', '101.002.003', NULL, NULL, 'How to clear cache', 'Open Cache Control and flush the layer that is serving stale data — memory or Redis.', 'Stale lists and settings usually mean cache, not a broken model.

## Steps

1. Open `/us/studio/cache`.

2. Identify memory versus Redis (whatever this install uses).

3. Flush the keys or layer the operator named. Do not invent a second cache UI.

4. Reload the Studio page that looked stale.

## Related

Jobs and Scheduled Tasks are not cache. If work is still running, look at `/us/studio/jobs` instead.', '101.003.002', 'How to clear AppEndO cache', 'Flush memory or Redis from Cache Control.', '2026-08-22T10:40:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:37.190Z', NULL, '2026-08-24T03:08:37.190Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('44', '101.001.008', '101.004.001', 'howto-open-public-site', '101.002.003', NULL, NULL, 'How to open the public site', 'The Home portal is /us — no Studio chrome. Studio is /us/studio after sign-in.', 'People mix these two URLs. They are different portals.

## Steps

1. For visitors: open `/us`. That is this handbook’s public site.

2. For operators: sign in, then open `/us/studio`.

3. A published CMS **Page** is `/us/{slug}` — for example `/us/guide` and `/us/about`.

4. Bound Studio routes such as `/us/users` stay Studio even if a CMS slug wished otherwise.

## Cultures

Paths start with the culture (`/us`, and other packs). Portals sit after that. See [Portals](/us/portals-and-front-office).', '101.003.002', 'How to open the AppEndO public site', 'Home portal /us versus Studio /us/studio.', '2026-08-22T10:50:00.000Z', NULL, FALSE, '101.006.001', NULL, NULL, 'AppEndO team', 'hello@append.os', NULL, NULL, NULL, '2026-08-24T03:08:37.240Z', NULL, '2026-08-24T03:08:37.240Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('45', '101.001.005', '101.004.001', 'comment-overview-01', '101.002.003', NULL, NULL, 'The screenshot callouts help', '', 'The numbered overlays on the Dashboard shot made the nav groups obvious. I stopped hunting for a separate docs microsite.', '101.003.003', NULL, NULL, '2026-08-20T14:10:00.000Z', NULL, FALSE, '101.006.001', NULL, '16', 'Mira Bell', 'mira.bell@example.com', NULL, NULL, NULL, '2026-08-24T03:08:37.316Z', NULL, '2026-08-24T03:08:37.316Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('46', '101.001.005', '101.004.001', 'comment-overview-02', '101.002.003', NULL, NULL, 'CMS as a package', '', 'Useful that this public site is itself the CMS package. The Packages guide clicked after I edited a row in Contents and refreshed /us.', '101.003.003', NULL, NULL, '2026-08-20T16:40:00.000Z', NULL, FALSE, '101.006.001', NULL, '16', 'Jon Hale', 'jon.hale@example.com', NULL, NULL, NULL, '2026-08-24T03:08:37.336Z', NULL, '2026-08-24T03:08:37.336Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('47', '101.001.005', '101.004.001', 'comment-map-01', '101.002.003', NULL, NULL, 'Operations list', '', 'SSH Hub and Platform Transfer were the two pages I did not expect. The Studio map listing matched the sidebar on my install.', '101.003.003', NULL, NULL, '2026-08-19T11:20:00.000Z', NULL, FALSE, '101.006.001', NULL, '17', 'Sera Holt', 'sera.holt@example.com', NULL, NULL, NULL, '2026-08-24T03:08:37.356Z', NULL, '2026-08-24T03:08:37.356Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('48', '101.001.005', '101.004.001', 'comment-overview-pending', '101.002.002', NULL, NULL, 'Waiting on review', '', 'This comment should stay off the public site until it is published.', '101.003.003', NULL, NULL, NULL, NULL, FALSE, '101.006.001', NULL, '16', 'Pending Guest', 'pending.guest@example.com', NULL, NULL, NULL, '2026-08-24T03:08:37.380Z', NULL, '2026-08-24T03:08:37.380Z');
INSERT INTO [cms_contents] ([id], [content_type_code], [language_code], [slug], [status_code], [status_code_updated_at], [status_code_updated_by], [title], [summary], [body], [body_format_code], [seo_title], [seo_note], [published_at], [operator_note], [comments_enabled], [comments_policy_code], [comments_body_format_code], [parent_content_id], [author_display_name], [author_email], [moderated_by], [moderated_at], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('49', '101.001.001', '101.004.001', 'internal-outline-draft', '101.002.001', NULL, NULL, 'Internal outline (unfinished)', 'A draft that must never appear on the public site.', 'Operator-only draft. Used to prove status filtering in the sample seed.', '101.003.003', NULL, NULL, NULL, 'Keep as draft. Public list must ignore this slug.', NULL, NULL, NULL, NULL, 'AppEndO team', NULL, NULL, NULL, NULL, '2026-08-24T03:08:37.403Z', NULL, '2026-08-24T03:08:37.403Z');
-- Captured 78 row(s) from cms_content_assets on 2026-08-24T12:57:05.464Z
-- WHERE ([content_id] IN ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49')) OR ([content_id] IN ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49'))
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('1', '6', {{package_blob:db/blobs/files/cms_content_assets_file_id=1.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=1.bin}}, 101944, 'shot-dashboard.jpg', 'image/jpeg', 0, 'f2ac4c848c55361081f85222b9f16b844d38b0ac8def2d461bdfe8275803a3e1', NULL, '2026-08-24T03:08:34.286Z', NULL, '2026-08-24T03:08:34.286Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('2', '7', {{package_blob:db/blobs/files/cms_content_assets_file_id=2.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=2.bin}}, 21840, 'shot-data-studio.jpg', 'image/jpeg', 0, '96a26d2695cbdc8b6ef9b0ffbdb2742cfaf996d95900fb029e97a50aa5e3d8b6', NULL, '2026-08-24T03:08:34.350Z', NULL, '2026-08-24T03:08:34.350Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('3', '8', {{package_blob:db/blobs/files/cms_content_assets_file_id=3.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=3.bin}}, 53011, 'shot-workflows.jpg', 'image/jpeg', 0, '1f4fd737212c4683b1eda14bf07bdcd4820bfaab953159d876465c7bdc948416', NULL, '2026-08-24T03:08:34.400Z', NULL, '2026-08-24T03:08:34.400Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('4', '9', {{package_blob:db/blobs/files/cms_content_assets_file_id=4.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=4.bin}}, 54481, 'shot-server-functions.jpg', 'image/jpeg', 0, '3d78df90b8bf1afd3d6ab3971089cb72c71cbe026abb7286a378f6fa2f85c4a5', NULL, '2026-08-24T03:08:34.453Z', NULL, '2026-08-24T03:08:34.453Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('5', '10', {{package_blob:db/blobs/files/cms_content_assets_file_id=5.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=5.bin}}, 59110, 'shot-portals.jpg', 'image/jpeg', 0, '897328a202d229b81c29a48d2d1e15e18007ca029c5af845981df1cb28c9cc4a', NULL, '2026-08-24T03:08:34.506Z', NULL, '2026-08-24T03:08:34.506Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('6', '11', {{package_blob:db/blobs/files/cms_content_assets_file_id=6.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=6.bin}}, 101944, 'shot-dashboard.jpg', 'image/jpeg', 0, 'f2ac4c848c55361081f85222b9f16b844d38b0ac8def2d461bdfe8275803a3e1', NULL, '2026-08-24T03:08:34.566Z', NULL, '2026-08-24T03:08:34.566Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('7', '11', {{package_blob:db/blobs/files/cms_content_assets_file_id=7.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=7.bin}}, 123023, 'shot-public-home.jpg', 'image/jpeg', 1, '4fbdb3f4c62d135e2d51e064c94c602f7273bf0f4f72e20f844f25cc196bbd7c', NULL, '2026-08-24T03:08:34.586Z', NULL, '2026-08-24T03:08:34.586Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('8', '12', {{package_blob:db/blobs/files/cms_content_assets_file_id=8.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=8.bin}}, 114240, 'shot-about-page.jpg', 'image/jpeg', 0, '04527eb2867c7b6a61ec7045d1ca5ad5e91419f03893aed46db11485a7856b8e', NULL, '2026-08-24T03:08:34.653Z', NULL, '2026-08-24T03:08:34.653Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('9', '12', {{package_blob:db/blobs/files/cms_content_assets_file_id=9.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=9.bin}}, 123023, 'shot-public-home.jpg', 'image/jpeg', 1, '4fbdb3f4c62d135e2d51e064c94c602f7273bf0f4f72e20f844f25cc196bbd7c', NULL, '2026-08-24T03:08:34.676Z', NULL, '2026-08-24T03:08:34.676Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('10', '12', {{package_blob:db/blobs/files/cms_content_assets_file_id=10.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=10.bin}}, 57916, 'shot-login.jpg', 'image/jpeg', 2, 'bf5a353034daef703c4dc95ff1a9b6f7618e8fa8057df6258a8d5f8452de64e7', NULL, '2026-08-24T03:08:34.696Z', NULL, '2026-08-24T03:08:34.696Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('11', '13', {{package_blob:db/blobs/files/cms_content_assets_file_id=11.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=11.bin}}, 57916, 'shot-login.jpg', 'image/jpeg', 0, 'bf5a353034daef703c4dc95ff1a9b6f7618e8fa8057df6258a8d5f8452de64e7', NULL, '2026-08-24T03:08:34.756Z', NULL, '2026-08-24T03:08:34.756Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('12', '13', {{package_blob:db/blobs/files/cms_content_assets_file_id=12.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=12.bin}}, 77066, 'shot-settings.jpg', 'image/jpeg', 1, '338f5e0cd5144ceeda199335024813e4f62f732861962536587051ea480a1835', NULL, '2026-08-24T03:08:34.776Z', NULL, '2026-08-24T03:08:34.776Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('13', '15', {{package_blob:db/blobs/files/cms_content_assets_file_id=13.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=13.bin}}, 101944, 'shot-dashboard.jpg', 'image/jpeg', 0, 'f2ac4c848c55361081f85222b9f16b844d38b0ac8def2d461bdfe8275803a3e1', NULL, '2026-08-24T03:08:34.880Z', NULL, '2026-08-24T03:08:34.880Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('14', '15', {{package_blob:db/blobs/files/cms_content_assets_file_id=14.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=14.bin}}, 86422, 'shot-guide-studio-map.jpg', 'image/jpeg', 1, '3430056cd12da4e1a094a48484c4ab5413273292ff80e9dbf2a950b2617516f8', NULL, '2026-08-24T03:08:34.900Z', NULL, '2026-08-24T03:08:34.900Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('15', '16', {{package_blob:db/blobs/files/cms_content_assets_file_id=15.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=15.bin}}, 101944, 'shot-dashboard.jpg', 'image/jpeg', 0, 'f2ac4c848c55361081f85222b9f16b844d38b0ac8def2d461bdfe8275803a3e1', NULL, '2026-08-24T03:08:34.976Z', NULL, '2026-08-24T03:08:34.976Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('16', '16', {{package_blob:db/blobs/files/cms_content_assets_file_id=16.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=16.bin}}, 52633, 'shot-packages.jpg', 'image/jpeg', 1, 'c036dea819d282743c08c2bf5b1a7bede9e4b11e950227559cbab88155a7319a', NULL, '2026-08-24T03:08:34.993Z', NULL, '2026-08-24T03:08:34.993Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('17', '17', {{package_blob:db/blobs/files/cms_content_assets_file_id=17.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=17.bin}}, 101944, 'shot-dashboard.jpg', 'image/jpeg', 0, 'f2ac4c848c55361081f85222b9f16b844d38b0ac8def2d461bdfe8275803a3e1', NULL, '2026-08-24T03:08:35.060Z', NULL, '2026-08-24T03:08:35.060Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('18', '17', {{package_blob:db/blobs/files/cms_content_assets_file_id=18.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=18.bin}}, 86422, 'shot-guide-studio-map.jpg', 'image/jpeg', 1, '3430056cd12da4e1a094a48484c4ab5413273292ff80e9dbf2a950b2617516f8', NULL, '2026-08-24T03:08:35.076Z', NULL, '2026-08-24T03:08:35.076Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('19', '18', {{package_blob:db/blobs/files/cms_content_assets_file_id=19.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=19.bin}}, 83218, 'shot-users.jpg', 'image/jpeg', 0, '519c7c11ae69259dfd6afd766435b22a329750275e5bd64bd65296b2ddacef56', NULL, '2026-08-24T03:08:35.143Z', NULL, '2026-08-24T03:08:35.143Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('20', '18', {{package_blob:db/blobs/files/cms_content_assets_file_id=20.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=20.bin}}, 64327, 'shot-roles.jpg', 'image/jpeg', 1, 'f8d1b45df945e1e5ff2c20e1b393a0dbb75fc9c2054b104973ee089309afeacc', NULL, '2026-08-24T03:08:35.166Z', NULL, '2026-08-24T03:08:35.166Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('21', '18', {{package_blob:db/blobs/files/cms_content_assets_file_id=21.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=21.bin}}, 57916, 'shot-login.jpg', 'image/jpeg', 2, 'bf5a353034daef703c4dc95ff1a9b6f7618e8fa8057df6258a8d5f8452de64e7', NULL, '2026-08-24T03:08:35.186Z', NULL, '2026-08-24T03:08:35.186Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('22', '19', {{package_blob:db/blobs/files/cms_content_assets_file_id=22.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=22.bin}}, 21840, 'shot-data-studio.jpg', 'image/jpeg', 0, '96a26d2695cbdc8b6ef9b0ffbdb2742cfaf996d95900fb029e97a50aa5e3d8b6', NULL, '2026-08-24T03:08:35.250Z', NULL, '2026-08-24T03:08:35.250Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('23', '19', {{package_blob:db/blobs/files/cms_content_assets_file_id=23.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=23.bin}}, 52070, 'shot-data-sources.jpg', 'image/jpeg', 1, 'bb7bb988236ff1d51078e8b3e635a7900760a10cf990b20ce5b31a3ac7b78c42', NULL, '2026-08-24T03:08:35.266Z', NULL, '2026-08-24T03:08:35.266Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('24', '20', {{package_blob:db/blobs/files/cms_content_assets_file_id=24.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=24.bin}}, 52070, 'shot-data-sources.jpg', 'image/jpeg', 0, 'bb7bb988236ff1d51078e8b3e635a7900760a10cf990b20ce5b31a3ac7b78c42', NULL, '2026-08-24T03:08:35.343Z', NULL, '2026-08-24T03:08:35.343Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('25', '20', {{package_blob:db/blobs/files/cms_content_assets_file_id=25.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=25.bin}}, 63061, 'shot-cache.jpg', 'image/jpeg', 1, '39c50ca963abfdaeb7df3b5028315de16f22d75880caff45e3778edb8ff49e20', NULL, '2026-08-24T03:08:35.363Z', NULL, '2026-08-24T03:08:35.363Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('26', '21', {{package_blob:db/blobs/files/cms_content_assets_file_id=26.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=26.bin}}, 53011, 'shot-workflows.jpg', 'image/jpeg', 0, '1f4fd737212c4683b1eda14bf07bdcd4820bfaab953159d876465c7bdc948416', NULL, '2026-08-24T03:08:35.450Z', NULL, '2026-08-24T03:08:35.450Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('27', '21', {{package_blob:db/blobs/files/cms_content_assets_file_id=27.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=27.bin}}, 104302, 'shot-jobs.jpg', 'image/jpeg', 1, '52e26ec59793214288d95067b53c47cbca53296e6dbfbc70d98303be1d865c54', NULL, '2026-08-24T03:08:35.476Z', NULL, '2026-08-24T03:08:35.476Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('28', '21', {{package_blob:db/blobs/files/cms_content_assets_file_id=28.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=28.bin}}, 52844, 'shot-scheduled-tasks.jpg', 'image/jpeg', 2, 'ec8907f20397f1ce808f42169703ad56163de0213fc13d117299b95ae3beff08', NULL, '2026-08-24T03:08:35.500Z', NULL, '2026-08-24T03:08:35.500Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('29', '22', {{package_blob:db/blobs/files/cms_content_assets_file_id=29.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=29.bin}}, 54481, 'shot-server-functions.jpg', 'image/jpeg', 0, '3d78df90b8bf1afd3d6ab3971089cb72c71cbe026abb7286a378f6fa2f85c4a5', NULL, '2026-08-24T03:08:35.566Z', NULL, '2026-08-24T03:08:35.566Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('30', '22', {{package_blob:db/blobs/files/cms_content_assets_file_id=30.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=30.bin}}, 112278, 'shot-dev-reference.jpg', 'image/jpeg', 1, '06774f91444e96f778f30b50a2a1b4cda4167b2832c4b0bbc05cd89b178b3d76', NULL, '2026-08-24T03:08:35.586Z', NULL, '2026-08-24T03:08:35.586Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('31', '22', {{package_blob:db/blobs/files/cms_content_assets_file_id=31.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=31.bin}}, 52844, 'shot-scheduled-tasks.jpg', 'image/jpeg', 2, 'ec8907f20397f1ce808f42169703ad56163de0213fc13d117299b95ae3beff08', NULL, '2026-08-24T03:08:35.610Z', NULL, '2026-08-24T03:08:35.610Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('32', '23', {{package_blob:db/blobs/files/cms_content_assets_file_id=32.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=32.bin}}, 112278, 'shot-dev-reference.jpg', 'image/jpeg', 0, '06774f91444e96f778f30b50a2a1b4cda4167b2832c4b0bbc05cd89b178b3d76', NULL, '2026-08-24T03:08:35.673Z', NULL, '2026-08-24T03:08:35.673Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('33', '23', {{package_blob:db/blobs/files/cms_content_assets_file_id=33.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=33.bin}}, 54481, 'shot-server-functions.jpg', 'image/jpeg', 1, '3d78df90b8bf1afd3d6ab3971089cb72c71cbe026abb7286a378f6fa2f85c4a5', NULL, '2026-08-24T03:08:35.690Z', NULL, '2026-08-24T03:08:35.690Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('34', '24', {{package_blob:db/blobs/files/cms_content_assets_file_id=34.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=34.bin}}, 21869, 'shot-base-components.jpg', 'image/jpeg', 0, '5386eda4b803452d53d45690bf48a7685dc3432c62c2fb142e0dcf58f314fdbf', NULL, '2026-08-24T03:08:35.753Z', NULL, '2026-08-24T03:08:35.753Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('35', '24', {{package_blob:db/blobs/files/cms_content_assets_file_id=35.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=35.bin}}, 21912, 'shot-client-components.jpg', 'image/jpeg', 1, '260a391162ad07f9d11d06ea8d15e363a257e4edf68ffebe9e6f8676f90f1387', NULL, '2026-08-24T03:08:35.776Z', NULL, '2026-08-24T03:08:35.776Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('36', '24', {{package_blob:db/blobs/files/cms_content_assets_file_id=36.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=36.bin}}, 98774, 'shot-theme.jpg', 'image/jpeg', 2, '19f9ed44e67fcc177e6d2229c4f05b826aff89ba5aac24b68a9040105dbdeac1', NULL, '2026-08-24T03:08:35.796Z', NULL, '2026-08-24T03:08:35.796Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('37', '25', {{package_blob:db/blobs/files/cms_content_assets_file_id=37.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=37.bin}}, 98774, 'shot-theme.jpg', 'image/jpeg', 0, '19f9ed44e67fcc177e6d2229c4f05b826aff89ba5aac24b68a9040105dbdeac1', NULL, '2026-08-24T03:08:35.860Z', NULL, '2026-08-24T03:08:35.860Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('38', '25', {{package_blob:db/blobs/files/cms_content_assets_file_id=38.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=38.bin}}, 21869, 'shot-base-components.jpg', 'image/jpeg', 1, '5386eda4b803452d53d45690bf48a7685dc3432c62c2fb142e0dcf58f314fdbf', NULL, '2026-08-24T03:08:35.876Z', NULL, '2026-08-24T03:08:35.876Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('39', '26', {{package_blob:db/blobs/files/cms_content_assets_file_id=39.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=39.bin}}, 59110, 'shot-portals.jpg', 'image/jpeg', 0, '897328a202d229b81c29a48d2d1e15e18007ca029c5af845981df1cb28c9cc4a', NULL, '2026-08-24T03:08:35.943Z', NULL, '2026-08-24T03:08:35.943Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('40', '26', {{package_blob:db/blobs/files/cms_content_assets_file_id=40.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=40.bin}}, 123023, 'shot-public-home.jpg', 'image/jpeg', 1, '4fbdb3f4c62d135e2d51e064c94c602f7273bf0f4f72e20f844f25cc196bbd7c', NULL, '2026-08-24T03:08:35.963Z', NULL, '2026-08-24T03:08:35.963Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('41', '26', {{package_blob:db/blobs/files/cms_content_assets_file_id=41.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=41.bin}}, 101944, 'shot-dashboard.jpg', 'image/jpeg', 2, 'f2ac4c848c55361081f85222b9f16b844d38b0ac8def2d461bdfe8275803a3e1', NULL, '2026-08-24T03:08:35.980Z', NULL, '2026-08-24T03:08:35.980Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('42', '27', {{package_blob:db/blobs/files/cms_content_assets_file_id=42.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=42.bin}}, 52633, 'shot-packages.jpg', 'image/jpeg', 0, 'c036dea819d282743c08c2bf5b1a7bede9e4b11e950227559cbab88155a7319a', NULL, '2026-08-24T03:08:36.036Z', NULL, '2026-08-24T03:08:36.036Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('43', '27', {{package_blob:db/blobs/files/cms_content_assets_file_id=43.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=43.bin}}, 49593, 'shot-cms-contents.jpg', 'image/jpeg', 1, '355f3c218537316e278d6c8e99634bfb2a4ef552012a9a43825f1ff02d3a56b3', NULL, '2026-08-24T03:08:36.053Z', NULL, '2026-08-24T03:08:36.053Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('44', '28', {{package_blob:db/blobs/files/cms_content_assets_file_id=44.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=44.bin}}, 47547, 'shot-file-manager.jpg', 'image/jpeg', 0, '9f9318772d648cd073879223f6b091dc715c0b130f4362a2de45103e97899eca', NULL, '2026-08-24T03:08:36.103Z', NULL, '2026-08-24T03:08:36.103Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('45', '28', {{package_blob:db/blobs/files/cms_content_assets_file_id=45.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=45.bin}}, 21936, 'shot-ssh.jpg', 'image/jpeg', 1, '5849cccac91fb3474e997d224407ee5b6f9a3a99d275a718b9ec46e2565501fc', NULL, '2026-08-24T03:08:36.123Z', NULL, '2026-08-24T03:08:36.123Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('46', '28', {{package_blob:db/blobs/files/cms_content_assets_file_id=46.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=46.bin}}, 104302, 'shot-jobs.jpg', 'image/jpeg', 2, '52e26ec59793214288d95067b53c47cbca53296e6dbfbc70d98303be1d865c54', NULL, '2026-08-24T03:08:36.143Z', NULL, '2026-08-24T03:08:36.143Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('47', '28', {{package_blob:db/blobs/files/cms_content_assets_file_id=47.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=47.bin}}, 63061, 'shot-cache.jpg', 'image/jpeg', 3, '39c50ca963abfdaeb7df3b5028315de16f22d75880caff45e3778edb8ff49e20', NULL, '2026-08-24T03:08:36.156Z', NULL, '2026-08-24T03:08:36.156Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('48', '28', {{package_blob:db/blobs/files/cms_content_assets_file_id=48.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=48.bin}}, 41841, 'shot-git.jpg', 'image/jpeg', 4, '48fdff45183e51dc933f18fe1bd00971074a97659d7769e6b82c5e6958697c29', NULL, '2026-08-24T03:08:36.173Z', NULL, '2026-08-24T03:08:36.173Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('49', '28', {{package_blob:db/blobs/files/cms_content_assets_file_id=49.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=49.bin}}, 123228, 'shot-platform-transfer.jpg', 'image/jpeg', 5, '1579d306748da27609ca569ed7c3904d189718dd9928ca5b0092b4c150e67419', NULL, '2026-08-24T03:08:36.193Z', NULL, '2026-08-24T03:08:36.193Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('50', '28', {{package_blob:db/blobs/files/cms_content_assets_file_id=50.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=50.bin}}, 105980, 'shot-logs.jpg', 'image/jpeg', 6, '2c7e1d3cda6f74faa76b5dfb2217ceba05814ac438ea80d4cfd204ccb7a9b7d4', NULL, '2026-08-24T03:08:36.216Z', NULL, '2026-08-24T03:08:36.216Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('51', '29', {{package_blob:db/blobs/files/cms_content_assets_file_id=51.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=51.bin}}, 61049, 'shot-chat-history.jpg', 'image/jpeg', 0, 'b438614244ab5b2eb22a97382c72e3e9334a9f9488bcc097763c25f2be87632d', NULL, '2026-08-24T03:08:36.273Z', NULL, '2026-08-24T03:08:36.273Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('52', '29', {{package_blob:db/blobs/files/cms_content_assets_file_id=52.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=52.bin}}, 77066, 'shot-settings.jpg', 'image/jpeg', 1, '338f5e0cd5144ceeda199335024813e4f62f732861962536587051ea480a1835', NULL, '2026-08-24T03:08:36.286Z', NULL, '2026-08-24T03:08:36.286Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('53', '29', {{package_blob:db/blobs/files/cms_content_assets_file_id=53.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=53.bin}}, 101944, 'shot-dashboard.jpg', 'image/jpeg', 2, 'f2ac4c848c55361081f85222b9f16b844d38b0ac8def2d461bdfe8275803a3e1', NULL, '2026-08-24T03:08:36.306Z', NULL, '2026-08-24T03:08:36.306Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('54', '30', {{package_blob:db/blobs/files/cms_content_assets_file_id=54.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=54.bin}}, 77066, 'shot-settings.jpg', 'image/jpeg', 0, '338f5e0cd5144ceeda199335024813e4f62f732861962536587051ea480a1835', NULL, '2026-08-24T03:08:36.356Z', NULL, '2026-08-24T03:08:36.356Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('55', '30', {{package_blob:db/blobs/files/cms_content_assets_file_id=55.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=55.bin}}, 57916, 'shot-login.jpg', 'image/jpeg', 1, 'bf5a353034daef703c4dc95ff1a9b6f7618e8fa8057df6258a8d5f8452de64e7', NULL, '2026-08-24T03:08:36.376Z', NULL, '2026-08-24T03:08:36.376Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('56', '30', {{package_blob:db/blobs/files/cms_content_assets_file_id=56.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=56.bin}}, 123228, 'shot-platform-transfer.jpg', 'image/jpeg', 2, '1579d306748da27609ca569ed7c3904d189718dd9928ca5b0092b4c150e67419', NULL, '2026-08-24T03:08:36.393Z', NULL, '2026-08-24T03:08:36.393Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('57', '31', {{package_blob:db/blobs/files/cms_content_assets_file_id=57.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=57.bin}}, 91970, 'shot-org-chart.jpg', 'image/jpeg', 0, 'bc414005a4465c4cda765bc0c901e0ce1ee53994f384ebc3c6590603c5d1c3bc', NULL, '2026-08-24T03:08:36.450Z', NULL, '2026-08-24T03:08:36.450Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('58', '31', {{package_blob:db/blobs/files/cms_content_assets_file_id=58.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=58.bin}}, 89362, 'shot-geo.jpg', 'image/jpeg', 1, 'cdce42a604f83c706336c899c383941cdab2f43f7e4ebc41ece7966eafc93752', NULL, '2026-08-24T03:08:36.470Z', NULL, '2026-08-24T03:08:36.470Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('59', '31', {{package_blob:db/blobs/files/cms_content_assets_file_id=59.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=59.bin}}, 52195, 'shot-base-info.jpg', 'image/jpeg', 2, '0e22d58b7ce18b0e9344de7a6aed317393488ecd51291062b3cd40605144f4dd', NULL, '2026-08-24T03:08:36.490Z', NULL, '2026-08-24T03:08:36.490Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('60', '32', {{package_blob:db/blobs/files/cms_content_assets_file_id=60.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=60.bin}}, 57916, 'shot-login.jpg', 'image/jpeg', 0, 'bf5a353034daef703c4dc95ff1a9b6f7618e8fa8057df6258a8d5f8452de64e7', NULL, '2026-08-24T03:08:36.550Z', NULL, '2026-08-24T03:08:36.550Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('61', '32', {{package_blob:db/blobs/files/cms_content_assets_file_id=61.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=61.bin}}, 101944, 'shot-dashboard.jpg', 'image/jpeg', 1, 'f2ac4c848c55361081f85222b9f16b844d38b0ac8def2d461bdfe8275803a3e1', NULL, '2026-08-24T03:08:36.570Z', NULL, '2026-08-24T03:08:36.570Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('62', '32', {{package_blob:db/blobs/files/cms_content_assets_file_id=62.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=62.bin}}, 123023, 'shot-public-home.jpg', 'image/jpeg', 2, '4fbdb3f4c62d135e2d51e064c94c602f7273bf0f4f72e20f844f25cc196bbd7c', NULL, '2026-08-24T03:08:36.590Z', NULL, '2026-08-24T03:08:36.590Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('63', '33', {{package_blob:db/blobs/files/cms_content_assets_file_id=63.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=63.bin}}, 57916, 'shot-login.jpg', 'image/jpeg', 0, 'bf5a353034daef703c4dc95ff1a9b6f7618e8fa8057df6258a8d5f8452de64e7', NULL, '2026-08-24T03:08:36.646Z', NULL, '2026-08-24T03:08:36.646Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('64', '34', {{package_blob:db/blobs/files/cms_content_assets_file_id=64.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=64.bin}}, 83218, 'shot-users.jpg', 'image/jpeg', 0, '519c7c11ae69259dfd6afd766435b22a329750275e5bd64bd65296b2ddacef56', NULL, '2026-08-24T03:08:36.710Z', NULL, '2026-08-24T03:08:36.710Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('65', '35', {{package_blob:db/blobs/files/cms_content_assets_file_id=65.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=65.bin}}, 64327, 'shot-roles.jpg', 'image/jpeg', 0, 'f8d1b45df945e1e5ff2c20e1b393a0dbb75fc9c2054b104973ee089309afeacc', NULL, '2026-08-24T03:08:36.766Z', NULL, '2026-08-24T03:08:36.766Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('66', '35', {{package_blob:db/blobs/files/cms_content_assets_file_id=66.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=66.bin}}, 83218, 'shot-users.jpg', 'image/jpeg', 1, '519c7c11ae69259dfd6afd766435b22a329750275e5bd64bd65296b2ddacef56', NULL, '2026-08-24T03:08:36.783Z', NULL, '2026-08-24T03:08:36.783Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('67', '36', {{package_blob:db/blobs/files/cms_content_assets_file_id=67.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=67.bin}}, 21840, 'shot-data-studio.jpg', 'image/jpeg', 0, '96a26d2695cbdc8b6ef9b0ffbdb2742cfaf996d95900fb029e97a50aa5e3d8b6', NULL, '2026-08-24T03:08:36.833Z', NULL, '2026-08-24T03:08:36.833Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('68', '37', {{package_blob:db/blobs/files/cms_content_assets_file_id=68.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=68.bin}}, 54481, 'shot-server-functions.jpg', 'image/jpeg', 0, '3d78df90b8bf1afd3d6ab3971089cb72c71cbe026abb7286a378f6fa2f85c4a5', NULL, '2026-08-24T03:08:36.883Z', NULL, '2026-08-24T03:08:36.883Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('69', '37', {{package_blob:db/blobs/files/cms_content_assets_file_id=69.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=69.bin}}, 112278, 'shot-dev-reference.jpg', 'image/jpeg', 1, '06774f91444e96f778f30b50a2a1b4cda4167b2832c4b0bbc05cd89b178b3d76', NULL, '2026-08-24T03:08:36.900Z', NULL, '2026-08-24T03:08:36.900Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('70', '38', {{package_blob:db/blobs/files/cms_content_assets_file_id=70.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=70.bin}}, 53011, 'shot-workflows.jpg', 'image/jpeg', 0, '1f4fd737212c4683b1eda14bf07bdcd4820bfaab953159d876465c7bdc948416', NULL, '2026-08-24T03:08:36.946Z', NULL, '2026-08-24T03:08:36.946Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('71', '39', {{package_blob:db/blobs/files/cms_content_assets_file_id=71.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=71.bin}}, 52633, 'shot-packages.jpg', 'image/jpeg', 0, 'c036dea819d282743c08c2bf5b1a7bede9e4b11e950227559cbab88155a7319a', NULL, '2026-08-24T03:08:36.996Z', NULL, '2026-08-24T03:08:36.996Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('72', '40', {{package_blob:db/blobs/files/cms_content_assets_file_id=72.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=72.bin}}, 49593, 'shot-cms-contents.jpg', 'image/jpeg', 0, '355f3c218537316e278d6c8e99634bfb2a4ef552012a9a43825f1ff02d3a56b3', NULL, '2026-08-24T03:08:37.056Z', NULL, '2026-08-24T03:08:37.056Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('73', '40', {{package_blob:db/blobs/files/cms_content_assets_file_id=73.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=73.bin}}, 123023, 'shot-public-home.jpg', 'image/jpeg', 1, '4fbdb3f4c62d135e2d51e064c94c602f7273bf0f4f72e20f844f25cc196bbd7c', NULL, '2026-08-24T03:08:37.073Z', NULL, '2026-08-24T03:08:37.073Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('74', '41', {{package_blob:db/blobs/files/cms_content_assets_file_id=74.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=74.bin}}, 98774, 'shot-theme.jpg', 'image/jpeg', 0, '19f9ed44e67fcc177e6d2229c4f05b826aff89ba5aac24b68a9040105dbdeac1', NULL, '2026-08-24T03:08:37.120Z', NULL, '2026-08-24T03:08:37.120Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('75', '42', {{package_blob:db/blobs/files/cms_content_assets_file_id=75.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=75.bin}}, 52070, 'shot-data-sources.jpg', 'image/jpeg', 0, 'bb7bb988236ff1d51078e8b3e635a7900760a10cf990b20ce5b31a3ac7b78c42', NULL, '2026-08-24T03:08:37.176Z', NULL, '2026-08-24T03:08:37.176Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('76', '43', {{package_blob:db/blobs/files/cms_content_assets_file_id=76.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=76.bin}}, 63061, 'shot-cache.jpg', 'image/jpeg', 0, '39c50ca963abfdaeb7df3b5028315de16f22d75880caff45e3778edb8ff49e20', NULL, '2026-08-24T03:08:37.223Z', NULL, '2026-08-24T03:08:37.223Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('77', '44', {{package_blob:db/blobs/files/cms_content_assets_file_id=77.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=77.bin}}, 123023, 'shot-public-home.jpg', 'image/jpeg', 0, '4fbdb3f4c62d135e2d51e064c94c602f7273bf0f4f72e20f844f25cc196bbd7c', NULL, '2026-08-24T03:08:37.276Z', NULL, '2026-08-24T03:08:37.276Z');
INSERT INTO [cms_content_assets] ([id], [content_id], [file], [file_xs], [file_size], [file_name], [file_mime], [sort_order], [sha256], [created_by], [created_at], [updated_by], [updated_at]) VALUES ('78', '44', {{package_blob:db/blobs/files/cms_content_assets_file_id=78.bin}}, {{package_blob:db/blobs/files/cms_content_assets_file_xs_id=78.bin}}, 59110, 'shot-portals.jpg', 'image/jpeg', 1, '897328a202d229b81c29a48d2d1e15e18007ca029c5af845981df1cb28c9cc4a', NULL, '2026-08-24T03:08:37.296Z', NULL, '2026-08-24T03:08:37.296Z');
-- Captured 73 row(s) from cms_content_relations on 2026-08-24T12:57:05.479Z
-- WHERE ([content_id_a] IN ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49')) OR ([content_id_b] IN ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49')) OR ([content_id_a] IN ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49')) OR ([content_id_b] IN ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49'))
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('1', '12', '16', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('2', '12', '17', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('3', '12', '32', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('4', '13', '18', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('5', '13', '30', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('6', '13', '17', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('7', '13', '15', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('8', '13', '14', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('9', '14', '27', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('10', '15', '17', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('11', '15', '16', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('12', '15', '32', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('13', '16', '17', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('14', '16', '27', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('15', '16', '26', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('16', '17', '18', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('17', '17', '28', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('18', '18', '31', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('19', '18', '30', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('20', '19', '20', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('21', '19', '31', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('22', '19', '22', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('23', '20', '28', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('24', '20', '30', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('25', '21', '22', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('26', '21', '28', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('27', '17', '21', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('28', '22', '23', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('29', '17', '23', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('30', '24', '25', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('31', '24', '26', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('32', '24', '27', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('33', '25', '30', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('34', '26', '27', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('35', '22', '28', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('36', '28', '30', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('37', '28', '29', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('38', '22', '29', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('39', '24', '29', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('40', '17', '31', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('41', '13', '32', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('42', '17', '32', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('43', '16', '32', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('44', '13', '33', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('45', '33', '44', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('46', '18', '33', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('47', '18', '34', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('48', '34', '35', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('49', '33', '34', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('50', '18', '35', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('51', '31', '35', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('52', '19', '36', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('53', '36', '42', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('54', '36', '37', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('55', '22', '37', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('56', '23', '37', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('57', '21', '38', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('58', '37', '38', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('59', '28', '38', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('60', '27', '39', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('61', '39', '40', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('62', '16', '39', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('63', '27', '40', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('64', '26', '40', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('65', '40', '44', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('66', '25', '41', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('67', '24', '41', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('68', '20', '42', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('69', '28', '42', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('70', '28', '43', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('71', '30', '43', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('72', '26', '44', 'Related on the public site.');
INSERT INTO [cms_content_relations] ([id], [content_id_a], [content_id_b], [note]) VALUES ('73', '15', '44', 'Related on the public site.');
-- Captured 1 row(s) from cms_content_revisions on 2026-08-24T12:57:05.489Z
-- WHERE ([content_id] IN ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49')) OR ([content_id] IN ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49'))
INSERT INTO [cms_content_revisions] ([id], [content_id], [revision_no], [title], [summary], [body], [created_by], [created_at]) VALUES ('1', '16', 1, 'Platform overview (draft title)', 'Early outline before the Studio screenshot pass.', 'AppEndO is a self-hosted platform. Expand with nav groups after screenshots land.', NULL, '2026-08-24T03:08:34.956Z');
-- Captured 85 row(s) from cms_content_tags on 2026-08-24T12:57:05.499Z
-- WHERE ([content_id] IN ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49')) OR ([content_id] IN ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49'))
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('11', '101.005.001');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('11', '101.005.002');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('12', '101.005.001');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('12', '101.005.002');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('12', '101.005.003');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('13', '101.005.003');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('13', '101.005.012');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('13', '101.005.013');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('14', '101.005.002');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('15', '101.005.001');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('15', '101.005.002');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('15', '101.005.003');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('16', '101.005.001');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('16', '101.005.002');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('17', '101.005.001');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('17', '101.005.002');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('17', '101.005.003');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('18', '101.005.003');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('18', '101.005.004');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('18', '101.005.012');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('19', '101.005.001');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('19', '101.005.003');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('19', '101.005.005');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('20', '101.005.005');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('20', '101.005.010');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('21', '101.005.001');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('21', '101.005.003');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('21', '101.005.006');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('22', '101.005.003');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('22', '101.005.007');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('23', '101.005.003');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('23', '101.005.007');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('24', '101.005.003');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('24', '101.005.008');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('25', '101.005.003');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('25', '101.005.008');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('26', '101.005.001');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('26', '101.005.002');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('26', '101.005.014');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('27', '101.005.001');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('27', '101.005.003');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('27', '101.005.009');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('28', '101.005.003');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('28', '101.005.010');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('29', '101.005.003');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('29', '101.005.011');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('30', '101.005.010');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('30', '101.005.012');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('30', '101.005.013');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('31', '101.005.004');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('31', '101.005.005');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('31', '101.005.012');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('32', '101.005.001');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('32', '101.005.003');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('32', '101.005.013');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('33', '101.005.012');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('33', '101.005.013');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('33', '101.005.015');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('34', '101.005.004');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('34', '101.005.015');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('35', '101.005.004');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('35', '101.005.012');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('35', '101.005.015');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('36', '101.005.005');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('36', '101.005.015');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('37', '101.005.007');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('37', '101.005.015');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('38', '101.005.006');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('38', '101.005.015');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('39', '101.005.009');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('39', '101.005.015');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('40', '101.005.009');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('40', '101.005.014');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('40', '101.005.015');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('41', '101.005.008');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('41', '101.005.015');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('42', '101.005.005');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('42', '101.005.010');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('42', '101.005.015');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('43', '101.005.010');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('43', '101.005.015');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('44', '101.005.003');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('44', '101.005.014');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('44', '101.005.015');
INSERT INTO [cms_content_tags] ([content_id], [tag_code]) VALUES ('49', '101.005.002');
-- Captured 1 row(s) from cms_settings on 2026-08-24T12:57:05.504Z
INSERT INTO [cms_settings] ([id], [comments_enabled], [comments_policy_code], [comments_body_format_code], [public_cache_ttl_seconds], [updated_by], [updated_at]) VALUES ('1', TRUE, '101.006.001', '101.003.003', 300, NULL, '2026-08-24T03:07:08.236Z');
