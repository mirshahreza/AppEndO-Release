import{g as gt}from"./chunk-5VM5RSS4-DB7s5IRo.js";import{d as mt,g as lt,f as xt,e as kt}from"./chunk-32BRIVSS-BxCl0mkh.js";import{V as _t,aP as vt,W as bt,aQ as wt,$ as Tt,aS as St,a as s,Y as R,B as $t,s as Mt}from"./mermaid.core-CUwlsqYF.js";import"./dayjs.min-C5-DKurV.js";import{s as X}from"./transform-C3k1rBga.js";import{d as it}from"./arc-aB2WyMwf.js";import"./index-X8VNd1Qb.js";import"./react-vendor-CsZD9bLw.js";import"./tanstack-query-BjZ08O4H.js";import"./AiFieldAssistSectionContext-Dc3GTQMY.js";import"./useHwyPublicCultureId-CzNTV3a_.js";import"./terminal-Cw-U0C22.js";import"./motion-CZjBJ88L.js";import"./HeroFieldControls-C11371Oz.js";import"./loader-circle-BOi6z1rb.js";import"./lucide-react-Bhi41pQe.js";import"./lock-3ohAIp8f.js";import"./flask-conical-CeC0ipDJ.js";import"./id-card-CUXrXPjF.js";import"./mail-DYrZWqUj.js";import"./FormChoiceFields-DXE7pFNe.js";import"./index-CX2UUQsi.js";import"./HwyPublicPortalLayout-CmutilE3.js";import"./useHwyPublicPortalDocumentTitle-RN3hsb1n.js";import"./hwySelfRegistrationNumericInput-DEuxNN2L.js";import"./UsersIcon-DCeYIj7S.js";import"./tanstack-virtual-BF62Is0T.js";import"./iconify-DuHxJVmX.js";var U=(function(){var t=s(function(h,r,n,l){for(n=n||{},l=h.length;l--;n[h[l]]=r);return n},"o"),e=[6,8,10,11,12,14,16,17,18],a=[1,9],p=[1,10],i=[1,11],u=[1,12],f=[1,13],o=[1,14],g={trace:s(function(){},"trace"),yy:{},symbols_:{error:2,start:3,journey:4,document:5,EOF:6,line:7,SPACE:8,statement:9,NEWLINE:10,title:11,acc_title:12,acc_title_value:13,acc_descr:14,acc_descr_value:15,acc_descr_multiline_value:16,section:17,taskName:18,taskData:19,$accept:0,$end:1},terminals_:{2:"error",4:"journey",6:"EOF",8:"SPACE",10:"NEWLINE",11:"title",12:"acc_title",13:"acc_title_value",14:"acc_descr",15:"acc_descr_value",16:"acc_descr_multiline_value",17:"section",18:"taskName",19:"taskData"},productions_:[0,[3,3],[5,0],[5,2],[7,2],[7,1],[7,1],[7,1],[9,1],[9,2],[9,2],[9,1],[9,1],[9,2]],performAction:s(function(r,n,l,y,d,c,v){var k=c.length-1;switch(d){case 1:return c[k-1];case 2:this.$=[];break;case 3:c[k-1].push(c[k]),this.$=c[k-1];break;case 4:case 5:this.$=c[k];break;case 6:case 7:this.$=[];break;case 8:y.setDiagramTitle(c[k].substr(6)),this.$=c[k].substr(6);break;case 9:this.$=c[k].trim(),y.setAccTitle(this.$);break;case 10:case 11:this.$=c[k].trim(),y.setAccDescription(this.$);break;case 12:y.addSection(c[k].substr(8)),this.$=c[k].substr(8);break;case 13:y.addTask(c[k-1],c[k]),this.$="task";break}},"anonymous"),table:[{3:1,4:[1,2]},{1:[3]},t(e,[2,2],{5:3}),{6:[1,4],7:5,8:[1,6],9:7,10:[1,8],11:a,12:p,14:i,16:u,17:f,18:o},t(e,[2,7],{1:[2,1]}),t(e,[2,3]),{9:15,11:a,12:p,14:i,16:u,17:f,18:o},t(e,[2,5]),t(e,[2,6]),t(e,[2,8]),{13:[1,16]},{15:[1,17]},t(e,[2,11]),t(e,[2,12]),{19:[1,18]},t(e,[2,4]),t(e,[2,9]),t(e,[2,10]),t(e,[2,13])],defaultActions:{},parseError:s(function(r,n){if(n.recoverable)this.trace(r);else{var l=new Error(r);throw l.hash=n,l}},"parseError"),parse:s(function(r){var n=this,l=[0],y=[],d=[null],c=[],v=this.table,k="",C=0,K=0,yt=2,D=1,dt=c.slice.call(arguments,1),_=Object.create(this.lexer),I={yy:{}};for(var O in this.yy)Object.prototype.hasOwnProperty.call(this.yy,O)&&(I.yy[O]=this.yy[O]);_.setInput(r,I.yy),I.yy.lexer=_,I.yy.parser=this,typeof _.yylloc>"u"&&(_.yylloc={});var Y=_.yylloc;c.push(Y);var pt=_.options&&_.options.ranges;typeof I.yy.parseError=="function"?this.parseError=I.yy.parseError:this.parseError=Object.getPrototypeOf(this).parseError;function ft(w){l.length=l.length-2*w,d.length=d.length-w,c.length=c.length-w}s(ft,"popStack");function tt(){var w;return w=y.pop()||_.lex()||D,typeof w!="number"&&(w instanceof Array&&(y=w,w=y.pop()),w=n.symbols_[w]||w),w}s(tt,"lex");for(var b,A,T,q,F={},N,M,et,W;;){if(A=l[l.length-1],this.defaultActions[A]?T=this.defaultActions[A]:((b===null||typeof b>"u")&&(b=tt()),T=v[A]&&v[A][b]),typeof T>"u"||!T.length||!T[0]){var H="";W=[];for(N in v[A])this.terminals_[N]&&N>yt&&W.push("'"+this.terminals_[N]+"'");_.showPosition?H="Parse error on line "+(C+1)+`:
`+_.showPosition()+`
Expecting `+W.join(", ")+", got '"+(this.terminals_[b]||b)+"'":H="Parse error on line "+(C+1)+": Unexpected "+(b==D?"end of input":"'"+(this.terminals_[b]||b)+"'"),this.parseError(H,{text:_.match,token:this.terminals_[b]||b,line:_.yylineno,loc:Y,expected:W})}if(T[0]instanceof Array&&T.length>1)throw new Error("Parse Error: multiple actions possible at state: "+A+", token: "+b);switch(T[0]){case 1:l.push(b),d.push(_.yytext),c.push(_.yylloc),l.push(T[1]),b=null,K=_.yyleng,k=_.yytext,C=_.yylineno,Y=_.yylloc;break;case 2:if(M=this.productions_[T[1]][1],F.$=d[d.length-M],F._$={first_line:c[c.length-(M||1)].first_line,last_line:c[c.length-1].last_line,first_column:c[c.length-(M||1)].first_column,last_column:c[c.length-1].last_column},pt&&(F._$.range=[c[c.length-(M||1)].range[0],c[c.length-1].range[1]]),q=this.performAction.apply(F,[k,K,C,I.yy,T[1],d,c].concat(dt)),typeof q<"u")return q;M&&(l=l.slice(0,-1*M*2),d=d.slice(0,-1*M),c=c.slice(0,-1*M)),l.push(this.productions_[T[1]][0]),d.push(F.$),c.push(F._$),et=v[l[l.length-2]][l[l.length-1]],l.push(et);break;case 3:return!0}}return!0},"parse")},m=(function(){var h={EOF:1,parseError:s(function(n,l){if(this.yy.parser)this.yy.parser.parseError(n,l);else throw new Error(n)},"parseError"),setInput:s(function(r,n){return this.yy=n||this.yy||{},this._input=r,this._more=this._backtrack=this.done=!1,this.yylineno=this.yyleng=0,this.yytext=this.matched=this.match="",this.conditionStack=["INITIAL"],this.yylloc={first_line:1,first_column:0,last_line:1,last_column:0},this.options.ranges&&(this.yylloc.range=[0,0]),this.offset=0,this},"setInput"),input:s(function(){var r=this._input[0];this.yytext+=r,this.yyleng++,this.offset++,this.match+=r,this.matched+=r;var n=r.match(/(?:\r\n?|\n).*/g);return n?(this.yylineno++,this.yylloc.last_line++):this.yylloc.last_column++,this.options.ranges&&this.yylloc.range[1]++,this._input=this._input.slice(1),r},"input"),unput:s(function(r){var n=r.length,l=r.split(/(?:\r\n?|\n)/g);this._input=r+this._input,this.yytext=this.yytext.substr(0,this.yytext.length-n),this.offset-=n;var y=this.match.split(/(?:\r\n?|\n)/g);this.match=this.match.substr(0,this.match.length-1),this.matched=this.matched.substr(0,this.matched.length-1),l.length-1&&(this.yylineno-=l.length-1);var d=this.yylloc.range;return this.yylloc={first_line:this.yylloc.first_line,last_line:this.yylineno+1,first_column:this.yylloc.first_column,last_column:l?(l.length===y.length?this.yylloc.first_column:0)+y[y.length-l.length].length-l[0].length:this.yylloc.first_column-n},this.options.ranges&&(this.yylloc.range=[d[0],d[0]+this.yyleng-n]),this.yyleng=this.yytext.length,this},"unput"),more:s(function(){return this._more=!0,this},"more"),reject:s(function(){if(this.options.backtrack_lexer)this._backtrack=!0;else return this.parseError("Lexical error on line "+(this.yylineno+1)+`. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
`+this.showPosition(),{text:"",token:null,line:this.yylineno});return this},"reject"),less:s(function(r){this.unput(this.match.slice(r))},"less"),pastInput:s(function(){var r=this.matched.substr(0,this.matched.length-this.match.length);return(r.length>20?"...":"")+r.substr(-20).replace(/\n/g,"")},"pastInput"),upcomingInput:s(function(){var r=this.match;return r.length<20&&(r+=this._input.substr(0,20-r.length)),(r.substr(0,20)+(r.length>20?"...":"")).replace(/\n/g,"")},"upcomingInput"),showPosition:s(function(){var r=this.pastInput(),n=new Array(r.length+1).join("-");return r+this.upcomingInput()+`
`+n+"^"},"showPosition"),test_match:s(function(r,n){var l,y,d;if(this.options.backtrack_lexer&&(d={yylineno:this.yylineno,yylloc:{first_line:this.yylloc.first_line,last_line:this.last_line,first_column:this.yylloc.first_column,last_column:this.yylloc.last_column},yytext:this.yytext,match:this.match,matches:this.matches,matched:this.matched,yyleng:this.yyleng,offset:this.offset,_more:this._more,_input:this._input,yy:this.yy,conditionStack:this.conditionStack.slice(0),done:this.done},this.options.ranges&&(d.yylloc.range=this.yylloc.range.slice(0))),y=r[0].match(/(?:\r\n?|\n).*/g),y&&(this.yylineno+=y.length),this.yylloc={first_line:this.yylloc.last_line,last_line:this.yylineno+1,first_column:this.yylloc.last_column,last_column:y?y[y.length-1].length-y[y.length-1].match(/\r?\n?/)[0].length:this.yylloc.last_column+r[0].length},this.yytext+=r[0],this.match+=r[0],this.matches=r,this.yyleng=this.yytext.length,this.options.ranges&&(this.yylloc.range=[this.offset,this.offset+=this.yyleng]),this._more=!1,this._backtrack=!1,this._input=this._input.slice(r[0].length),this.matched+=r[0],l=this.performAction.call(this,this.yy,this,n,this.conditionStack[this.conditionStack.length-1]),this.done&&this._input&&(this.done=!1),l)return l;if(this._backtrack){for(var c in d)this[c]=d[c];return!1}return!1},"test_match"),next:s(function(){if(this.done)return this.EOF;this._input||(this.done=!0);var r,n,l,y;this._more||(this.yytext="",this.match="");for(var d=this._currentRules(),c=0;c<d.length;c++)if(l=this._input.match(this.rules[d[c]]),l&&(!n||l[0].length>n[0].length)){if(n=l,y=c,this.options.backtrack_lexer){if(r=this.test_match(l,d[c]),r!==!1)return r;if(this._backtrack){n=!1;continue}else return!1}else if(!this.options.flex)break}return n?(r=this.test_match(n,d[y]),r!==!1?r:!1):this._input===""?this.EOF:this.parseError("Lexical error on line "+(this.yylineno+1)+`. Unrecognized text.
`+this.showPosition(),{text:"",token:null,line:this.yylineno})},"next"),lex:s(function(){var n=this.next();return n||this.lex()},"lex"),begin:s(function(n){this.conditionStack.push(n)},"begin"),popState:s(function(){var n=this.conditionStack.length-1;return n>0?this.conditionStack.pop():this.conditionStack[0]},"popState"),_currentRules:s(function(){return this.conditionStack.length&&this.conditionStack[this.conditionStack.length-1]?this.conditions[this.conditionStack[this.conditionStack.length-1]].rules:this.conditions.INITIAL.rules},"_currentRules"),topState:s(function(n){return n=this.conditionStack.length-1-Math.abs(n||0),n>=0?this.conditionStack[n]:"INITIAL"},"topState"),pushState:s(function(n){this.begin(n)},"pushState"),stateStackSize:s(function(){return this.conditionStack.length},"stateStackSize"),options:{"case-insensitive":!0},performAction:s(function(n,l,y,d){switch(y){case 0:break;case 1:break;case 2:return 10;case 3:break;case 4:break;case 5:return 4;case 6:return 11;case 7:return this.begin("acc_title"),12;case 8:return this.popState(),"acc_title_value";case 9:return this.begin("acc_descr"),14;case 10:return this.popState(),"acc_descr_value";case 11:this.begin("acc_descr_multiline");break;case 12:this.popState();break;case 13:return"acc_descr_multiline_value";case 14:return 17;case 15:return 18;case 16:return 19;case 17:return":";case 18:return 6;case 19:return"INVALID"}},"anonymous"),rules:[/^(?:%(?!\{)[^\n]*)/i,/^(?:[^\}]%%[^\n]*)/i,/^(?:[\n]+)/i,/^(?:\s+)/i,/^(?:#[^\n]*)/i,/^(?:journey\b)/i,/^(?:title\s[^#\n;]+)/i,/^(?:accTitle\s*:\s*)/i,/^(?:(?!\n||)*[^\n]*)/i,/^(?:accDescr\s*:\s*)/i,/^(?:(?!\n||)*[^\n]*)/i,/^(?:accDescr\s*\{\s*)/i,/^(?:[\}])/i,/^(?:[^\}]*)/i,/^(?:section\s[^#:\n;]+)/i,/^(?:[^#:\n;]+)/i,/^(?::[^#\n;]+)/i,/^(?::)/i,/^(?:$)/i,/^(?:.)/i],conditions:{acc_descr_multiline:{rules:[12,13],inclusive:!1},acc_descr:{rules:[10],inclusive:!1},acc_title:{rules:[8],inclusive:!1},INITIAL:{rules:[0,1,2,3,4,5,6,7,9,11,14,15,16,17,18,19],inclusive:!0}}};return h})();g.lexer=m;function x(){this.yy={}}return s(x,"Parser"),x.prototype=g,g.Parser=x,new x})();U.parser=U;var Et=U,V="",Z=[],L=[],B=[],Ct=s(function(){Z.length=0,L.length=0,V="",B.length=0,Mt()},"clear"),Pt=s(function(t){V=t,Z.push(t)},"addSection"),It=s(function(){return Z},"getSections"),At=s(function(){let t=rt();const e=100;let a=0;for(;!t&&a<e;)t=rt(),a++;return L.push(...B),L},"getTasks"),Ft=s(function(){const t=[];return L.forEach(a=>{a.people&&t.push(...a.people)}),[...new Set(t)].sort()},"updateActors"),Vt=s(function(t,e){const a=e.substr(1).split(":");let p=0,i=[];a.length===1?(p=Number(a[0]),i=[]):(p=Number(a[0]),i=a[1].split(","));const u=i.map(o=>o.trim()),f={section:V,type:V,people:u,task:t,score:p};B.push(f)},"addTask"),Rt=s(function(t){const e={section:V,type:V,description:t,task:t,classes:[]};L.push(e)},"addTaskOrg"),rt=s(function(){const t=s(function(a){return B[a].processed},"compileTask");let e=!0;for(const[a,p]of B.entries())t(a),e=e&&p.processed;return e},"compileTasks"),Lt=s(function(){return Ft()},"getActors"),nt={getConfig:s(()=>R().journey,"getConfig"),clear:Ct,setDiagramTitle:St,getDiagramTitle:Tt,setAccTitle:wt,getAccTitle:bt,setAccDescription:vt,getAccDescription:_t,addSection:Pt,getSections:It,getTasks:At,addTask:Vt,addTaskOrg:Rt,getActors:Lt},Bt=s(t=>`.label {
    font-family: ${t.fontFamily};
    color: ${t.textColor};
  }
  .mouth {
    stroke: #666;
  }

  line {
    stroke: ${t.textColor}
  }

  .legend {
    fill: ${t.textColor};
    font-family: ${t.fontFamily};
  }

  .label text {
    fill: #333;
  }
  .label {
    color: ${t.textColor}
  }

  .face {
    ${t.faceColor?`fill: ${t.faceColor}`:"fill: #FFF8DC"};
    stroke: #999;
  }

  .node rect,
  .node circle,
  .node ellipse,
  .node polygon,
  .node path {
    fill: ${t.mainBkg};
    stroke: ${t.nodeBorder};
    stroke-width: 1px;
  }

  .node .label {
    text-align: center;
  }
  .node.clickable {
    cursor: pointer;
  }

  .arrowheadPath {
    fill: ${t.arrowheadColor};
  }

  .edgePath .path {
    stroke: ${t.lineColor};
    stroke-width: 1.5px;
  }

  .flowchart-link {
    stroke: ${t.lineColor};
    fill: none;
  }

  .edgeLabel {
    background-color: ${t.edgeLabelBackground};
    rect {
      opacity: 0.5;
    }
    text-align: center;
  }

  .cluster rect {
  }

  .cluster text {
    fill: ${t.titleColor};
  }

  div.mermaidTooltip {
    position: absolute;
    text-align: center;
    max-width: 200px;
    padding: 2px;
    font-family: ${t.fontFamily};
    font-size: 12px;
    background: ${t.tertiaryColor};
    border: 1px solid ${t.border2};
    border-radius: 2px;
    pointer-events: none;
    z-index: 100;
  }

  .task-type-0, .section-type-0  {
    ${t.fillType0?`fill: ${t.fillType0}`:""};
  }
  .task-type-1, .section-type-1  {
    ${t.fillType0?`fill: ${t.fillType1}`:""};
  }
  .task-type-2, .section-type-2  {
    ${t.fillType0?`fill: ${t.fillType2}`:""};
  }
  .task-type-3, .section-type-3  {
    ${t.fillType0?`fill: ${t.fillType3}`:""};
  }
  .task-type-4, .section-type-4  {
    ${t.fillType0?`fill: ${t.fillType4}`:""};
  }
  .task-type-5, .section-type-5  {
    ${t.fillType0?`fill: ${t.fillType5}`:""};
  }
  .task-type-6, .section-type-6  {
    ${t.fillType0?`fill: ${t.fillType6}`:""};
  }
  .task-type-7, .section-type-7  {
    ${t.fillType0?`fill: ${t.fillType7}`:""};
  }

  .actor-0 {
    ${t.actor0?`fill: ${t.actor0}`:""};
  }
  .actor-1 {
    ${t.actor1?`fill: ${t.actor1}`:""};
  }
  .actor-2 {
    ${t.actor2?`fill: ${t.actor2}`:""};
  }
  .actor-3 {
    ${t.actor3?`fill: ${t.actor3}`:""};
  }
  .actor-4 {
    ${t.actor4?`fill: ${t.actor4}`:""};
  }
  .actor-5 {
    ${t.actor5?`fill: ${t.actor5}`:""};
  }
  ${gt()}
`,"getStyles"),jt=Bt,J=s(function(t,e){return kt(t,e)},"drawRect"),Nt=s(function(t,e){const p=t.append("circle").attr("cx",e.cx).attr("cy",e.cy).attr("class","face").attr("r",15).attr("stroke-width",2).attr("overflow","visible"),i=t.append("g");i.append("circle").attr("cx",e.cx-15/3).attr("cy",e.cy-15/3).attr("r",1.5).attr("stroke-width",2).attr("fill","#666").attr("stroke","#666"),i.append("circle").attr("cx",e.cx+15/3).attr("cy",e.cy-15/3).attr("r",1.5).attr("stroke-width",2).attr("fill","#666").attr("stroke","#666");function u(g){const m=it().startAngle(Math.PI/2).endAngle(3*(Math.PI/2)).innerRadius(7.5).outerRadius(6.8181818181818175);g.append("path").attr("class","mouth").attr("d",m).attr("transform","translate("+e.cx+","+(e.cy+2)+")")}s(u,"smile");function f(g){const m=it().startAngle(3*Math.PI/2).endAngle(5*(Math.PI/2)).innerRadius(7.5).outerRadius(6.8181818181818175);g.append("path").attr("class","mouth").attr("d",m).attr("transform","translate("+e.cx+","+(e.cy+7)+")")}s(f,"sad");function o(g){g.append("line").attr("class","mouth").attr("stroke",2).attr("x1",e.cx-5).attr("y1",e.cy+7).attr("x2",e.cx+5).attr("y2",e.cy+7).attr("class","mouth").attr("stroke-width","1px").attr("stroke","#666")}return s(o,"ambivalent"),e.score>3?u(i):e.score<3?f(i):o(i),p},"drawFace"),ot=s(function(t,e){const a=t.append("circle");return a.attr("cx",e.cx),a.attr("cy",e.cy),a.attr("class","actor-"+e.pos),a.attr("fill",e.fill),a.attr("stroke",e.stroke),a.attr("r",e.r),a.class!==void 0&&a.attr("class",a.class),e.title!==void 0&&a.append("title").text(e.title),a},"drawCircle"),ct=s(function(t,e){return xt(t,e)},"drawText"),Wt=s(function(t,e){function a(i,u,f,o,g){return i+","+u+" "+(i+f)+","+u+" "+(i+f)+","+(u+o-g)+" "+(i+f-g*1.2)+","+(u+o)+" "+i+","+(u+o)}s(a,"genPoints");const p=t.append("polygon");p.attr("points",a(e.x,e.y,50,20,7)),p.attr("class","labelBox"),e.y=e.y+e.labelMargin,e.x=e.x+.5*e.labelMargin,ct(t,e)},"drawLabel"),zt=s(function(t,e,a){const p=t.append("g"),i=lt();i.x=e.x,i.y=e.y,i.fill=e.fill,i.width=a.width*e.taskCount+a.diagramMarginX*(e.taskCount-1),i.height=a.height,i.class="journey-section section-type-"+e.num,i.rx=3,i.ry=3,J(p,i),ht(a)(e.text,p,i.x,i.y,i.width,i.height,{class:"journey-section section-type-"+e.num},a,e.colour)},"drawSection"),Q=-1,Ot=s(function(t,e,a,p){const i=e.x+a.width/2,u=t.append("g");Q++,u.append("line").attr("id",p+"-task"+Q).attr("x1",i).attr("y1",e.y).attr("x2",i).attr("y2",450).attr("class","task-line").attr("stroke-width","1px").attr("stroke-dasharray","4 2").attr("stroke","#666"),Nt(u,{cx:i,cy:300+(5-e.score)*30,score:e.score});const o=lt();o.x=e.x,o.y=e.y,o.fill=e.fill,o.width=a.width,o.height=a.height,o.class="task task-type-"+e.num,o.rx=3,o.ry=3,J(u,o);let g=e.x+14;e.people.forEach(m=>{const x=e.actors[m].color,h={cx:g,cy:e.y,r:7,fill:x,stroke:"#000",title:m,pos:e.actors[m].position};ot(u,h),g+=10}),ht(a)(e.task,u,o.x,o.y,o.width,o.height,{class:"task"},a,e.colour)},"drawTask"),Yt=s(function(t,e){mt(t,e)},"drawBackgroundRect"),ht=(function(){function t(i,u,f,o,g,m,x,h){const r=u.append("text").attr("x",f+g/2).attr("y",o+m/2+5).style("font-color",h).style("text-anchor","middle").text(i);p(r,x)}s(t,"byText");function e(i,u,f,o,g,m,x,h,r){const{taskFontSize:n,taskFontFamily:l}=h,y=i.split(/<br\s*\/?>/gi);for(let d=0;d<y.length;d++){const c=d*n-n*(y.length-1)/2,v=u.append("text").attr("x",f+g/2).attr("y",o).attr("fill",r).style("text-anchor","middle").style("font-size",n).style("font-family",l);v.append("tspan").attr("x",f+g/2).attr("dy",c).text(y[d]),v.attr("y",o+m/2).attr("dominant-baseline","central").attr("alignment-baseline","central"),p(v,x)}}s(e,"byTspan");function a(i,u,f,o,g,m,x,h){const r=u.append("switch"),l=r.append("foreignObject").attr("x",f).attr("y",o).attr("width",g).attr("height",m).attr("position","fixed").append("xhtml:div").style("display","table").style("height","100%").style("width","100%");l.append("div").attr("class","label").style("display","table-cell").style("text-align","center").style("vertical-align","middle").text(i),e(i,r,f,o,g,m,x,h),p(l,x)}s(a,"byFo");function p(i,u){for(const f in u)f in u&&i.attr(f,u[f])}return s(p,"_setTextAttrs"),function(i){return i.textPlacement==="fo"?a:i.textPlacement==="old"?t:e}})(),qt=s(function(t,e){Q=-1,t.append("defs").append("marker").attr("id",e+"-arrowhead").attr("refX",5).attr("refY",2).attr("markerWidth",6).attr("markerHeight",4).attr("orient","auto").append("path").attr("d","M 0,0 V 4 L6,2 Z")},"initGraphics"),j={drawRect:J,drawCircle:ot,drawSection:zt,drawText:ct,drawLabel:Wt,drawTask:Ot,drawBackgroundRect:Yt,initGraphics:qt},Ht=s(function(t){Object.keys(t).forEach(function(a){$[a]=t[a]})},"setConf"),E={},z=0;function ut(t){const e=R().journey,a=e.maxLabelWidth;z=0;let p=60;Object.keys(E).forEach(i=>{const u=E[i].color,f={cx:20,cy:p,r:7,fill:u,stroke:"#000",pos:E[i].position};j.drawCircle(t,f);let o=t.append("text").attr("visibility","hidden").text(i);const g=o.node().getBoundingClientRect().width;o.remove();let m=[];if(g<=a)m=[i];else{const x=i.split(" ");let h="";o=t.append("text").attr("visibility","hidden"),x.forEach(r=>{const n=h?`${h} ${r}`:r;if(o.text(n),o.node().getBoundingClientRect().width>a){if(h&&m.push(h),h=r,o.text(r),o.node().getBoundingClientRect().width>a){let y="";for(const d of r)y+=d,o.text(y+"-"),o.node().getBoundingClientRect().width>a&&(m.push(y.slice(0,-1)+"-"),y=d);h=y}}else h=n}),h&&m.push(h),o.remove()}m.forEach((x,h)=>{const r={x:40,y:p+7+h*20,fill:"#666",text:x,textMargin:e.boxTextMargin??5},l=j.drawText(t,r).node().getBoundingClientRect().width;l>z&&l>e.leftMargin-l&&(z=l)}),p+=Math.max(20,m.length*20)})}s(ut,"drawActorLegend");var $=R().journey,P=0,Xt=s(function(t,e,a,p){const i=R(),u=i.journey.titleColor,f=i.journey.titleFontSize,o=i.journey.titleFontFamily,g=i.securityLevel;let m;g==="sandbox"&&(m=X("#i"+e));const x=g==="sandbox"?X(m.nodes()[0].contentDocument.body):X("body");S.init();const h=x.select("#"+e);j.initGraphics(h,e);const r=p.db.getTasks(),n=p.db.getDiagramTitle(),l=p.db.getActors();for(const C in E)delete E[C];let y=0;l.forEach(C=>{E[C]={color:$.actorColours[y%$.actorColours.length],position:y},y++}),ut(h),P=$.leftMargin+z,S.insert(0,0,P,Object.keys(E).length*50),Gt(h,r,0,e);const d=S.getBounds();n&&h.append("text").text(n).attr("x",P).attr("font-size",f).attr("font-weight","bold").attr("y",25).attr("fill",u).attr("font-family",o);const c=d.stopy-d.starty+2*$.diagramMarginY,v=P+d.stopx+2*$.diagramMarginX;$t(h,c,v,$.useMaxWidth),h.append("line").attr("x1",P).attr("y1",$.height*4).attr("x2",v-P-4).attr("y2",$.height*4).attr("stroke-width",4).attr("stroke","black").attr("marker-end","url(#"+e+"-arrowhead)");const k=n?70:0;h.attr("viewBox",`${d.startx} -25 ${v} ${c+k}`),h.attr("preserveAspectRatio","xMinYMin meet"),h.attr("height",c+k+25)},"draw"),S={data:{startx:void 0,stopx:void 0,starty:void 0,stopy:void 0},verticalPos:0,sequenceItems:[],init:s(function(){this.sequenceItems=[],this.data={startx:void 0,stopx:void 0,starty:void 0,stopy:void 0},this.verticalPos=0},"init"),updateVal:s(function(t,e,a,p){t[e]===void 0?t[e]=a:t[e]=p(a,t[e])},"updateVal"),updateBounds:s(function(t,e,a,p){const i=R().journey,u=this;let f=0;function o(g){return s(function(x){f++;const h=u.sequenceItems.length-f+1;u.updateVal(x,"starty",e-h*i.boxMargin,Math.min),u.updateVal(x,"stopy",p+h*i.boxMargin,Math.max),u.updateVal(S.data,"startx",t-h*i.boxMargin,Math.min),u.updateVal(S.data,"stopx",a+h*i.boxMargin,Math.max),g!=="activation"&&(u.updateVal(x,"startx",t-h*i.boxMargin,Math.min),u.updateVal(x,"stopx",a+h*i.boxMargin,Math.max),u.updateVal(S.data,"starty",e-h*i.boxMargin,Math.min),u.updateVal(S.data,"stopy",p+h*i.boxMargin,Math.max))},"updateItemBounds")}s(o,"updateFn"),this.sequenceItems.forEach(o())},"updateBounds"),insert:s(function(t,e,a,p){const i=Math.min(t,a),u=Math.max(t,a),f=Math.min(e,p),o=Math.max(e,p);this.updateVal(S.data,"startx",i,Math.min),this.updateVal(S.data,"starty",f,Math.min),this.updateVal(S.data,"stopx",u,Math.max),this.updateVal(S.data,"stopy",o,Math.max),this.updateBounds(i,f,u,o)},"insert"),bumpVerticalPos:s(function(t){this.verticalPos=this.verticalPos+t,this.data.stopy=this.verticalPos},"bumpVerticalPos"),getVerticalPos:s(function(){return this.verticalPos},"getVerticalPos"),getBounds:s(function(){return this.data},"getBounds")},G=$.sectionFills,st=$.sectionColours,Gt=s(function(t,e,a,p){const i=R().journey;let u="";const f=i.height*2+i.diagramMarginY,o=a+f;let g=0,m="#CCC",x="black",h=0;for(const[r,n]of e.entries()){if(u!==n.section){m=G[g%G.length],h=g%G.length,x=st[g%st.length];let y=0;const d=n.section;for(let v=r;v<e.length&&e[v].section==d;v++)y=y+1;const c={x:r*i.taskMargin+r*i.width+P,y:50,text:n.section,fill:m,num:h,colour:x,taskCount:y};j.drawSection(t,c,i),u=n.section,g++}const l=n.people.reduce((y,d)=>(E[d]&&(y[d]=E[d]),y),{});n.x=r*i.taskMargin+r*i.width+P,n.y=o,n.width=i.diagramMarginX,n.height=i.diagramMarginY,n.colour=x,n.fill=m,n.num=h,n.actors=l,j.drawTask(t,n,i,p),S.insert(n.x,n.y,n.x+n.width+i.taskMargin,450)}},"drawTasks"),at={setConf:Ht,draw:Xt},be={parser:Et,db:nt,renderer:at,styles:jt,init:s(t=>{at.setConf(t.journey),nt.clear()},"init")};export{be as diagram};
