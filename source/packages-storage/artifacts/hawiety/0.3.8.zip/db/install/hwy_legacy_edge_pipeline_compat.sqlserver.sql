-- AppEndO edge bridge views for legacy pipeline SQL + membership_status_legacy sync on dbo.hwy_members.
-- Physical PascalCase member columns are retired by hwy_members_legacy_pascal_retire.sqlserver.sql (computed aliases).

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF OBJECT_ID(N'dbo.hwy_members', N'U') IS NULL
BEGIN
  PRINT 'hwy_legacy_edge_pipeline_compat skipped — dbo.hwy_members missing';
END
ELSE
BEGIN
  IF OBJECT_ID(N'dbo.base_users', N'U') IS NOT NULL
  BEGIN
    UPDATE m
    SET user_id = u.id
    FROM dbo.hwy_members m
    INNER JOIN dbo.base_users u ON LTRIM(RTRIM(u.username)) = LTRIM(RTRIM(m.username))
    WHERE m.user_id IS NULL AND NULLIF(LTRIM(RTRIM(m.username)), N'') IS NOT NULL;
  END;

  IF OBJECT_ID(N'dbo.base_info', N'U') IS NOT NULL
     AND COL_LENGTH(N'dbo.hwy_members', N'membership_status_legacy') IS NOT NULL
  BEGIN
    UPDATE m
    SET membership_status_legacy = CASE LTRIM(RTRIM(bi.short_name))
      WHEN N'active' THEN 10851
      WHEN N'pending_call_center' THEN 10852
      WHEN N'pending_local' THEN 10853
      WHEN N'rejected_call_center' THEN 10854
      WHEN N'pending_cancellation' THEN 10855
      WHEN N'rejected_local' THEN 10856
      WHEN N'rejected_local_verification' THEN 10857
      ELSE m.membership_status_legacy
    END
    FROM dbo.hwy_members m
    INNER JOIN dbo.base_info bi ON bi.id = m.membership_status_code
    WHERE m.membership_status_legacy IS NULL;
  END;

  PRINT 'hwy_legacy_edge_pipeline_compat member sync ready';
END
GO

IF OBJECT_ID(N'dbo.base_users', N'U') IS NOT NULL
BEGIN
  EXEC(N'
    CREATE OR ALTER VIEW dbo.AppEnd_Users AS
    SELECT
      u.id AS Id,
      u.username AS UserName,
      u.email AS Email,
      u.mobile AS Mobile,
      u.locked AS Locked
    FROM dbo.base_users u;
  ');
END
GO

IF OBJECT_ID(N'dbo.base_roles', N'U') IS NOT NULL
BEGIN
  EXEC(N'
    CREATE OR ALTER VIEW dbo.AppEnd_Roles AS
    SELECT
      r.id AS Id,
      r.name AS RoleName
    FROM dbo.base_roles r;
  ');
END
GO

IF OBJECT_ID(N'dbo.base_user_roles', N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.base_roles', N'U') IS NOT NULL
BEGIN
  EXEC(N'
    CREATE OR ALTER VIEW dbo.AppEnd_Users_R_Roles AS
    SELECT
      ROW_NUMBER() OVER (ORDER BY ur.user_id, ur.role_name) AS Id,
      ur.user_id AS UserId,
      TRY_CAST(
        REPLACE(ur.role_name, N''HWY_R_'', N'''')
        AS INT
      ) AS RoleId,
      CAST(1 AS BIT) AS Approved,
      ur.created_at AS CreatedOn,
      ur.created_by AS CreatedBy,
      ur.created_by AS ApprovedBy
    FROM dbo.base_user_roles ur
    INNER JOIN dbo.base_roles r ON r.name = ur.role_name
    WHERE ur.role_name LIKE N''HWY_R[_]%'';
  ');
END
GO
