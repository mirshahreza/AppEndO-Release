SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_attendance_counts
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    (SELECT COUNT(*) FROM dbo.hwy_activity_attendances WHERE member_id = @member_id) AS activities,
    (SELECT COUNT(*) FROM dbo.hwy_course_attendances WHERE member_id = @member_id) AS courses;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_dossier_nav_counts
  @member_id BIGINT,
  @profile_photo_kind_slug NVARCHAR(128)
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    (SELECT COUNT(*)
     FROM dbo.hwy_member_files f
     LEFT JOIN dbo.base_info bk ON bk.id = f.file_kind_code
     WHERE f.member_id = @member_id
       AND ISNULL(bk.short_name, N'') <> @profile_photo_kind_slug) AS files,
    (SELECT COUNT(*) FROM dbo.hwy_member_notes WHERE member_id = @member_id) AS notes,
    (SELECT COUNT(*) FROM dbo.hwy_member_security_profile WHERE member_id = @member_id) AS securityProfile,
    (SELECT COUNT(*) FROM dbo.hwy_member_institutes WHERE member_id = @member_id) AS institutes,
    (SELECT COUNT(*) FROM dbo.hwy_member_targhin_requests WHERE member_id = @member_id) AS targhin,
    (SELECT COUNT(*)
     FROM dbo.hwy_members host
     INNER JOIN dbo.hwy_members km ON 1 = 1
     WHERE host.id = @member_id
       AND NULLIF(LTRIM(RTRIM(host.username)), N'') IS NOT NULL
       AND (
         LTRIM(RTRIM(km.referrer_username)) = LTRIM(RTRIM(host.username))
         OR LTRIM(RTRIM(km.second_referrer_username)) = LTRIM(RTRIM(host.username))
       )) AS kasb;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_similar_anchor
  @member_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    CAST(v.id AS VARCHAR(32)) AS memberId,
    v.phone1 AS phone1,
    v.phone2 AS phone2,
    v.firstname AS firstname,
    v.fathername AS fathername,
    v.grandfathername AS grandfathername,
    v.lastname AS lastname,
    CAST(v.birth_year AS VARCHAR(16)) AS birthYear,
    v.display_full_name AS displayFullName,
    v.username AS username,
    v.addr_province_id AS addrProvinceId
  FROM dbo.vw_hwy_members v
  WHERE v.id = @member_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_similar_by_names
  @member_id BIGINT,
  @firstname NVARCHAR(500),
  @fathername NVARCHAR(500),
  @grandfathername NVARCHAR(500),
  @row_limit INT = 100
AS
BEGIN
  SET NOCOUNT ON;

  SELECT TOP (@row_limit)
    CAST(v.id AS VARCHAR(32)) AS id,
    v.username AS username,
    v.display_full_name AS displayFullName,
    CAST(v.birth_year AS VARCHAR(16)) AS birthYear,
    v.phone1 AS phone1,
    v.phone2 AS phone2,
    v.gender_code AS genderCode,
    v.membership_status_code AS membershipStatusCode,
    v.avatar_url AS avatarUrl,
    CAST(v.nakhebin_id AS VARCHAR(32)) AS nakhebinId,
    v.family_code AS familyCode,
    v.membership_on AS membershipOn,
    v.electoral_division_path AS electoralDivisionPath,
    v.addr_province_id AS addrProvinceId
  FROM dbo.vw_hwy_members v
  WHERE v.id <> @member_id
    AND LTRIM(RTRIM(ISNULL(v.firstname, N''))) = @firstname
    AND LTRIM(RTRIM(ISNULL(v.fathername, N''))) = @fathername
    AND LTRIM(RTRIM(ISNULL(v.grandfathername, N''))) = @grandfathername
  ORDER BY v.id ASC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_similar_by_filter
  @member_id BIGINT,
  @match_first_name BIT = 0,
  @match_father_name BIT = 0,
  @match_grandfather_name BIT = 0,
  @match_birth_year BIT = 0,
  @match_phone1 BIT = 0,
  @firstname NVARCHAR(500) = NULL,
  @fathername NVARCHAR(500) = NULL,
  @grandfathername NVARCHAR(500) = NULL,
  @birth_year NVARCHAR(16) = NULL,
  @phone_digits NVARCHAR(32) = NULL,
  @row_limit INT = 100
AS
BEGIN
  SET NOCOUNT ON;

  SELECT TOP (@row_limit)
    CAST(v.id AS VARCHAR(32)) AS id,
    v.username AS username,
    v.display_full_name AS displayFullName,
    CAST(v.birth_year AS VARCHAR(16)) AS birthYear,
    v.phone1 AS phone1,
    v.phone2 AS phone2,
    v.gender_code AS genderCode,
    v.membership_status_code AS membershipStatusCode,
    v.avatar_url AS avatarUrl,
    CAST(v.nakhebin_id AS VARCHAR(32)) AS nakhebinId,
    v.family_code AS familyCode,
    v.membership_on AS membershipOn,
    v.electoral_division_path AS electoralDivisionPath,
    v.addr_province_id AS addrProvinceId
  FROM dbo.vw_hwy_members v
  WHERE v.id <> @member_id
    AND (@match_first_name = 0 OR LTRIM(RTRIM(ISNULL(v.firstname, N''))) = @firstname)
    AND (@match_father_name = 0 OR LTRIM(RTRIM(ISNULL(v.fathername, N''))) = @fathername)
    AND (@match_grandfather_name = 0 OR LTRIM(RTRIM(ISNULL(v.grandfathername, N''))) = @grandfathername)
    AND (@match_birth_year = 0 OR CAST(v.birth_year AS VARCHAR(16)) = @birth_year)
    AND (
      @match_phone1 = 0
      OR REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(v.phone1, N''))), N' ', N''), N'-', N''), N'+', N''), N'(', N''), N')', N'') = @phone_digits
      OR REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(v.phone2, N''))), N' ', N''), N'-', N''), N'+', N''), N'(', N''), N')', N'') = @phone_digits
    )
  ORDER BY v.id ASC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_activity_attendances_list
  @member_id BIGINT,
  @offset INT,
  @page_size INT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    att.id,
    att.activity_id,
    act.title AS activity_title,
    act.activity_date,
    act.activity_type_code,
    att.created_at,
    att.selfie_size_bytes
  FROM dbo.hwy_activity_attendances att
  INNER JOIN dbo.hwy_activities act ON act.id = att.activity_id
  WHERE att.member_id = @member_id
  ORDER BY att.created_at DESC, att.id DESC
  OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_course_attendances_list
  @member_id BIGINT,
  @offset INT,
  @page_size INT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    att.id,
    att.course_id,
    c.course_date,
    c.course_type_code,
    c.course_subtype_code,
    att.note,
    att.created_at
  FROM dbo.hwy_course_attendances att
  INNER JOIN dbo.hwy_courses c ON c.id = att.course_id
  WHERE att.member_id = @member_id
  ORDER BY att.created_at DESC, att.id DESC
  OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_org_membership_transfer_members_browse
  @active_status_code NVARCHAR(32),
  @other_portal_code NVARCHAR(32),
  @browse_page_size INT
AS
BEGIN
  SET NOCOUNT ON;

  SELECT TOP (@browse_page_size)
    CAST(m.id AS VARCHAR(32)) AS id,
    u.username AS username,
    m.first_name AS firstName,
    m.father_name AS fatherName,
    m.grandfather_name AS grandfatherName,
    m.family_name AS familyName,
    m.gender_code AS genderCode,
    m.birth_year AS birthYear,
    m.phone1 AS phone1,
    m.phone2 AS phone2,
    m.membership_on AS membershipOn,
    m.nakhebin_id AS nakhebinId,
    m.nakhebin_link_region_id AS nakhebinLinkRegionId,
    m.registration_channel_code AS registrationChannelCode,
    m.membership_status_code AS membershipStatusCode
  FROM dbo.hwy_members m
  LEFT JOIN dbo.base_users u ON u.id = m.user_id
  WHERE m.membership_status_code = @active_status_code
    AND COALESCE(m.registration_channel_code, N'') <> @other_portal_code
  ORDER BY m.membership_on DESC, m.id DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_org_membership_transfer_members_search
  @active_status_code NVARCHAR(32),
  @other_portal_code NVARCHAR(32),
  @offset INT,
  @page_size INT,
  @username NVARCHAR(128) = NULL,
  @tracking_code NVARCHAR(64) = NULL,
  @gender_code NVARCHAR(32) = NULL,
  @birth_year NVARCHAR(16) = NULL,
  @phone NVARCHAR(32) = NULL,
  @first_name_like NVARCHAR(256) = NULL,
  @father_name_like NVARCHAR(256) = NULL,
  @grandfather_name_like NVARCHAR(256) = NULL,
  @family_name_like NVARCHAR(256) = NULL
AS
BEGIN
  SET NOCOUNT ON;

  SELECT
    COUNT(*) OVER() AS __total,
    CAST(m.id AS VARCHAR(32)) AS id,
    u.username AS username,
    m.first_name AS firstName,
    m.father_name AS fatherName,
    m.grandfather_name AS grandfatherName,
    m.family_name AS familyName,
    m.gender_code AS genderCode,
    m.birth_year AS birthYear,
    m.phone1 AS phone1,
    m.phone2 AS phone2,
    m.membership_on AS membershipOn,
    m.nakhebin_id AS nakhebinId,
    m.nakhebin_link_region_id AS nakhebinLinkRegionId,
    m.registration_channel_code AS registrationChannelCode,
    m.membership_status_code AS membershipStatusCode
  FROM dbo.hwy_members m
  LEFT JOIN dbo.base_users u ON u.id = m.user_id
  WHERE m.membership_status_code = @active_status_code
    AND COALESCE(m.registration_channel_code, N'') <> @other_portal_code
    AND (@username IS NULL OR u.username = @username)
    AND (
      @tracking_code IS NULL
      OR CAST(m.id AS NVARCHAR(32)) = @tracking_code
      OR (TRY_CAST(@tracking_code AS BIGINT) IS NOT NULL AND m.id = TRY_CAST(@tracking_code AS BIGINT))
    )
    AND (@gender_code IS NULL OR m.gender_code = @gender_code)
    AND (@birth_year IS NULL OR m.birth_year = @birth_year)
    AND (@phone IS NULL OR m.phone1 = @phone OR m.phone2 = @phone)
    AND (@first_name_like IS NULL OR m.first_name LIKE @first_name_like)
    AND (@father_name_like IS NULL OR m.father_name LIKE @father_name_like)
    AND (@grandfather_name_like IS NULL OR m.grandfather_name LIKE @grandfather_name_like)
    AND (@family_name_like IS NULL OR m.family_name LIKE @family_name_like)
  ORDER BY m.created_at DESC, m.id DESC
  OFFSET @offset ROWS FETCH NEXT @page_size ROWS ONLY;
END;
GO
