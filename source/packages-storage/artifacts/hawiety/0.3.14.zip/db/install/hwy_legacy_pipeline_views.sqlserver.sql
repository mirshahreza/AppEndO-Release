-- Candidate pipeline stage views (edge). Idempotent CREATE OR ALTER.

CREATE OR ALTER VIEW [dbo].[vw_hwy_candidate_pipeline_security]
AS
SELECT T.id, picture_file_body_xs, first_name, father_name, grandfather_name, family_name, gender_id, phone1, username, user_id,
	nakheb_join_province_id, nakheb_join_circle_id, nakheb_join_tamvin_id, nakheb_join_eghtera_id,
	security_status_id,security_status_on, security_status_result, is_employee, is_approved, role_of_tarshih, date_of_tarshih,
	moarassheh_of_tarshih,approved_by, area_of_tarshih,
	DATEDIFF(DAY, date_of_tarshih, GETDATE()) days_from
FROM
(
	SELECT hwy_members.id,T.id AS security_status_id,first_name,father_name,grandfather_name,family_name,username, user_id, phone1,
	nakheb_join_province_id, nakheb_join_circle_id, nakheb_join_tamvin_id, nakheb_join_eghtera_id,
	hwy_members.gender_id , picture_file_body_xs,T.created_on AS security_status_on,T.final_result AS security_status_result,
	CAST((SELECT COUNT(*) FROM vw_hwy_platform_user_roles URR WITH(NOLOCK) WHERE URR.user_id=hwy_members.user_id AND URR.role_id IN (1000004,1000005)) AS BIT) AS is_employee,
	(SELECT TOP 1 ISNULL(URR.approved,0)
		FROM vw_hwy_platform_user_roles URR
		LEFT OUTER JOIN vw_hwy_platform_roles R ON R.id=URR.role_id
		WHERE URR.user_id=hwy_members.user_id AND URR.role_id IN (1000004,1000005)
	) AS is_approved,
	(SELECT TOP 1 role_name
		FROM vw_hwy_platform_user_roles URR
		LEFT OUTER JOIN vw_hwy_platform_roles R ON R.id=URR.role_id
		WHERE URR.user_id=hwy_members.user_id AND URR.role_id IN (1000004,1000005)
	) AS role_of_tarshih,
	(SELECT TOP 1 URR.created_at
		FROM vw_hwy_platform_user_roles URR
		WHERE URR.user_id=hwy_members.user_id AND URR.role_id IN (1000004,1000005)
	) AS date_of_tarshih,
	(SELECT TOP 1 URR.created_by
		FROM vw_hwy_platform_user_roles URR
		WHERE URR.user_id=hwy_members.user_id AND URR.role_id IN (1000004,1000005)
	) AS moarassheh_of_tarshih,
	(SELECT TOP 1 URR.approved_by
		FROM vw_hwy_platform_user_roles URR
		WHERE URR.user_id=hwy_members.user_id AND URR.role_id IN (1000004,1000005)
	) AS approved_by,
	(SELECT dbo.hwy_member_agg_area_limits_for_tarshih(hwy_members.id)) AS area_of_tarshih
	FROM  dbo.vw_hwy_members_legacy_row hwy_members WITH(NOLOCK)
	LEFT OUTER JOIN hwy_member_security_statuses T WITH(NOLOCK) ON T.member_id=hwy_members.id
	WHERE membership_status_legacy=10851
) T
WHERE is_employee=1;
GO

CREATE OR ALTER VIEW [dbo].[vw_hwy_candidate_pipeline_interview]
AS
SELECT
  M.id AS id,
  M.picture_file_body_xs,
  M.first_name,
  M.father_name,
  M.grandfather_name,
  M.family_name,
  M.gender_id,
  M.phone1,
  M.username,
  M.user_id,
  M.nakheb_join_province_id,
  M.nakheb_join_circle_id,
  M.nakheb_join_tamvin_id,
  M.nakheb_join_eghtera_id,
  iv.id AS interview_id,
  iv.interview_on AS interview_on,
  iv.final_result AS interview_final_result,
  R.role_name AS role_of_tarshih,
  URR.role_id AS role_id,
  URR.created_at AS date_of_tarshih,
  URR.created_by AS moarassheh_of_tarshih,
  dbo.hwy_member_agg_area_limits_for_tarshih(M.id) AS area_of_tarshih,
  sec.created_on AS date_of_sp
FROM dbo.vw_hwy_members_legacy_row M WITH (NOLOCK)
INNER JOIN dbo.vw_hwy_platform_user_roles URR WITH (NOLOCK)
  ON URR.user_id = M.user_id AND URR.role_id IN (1000004, 1000005)
LEFT OUTER JOIN dbo.vw_hwy_platform_roles R WITH (NOLOCK) ON R.id= URR.role_id
OUTER APPLY (
  SELECT TOP 1 SP.can_get_masooliat, SP.created_on
  FROM dbo.hwy_member_security_profile_history SP WITH (NOLOCK)
  WHERE SP.member_id = M.id
  ORDER BY SP.created_on DESC
) sec
OUTER APPLY (
  SELECT TOP 1 I.id, I.interview_on, I.final_result
  FROM dbo.hwy_member_interviews_2022 I WITH (NOLOCK)
  WHERE I.member_id = M.id
  ORDER BY I.created_on DESC
) iv
WHERE M.membership_status_legacy = 10851
  AND sec.can_get_masooliat = 211751;
GO

CREATE OR ALTER VIEW [dbo].[vw_hwy_candidate_pipeline_install]
AS
SELECT hwy_members.id,first_name,father_name,grandfather_name,family_name,username, hwy_members.user_id, phone1, ISNULL(stat_fields_completed,0) profile_perfect, stat_fields_completed,
	nakheb_join_province_id, nakheb_join_circle_id, nakheb_join_tamvin_id, nakheb_join_eghtera_id,
	hwy_members.gender_id , picture_file_body_xs,
	role_id AS role_of_tarshih_id,role_name AS role_of_tarshih,URR.created_at AS date_of_tarshih , URR.created_by AS moarassheh_of_tarshih,CAST(A.item_id AS VARCHAR(32)) AS area_id,
	dbo.hwy_member_passed_necessary_dorat(hwy_members.id) necessary_dorat_passed,
	hwy_members.area_limit_id,BI_AreaLimitId.title AS area_limit_id_title ,
	area_limit_province_id,BI_AreaLimitProvince.title AS area_limit_province_id_title,
	area_limit_circle_id,T_AreaLimitCircle.circle_name AS area_limit_circle_id_title,
	area_limit_tamvin_id,T_AreaLimitTamvin.tamvin_name AS area_limit_tamvin_id_title,
	(SELECT TOP 1 I2022.final_result FROM hwy_member_interviews_2022 I2022 WITH(NOLOCK) WHERE member_id=hwy_members.id ORDER BY I2022.created_on DESC) AS interview_final_result_id,
	(SELECT TOP 1 B.title FROM hwy_member_interviews_2022 I2022 WITH(NOLOCK) LEFT OUTER JOIN dbo.hwy_ref_base_information B ON B.id=I2022.final_result WHERE member_id=hwy_members.id ORDER BY I2022.created_on DESC) AS interview_final_result_title,
	(SELECT STRING_AGG(bi.title, ' , ') FROM dbo.hwy_ref_members_gender_limits gl WITH(NOLOCK) LEFT OUTER JOIN dbo.hwy_ref_base_information bi ON bi.id=gl.item_id WHERE gl.member_id=[hwy_members].[id]) AS gender_limits,
	(SELECT dbo.hwy_member_agg_area_limits(hwy_members.id)) AS areas_limits,
	(SELECT STRING_AGG(role_name, ' , ') FROM dbo.vw_hwy_members_legacy_row ForAgg WITH(NOLOCK) LEFT OUTER JOIN vw_hwy_platform_user_roles WITH(NOLOCK) on ForAgg.user_id=vw_hwy_platform_user_roles.user_id LEFT OUTER JOIN vw_hwy_platform_roles WITH(NOLOCK) on vw_hwy_platform_user_roles.role_id=vw_hwy_platform_roles.id WHERE ForAgg.id=[hwy_members].[id] AND vw_hwy_platform_user_roles.approved=1) AS roles_limits,
	(SELECT dbo.hwy_member_agg_area_limits_for_tarshih(hwy_members.id)) AS area_of_tarshih,
	(SELECT TOP 1 CAST(ISNULL(MM.oath_file_size,0) AS BIT) FROM dbo.vw_hwy_members_legacy_row MM WHERE MM.id=hwy_members.id) has_oath,
	(CASE WHEN ISNULL(nakheb_card_front_approved,0) = 0 OR ISNULL(national_card_front_approved,0) = 0 OR ISNULL(national_card_behind_approved,0) = 0 OR ISNULL(picture_approved,0) = 0 OR ISNULL(oath_approved,0) = 0 OR ISNULL(maskan_card_front_approved,0) = 0 THEN CAST(0 AS BIT) ELSE CAST(1 AS BIT) END) all_images_approved,
	(SELECT TOP 1 SP.can_get_masooliat FROM hwy_member_security_profile_history SP WHERE SP.member_id=hwy_members.id ORDER BY SP.created_on DESC) security_status
	FROM  dbo.vw_hwy_members_legacy_row hwy_members WITH(NOLOCK)
	LEFT OUTER JOIN vw_hwy_platform_user_roles URR WITH(NOLOCK) ON URR.user_id=hwy_members.user_id AND URR.role_id IN (1000004, 1000005)
	LEFT OUTER JOIN vw_hwy_platform_roles R ON R.id=URR.role_id
	OUTER APPLY (
		SELECT TOP 1 AL.item_id
		FROM dbo.hwy_member_area_limits AL WITH (NOLOCK)
		WHERE AL.member_id = hwy_members.id AND ISNULL(AL.approved, 0) IN (0, 1)
		ORDER BY AL.approved DESC, AL.id DESC
	) A
	LEFT OUTER JOIN dbo.hwy_ref_base_information BI_AreaLimitId WITH(NOLOCK) ON BI_AreaLimitId.id=hwy_members.area_limit_id
	LEFT OUTER JOIN dbo.hwy_ref_base_information BI_AreaLimitProvince WITH(NOLOCK) ON BI_AreaLimitProvince.id= area_limit_province_id
	LEFT OUTER JOIN dbo.hwy_ref_h_circles T_AreaLimitCircle WITH(NOLOCK) ON T_AreaLimitCircle.circle_id= area_limit_circle_id
	LEFT OUTER JOIN dbo.hwy_ref_h_tamvinat T_AreaLimitTamvin WITH(NOLOCK) ON T_AreaLimitTamvin.tamvin_id= area_limit_tamvin_id
	WHERE membership_status_legacy=10851 AND ISNULL(URR.approved, 0) <> 1;
GO

CREATE OR ALTER VIEW [dbo].[vw_hwy_candidate_pipeline_courses]
AS
SELECT T.id, picture_file_body_xs, first_name, father_name, grandfather_name, family_name, gender_id, phone1, username, user_id,education_level_legacy_id,
	nakheb_join_province_id, nakheb_join_circle_id, nakheb_join_tamvin_id, nakheb_join_eghtera_id,
	passed_dorat, is_employee, role_of_tarshih, date_of_tarshih, moarassheh_of_tarshih, area_of_tarshih, passed_necessary_dorat, interview_final_result
FROM
(
	SELECT hwy_members.id,first_name,father_name,grandfather_name,family_name,username, user_id, phone1,
	nakheb_join_province_id, nakheb_join_circle_id, nakheb_join_tamvin_id, nakheb_join_eghtera_id,
	hwy_members.gender_id , picture_file_body_xs,education_level_legacy_id,
	CAST((SELECT COUNT(*) FROM vw_hwy_platform_user_roles URR WITH(NOLOCK) WHERE URR.user_id=hwy_members.user_id AND URR.role_id IN (1000004,1000005)) AS BIT) AS is_employee,
	dbo.hwy_member_passed_necessary_dorat(hwy_members.id) passed_necessary_dorat,
	(SELECT STRING_AGG('<div data-doratid="'+CAST(T.id AS VARCHAR)+'" class="badge bg-success text-light fs-d9 m-1">'+T.title+'</div>','') FROM
		(
		SELECT DISTINCT B.id,B.title FROM dbo.hwy_ref_members_dorat md
		LEFT OUTER JOIN dbo.hwy_ref_dorat d ON d.id=md.dorat_id
		LEFT OUTER JOIN dbo.hwy_ref_base_information B ON B.id=d.dorat_sub_type_id
		WHERE md.member_id=hwy_members.id AND d.dorat_sub_type_id IN (11071,11152,11028,11123,111533,11077,213957,213959,11072) AND d.status_id=215116
		) T
	) AS passed_dorat,
	(SELECT TOP 1 role_name
		FROM vw_hwy_platform_user_roles URR
		LEFT OUTER JOIN vw_hwy_platform_roles R ON R.id=URR.role_id
		WHERE URR.user_id=hwy_members.user_id AND URR.role_id IN (1000004,1000005)
	) AS role_of_tarshih,
	(SELECT TOP 1 URR.created_at
		FROM vw_hwy_platform_user_roles URR
		WHERE URR.user_id=hwy_members.user_id AND URR.role_id IN (1000004,1000005)
	) AS date_of_tarshih,
	(SELECT TOP 1 URR.created_by
		FROM vw_hwy_platform_user_roles URR
		WHERE URR.user_id=hwy_members.user_id AND URR.role_id IN (1000004,1000005)
	) AS moarassheh_of_tarshih,
	(SELECT dbo.hwy_member_agg_area_limits_for_tarshih(hwy_members.id)) AS area_of_tarshih,
	(SELECT TOP 1 I2022.final_result FROM hwy_member_interviews_2022 I2022 WITH(NOLOCK) WHERE member_id=hwy_members.id ORDER BY I2022.created_on DESC) AS interview_final_result
	FROM  dbo.vw_hwy_members_legacy_row hwy_members WITH(NOLOCK)
	WHERE membership_status_legacy=10851 AND (SELECT TOP 1 SP.can_get_masooliat FROM hwy_member_security_profile_history SP WHERE SP.member_id=hwy_members.id ORDER BY SP.created_on DESC)=211751
) T
WHERE
	interview_final_result=213609
	OR
	(
		interview_final_result=213610
		AND
		(SELECT TOP 1 URR.role_id FROM vw_hwy_platform_user_roles URR WITH(NOLOCK) WHERE role_id=1000005 AND URR.user_id=T.user_id)=1000005
	);
GO

IF OBJECT_ID(N'dbo.HWY_VW_Employees_SecurityStatuses', N'V') IS NOT NULL
  DROP VIEW dbo.HWY_VW_Employees_SecurityStatuses;
GO
IF OBJECT_ID(N'dbo.HWY_VW_Employees_InterviewManagement', N'V') IS NOT NULL
  DROP VIEW dbo.HWY_VW_Employees_InterviewManagement;
GO
IF OBJECT_ID(N'dbo.HWY_VW_Employees_PassedNecessaryDoratManagement', N'V') IS NOT NULL
  DROP VIEW dbo.HWY_VW_Employees_PassedNecessaryDoratManagement;
GO
IF OBJECT_ID(N'dbo.HWY_VW_Employees_ToApproveResponsibility', N'V') IS NOT NULL
  DROP VIEW dbo.HWY_VW_Employees_ToApproveResponsibility;
GO
