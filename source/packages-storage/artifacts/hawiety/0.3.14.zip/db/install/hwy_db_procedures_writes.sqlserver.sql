SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_targhin_decide_request
  @request_id BIGINT,
  @status_code NVARCHAR(32),
  @final_reason_code NVARCHAR(128),
  @final_note NVARCHAR(4000),
  @actor_user_id BIGINT = NULL,
  @membership_status_code_on_approve NVARCHAR(128) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  DECLARE @member_id BIGINT;
  DECLARE @current_status NVARCHAR(32);

  BEGIN TRAN;

  SELECT @member_id = member_id, @current_status = status_code
  FROM dbo.hwy_member_targhin_requests WITH (UPDLOCK, ROWLOCK)
  WHERE id= @request_id;

  IF @member_id IS NULL
  BEGIN
    ROLLBACK;
    THROW 51000, N'Targhin request not found.', 1;
  END;

  IF LTRIM(RTRIM(@current_status)) <> N'pending'
  BEGIN
    ROLLBACK;
    THROW 51001, N'Targhin request is not pending.', 1;
  END;

  UPDATE dbo.hwy_member_targhin_requests
  SET
    status_code = @status_code,
    final_reason_code = @final_reason_code,
    final_note = @final_note,
    final_by = @actor_user_id,
    final_at = SYSUTCDATETIME()
  WHERE id= @request_id AND status_code = N'pending';

  IF @@ROWCOUNT = 0
  BEGIN
    ROLLBACK;
    THROW 51002, N'Targhin request is not pending.', 1;
  END;

  IF @status_code = N'approved' AND @membership_status_code_on_approve IS NOT NULL
  BEGIN
    UPDATE dbo.hwy_members
    SET
      membership_status_code = @membership_status_code_on_approve,
      membership_status_updated_on = SYSUTCDATETIME(),
      membership_status_updated_by = @actor_user_id
    WHERE id= @member_id;
  END;

  COMMIT;

  SELECT
    CAST(@request_id AS VARCHAR(32)) AS request_id,
    CAST(@member_id AS VARCHAR(32)) AS member_id,
    @status_code AS status_code;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_activity_apply_workflow
  @activity_id BIGINT,
  @target_status_code NVARCHAR(32),
  @note NVARCHAR(512) = NULL,
  @actor_username NVARCHAR(256),
  @step_id UNIQUEIDENTIFIER
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  BEGIN TRAN;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_activities WHERE id= @activity_id)
  BEGIN
    ROLLBACK;
    THROW 52000, N'Activity not found.', 1;
  END;

  UPDATE dbo.hwy_activities
  SET
    status_code = @target_status_code,
    status_note = @note,
    legacy_updated_by = @actor_username,
    updated_at = SYSUTCDATETIME()
  WHERE id= @activity_id;

  INSERT INTO dbo.hwy_activity_approval_steps (
    id, activity_id, status_code, note, legacy_created_by, created_at
  ) VALUES (
    @step_id, @activity_id, @target_status_code, @note, @actor_username, SYSUTCDATETIME()
  );

  COMMIT;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_course_apply_workflow
  @course_id BIGINT,
  @target_status_code NVARCHAR(32),
  @note NVARCHAR(1000) = NULL,
  @actor_username NVARCHAR(256),
  @step_id UNIQUEIDENTIFIER
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  BEGIN TRAN;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_courses WHERE id= @course_id)
  BEGIN
    ROLLBACK;
    THROW 52100, N'Course not found.', 1;
  END;

  UPDATE dbo.hwy_courses
  SET
    status_code = @target_status_code,
    status_note = @note,
    legacy_status_changed_by = @actor_username,
    legacy_updated_by = @actor_username,
    status_changed_at = SYSUTCDATETIME(),
    updated_at = SYSUTCDATETIME()
  WHERE id= @course_id;

  INSERT INTO dbo.hwy_course_approval_steps (
    id, course_id, status_code, note, legacy_created_by, created_at
  ) VALUES (
    @step_id, @course_id, @target_status_code, @note, @actor_username, SYSUTCDATETIME()
  );

  COMMIT;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_reject_request
  @request_id UNIQUEIDENTIFIER,
  @actor_user_id BIGINT,
  @note NVARCHAR(4000) = NULL
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  DECLARE @member_id BIGINT = NULL;
  DECLARE @legacy_geo_id INT = NULL;

  SELECT @member_id = member_id, @legacy_geo_id = legacy_geo_id
  FROM dbo.hwy_geo_responsibility_requests
  WHERE id= @request_id AND status = N'submitted';

  UPDATE dbo.hwy_geo_responsibility_requests
  SET status = N'rejected',
      decided_by = @actor_user_id,
      decided_at = SYSUTCDATETIME(),
      decision_note = @note
  WHERE id= @request_id AND status = N'submitted';

  IF @@ROWCOUNT = 0
    THROW 53000, N'Pending request not found.', 1;

  IF @member_id IS NOT NULL AND @legacy_geo_id IS NOT NULL
  BEGIN
    EXEC dbo.hwy_geo_responsibility_sync_member_area_limit
      @member_id = @member_id,
      @legacy_geo_id = @legacy_geo_id,
      @approved = NULL,
      @actor_user_id = @actor_user_id;
  END;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_cancel_nomination
  @request_id UNIQUEIDENTIFIER,
  @actor_user_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  DECLARE @member_id BIGINT = NULL;
  DECLARE @legacy_geo_id INT = NULL;

  SELECT @member_id = member_id, @legacy_geo_id = legacy_geo_id
  FROM dbo.hwy_geo_responsibility_requests
  WHERE id= @request_id AND status = N'submitted';

  UPDATE dbo.hwy_geo_responsibility_requests
  SET status = N'cancelled',
      decided_by = @actor_user_id,
      decided_at = SYSUTCDATETIME(),
      decision_note = N'cancelled_by_nominator'
  WHERE id= @request_id AND status = N'submitted';

  IF @@ROWCOUNT = 0
    THROW 53001, N'Pending request not found.', 1;

  IF @member_id IS NOT NULL AND @legacy_geo_id IS NOT NULL
  BEGIN
    EXEC dbo.hwy_geo_responsibility_sync_member_area_limit
      @member_id = @member_id,
      @legacy_geo_id = @legacy_geo_id,
      @approved = NULL,
      @actor_user_id = @actor_user_id;
  END;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_sync_member_area_limit
  @member_id BIGINT,
  @legacy_geo_id INT,
  @actor_user_id BIGINT,
  @event_at DATETIME2 = NULL,
  @approved BIT = NULL
AS
BEGIN
  SET NOCOUNT ON;

  IF OBJECT_ID(N'dbo.hwy_member_area_limits', N'U') IS NULL
    RETURN;

  IF @member_id IS NULL OR @member_id <= 0 OR @legacy_geo_id IS NULL OR @legacy_geo_id <= 0
    RETURN;

  SET @event_at = COALESCE(@event_at, SYSUTCDATETIME());

  DECLARE @actor_name NVARCHAR(256);
  SELECT @actor_name = COALESCE(NULLIF(LTRIM(RTRIM(u.username)), N''), CAST(@actor_user_id AS NVARCHAR(32)))
  FROM dbo.base_users u WITH (NOLOCK)
  WHERE u.id = @actor_user_id;

  IF @actor_name IS NULL
    SET @actor_name = CAST(@actor_user_id AS NVARCHAR(32));

  IF @approved IS NULL
  BEGIN
    DELETE FROM dbo.hwy_member_area_limits
    WHERE member_id = @member_id AND item_id = @legacy_geo_id;
    RETURN;
  END;

  MERGE dbo.hwy_member_area_limits AS t
  USING (
    SELECT @member_id AS member_id, @legacy_geo_id AS item_id
  ) AS s
    ON t.member_id = s.member_id AND t.item_id = s.item_id
  WHEN MATCHED THEN UPDATE SET
    approved = @approved,
    approved_by = CASE WHEN @approved = 1 THEN @actor_name ELSE t.approved_by END,
    approved_on = CASE WHEN @approved = 1 THEN @event_at ELSE t.approved_on END
  WHEN NOT MATCHED THEN INSERT (
    id, member_id, item_id, approved, created_by, created_on, approved_by, approved_on
  ) VALUES (
    NEWID(),
    @member_id,
    @legacy_geo_id,
    @approved,
    @actor_name,
    @event_at,
    CASE WHEN @approved = 1 THEN @actor_name ELSE NULL END,
    CASE WHEN @approved = 1 THEN @event_at ELSE NULL END
  );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_grant_official_access
  @user_id BIGINT,
  @role_name NVARCHAR(128),
  @geo_base_info_id NVARCHAR(128),
  @actor_user_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  IF NOT EXISTS (
    SELECT 1 FROM dbo.base_user_roles WHERE user_id = @user_id AND role_name = @role_name
  )
  BEGIN
    INSERT INTO dbo.base_user_roles (user_id, role_name, created_by, created_at, updated_at)
    VALUES (@user_id, @role_name, @actor_user_id, SYSUTCDATETIME(), SYSUTCDATETIME());
  END;

  IF NOT EXISTS (
    SELECT 1 FROM dbo.base_scope_memberships
    WHERE user_id = @user_id AND dimension_key = N'geo' AND node_id = @geo_base_info_id
  )
  BEGIN
    INSERT INTO dbo.base_scope_memberships (
      user_id, dimension_key, node_id, created_by, updated_by, created_at, updated_at
    ) VALUES (
      @user_id, N'geo', @geo_base_info_id, @actor_user_id, @actor_user_id, SYSUTCDATETIME(), SYSUTCDATETIME()
    );

    INSERT INTO dbo.base_scope_membership_events (
      dimension_key, node_id, user_id, event_type, actor_user_id, created_at
    ) VALUES (
      N'geo', @geo_base_info_id, @user_id, N'assigned', @actor_user_id, SYSUTCDATETIME()
    );
  END;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_revoke_official_access
  @user_id BIGINT,
  @role_name NVARCHAR(128),
  @geo_base_info_id NVARCHAR(128),
  @actor_user_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  DECLARE @scope_id BIGINT;

  SELECT @scope_id = id
  FROM dbo.base_scope_memberships
  WHERE user_id = @user_id AND dimension_key = N'geo' AND node_id = @geo_base_info_id;

  IF @scope_id IS NOT NULL
  BEGIN
    DELETE FROM dbo.base_scope_memberships WHERE id= @scope_id;

    INSERT INTO dbo.base_scope_membership_events (
      dimension_key, node_id, user_id, event_type, actor_user_id, created_at
    ) VALUES (
      N'geo', @geo_base_info_id, @user_id, N'removed', @actor_user_id, SYSUTCDATETIME()
    );
  END;

  IF NOT EXISTS (
    SELECT 1 FROM dbo.hwy_geo_responsibility_requests
    WHERE user_id = @user_id
      AND role_name = @role_name
      AND status = N'approved'
      AND revoked_at IS NULL
      AND request_kind = N'nomination'
  )
  AND NOT EXISTS (
    SELECT 1 FROM dbo.base_scope_memberships sm
    INNER JOIN dbo.base_user_roles ur ON ur.user_id = sm.user_id AND ur.role_name = @role_name
    WHERE sm.user_id = @user_id AND sm.dimension_key = N'geo'
  )
  BEGIN
    DELETE FROM dbo.base_user_roles WHERE user_id = @user_id AND role_name = @role_name;
  END;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_approve_nomination
  @request_id UNIQUEIDENTIFIER,
  @member_id BIGINT,
  @user_id BIGINT,
  @geo_level NVARCHAR(32),
  @geo_base_info_id NVARCHAR(128),
  @role_name NVARCHAR(128),
  @actor_user_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  BEGIN TRAN;

  DECLARE @legacy_geo_id INT = NULL;
  DECLARE @decided_at DATETIME2 = SYSUTCDATETIME();

  SELECT @legacy_geo_id = legacy_geo_id
  FROM dbo.hwy_geo_responsibility_requests
  WHERE id= @request_id;

  DECLARE @cleared_limits TABLE (
    member_id BIGINT NOT NULL,
    legacy_geo_id INT NOT NULL
  );

  UPDATE r
  SET revoked_at = @decided_at, revoked_by = @actor_user_id
  OUTPUT deleted.member_id, deleted.legacy_geo_id INTO @cleared_limits (member_id, legacy_geo_id)
  FROM dbo.hwy_geo_responsibility_requests r
  INNER JOIN dbo.hwy_members om ON om.id= r.member_id
  INNER JOIN dbo.hwy_members nm ON nm.id= @member_id
  WHERE r.geo_base_info_id = @geo_base_info_id
    AND r.role_name = @role_name
    AND r.geo_level = @geo_level
    AND r.status = N'approved'
    AND r.revoked_at IS NULL
    AND r.request_kind = N'nomination'
    AND r.member_id <> @member_id
    AND r.legacy_geo_id IS NOT NULL
    AND dbo.hwy_geo_members_same_gender_partition(om.gender_code, nm.gender_code) = 1;

  UPDATE r
  SET status = N'cancelled',
      decided_by = @actor_user_id,
      decided_at = @decided_at,
      decision_note = COALESCE(r.decision_note, N'')
  OUTPUT deleted.member_id, deleted.legacy_geo_id INTO @cleared_limits (member_id, legacy_geo_id)
  FROM dbo.hwy_geo_responsibility_requests r
  INNER JOIN dbo.hwy_members om ON om.id= r.member_id
  INNER JOIN dbo.hwy_members nm ON nm.id= @member_id
  WHERE r.status = N'submitted'
    AND r.geo_base_info_id = @geo_base_info_id
    AND r.role_name = @role_name
    AND r.geo_level = @geo_level
    AND r.request_kind = N'nomination'
    AND r.id <> @request_id
    AND r.legacy_geo_id IS NOT NULL
    AND dbo.hwy_geo_members_same_gender_partition(om.gender_code, nm.gender_code) = 1;

  DELETE al
  FROM dbo.hwy_member_area_limits al
  INNER JOIN @cleared_limits c
    ON c.member_id = al.member_id AND c.legacy_geo_id = al.item_id;

  UPDATE dbo.hwy_geo_responsibility_requests
  SET status = N'approved',
      decided_by = @actor_user_id,
      decided_at = @decided_at
  WHERE id= @request_id AND status = N'submitted';

  IF @@ROWCOUNT = 0
  BEGIN
    ROLLBACK;
    THROW 53100, N'Pending request not found.', 1;
  END;

  IF @legacy_geo_id IS NOT NULL
  BEGIN
    EXEC dbo.hwy_geo_responsibility_sync_member_area_limit
      @member_id = @member_id,
      @legacy_geo_id = @legacy_geo_id,
      @approved = 1,
      @actor_user_id = @actor_user_id,
      @event_at = @decided_at;
  END;

  EXEC dbo.hwy_geo_responsibility_grant_official_access
    @user_id = @user_id,
    @role_name = @role_name,
    @geo_base_info_id = @geo_base_info_id,
    @actor_user_id = @actor_user_id;

  COMMIT;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_approve_official_removal
  @request_id UNIQUEIDENTIFIER,
  @holding_request_id UNIQUEIDENTIFIER,
  @user_id BIGINT,
  @geo_base_info_id NVARCHAR(128),
  @role_name NVARCHAR(128),
  @actor_user_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  BEGIN TRAN;

  UPDATE dbo.hwy_geo_responsibility_requests
  SET revoked_at = SYSUTCDATETIME(), revoked_by = @actor_user_id
  WHERE id= @holding_request_id
    AND status = N'approved'
    AND revoked_at IS NULL;

  UPDATE dbo.hwy_geo_responsibility_requests
  SET status = N'approved',
      decided_by = @actor_user_id,
      decided_at = SYSUTCDATETIME()
  WHERE id= @request_id AND status = N'submitted';

  IF @@ROWCOUNT = 0
  BEGIN
    ROLLBACK;
    THROW 53101, N'Pending request not found.', 1;
  END;

  DECLARE @holding_member_id BIGINT = NULL;
  DECLARE @holding_legacy_geo_id INT = NULL;

  SELECT @holding_member_id = member_id, @holding_legacy_geo_id = legacy_geo_id
  FROM dbo.hwy_geo_responsibility_requests
  WHERE id= @holding_request_id;

  EXEC dbo.hwy_geo_responsibility_revoke_official_access
    @user_id = @user_id,
    @role_name = @role_name,
    @geo_base_info_id = @geo_base_info_id,
    @actor_user_id = @actor_user_id;

  IF @holding_member_id IS NOT NULL AND @holding_legacy_geo_id IS NOT NULL
  BEGIN
    EXEC dbo.hwy_geo_responsibility_sync_member_area_limit
      @member_id = @holding_member_id,
      @legacy_geo_id = @holding_legacy_geo_id,
      @approved = NULL,
      @actor_user_id = @actor_user_id;
  END;

  COMMIT;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_approve_scope_removal
  @request_id UNIQUEIDENTIFIER,
  @user_id BIGINT,
  @geo_base_info_id NVARCHAR(128),
  @role_name NVARCHAR(128),
  @actor_user_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  BEGIN TRAN;

  UPDATE dbo.hwy_geo_responsibility_requests
  SET status = N'approved',
      decided_by = @actor_user_id,
      decided_at = SYSUTCDATETIME()
  WHERE id= @request_id AND status = N'submitted';

  IF @@ROWCOUNT = 0
  BEGIN
    ROLLBACK;
    THROW 53102, N'Pending request not found.', 1;
  END;

  EXEC dbo.hwy_geo_responsibility_revoke_official_access
    @user_id = @user_id,
    @role_name = @role_name,
    @geo_base_info_id = @geo_base_info_id,
    @actor_user_id = @actor_user_id;

  COMMIT;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_targhin_create_request
  @member_id BIGINT,
  @request_reason_code NVARCHAR(128),
  @request_note NVARCHAR(4000),
  @created_by BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  INSERT INTO dbo.hwy_member_targhin_requests (member_id, request_reason_code, request_note, created_by)
  OUTPUT
    CAST(INSERTED.id AS VARCHAR(32)) AS id,
    CAST(INSERTED.member_id AS VARCHAR(32)) AS member_id,
    INSERTED.request_reason_code AS request_reason_code,
    INSERTED.request_note AS request_note,
    INSERTED.status_code AS status_code,
    INSERTED.created_at AS created_at,
    CAST(INSERTED.created_by AS VARCHAR(32)) AS created_by
  VALUES (@member_id, @request_reason_code, @request_note, @created_by);
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_note_insert
  @member_id BIGINT,
  @body NVARCHAR(MAX),
  @subject_code NVARCHAR(128) = NULL,
  @created_by BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;

  INSERT INTO dbo.hwy_member_notes (member_id, body, subject_code, created_by)
  OUTPUT
    CAST(INSERTED.id AS VARCHAR(32)) AS id,
    CAST(INSERTED.member_id AS VARCHAR(32)) AS member_id,
    INSERTED.body AS body,
    INSERTED.subject_code AS subject_code,
    INSERTED.created_at AS created_at,
    CAST(INSERTED.created_by AS VARCHAR(32)) AS created_by
  VALUES (@member_id, @body, @subject_code, @created_by);
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_targhin_nego_note_insert
  @member_id BIGINT,
  @note NVARCHAR(4000),
  @created_by_legacy NVARCHAR(256),
  @created_by_user_id BIGINT = NULL
AS
BEGIN
  SET NOCOUNT ON;

  INSERT INTO dbo.hwy_member_targhin_nego_notes (
    member_id, note, created_by_legacy, created_by_user_id, created_at
  )
  OUTPUT CAST(INSERTED.id AS VARCHAR(32)) AS id
  VALUES (@member_id, @note, @created_by_legacy, @created_by_user_id, SYSUTCDATETIME());
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_member_file_delete
  @file_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @member_id BIGINT = NULL;

  SELECT @member_id = member_id
  FROM dbo.hwy_member_files WITH (UPDLOCK, HOLDLOCK)
  WHERE id = @file_id;

  DELETE FROM dbo.hwy_member_files
  WHERE id = @file_id;

  IF @@ROWCOUNT = 0
    THROW 56402, N'File not found.', 1;

  IF @member_id IS NOT NULL
    EXEC dbo.hwy_member_sync_registration_files_member_row @member_id = @member_id;

  SELECT 1 AS deleted;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_activity_file_delete
  @file_id UNIQUEIDENTIFIER,
  @activity_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  DELETE FROM dbo.hwy_activity_files
  WHERE id= @file_id AND activity_id = @activity_id;

  IF @@ROWCOUNT = 0
    THROW 54000, N'File not found.', 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_org_membership_transfer_request
  @member_id BIGINT,
  @institute_id BIGINT,
  @status_code NVARCHAR(128),
  @join_path_code NVARCHAR(128),
  @invited_by BIGINT = NULL,
  @invited_at DATETIME2,
  @created_at DATETIME2,
  @updated_at DATETIME2
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  MERGE dbo.hwy_member_institutes AS t
  USING (SELECT @member_id AS member_id, @institute_id AS institute_id) AS s
    ON t.member_id = s.member_id AND t.institute_id = s.institute_id
  WHEN MATCHED THEN UPDATE SET
    status_code = @status_code,
    join_path_code = @join_path_code,
    invited_by = @invited_by,
    invited_at = @invited_at,
    member_accepted = 0,
    updated_at = @updated_at,
    updated_by = @invited_by
  WHEN NOT MATCHED THEN INSERT (
    member_id, institute_id, status_code, join_path_code,
    invited_by, invited_at, member_accepted, created_at, updated_at, created_by, updated_by
  ) VALUES (
    @member_id, @institute_id, @status_code, @join_path_code,
    @invited_by, @invited_at, 0, @created_at, @updated_at, @invited_by, @invited_by
  );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_org_membership_transfer_rollback
  @member_id BIGINT,
  @institute_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  DELETE FROM dbo.hwy_member_institutes
  WHERE member_id = @member_id AND institute_id = @institute_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_submit_nomination
  @member_id BIGINT,
  @user_id BIGINT,
  @geo_level NVARCHAR(32),
  @geo_base_info_id NVARCHAR(128),
  @legacy_geo_id BIGINT,
  @role_name NVARCHAR(128),
  @nominated_by BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  BEGIN TRAN;

  UPDATE r
  SET status = N'superseded',
      decided_by = @nominated_by,
      decided_at = SYSUTCDATETIME(),
      decision_note = N'superseded_by_new_nomination'
  FROM dbo.hwy_geo_responsibility_requests r
  INNER JOIN dbo.hwy_members om ON om.id= r.member_id
  INNER JOIN dbo.hwy_members nm ON nm.id= @member_id
  WHERE r.status = N'submitted'
    AND r.geo_base_info_id = @geo_base_info_id
    AND r.role_name = @role_name
    AND r.request_kind = N'nomination'
    AND r.member_id <> @member_id
    AND dbo.hwy_geo_members_same_gender_partition(om.gender_code, nm.gender_code) = 1;

  INSERT INTO dbo.hwy_geo_responsibility_requests (
    member_id, user_id, geo_level, geo_base_info_id, legacy_geo_id, role_name, request_kind, status, nominated_by
  )
  OUTPUT CAST(INSERTED.id AS NVARCHAR(36)) AS request_id
  VALUES (
    @member_id, @user_id, @geo_level, @geo_base_info_id, @legacy_geo_id, @role_name,
    N'nomination', N'submitted', @nominated_by
  );

  EXEC dbo.hwy_geo_responsibility_sync_member_area_limit
    @member_id = @member_id,
    @legacy_geo_id = @legacy_geo_id,
    @approved = 0,
    @actor_user_id = @nominated_by;

  COMMIT;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_geo_responsibility_submit_official_removal
  @member_id BIGINT,
  @user_id BIGINT = NULL,
  @geo_level NVARCHAR(32),
  @geo_base_info_id NVARCHAR(128),
  @legacy_geo_id BIGINT,
  @role_name NVARCHAR(128),
  @nominated_by BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  INSERT INTO dbo.hwy_geo_responsibility_requests (
    member_id, user_id, geo_level, geo_base_info_id, legacy_geo_id, role_name, request_kind, status, nominated_by
  )
  OUTPUT CAST(INSERTED.id AS NVARCHAR(36)) AS request_id
  VALUES (
    @member_id, @user_id, @geo_level, @geo_base_info_id, @legacy_geo_id, @role_name,
    N'official_removal', N'submitted', @nominated_by
  );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_activity_attendance_add
  @activity_id BIGINT,
  @member_id BIGINT,
  @attendance_id BIGINT,
  @legacy_created_by NVARCHAR(256)
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_members WHERE id= @member_id)
    THROW 55000, N'Member not found.', 1;

  IF EXISTS (SELECT 1 FROM dbo.hwy_activity_attendances WHERE activity_id = @activity_id AND member_id = @member_id)
    THROW 55001, N'Member is already on this activity.', 1;

  INSERT INTO dbo.hwy_activity_attendances (
    id, member_id, activity_id, legacy_created_by, created_at
  ) VALUES (
    @attendance_id, @member_id, @activity_id, @legacy_created_by, SYSUTCDATETIME()
  );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_activity_attendance_remove
  @activity_id BIGINT,
  @attendance_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  DELETE FROM dbo.hwy_activity_attendances
  WHERE id= @attendance_id AND activity_id = @activity_id;

  IF @@ROWCOUNT = 0
    THROW 55002, N'Attendance not found.', 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_course_attendance_add
  @course_id BIGINT,
  @member_id BIGINT,
  @attendance_id BIGINT,
  @note NVARCHAR(512) = NULL,
  @legacy_created_by NVARCHAR(256)
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  IF NOT EXISTS (SELECT 1 FROM dbo.hwy_members WHERE id= @member_id)
    THROW 55100, N'Member not found.', 1;

  IF EXISTS (SELECT 1 FROM dbo.hwy_course_attendances WHERE course_id = @course_id AND member_id = @member_id)
    THROW 55101, N'Member is already on this course.', 1;

  INSERT INTO dbo.hwy_course_attendances (
    id, member_id, course_id, note, legacy_created_by, created_at
  ) VALUES (
    @attendance_id, @member_id, @course_id, @note, @legacy_created_by, SYSUTCDATETIME()
  );
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_course_attendance_remove
  @course_id BIGINT,
  @attendance_id BIGINT
AS
BEGIN
  SET NOCOUNT ON;

  DELETE FROM dbo.hwy_course_attendances
  WHERE id= @attendance_id AND course_id = @course_id;

  IF @@ROWCOUNT = 0
    THROW 55102, N'Attendance not found.', 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.hwy_activity_self_announce
  @attendance_id BIGINT,
  @member_id BIGINT,
  @activity_id BIGINT,
  @nb_location_lat FLOAT = NULL,
  @nb_location_lon FLOAT = NULL,
  @selfie_file_name NVARCHAR(128),
  @selfie_mime NVARCHAR(32),
  @selfie_size_bytes INT,
  @selfie_content VARBINARY(MAX),
  @nb_device_os NVARCHAR(256) = NULL,
  @nb_device_id NVARCHAR(256) = NULL,
  @nb_device_datetime DATETIME2 = NULL,
  @legacy_created_by NVARCHAR(256)
AS
BEGIN
  SET NOCOUNT ON;
  SET XACT_ABORT ON;

  IF EXISTS (
    SELECT 1 FROM dbo.hwy_activity_attendances
    WHERE activity_id = @activity_id AND member_id = @member_id
  )
    THROW 55201, N'You are already registered for this activity.', 1;

  INSERT INTO dbo.hwy_activity_attendances (
    id, member_id, activity_id,
    nb_location_lat, nb_location_lon,
    selfie_file_name, selfie_mime, selfie_size_bytes, selfie_content,
    nb_device_os, nb_device_id, nb_device_datetime,
    legacy_created_by, created_at
  ) VALUES (
    @attendance_id, @member_id, @activity_id,
    @nb_location_lat, @nb_location_lon,
    @selfie_file_name, @selfie_mime, @selfie_size_bytes, @selfie_content,
    @nb_device_os, @nb_device_id, @nb_device_datetime,
    @legacy_created_by, SYSUTCDATETIME()
  );
END;
GO
