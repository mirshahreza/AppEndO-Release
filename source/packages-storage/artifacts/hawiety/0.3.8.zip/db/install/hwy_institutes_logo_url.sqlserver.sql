-- Optional institute logo for public self-registration chrome (URL path, not binary).
IF COL_LENGTH(N'dbo.hwy_institutes', N'logo_url') IS NULL
BEGIN
  ALTER TABLE dbo.hwy_institutes ADD logo_url NVARCHAR(4000) NULL;
END;
GO
